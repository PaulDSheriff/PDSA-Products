﻿using System;
using System.Windows;

using Sample.Project.EntityLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.ValidationLayer;
using PDSA.Validation;
using PDSA.WPF;

namespace ValidationSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void DisplayValidationRules(PDSAValidationRules rules)
    {
      lstRules.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSAValidationRule));
      lstRules.DataContext = rules;
    }

    #region Create Customer Object
    private Customer CreateNewCustomer()
    {
      Customer entity = new Customer();

      entity.Address1 = "17852 E. 17th Street";
      entity.Address2 = "Suite 205";
      entity.City = "Tustin";
      entity.CompanyName = "PDSA, Inc.";
      entity.Country = "USA";
      entity.CustomerId = 1;
      entity.EmailAddress = "PSheriff@pdsa.com";
      entity.Fax = "(714) 734-9793";
      entity.FirstName = "Paul";
      entity.InsertDate = DateTime.Now;
      entity.InsertName = "PDSA";
      entity.LastName = "Sheriff";
      entity.Phone = "(714) 734-9792";
      entity.PostalCode = "92780";
      entity.StateCode = "CA";
      entity.Title = "President";

      return entity;
    }
    #endregion

    #region Create Product Entity & Validator
    private Product CreateNewProduct()
    {
      Product prod = new Product();

      prod.ProductId = 1;
      prod.ProductName = "A New Product";
      prod.IntroductionDate = DateTime.Now;
      prod.Cost = 10;
      prod.Price = 20;
      prod.IsDiscontinued = false;

      return prod;
    }

    private ProductValidator CreateNewValidator(Product prod)
    {
      ProductValidator prodValid;

      prodValid = new ProductValidator(prod);

      // The following code would normally go into the "Validator".InitProperties() method
      PDSAProperty prop;

      prop = prodValid.Properties.GetByName(ProductValidator.ColumnNames.ProductName);
      prop.IsRequired = true;
      prop.MinLength = 6;

      prop = prodValid.Properties.GetByName(ProductValidator.ColumnNames.Cost);
      prop.MaxValue = 9999;
      prop.MinValue = 0;

      prop = prodValid.Properties.GetByName(ProductValidator.ColumnNames.Price);
      prop.MaxValue = 9999;
      prop.MinValue = 0;

      prop = prodValid.Properties.GetByName(ProductValidator.ColumnNames.IntroductionDate);
      prop.MinValue = Convert.ToDateTime("1/1/2000");
      prop.MaxValue = DateTime.Now;

      return prodValid;
    }
    #endregion

    private void btnTestRequired_Click(object sender, RoutedEventArgs e)
    {
      RequiredValidationHardCoded();
    }

    private void RequiredValidationHardCoded()
    {
      Product prod;
      ProductValidator prodValid;

      // Create ProductEntity Class
      prod = new Product();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = new ProductValidator(prod);

      // Set ProductName to empty to fail the "Required" test
      prod.ProductName = string.Empty;
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {

        DisplayValidationRules(ex.BusinessRuleMessages);

        MessageBox.Show(ex.Message);

        // You can loop thru all business rule messages if you need to
        foreach (PDSAValidationRule item in ex.BusinessRuleMessages)
        {
          System.Diagnostics.Debug.WriteLine(item.PropertyName);
          System.Diagnostics.Debug.WriteLine(item.Message);
        }
      }
    }

    private void RequiredValidation()
    {
      Product prod;
      ProductValidator prodValid;

      // Create ProductEntity Class
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);
            
      // Set Properties to Test
      prod.ProductName = string.Empty;
      prod.IntroductionDate = DateTime.MinValue;

      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnTestMin_Click(object sender, RoutedEventArgs e)
    {
      MinRequiredSample();
    }

    private void MinRequiredSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create new Product Class
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.Cost = -1;
      prod.Price = -1;
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnTestMax_Click(object sender, RoutedEventArgs e)
    {
      MaxRequiredSample();
    }

    private void MaxRequiredSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create new Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties To Test
      prod.Cost = 999999999;
      prod.Price = 999999999;
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnTestMaxLength_Click(object sender, RoutedEventArgs e)
    {
      MaxLengthSample();
    }

    private void MaxLengthSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create new Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.ProductName = "This is a very, very, very long string for a product name as we are testing the max length feature of the validation class";
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnMinLength_Click(object sender, RoutedEventArgs e)
    {
      MinLengthSample();
    }

    private void MinLengthSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create new Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.ProductName = "short";
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnCustom_Click(object sender, RoutedEventArgs e)
    {
      CustomValidationSample();
    }

    private void CustomValidationSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create new Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.IntroductionDate = DateTime.Now.AddDays(20);
      prod.Cost = 20;
      prod.Price = 10;

      // The following code must be in the ValidateCore method of the ProductValidator class in order for this code sample to work:
      //if (Entity.Price < Entity.Cost)
      //  base.Properties.BusinessRuleMessages.Add(new PDSAValidationRule("Cost", "Cost must be less than price"));

      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnTestMinDate_Click(object sender, RoutedEventArgs e)
    {
      MinDateSample();
    }

    private void MinDateSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create New Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.IntroductionDate = Convert.ToDateTime("1/1/1999");
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnTestMaxDate_Click(object sender, RoutedEventArgs e)
    {
      MaxDateSample();
    }

    private void MaxDateSample()
    {
      Product prod;
      ProductValidator prodValid;

      // Create New Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.IntroductionDate = DateTime.Now.AddDays(1);
      try
      {
        prodValid.Validate();
      }
      catch (PDSAValidationException ex)
      {
        DisplayValidationRules(ex.BusinessRuleMessages);
        MessageBox.Show(ex.Message);
      }
    }

    private void btnCheckBusinessRule_Click(object sender, RoutedEventArgs e)
    {
      CheckBusinessRuleMethod();
    }

    private void CheckBusinessRuleMethod()
    {
      Product prod;
      ProductValidator prodValid;

      // Create New Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = CreateNewValidator(prod);

      // Set Properties to Test
      prod.ProductName = string.Empty;
      prod.Cost = 20;
      prod.Price = 10;
      prod.IntroductionDate = DateTime.Now.AddDays(1);

      if (prodValid.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
      {
        MessageBox.Show("Passed");
      }
      else
      {
        DisplayValidationRules(prodValid.Properties.BusinessRuleMessages);

        MessageBox.Show("Failed" +
          Environment.NewLine + Environment.NewLine +
          prodValid.Properties.BusinessRuleMessages.ToString());
      }
    }

    private void btnCheckOneProperty_Click(object sender, RoutedEventArgs e)
    {
      Product prod;
      ProductValidator prodValid;
      PDSAProperty prop;

      // Create New Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = new ProductValidator(prod);

      // Set Properties to Test
      prod.ProductName = "";
      prod.Cost = 20;
      prod.Price = 10;
      prod.IntroductionDate = DateTime.Now.AddDays(1);

      prop = prodValid.CheckBusinessRule(ProductValidator.ColumnNames.ProductName);

      if (prop != null)
      {
        if (prop.IsValid)
          MessageBox.Show("Valid");
        else
        {
          DisplayValidationRules(prop.BusinessRuleMessages);
          MessageBox.Show(prop.BusinessRuleMessages.ToString());
        }
      }
      else
        MessageBox.Show("Can't find the property");
    }

    private void btnCheckSetAsNull_Click(object sender, RoutedEventArgs e)
    {
      Product prod;
      ProductValidator prodValid;

      // Create New Product
      prod = CreateNewProduct();
      // Create Validator Class and Pass in ProductEntity Class
      prodValid = new ProductValidator(prod);

      // Set Properties to Test
      prod.ProductName = "This is a test";
      prod.Cost = 21;
      prod.Price = 30;
      prod.IntroductionDate = Convert.ToDateTime("1/1/1990");

      prodValid.Properties.GetByName("IntroductionDate").MinValue = DateTime.MinValue;
      prodValid.Properties.GetByName("IntroductionDate").SetAsNull = true;

      if (prodValid.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
      {
        MessageBox.Show("Passed");
      }
      else
      {
        DisplayValidationRules(prodValid.Properties.BusinessRuleMessages);

        MessageBox.Show("Failed" +
          Environment.NewLine + Environment.NewLine +
          prodValid.Properties.BusinessRuleMessages.ToString());
      }
    }

    private void btnRegularExpressions_Click(object sender, RoutedEventArgs e)
    {
      RegularExpressions();
    }

    private void RegularExpressions()
    {
      Customer entity;
      CustomerValidator validator;

      // Create New Customer
      entity = CreateNewCustomer();
      // Create Validator Class and Pass in ProductEntity Class
      validator = new CustomerValidator(entity);

      // Set Properties to Test
      entity.EmailAddress = "bademail.com";
      entity.PostalCode = "00000000";
      entity.Phone = "(714)a293sksk";

      validator.Properties.GetByName("EmailAddress").RegularExpression = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
      validator.Properties.GetByName("EmailAddress").RegularExpressionMessage = "Email address is not valid.";
      validator.Properties.GetByName("PostalCode").RegularExpression = @"^\d{5}$";
      validator.Properties.GetByName("PostalCode").RegularExpressionMessage = "Postal Code format is not valid.";
      validator.Properties.GetByName("Phone").RegularExpression = @"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}";
      validator.Properties.GetByName("Phone").RegularExpressionMessage = "Phone format is not valid.";

      if (validator.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
      {
        MessageBox.Show("Passed");
      }
      else
      {
        DisplayValidationRules(validator.Properties.BusinessRuleMessages);

        MessageBox.Show("Failed" +
          Environment.NewLine + Environment.NewLine +
          validator.Properties.BusinessRuleMessages.ToString());
      }
    }

    private void btnMessagesToSpanish_Click(object sender, RoutedEventArgs e)
    {
      // The various messages that are displayed for minimum length,maximum length, etc. are all in static properties in a PDSAValidationMessages class.
      // You can modify these one time in your application to reflect a new language

      PDSAValidationMessages.BusinessRulesFailed = "Las reglas de negocio no en los  {0}";
      PDSAValidationMessages.CantConvertToType = "No se puede convertir {0} valor a los datos de tipo {0}.";
      PDSAValidationMessages.InvalidDate = "{0} es una fecha no válida. {0} debe ser una fecha válida y mayor o igual a {1} y menor o igual a {2}.";
      PDSAValidationMessages.InvalidMinMax = "{0} debe ser mayor o igual a {1} y menor o igual a {2}.";
      PDSAValidationMessages.InvalidNumericValue = "{0} es un número válido. {0} debe ser un valor numérico y mayor que o igual a {1} y menor o igual a {2}.";
      PDSAValidationMessages.MaxLength = "{0} sólo puede ser {1} caracteres.";
      PDSAValidationMessages.MaxValue = "{0} debe ser menor o igual a {1}.";
      PDSAValidationMessages.MinLength = "{0} debe ser mayor o igual a {1} caracteres.";
      PDSAValidationMessages.MinValue = "{0} debe ser mayor o igual a {1}.";
      PDSAValidationMessages.MustBeFilledIn = "{0} debe ser llenado pulg";
    }

    private void btnMessagesToEnglish_Click(object sender, RoutedEventArgs e)
    {
      // The various messages that are displayed for minimum length,maximum length, etc. are all in static properties in a PDSAValidationMessages class.
      // You can modify these one time in your application to reflect a new language

      PDSAValidationMessages.BusinessRulesFailed = "Business rules failed in {0}";
      PDSAValidationMessages.CantConvertToType = "Can't Convert Value {0) to Data Type {0}.";
      PDSAValidationMessages.InvalidDate = "{0} is an invalid date. {0} must be a valid date and greater than or equal to {1} and less than or equal to {2}.";
      PDSAValidationMessages.InvalidMinMax = "{0} must be greater than or equal to {1} and less than or equal to {2}.";
      PDSAValidationMessages.InvalidNumericValue = "{0} is an invalid number. {0} must be a numeric value and greater than or equal to {1} and less than or equal to {2}.";
      PDSAValidationMessages.MaxLength = "{0} can only be {1} characters long.";
      PDSAValidationMessages.MaxValue = "{0} must be less than or equal to {1}.";
      PDSAValidationMessages.MinLength = "{0} must be greater than or equal to {1} characters long.";
      PDSAValidationMessages.MinValue = "{0} must be greater than or equal to {1}.";
      PDSAValidationMessages.MustBeFilledIn = "{0} must be filled in.";
    }
  }
}
