Overview of this Sample
--------------------------------------
This sample shows how to use the validation system with Entity classes

Tables Used - Only need to add the Entity and Business folders
--------------------------------------------------------------
Product
Customer