Overview of this Sample
--------------------------------------
This sample shows how to use the Product Table using Dynamic SQL and Stored Procedures in one class

You need to choose "Generate Dynamic SQL?" and "Generate Stored Procedures?" options when creating the project to generate the Product table

You will need to add the stored procedures generated in the [My Documents]\Haystack\Gen\SQL\Product.sql file to your PDSASamples database