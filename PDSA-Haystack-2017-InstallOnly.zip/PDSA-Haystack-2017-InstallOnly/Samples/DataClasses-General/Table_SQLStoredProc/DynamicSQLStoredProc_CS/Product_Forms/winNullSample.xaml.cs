﻿using System;
using System.Windows;
using PDSA.Validation;

using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;

namespace DynamicSQLStoredProc
{
  /// <summary>
  /// Interaction logic for winNullSample.xaml
  /// </summary>
  public partial class winNullSample : Window
  {
    public winNullSample()
    {
      InitializeComponent();
    }

    ProductManager mgr = null;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      mgr = new ProductManager();
      ucProdInfo.DataContext = App.CreateDefaultProduct();
    }

    #region LoadByPK Methods
    private void btnLoadByPK_Click(object sender, RoutedEventArgs e)
    {
      LoadARecord();
    }

    private void LoadARecord()
    {
      try
      {
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        if (mgr.DataObject.LoadByPK(mgr.Entity.ProductId) == 1)
        {
          ucProdInfo.GetNullFlags(mgr);

          MessageBox.Show("Product Loaded");
        }
        else
          MessageBox.Show("Product Primary Key NOT Found");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Update By PK
    private void btnUpdateByPK_Click(object sender, RoutedEventArgs e)
    {
      UpdateByPK();
    }

    private void UpdateByPK()
    {
      try
      {
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;
        ucProdInfo.SetNullFlags(mgr);

        // Update the Data. 
        // Calling the Update method will update just the current record because the default UpdateFilter=PrimaryKey
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        if (mgr.DataObject.Update() == 1)
        {
          MessageBox.Show("Data Updated");
        }
        else
          MessageBox.Show("Data NOT Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Set Cost Field to Null
    private void btnSetCostNull_Click(object sender, RoutedEventArgs e)
    {
      SetCostFieldToNull();
    }

    private void SetCostFieldToNull()
    {
      try
      {
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Set the SetAsNull property on the Entity Class = true
        mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.Cost, true);
        
        // For "Nullable" data types you can set Entity to "null"
        //mgr.Entity.IsDiscontinued = null;
        
        // Update the Data. 
        // Calling the Update method will update just the current record because the default UpdateFilter=PrimaryKey
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        if (mgr.DataObject.Update() == 1)
        {
          MessageBox.Show("Data Updated");
        }
        else
          MessageBox.Show("Data NOT Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Hard Coded Null Sample
    private void HardCodedSampleSettingNull()
    {
      ProductManager mgr = new ProductManager();
      mgr.DataObject.LoadByPK(1);

      // Set Cost Column to Null
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.Cost, true);

      // Update the Data
      mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
      if (mgr.DataObject.Update() == 1)
      {
        MessageBox.Show("Data Updated");
      }
      else
        MessageBox.Show("Data NOT Updated");
    }
    #endregion

    #region Insert with Nulls Checked Sample
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertWithNulls();
    }

    private void InsertWithNulls()
    {
      try
      {
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;
        ucProdInfo.SetNullFlags(mgr);

        // Insert a new record
        if (mgr.DataObject.Insert() == 1)
        {
          MessageBox.Show("Data Inserted");
        }
        else
          MessageBox.Show("Data NOT Inserted");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion
    
    #region SetAllNullToTrueSample Method
    private void btnSetAllNullToTrue_Click(object sender, RoutedEventArgs e)
    {
      SetAllNullToTrueSample();
    }

    private void SetAllNullToTrueSample()
    {
      ProductManager mgr = new ProductManager();
      Product entity = mgr.Entity;

      try
      {
        // This will initialize all values to NULL
        // If you do not modify the properties, then NULLs will be put into the database
        // Need to use the Validator class for setting all values to null, the Entity class is evaluated before and will override the Validator.
        mgr.Validator.ResetAllSetAsNullProperties(true);

        // Only the ProductName column will be updated in the database.
        entity.ProductName = "A New One";

        mgr.DataObject.Insert();
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion

  }
}
