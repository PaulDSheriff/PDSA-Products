﻿using System;
using System.Text;
using System.Windows;

using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.BusinessLayer;
using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;

namespace DynamicSQLStoredProc
{
  /// <summary>
  /// Interaction logic for winProductMetaData.xaml
  /// </summary>
  public partial class winProductMetaData : Window
  {
    public winProductMetaData()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ucProdInfo.DataContext = App.CreateDefaultProduct();
    }

    #region AllColumns Sample
    private void btnAllColumns_Click(object sender, RoutedEventArgs e)
    {
      AllColumns();
    }

    private void AllColumns()
    {
      ProductManager mgr;
      PDSAProperty prop = new PDSAProperty();
      
      mgr = new ProductManager();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(prop.GetPropertiesAsPropertyHeaderCollection());
      lstData.DataContext = mgr.DataObject.AllColumns;
    }
    #endregion

    private void btnCheckBusinessRules_Click(object sender, RoutedEventArgs e)
    {
      CheckBusinessRules();
    }

    private void CheckBusinessRules()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.Validator.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
          MessageBox.Show("Business Rules Passed");
        else
          MessageBox.Show(mgr.Validator.Properties.BusinessRuleMessages.ToString());
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnClassName_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductManager();

      sb.Append("Entity Class Name: " + mgr.Entity.ClassName + Environment.NewLine);
      sb.Append("Manager Class Name: " + mgr.ClassName + Environment.NewLine);
      sb.Append("Data Class Name: " + mgr.DataObject.ClassName + Environment.NewLine);
      sb.Append("Validator Class Name: " + mgr.Validator.ClassName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnCommandTimeout_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Command Timeout: " + mgr.DataObject.CommandTimeout.ToString();
    }

    private void btnDBObjectName_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Data Object Name: " + mgr.DataObject.DBObjectName;
    }

    private void btnDBObjectNameOnly_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Data Object Name Only: " + mgr.DataObject.DBObjectNameOnly;
    }

    private void btnDeleteSql_Click(object sender, RoutedEventArgs e)
    {
      DeleteSql();
    }

    private void DeleteSql()
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "DELETE SQL: " + mgr.DataObject.DeleteSQL();
    }

    private void btnInsertSql_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "INSERT SQL: " + mgr.DataObject.InsertSQL();
    }

    private void btnOrderByClauseSQL_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      mgr.DataObject.OrderByFilter = ProductData.OrderByFilters.ProductName;

      txtData.Text = "ORDER BY SQL: " + mgr.DataObject.OrderByClauseSQL();
    }

    private void btnPKType_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Primary Key Type: " + mgr.DataObject.PrimaryKeyType.ToString();
    }

    private void btnPKGenerateGUID_Click(object sender, RoutedEventArgs e)
    {
      PKGenerateGuid();
    }

    private void PKGenerateGuid()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        txtData.Text = "PK Generate Guid: " + mgr.DataObject.PKGenerateGuid();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnPrimaryKeyGenerate_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "PrimaryKeyGenerate Flag: " + mgr.DataObject.PrimaryKeyGenerate.ToString();
    }

    private void btnRowCountSQL_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Row Count SQL: " + mgr.DataObject.RowCountSQL();
    }

    private void btnSchemaName_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "Schema Name: " + mgr.DataObject.SchemaName;
    }

    private void btnSelectSQL_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "SELECT SQL: " + mgr.DataObject.SelectSQL();
    }

    private void btnUpdateSQL_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      txtData.Text = "UPDATE SQL: " + mgr.DataObject.UpdateSQL();
    }

    private void btnWhereSQL_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;

      mgr = new ProductManager();

      mgr.DataObject.WhereFilter = ProductData.WhereFilters.PrimaryKey;

      txtData.Text = "WHERE SQL: " + mgr.DataObject.WhereClauseSQL();
    }

    private void btnPDSALoginName_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductManager();

      sb.Append("Entity Login Name: " + mgr.Entity.PDSALoginName + Environment.NewLine);
      sb.Append("Manager Login Name: " + mgr.PDSALoginName + Environment.NewLine);
      sb.Append("Data Login Name: " + mgr.DataObject.PDSALoginName + Environment.NewLine);
      sb.Append("Validator Login Name: " + mgr.Validator.PDSALoginName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }
  }
}
