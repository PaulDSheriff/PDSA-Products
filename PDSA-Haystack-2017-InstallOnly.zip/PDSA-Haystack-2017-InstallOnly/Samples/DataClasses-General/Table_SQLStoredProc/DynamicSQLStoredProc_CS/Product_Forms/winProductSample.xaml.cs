﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

using PDSA.Common;
using PDSA.DataLayer;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.BusinessLayer;
using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;
using Sample.Project.ValidationLayer;
 
namespace DynamicSQLStoredProc
{
  /// <summary>
  /// Interaction logic for winProductSample.xaml
  /// </summary>
  public partial class winProductSample : Window
  {
    public winProductSample()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();
      ucProdInfo.DataContext = App.CreateDefaultProduct();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(mgr.DataObject.GetColumnsAsPropertyHeaderCollection());
    }

    #region LoadByPK Methods
    private void btnLoadByPK_Click(object sender, RoutedEventArgs e)
    {
      LoadARecord();
    }

    private void LoadARecord()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        if (mgr.DataObject.LoadByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;
          ucProdInfo.GetNullFlags(mgr);

          MessageBox.Show("Product Loaded");
        }
        else
          MessageBox.Show("Product Primary Key NOT Found");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadAll Methods
    private void btnLoadAll_Click(object sender, RoutedEventArgs e)
    {
      LoadAllSample();
    }

    private void LoadAllSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        // Load all rows
        mgr.DataObject.Load();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          // Use the DataSetObject property to retrieve the rows
          lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadUsingWhere Methods
    private void btnLoadWhere_Click(object sender, RoutedEventArgs e)
    {
      LoadUsingWhere();
    }

    private void LoadUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Set a Where Filter
        mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          mgr.Entity.ProductName += new PDSADataManager().Provider.LikeOperator;
          mgr.DataObject.Load();
          tbSQL.Text = mgr.DataObject.SQL;

          if (mgr.DataObject.RowsAffected > 0)
          {
            // Use the DataSetObject property to retrieve the rows
            lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
          }
          else
            MessageBox.Show("No Records Match Search Criteria");
        }
        else
        {
          MessageBox.Show("Please fill in a Product Name before Running this Method");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataSet Methods
    private void btnGetDataSet_Click(object sender, RoutedEventArgs e)
    {
      GetDataSet();
    }

    private void GetDataSet()
    {
      ProductManager mgr;
      DataSet ds;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        ds = mgr.DataObject.GetDataSet();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataSet, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = ds.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataTable
    private void btnGetDataTable_Click(object sender, RoutedEventArgs e)
    {
      GetDataTable();
    }

    private void GetDataTable()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = dt;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataReader
    private void btnGetDataReader_Click(object sender, RoutedEventArgs e)
    {
      GetDataReader();
    }

    private void GetDataReader()
    {
      ProductManager mgr;
      ProductCollection coll = new ProductCollection();
      Product entity;
      SqlDataReader dr = null;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        dr = (SqlDataReader)mgr.DataObject.GetDataReader();
        tbSQL.Text = mgr.DataObject.SQL;

        if (dr.HasRows)
        {
          while (dr.Read())
          {
            entity = new Product();

            // Use the PDSAString.GetData() method to avoid Null values
            entity.ProductId = Convert.ToInt32(PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductId], "0"));
            entity.ProductName = PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductName], "");
            entity.Cost = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Cost], "0"));
            entity.Price = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Price], "0"));
            entity.IsDiscontinued = Convert.ToBoolean(PDSAString.GetData(dr[ProductValidator.ColumnNames.IsDiscontinued], "false"));
            entity.IntroductionDate = Convert.ToDateTime(PDSAString.GetData(dr[ProductValidator.ColumnNames.IntroductionDate], DateTime.Now.ToString()));

            coll.Add(entity);
          }
        }

        lstData.DataContext = coll;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }
    #endregion

    #region BuildCollection Methods
    private void btnBuildCollection_Click(object sender, RoutedEventArgs e)
    {
      BuildCollection();
    }

    private void BuildCollection()
    {
      ProductManager mgr;
      ProductCollection coll;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        // After the Call to BuildCollection, the RowsAffected Property is Set
        coll = mgr.BuildCollection();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = coll;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertSample();
    }

    private void InsertSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        mgr.DataObject.Insert();

        tbSQL.Text = mgr.DataObject.SQL;

        tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;

        MessageBox.Show("Data Inserted");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Update Methods
    private void btnUpdateByPK_Click(object sender, RoutedEventArgs e)
    {
      UpdateSample();
    }

    private void UpdateSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        if (Convert.ToBoolean(chkUseAudit.IsChecked))
        {
          mgr.Entity.ProductId = Convert.ToInt32(ucProdInfo.txtProductId.Text);
          // If using Audit Tracking, need to load the record from the database first
          mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
          mgr.DataObject.UseAuditTracking = true;
        }

        mgr.Entity = (Product)ucProdInfo.DataContext;
        ucProdInfo.SetNullFlags(mgr);

        // Update the Data. 
        // Calling the Update method will update just the current record because the default UpdateFilter=PrimaryKey
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        if (mgr.DataObject.Update() == 1)
        {
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
          tbSQL.Text = mgr.DataObject.SQL;

          MessageBox.Show("Data Updated");
        }
        else
          MessageBox.Show("Data NOT Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteByPK Method
    private void btnDeleteByPK_Click(object sender, RoutedEventArgs e)
    {
      DeleteSample();
    }

    private void DeleteSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        if (mgr.DataObject.DeleteByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;

          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToXml Methods
    private void btnDataRowToXml_Click(object sender, RoutedEventArgs e)
    {
      DataRowToXml();
    }

    private void DataRowToXml()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          tbAuditXml.Text = mgr.DataObject.DataSetRowToXml(0);

          MessageBox.Show("XML Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Create Entity From DataRow
    private void btnCreateEntityFromDataRow_Click(object sender, RoutedEventArgs e)
    {
      EntityFromDataRow();
    }

    private void EntityFromDataRow()
    {
      ProductManager mgr;
      Product entity;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          entity = mgr.DataObject.CreateEntityFromDataRow(dr);

          MessageBox.Show("Entity Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToProperties Sample
    private void btnDataRowToProperties_Click(object sender, RoutedEventArgs e)
    {
      DataRowToPropertiesSample();
    }

    private void DataRowToPropertiesSample()
    {
      ProductManager mgr;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          // Set the internal properties
          mgr.DataObject.DataRowToProperties(dr);

          MessageBox.Show("DataRow Put Into Properties");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount sample
    private void btnRowCount_Click(object sender, RoutedEventArgs e)
    {
      RowCountSample();
    }

    private void RowCountSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseStoredProcs = (bool)chkUseStoredProcs.IsChecked;

        MessageBox.Show("Total Record Count is " + mgr.DataObject.RowCount().ToString());
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion


    #region DeleteByPK Using Where Method
    private void btnDeleteByPKUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      DeletePKSampleWhere();
    }

    private void DeletePKSampleWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        mgr.DataObject.DeleteFilter = ProductData.DeleteFilters.DeleteByPK;
        mgr.DataObject.Delete();
        if (mgr.DataObject.RowsAffected == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;

          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteUsingWhere Methods
    private void btnDeleteUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      DeleteUsingWhere();
    }

    private void DeleteUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
        mgr.Entity.ProductName += new PDSADataManager().Provider.LikeOperator;

        mgr.DataObject.Delete();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
          MessageBox.Show("Data Deleted");
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount using WHERE sample
    private void btnRowCountUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      RowCountUsingWhere();
    }

    private void RowCountUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Set a Where Filter
        mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
          mgr.Entity.ProductName += new PDSADataManager().Provider.LikeOperator;

          MessageBox.Show("Record Count is " + mgr.DataObject.RowCount().ToString());
          tbSQL.Text = mgr.DataObject.SQL;
        }
        else
        {
          MessageBox.Show("Please fill in a Partial Product Name");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom SELECT sample
    private void btnCustomSelect_Click(object sender, RoutedEventArgs e)
    {
      CustomSelect();
    }

    private void CustomSelect()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.SelectFilter = ProductData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom WHERE sample
    private void btnCustomWhere_Click(object sender, RoutedEventArgs e)
    {
      CustomWhereSample();
    }

    private void CustomWhereSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.SelectFilter = ProductData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        mgr.DataObject.WhereFilter = ProductData.WhereFilters.Custom;
        mgr.DataObject.WhereCustom = " WHERE " + ProductValidator.ColumnNames.Price + " > 20";

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom ORDER BY sample
    private void btnCustomOrderBy_Click(object sender, RoutedEventArgs e)
    {
      CustomOrderBySample();
    }

    private void CustomOrderBySample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();


        mgr.DataObject.SelectFilter = ProductData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        mgr.DataObject.WhereFilter = ProductData.WhereFilters.Custom;
        mgr.DataObject.WhereCustom = " WHERE " + ProductValidator.ColumnNames.Price + " > 20";

        mgr.DataObject.OrderByFilter = ProductData.OrderByFilters.Custom;
        mgr.DataObject.OrderByCustom = " ORDER BY " + ProductValidator.ColumnNames.Price + " DESC";

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom INSERT sample
    private void btnCustomInsert_Click(object sender, RoutedEventArgs e)
    {
      CustomInsertSample();
    }

    private void CustomInsertSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      // IDataParameter param;
      string sql;

      sql = "INSERT INTO PDSASample.Product(ProductName) VALUES (@ProductName)";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Need to fill in some values to avoid business rule failure
        mgr.Entity.ProductName = "A New Product";
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = new PDSADataManager().Provider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        // Can use the following:
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@ProductName", DbType.String, mgr.Entity.ProductName));
        // or do the following:
        // param = new PDSADataManager().Provider.CreateParameter("@ProductName", DbType.String, "Product Name");
        // cmd.Parameters.Add(param);

        mgr.DataObject.InsertFilter = ProductData.InsertFilters.Custom;
        mgr.DataObject.InsertCustom = sql;

        mgr.DataObject.Insert();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom UPDATE Sample
    private void btnCustomUpdate_Click(object sender, RoutedEventArgs e)
    {
      CustomUpdateSample();
    }

    private void CustomUpdateSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "UPDATE PDSASample.Product SET IntroductionDate = @IntroductionDate";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = new PDSADataManager().Provider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@IntroductionDate", DbType.String, mgr.Entity.IntroductionDate));
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.Custom;
        mgr.DataObject.UpdateCustom = sql;

        mgr.DataObject.Update();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom DELETE Sample
    private void btnCustomDelete_Click(object sender, RoutedEventArgs e)
    {
      CustomDeleteSample();
    }
    
    private void CustomDeleteSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "DELETE FROM PDSASample.Product ";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);

        cmd = new PDSADataManager().Provider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.DeleteFilter = ProductData.DeleteFilters.Custom;
        mgr.DataObject.DeleteCustom = sql;

        mgr.DataObject.Delete();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GenerateException Method
    private void btnGenException_Click(object sender, RoutedEventArgs e)
    {
      GenerateException();
    }

    private void GenerateException()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "UPDATE PDSASample.Product SET InroductionDate = @IntroductionDate";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = new PDSADataManager().Provider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@IntroductionDate", DbType.String, mgr.Entity.IntroductionDate));
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.Custom;
        mgr.DataObject.UpdateCustom = sql;

        mgr.DataObject.Update();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion

    #region UseStoredProc Checked/Unchecked Events
    private void chkUseStoredProcs_Checked(object sender, RoutedEventArgs e)
    {
      grdDynamicOnly.IsEnabled = false;
    }

    private void chkUseStoredProcs_Unchecked(object sender, RoutedEventArgs e)
    {
      grdDynamicOnly.IsEnabled = true;
    }
    #endregion
  }
}