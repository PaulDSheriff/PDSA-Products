﻿using System;
using System.Windows;
using System.Windows.Threading;

using Sample.Project.EntityLayer;

namespace DynamicSQLStoredProc
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
    public static Product CreateDefaultProduct()
    {
      Product ret = new Product();

      ret.ProductId = 1;
      ret.ProductName = "Abcd";
      ret.IntroductionDate = Convert.ToDateTime("1/1/2010");
      ret.Cost = 10;
      ret.Price = 20;

      return ret;
    }

    private void Application_Startup(object sender, StartupEventArgs e)
    {
      AppDomain currentDomain = AppDomain.CurrentDomain;
      currentDomain.UnhandledException += new UnhandledExceptionEventHandler(currentDomain_UnhandledException);
      App.Current.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(App_DispatcherUnhandledException);
    }

    #region Unhandled Exception Events
    void currentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
      string msg;

      msg = "If you are getting an error message here. This means that you are most likely using a demo version of the Haystack DLLs. These DLLs will only run under Debug mode in VS.NET." + Environment.NewLine + Environment.NewLine;
      msg += ((Exception)e.ExceptionObject).Message;
      MessageBox.Show(msg);
    }

    void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
      string msg;

      msg = "If you are getting an error message here. This means that you are most likely using a demo version of the Haystack DLLs. These DLLs will only run under Debug mode in VS.NET." + Environment.NewLine + Environment.NewLine;
      msg += e.Exception.Message;
      MessageBox.Show(msg);

      // Prevent default unhandled exception processing
      e.Handled = true;
    }
    #endregion
  }
}
