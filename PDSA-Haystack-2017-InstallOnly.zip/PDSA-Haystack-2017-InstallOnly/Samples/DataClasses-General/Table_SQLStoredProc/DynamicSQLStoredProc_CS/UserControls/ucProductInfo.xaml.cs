﻿using System;
using System.Windows.Controls;
using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer; 

namespace DynamicSQLStoredProc
{
  /// <summary>
  /// Interaction logic for ucProductInfo.xaml
  /// </summary>
  public partial class ucProductInfo : UserControl
  {
    public ucProductInfo()
    {
      InitializeComponent();
    }

    public void GetNullFlags(ProductManager mgr)
    {
      chkProductIdNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.ProductId);
      chkProductNameNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.ProductName);
      chkIntroductionDateNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.IntroductionDate);
      chkCostNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.Cost);
      chkPriceNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.Price);
      chkIsDiscontinuedNull.IsChecked = mgr.Validator.Properties.WasPropertyReadInAsNull(ProductValidator.ColumnNames.IsDiscontinued);
    }
       
    public void SetNullFlags(ProductManager mgr)
    {
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.ProductId, Convert.ToBoolean(chkProductIdNull.IsChecked));
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.ProductName, Convert.ToBoolean(chkProductNameNull.IsChecked));
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.IntroductionDate, Convert.ToBoolean(chkIntroductionDateNull.IsChecked));
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.Cost, Convert.ToBoolean(chkCostNull.IsChecked));
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.Price, Convert.ToBoolean(chkPriceNull.IsChecked));
      mgr.Entity.SetAsNullFlagForProperty(ProductValidator.ColumnNames.IsDiscontinued, Convert.ToBoolean(chkIsDiscontinuedNull.IsChecked));
    }
  }
}
