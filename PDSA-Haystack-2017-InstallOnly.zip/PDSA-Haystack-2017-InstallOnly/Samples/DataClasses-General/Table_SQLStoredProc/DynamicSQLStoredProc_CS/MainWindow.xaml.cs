﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DynamicSQLStoredProc
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Product Table Samples
    private void btnProductCRUD_Click(object sender, RoutedEventArgs e)
    {
      winProductSample win = new winProductSample();

      win.Show();
    }

    private void btnProductMetaData_Click(object sender, RoutedEventArgs e)
    {
      winProductMetaData win = new winProductMetaData();

      win.Show();
    }

    private void btnWorkWithNulls_Click(object sender, RoutedEventArgs e)
    {
      winNullSample win = new winNullSample();

      win.Show();
    }
    #endregion
  }
}
