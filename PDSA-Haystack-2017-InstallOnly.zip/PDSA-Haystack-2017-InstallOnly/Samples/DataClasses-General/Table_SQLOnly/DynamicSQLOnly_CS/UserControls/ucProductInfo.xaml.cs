﻿using System.Windows.Controls;


namespace DynamicSQLOnly
{
  /// <summary>
  /// Interaction logic for ucProductInfo.xaml
  /// </summary>
  public partial class ucProductInfo : UserControl
  {
    public ucProductInfo()
    {
      InitializeComponent();
    }
  }
}
