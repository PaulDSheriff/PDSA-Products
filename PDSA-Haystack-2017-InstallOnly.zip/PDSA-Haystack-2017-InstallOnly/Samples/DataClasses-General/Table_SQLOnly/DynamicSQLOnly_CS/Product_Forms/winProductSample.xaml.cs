﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

using PDSA.Common;
using PDSA.DataLayer;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;

namespace DynamicSQLOnly
{
  public partial class winProductSample : Window
  {
    public winProductSample()
    {
      InitializeComponent();
    }

    private Product mOldEntity;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      ucProdInfo.DataContext = App.CreateDefaultProduct();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(mgr.DataObject.GetColumnsAsPropertyHeaderCollection());
    }

    #region LoadByPK Methods
    private void btnLoadByPK_Click(object sender, RoutedEventArgs e)
    {
      LoadByPKSample();
    }

    private void LoadByPKSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.DataObject.LoadByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;

          MessageBox.Show("Product Loaded");
        }
        else
          MessageBox.Show("Product Primary Key NOT Found");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadAll Methods
    private void btnLoadAll_Click(object sender, RoutedEventArgs e)
    {
      LoadAllSample();
    }

    private void LoadAllSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Load all rows
        mgr.DataObject.Load();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          // Use the DataSetObject property to retrieve the rows
          lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadUsingWhere Methods
    private void btnLoadWhere_Click(object sender, RoutedEventArgs e)
    {
      LoadUsingWhere();
    }

    private void LoadUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Set a Where Filter
        mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          mgr.Entity.ProductName += mgr.DataProvider.LikeOperator;
          mgr.DataObject.Load();
          tbSQL.Text = mgr.DataObject.SQL;

          if (mgr.DataObject.RowsAffected > 0)
          {
            // Use the DataSetObject property to retrieve the rows
            lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
          }
          else
            MessageBox.Show("No Records Match Search Criteria");
        }
        else
        {
          MessageBox.Show("Please fill in a Product Name before Running this Method");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataSet Methods
    private void btnGetDataSet_Click(object sender, RoutedEventArgs e)
    {
      GetDataSet();
    }

    private void GetDataSet()
    {
      ProductManager mgr;
      DataSet ds;

      try
      {
        mgr = new ProductManager();

        ds = mgr.DataObject.GetDataSet();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataSet, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = ds.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataTable
    private void btnGetDataTable_Click(object sender, RoutedEventArgs e)
    {
      GetDataTable();
    }

    private void GetDataTable()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = dt;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataReader
    private void btnGetDataReader_Click(object sender, RoutedEventArgs e)
    {
      GetDataReader();
    }

    private void GetDataReader()
    {
      ProductManager mgr;
      ProductCollection coll = new ProductCollection();
      Product entity;
      SqlDataReader dr = null;

      try
      {
        mgr = new ProductManager();

        dr = (SqlDataReader)mgr.DataObject.GetDataReader();
        tbSQL.Text = mgr.DataObject.SQL;

        if (dr.HasRows)
        {
          while (dr.Read())
          {
            entity = new Product();

            // Use the PDSAString.GetData() method to avoid Null values
            entity.ProductId = Convert.ToInt32(PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductId], "0"));
            entity.ProductName = PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductName], "");
            entity.Cost = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Cost], "0"));
            entity.Price = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Price], "0"));
            entity.IsDiscontinued = Convert.ToBoolean(PDSAString.GetData(dr[ProductValidator.ColumnNames.IsDiscontinued], "false"));
            entity.IntroductionDate = Convert.ToDateTime(PDSAString.GetData(dr[ProductValidator.ColumnNames.IntroductionDate], DateTime.Now.ToString()));

            coll.Add(entity);
          }
        }

        lstData.DataContext = coll;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }
    #endregion

    #region BuildCollection Methods
    private void btnBuildCollection_Click(object sender, RoutedEventArgs e)
    {
      BuildCollection();
    }

    private void BuildCollection()
    {
      ProductManager mgr;
      ProductCollection coll;

      try
      {
        mgr = new ProductManager();

        // After the Call to BuildCollection, the RowsAffected Property is Set
        coll = mgr.BuildCollection();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = coll;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertSample();
    }

    private void InsertSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        mgr.DataObject.Insert();

        // Save old entity to test out the UPDATE
        mOldEntity = mgr.Validator.CloneEntity(mgr.Entity);

        tbSQL.Text = mgr.DataObject.SQL;

        tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
        Clipboard.SetText(tbAuditXml.Text);

        MessageBox.Show("Data Inserted");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region InsertHardCoded Sample
    private void InsertSampleHardCoded()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Fill in Entity object with values
        mgr.Entity.ProductName = "A New Product";
        mgr.Entity.IntroductionDate = DateTime.Now;
        mgr.Entity.Cost = 10;
        mgr.Entity.Price = 20;
        mgr.Entity.IsDiscontinued = false;

        mgr.DataObject.Insert();

        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Data Inserted");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Update Methods
    private void btnUpdateByPK_Click(object sender, RoutedEventArgs e)
    {
      UpdateSample();
    }

    private void UpdateSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseAuditTracking = (bool)chkUseAudit.IsChecked;

        // If using Audit Tracking, need to load the record from the 
        // database prior to filling in the data to update.
        if (Convert.ToBoolean(chkUseAudit.IsChecked))
        {
          mgr.DataObject.LoadByPK(Convert.ToInt32(ucProdInfo.txtProductId.Text));
        }
        // The following code tests out setting the AuditTrackRowFromEntity method
        //if (mOldEntity != null)
        //  mgr.DataObject.SetAuditTrackRowFromEntity(mOldEntity);

        // Now update the Entity
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Update the Data. 
        // Calling the Update method will update just the current record because the default UpdateFilter=PrimaryKey
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        if (mgr.DataObject.Update() == 1)
        {
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
          tbSQL.Text = mgr.DataObject.SQL;
          Clipboard.SetText(tbAuditXml.Text);

          MessageBox.Show("Data Updated");
        }
        else
          MessageBox.Show("Data NOT Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region UpdateHardCoded Method
    private void UpdateHardCoded()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Load all fields into Entity object from table first
        mgr.DataObject.LoadByPK(1);

        // Update values in Entity that need to be updated
        mgr.Entity.ProductName += " - CHANGED";
        mgr.Entity.Cost -= 5;

        // Update the Data
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        mgr.DataObject.Update();

        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Data Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteByPK Method
    private void btnDeleteByPK_Click(object sender, RoutedEventArgs e)
    {
      DeleteSample();
    }

    private void DeleteSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);

        if (mgr.DataObject.DeleteByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
          Clipboard.SetText(tbAuditXml.Text);

          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteByPKHardCoded Method
    private void DeleteByPKHardCoded()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity.ProductId = 1;

        if (mgr.DataObject.DeleteByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;

          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted.");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteByPK Using Where Method
    private void btnDeleteByPKUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      DeletePKSampleWhere();
    }

    private void DeletePKSampleWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        mgr.DataObject.DeleteFilter = ProductData.DeleteFilters.DeleteByPK;
        mgr.DataObject.Delete();
        if (mgr.DataObject.RowsAffected == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;

          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;
          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteUsingWhere Methods
    private void btnDeleteUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      DeleteUsingWhere();
    }

    private void DeleteUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
        mgr.Entity.ProductName += mgr.DataProvider.LikeOperator;

        mgr.DataObject.Delete();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
          MessageBox.Show("Data Deleted");
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToXml Methods
    private void btnDataRowToXml_Click(object sender, RoutedEventArgs e)
    {
      DataRowToXml();
    }

    private void DataRowToXml()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          tbAuditXml.Text = mgr.DataObject.DataSetRowToXml(0);

          MessageBox.Show("XML Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Create Entity From DataRow
    private void btnCreateEntityFromDataRow_Click(object sender, RoutedEventArgs e)
    {
      EntityFromDataRow();
    }

    private void EntityFromDataRow()
    {
      ProductManager mgr;
      Product entity;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          entity = mgr.DataObject.CreateEntityFromDataRow(dr);

          MessageBox.Show("Entity Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToProperties Sample
    private void btnDataRowToProperties_Click(object sender, RoutedEventArgs e)
    {
      DataRowToPropertiesSample();
    }

    private void DataRowToPropertiesSample()
    {
      ProductManager mgr;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          // Set the internal properties
          mgr.DataObject.DataRowToProperties(dr);

          MessageBox.Show("DataRow Put Into Properties");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount sample
    private void btnRowCount_Click(object sender, RoutedEventArgs e)
    {
      RowCountSample();
    }

    private void RowCountSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        MessageBox.Show("Total Record Count is " +
           mgr.DataObject.RowCount().ToString());
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount using WHERE sample
    private void btnRowCountUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      RowCountUsingWhere();
    }

    private void RowCountUsingWhere()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          // Set a Where Filter
          mgr.DataObject.WhereFilter = ProductData.WhereFilters.LikeProductName;
          mgr.Entity.ProductName += mgr.DataProvider.LikeOperator;

          MessageBox.Show("Record Count is " + mgr.DataObject.RowCount().ToString());
          tbSQL.Text = mgr.DataObject.SQL;
        }
        else
        {
          MessageBox.Show("Please fill in a Partial Product Name");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom SELECT sample
    private void btnCustomSelect_Click(object sender, RoutedEventArgs e)
    {
      CustomSelect();
    }

    private void CustomSelect()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        lstData.DataContext = mgr.CustomSelect();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom WHERE sample
    private void btnCustomWhere_Click(object sender, RoutedEventArgs e)
    {
      CustomWhereSample();
    }

    private void CustomWhereSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        lstData.DataContext = mgr.PriceGreaterThan20();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom ORDER BY sample
    private void btnCustomOrderBy_Click(object sender, RoutedEventArgs e)
    {
      CustomOrderBySample();
    }

    private void CustomOrderBySample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.OrderByFilter = ProductData.OrderByFilters.Custom;
        mgr.DataObject.OrderByCustom = " ORDER BY " + ProductValidator.ColumnNames.Price + " DESC";

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom INSERT sample
    private void btnCustomInsert_Click(object sender, RoutedEventArgs e)
    {
      CustomInsertSample();
    }

    private void CustomInsertSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      // IDataParameter param;
      string sql;

      sql = "INSERT INTO PDSASample.Product(ProductName) VALUES (@ProductName)";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Need to fill in some values to avoid business rule failure
        mgr.Entity.ProductName = "A New Product";
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = mgr.DataProvider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        // Can use the following:
        mgr.DataObject.CommandObject.Parameters.Add(
           mgr.DataProvider.CreateParameter("@ProductName",
           DbType.String, mgr.Entity.ProductName));
        // or do the following:
        // param = mgr.DataProvider.CreateParameter("@ProductName", 
        //      DbType.String, "Product Name");
        // cmd.Parameters.Add(param);

        mgr.DataObject.InsertFilter = ProductData.InsertFilters.Custom;
        mgr.DataObject.InsertCustom = sql;

        mgr.DataObject.Insert();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom UPDATE Sample
    private void btnCustomUpdate_Click(object sender, RoutedEventArgs e)
    {
      CustomUpdateSample();
    }

    private void CustomUpdateSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "UPDATE PDSASample.Product SET IntroductionDate = @IntroductionDate";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = mgr.DataProvider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(
             mgr.DataProvider.CreateParameter("@IntroductionDate",
                 DbType.String, mgr.Entity.IntroductionDate));
        mgr.DataObject.CommandObject.Parameters.Add(
             mgr.DataProvider.CreateParameter("@ProductId",
                 DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.Custom;
        mgr.DataObject.UpdateCustom = sql;

        mgr.DataObject.Update();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom DELETE Sample
    private void btnCustomDelete_Click(object sender, RoutedEventArgs e)
    {
      CustomDeleteSample();
    }

    private void CustomDeleteSample()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "DELETE FROM PDSASample.Product ";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);

        cmd = mgr.DataProvider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(mgr.DataProvider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.DeleteFilter = ProductData.DeleteFilters.Custom;
        mgr.DataObject.DeleteCustom = sql;

        mgr.DataObject.Delete();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GenerateException Method
    private void btnGenException_Click(object sender, RoutedEventArgs e)
    {
      GenerateException();
    }

    private void GenerateException()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "UPDATE PDSASample.Product SET InroductionDate = @IntroductionDate";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = mgr.DataProvider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(mgr.DataProvider.CreateParameter("@IntroductionDate", DbType.String, mgr.Entity.IntroductionDate));
        mgr.DataObject.CommandObject.Parameters.Add(mgr.DataProvider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.Custom;
        mgr.DataObject.UpdateCustom = sql;

        mgr.DataObject.Update();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion

    #region Validate Sample
    private void btnValidate_Click(object sender, RoutedEventArgs e)
    {
      ValidateSample();
    }

    private void ValidateSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.Validate();

        MessageBox.Show("Validation Passed");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region CheckBuinessRulesSample Method
    private void btnCheckBusinessRules_Click(object sender, RoutedEventArgs e)
    {
      CheckBusinessRulesSample();
    }

    private void CheckBusinessRulesSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.DataObject.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
          MessageBox.Show("Validation Passed");
        else
          MessageBox.Show("Data is Invalid" + Environment.NewLine +
            mgr.DataObject.BusinessRuleMessages.ToString());
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Get Dataset As XML Method
    private void btnGetAsXml_Click(object sender, RoutedEventArgs e)
    {
      GetAsXmlSample();
    }

    private void GetAsXmlSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        tbAuditXml.Text = mgr.DataObject.GetDataSetAsXml(PDSA.DataLayer.DataClasses.PDSAXmlGenerationType.AttributeBased);
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Convert DataSet to Excel String
    private void btnDataSetToExcel_Click(object sender, RoutedEventArgs e)
    {
      DataSetToExcelSample();
    }

    private void DataSetToExcelSample()
    {
      ProductManager mgr;
      string excel;

      try
      {
        mgr = new ProductManager();

        excel = mgr.DataObject.GetDataSetAsExcelString();
        Clipboard.SetText(excel);
        tbAuditXml.Text = excel;
        tbSQL.Text = mgr.DataObject.SQL;

        //System.IO.File.WriteAllText(@"d:\samples\Products.xls", excel);

        MessageBox.Show("Results Posted To Clipboard. Save to a File and Open with Excel");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Search Methods
    private void btnLoadSearch_Click(object sender, RoutedEventArgs e)
    {
      LoadUsingSearchSample();
    }

    private void LoadUsingSearchSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.SelectFilter = ProductData.SelectFilters.Search;
        mgr.Entity.ProductName = "S";

        // Load all rows
        mgr.DataObject.Load();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          // Use the DataSetObject property to retrieve the rows
          lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region CheckForNull Method
    private void btnNullCheck_Click(object sender, RoutedEventArgs e)
    {
      CheckForNull();
    }

    private void CheckForNull()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.LoadByPK(1);

        // Check for null
        if (mgr.Entity.IsValueNull("Cost"))
          MessageBox.Show("Cost is null");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Search
    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      SearchSample();
    }

    private void SearchSample()
    {
      ProductManager mgr = null;

      try
      {
        mgr = new ProductManager();

        mgr.DataObject.SelectFilter = ProductData.SelectFilters.Search;
        mgr.Entity.ProductName = "a";

        lstData.DataContext = mgr.BuildCollection();
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion
  }
}