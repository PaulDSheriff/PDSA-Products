Overview of this Sample
--------------------------------------
This sample shows how to use the Product Table using Dynamic SQL

This sample also illustrates adding your own custom methods to the Manager class to use a Custom SELECT and a Custom WHERE

You need to open the ProductManager class after generating and add the following two methods:

    public ProductCollection CustomSelect()
    {
      DataObject.SelectFilter = ProductData.SelectFilters.Custom;
      DataObject.SelectCustom = "SELECT * FROM " + DataObject.DBObjectNameOnly;

      return BuildCollection();
    }

    public ProductCollection PriceGreaterThan20()
    {
      DataObject.SelectFilter = ProductData.SelectFilters.Custom;
      DataObject.SelectCustom = "SELECT * FROM " + DataObject.DBObjectNameOnly;

      DataObject.WhereFilter = ProductData.WhereFilters.Custom;
      DataObject.WhereCustom = " WHERE " + ProductValidator.ColumnNames.Price + " > 20";
      
      return BuildCollection();
    }