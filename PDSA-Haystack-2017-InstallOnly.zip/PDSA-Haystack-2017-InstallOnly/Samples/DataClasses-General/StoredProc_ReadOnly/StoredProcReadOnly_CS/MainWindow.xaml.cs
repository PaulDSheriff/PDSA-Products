﻿using System.Windows;

namespace StoredProcReadOnly
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Product Stored Proc Read-Only Input/Output Parameters Sample
    private void btnProductReadOnlyInOut_Click(object sender, RoutedEventArgs e)
    {
      winProductReadOnlyInOutSample win = new winProductReadOnlyInOutSample();

      win.Show();
    }
    #endregion

    #region Product Stored Proc Read-Only Input Parameters Sample
    private void btnProductReadOnlyInput_Click(object sender, RoutedEventArgs e)
    {
      winProductReadOnlyInputSample win = new winProductReadOnlyInputSample();

      win.Show();
    }
    #endregion

    #region AllFieldTypes Table Samples
    private void btnAllFieldsMetaData_Click(object sender, RoutedEventArgs e)
    {
      //winAllFieldsMetaData win = new winAllFieldsMetaData();

      //win.Show();
    }

    private void btnAllFields_Click(object sender, RoutedEventArgs e)
    {
      //winAllFieldsSample win = new winAllFieldsSample();

      //win.Show();
    }
    #endregion

    #region Product Stored Proc Read-Only No Parameters Sample
    private void btnProductReadOnlyNoParams_Click(object sender, RoutedEventArgs e)
    {
      winProductReadOnlySample win = new winProductReadOnlySample();

      win.Show();
    }
    #endregion
  }
}
