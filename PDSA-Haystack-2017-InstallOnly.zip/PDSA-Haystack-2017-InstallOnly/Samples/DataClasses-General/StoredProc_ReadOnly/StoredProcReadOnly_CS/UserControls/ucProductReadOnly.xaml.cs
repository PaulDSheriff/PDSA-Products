﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;

namespace StoredProcReadOnly
{
  /// <summary>
  /// Interaction logic for ucProductReadOnly.xaml
  /// </summary>
  public partial class ucProductReadOnly : UserControl
  {
    public ucProductReadOnly()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      txtProductId.Text = "1";
      txtProductName.Text = "A";
      txtCost.Text = "10";
      txtPrice.Text = "20";
      txtIntroductionDate.Text = DateTime.Now.ToShortDateString();
    }

    public int GetKey()
    {
      if (txtProductId.Text.Trim() != string.Empty)
        return Convert.ToInt32(txtProductId.Text);
      else
        return -1;
    }

    public void SetKey(int productId)
    {
      txtProductId.Text = productId.ToString();
    }

    public ProductReadOnlyInOutParams GetInfo()
    {
      ProductReadOnlyInOutParams prod = new ProductReadOnlyInOutParams();

      prod.ProductName = txtProductName.Text;
      if(txtCost.Text.Trim() != string.Empty)
        prod.Cost = Convert.ToDecimal(txtCost.Text);
      if(txtPrice.Text.Trim() != string.Empty)
        prod.Price = Convert.ToDecimal(txtPrice.Text);
      if(txtIntroductionDate.Text.Trim() != string.Empty)
        prod.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      prod.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      return prod;
    }

    public ProductReadOnlyInputParams GetInfoForInputOnly()
    {
      ProductReadOnlyInputParams prod = new ProductReadOnlyInputParams();

      prod.ProductName = txtProductName.Text;
      if (txtCost.Text.Trim() != string.Empty)
        prod.Cost = Convert.ToDecimal(txtCost.Text);
      if (txtPrice.Text.Trim() != string.Empty)
        prod.Price = Convert.ToDecimal(txtPrice.Text);
      if (txtIntroductionDate.Text.Trim() != string.Empty)
        prod.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      prod.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      return prod;
    }

    public ProductReadOnlyNoParams GetInfoForNoParams()
    {
      ProductReadOnlyNoParams prod = new ProductReadOnlyNoParams();

      prod.ProductName = txtProductName.Text;
      if (txtCost.Text.Trim() != string.Empty)
        prod.Cost = Convert.ToDecimal(txtCost.Text);
      if (txtPrice.Text.Trim() != string.Empty)
        prod.Price = Convert.ToDecimal(txtPrice.Text);
      if (txtIntroductionDate.Text.Trim() != string.Empty)
        prod.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      prod.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      return prod;
    }

    public void SetInfo(ProductReadOnlyInputParams prod)
    {
      txtProductName.Text = prod.ProductName;
      txtCost.Text = prod.Cost.ToString();
      txtPrice.Text = prod.Price.ToString();
      txtIntroductionDate.Text = prod.IntroductionDate.ToShortDateString();
      chkIsDiscontinued.IsChecked = prod.IsDiscontinued;
    }
  }
}
