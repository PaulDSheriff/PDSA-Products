﻿using System;
using System.Data;
using System.Text;
using System.Windows;

using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.WPF;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;
using Sample.Project.BusinessLayer;
 
namespace StoredProcReadOnly
{
  /// <summary>
  /// Interaction logic for winProductReadOnlySample.xaml
  /// </summary>
  public partial class winProductReadOnlySample : Window
  {
    public winProductReadOnlySample()
    {
      InitializeComponent();
    }

    #region Read Data Sample
    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      ReadOnlySample();
    }

    private void ReadOnlySample()
    {
      ProductReadOnlyNoParamsManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductReadOnlyNoParamsManager();

        dt = mgr.DataObject.GetDataTable();
        
        lstData.View = PDSAWPFListView.CreateGridViewColumns(dt);
        lstData.DataContext = dt;

        tbSQL.Text = mgr.DataObject.SQL;
        txtData.Text = "Rows Read: " + mgr.DataObject.RowsAffected.ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region AllParameters Sample
    private void btnAllParameters_Click(object sender, RoutedEventArgs e)
    {
      AllParmeters();
    }

    private void AllParmeters()
    {
      ProductReadOnlyNoParamsManager mgr;
      PDSADataParameter param = new PDSADataParameter();

      mgr = new ProductReadOnlyNoParamsManager();

      lstData.View = PDSAWPFListView.CreateGridViewColumns(param.GetPropertiesAsPropertyHeaderCollection());
      lstData.DataContext = mgr.DataObject.AllParameters;
    }
    #endregion

     private void btnClassName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductReadOnlyNoParamsManager();

      sb.Append("Entity Class Name: " + mgr.Entity.ClassName + Environment.NewLine);
      sb.Append("Manager Class Name: " + mgr.ClassName + Environment.NewLine);
      sb.Append("Data Class Name: " + mgr.DataObject.ClassName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnCommandTimeout_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;

      mgr = new ProductReadOnlyNoParamsManager();

      txtData.Text = "Command Timeout: " + mgr.DataObject.CommandTimeout.ToString();
    }

    private void btnDBObjectName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;

      mgr = new ProductReadOnlyNoParamsManager();

      txtData.Text = "Data Object Name: " + mgr.DataObject.DBObjectName;
    }

    private void btnDBObjectNameOnly_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;

      mgr = new ProductReadOnlyNoParamsManager();

      txtData.Text = "Data Object Name Only: " + mgr.DataObject.DBObjectNameOnly;
    }

    private void btnSchemaName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;

      mgr = new ProductReadOnlyNoParamsManager();

      txtData.Text = "Schema Name: " + mgr.DataObject.SchemaName;
    }

    private void btnPDSALoginName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductReadOnlyNoParamsManager();

      sb.Append("Entity Login Name: " + mgr.Entity.PDSALoginName + Environment.NewLine);
      sb.Append("Manager Login Name: " + mgr.PDSALoginName + Environment.NewLine);
      sb.Append("Data Login Name: " + mgr.DataObject.PDSALoginName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnDataToColl_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyNoParamsManager mgr;
      ProductReadOnlyNoParamsCollection coll;
      DataSet ds = new DataSet();

      mgr = new ProductReadOnlyNoParamsManager();
      ds = mgr.DataObject.GetDataSet();

      coll = mgr.BuildCollection(ds);

      lstData.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
      lstData.DataContext = coll;
    }
  }
}
