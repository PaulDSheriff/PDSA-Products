﻿using System;
using System.Data;
using System.Text;
using System.Windows;

using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.BusinessLayer;
 
namespace StoredProcReadOnly
{
  /// <summary>
  /// Interaction logic for winProductReadOnlyInOutSample.xaml
  /// </summary>
  public partial class winProductReadOnlyInOutSample : Window
  {
    public winProductReadOnlyInOutSample()
    {
      InitializeComponent();
    }

    #region Read Data Sample
    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      ReadOnlySample();
    }

    private void ReadOnlySample()
    {
      ProductReadOnlyInOutParamsManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductReadOnlyInOutParamsManager();

        mgr.Entity = ucProdInfo.GetInfo();
        mgr.Entity.ProductName += mgr.DataProvider.LikeOperator;

        dt = mgr.DataObject.GetDataTable();
        lstData.View = PDSAWPFListView.CreateGridViewColumns(dt);
        lstData.DataContext = dt;

        tbSQL.Text = mgr.DataObject.SQL;
        txtData.Text = "Rows Read: " + mgr.Entity.RowsRead.ToString();
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region AllParameters Sample
    private void btnAllParameters_Click(object sender, RoutedEventArgs e)
    {
      AllParmeters();
    }

    private void AllParmeters()
    {
      ProductReadOnlyInOutParamsManager mgr;
      PDSADataParameter param = new PDSADataParameter();

      mgr = new ProductReadOnlyInOutParamsManager();

      lstData.View = PDSAWPFListView.CreateGridViewColumns(param.GetPropertiesAsPropertyHeaderCollection());
      lstData.DataContext = mgr.DataObject.AllParameters;
    }
    #endregion

    private void btnCheckBusinessRules_Click(object sender, RoutedEventArgs e)
    {
#if VALIDATORCLASS
      CheckBusinessRules();
#else
      MessageBox.Show("Validation rules can only be checked if you generate stored proc classes with Validation. By default they are not generated with Validation.");
#endif
    }

#if VALIDATORCLASS
    private void CheckBusinessRules()
    {
      ProductReadOnlyInOutParamsManager mgr;

      try
      {
        mgr = new ProductReadOnlyInOutParamsManager();

        mgr.Entity = ucProdInfo.GetInfo();

        if (mgr.Validator.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
          MessageBox.Show("Business Rules Passed");
        else
          MessageBox.Show(mgr.Validator.Properties.BusinessRuleMessages.ToString());
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
#endif

    private void btnClassName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductReadOnlyInOutParamsManager();

      sb.Append("Entity Class Name: " + mgr.Entity.ClassName + Environment.NewLine);
      sb.Append("Manager Class Name: " + mgr.ClassName + Environment.NewLine);
      sb.Append("Data Class Name: " + mgr.DataObject.ClassName + Environment.NewLine);
      //sb.Append("Validator Class Name: " + mgr.Validator.ClassName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnCommandTimeout_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;

      mgr = new ProductReadOnlyInOutParamsManager();

      txtData.Text = "Command Timeout: " + mgr.DataObject.CommandTimeout.ToString();
    }

    private void btnDBObjectName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;

      mgr = new ProductReadOnlyInOutParamsManager();

      txtData.Text = "Data Object Name: " + mgr.DataObject.DBObjectName;
    }

    private void btnDBObjectNameOnly_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;

      mgr = new ProductReadOnlyInOutParamsManager();

      txtData.Text = "Data Object Name Only: " + mgr.DataObject.DBObjectNameOnly;
    }

    private void btnSchemaName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;

      mgr = new ProductReadOnlyInOutParamsManager();

      txtData.Text = "Schema Name: " + mgr.DataObject.SchemaName;
    }

    private void btnPDSALoginName_Click(object sender, RoutedEventArgs e)
    {
      ProductReadOnlyInOutParamsManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductReadOnlyInOutParamsManager();

      sb.Append("Entity Login Name: " + mgr.Entity.PDSALoginName + Environment.NewLine);
      sb.Append("Manager Login Name: " + mgr.PDSALoginName + Environment.NewLine);
      sb.Append("Data Login Name: " + mgr.DataObject.PDSALoginName + Environment.NewLine);
      //sb.Append("Validator Login Name: " + mgr.Validator.PDSALoginName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

  }
}
