﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RelationshipsSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnManual_Click(object sender, RoutedEventArgs e)
    {
      winCustOrdersManual win = new winCustOrdersManual();

      win.Show();
    }

    private void btnDataProvider_Click(object sender, RoutedEventArgs e)
    {
      winCustOrdersDataProvider win = new winCustOrdersDataProvider();

      win.Show();
    }
  }
}
