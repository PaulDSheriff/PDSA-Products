﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;
using Sample.Project.BusinessLayer;

namespace RelationshipsSample
{
  /// <summary>
  /// Interaction logic for winCustOrdersManual.xaml
  /// </summary>
  public partial class winCustOrdersManual : Window
  {
    public winCustOrdersManual()
    {
      InitializeComponent();
    }

    private void btnLoadCustomers_Click(object sender, RoutedEventArgs e)
    {
      CustomerManager mgr = new CustomerManager();

      lstCust.DataContext = new 
        ObservableCollection<Customer>
        (mgr.BuildCollection());
    }

    private void lstCust_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (lstCust.SelectedIndex != -1)
      {
        OrderHeaderManager mgr = new OrderHeaderManager();

        lstOrders.DataContext = 
          new ObservableCollection<OrderHeader>(
            mgr.GetOrderHeadersByFK_CustomerIdEntity(
            (Customer)lstCust.SelectedItem));
      }
    }

    private void lstOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (lstOrders.SelectedIndex != -1)
      {
        OrderLineItemManager mgr = new OrderLineItemManager();

        lstLineItems.DataContext = new ObservableCollection<OrderLineItem>(
          mgr.GetOrderLineItemsByFK_OrdersEntity(
          (OrderHeader)lstOrders.SelectedItem));
      }
      else
        lstLineItems.DataContext = null;
    }
  }
}
