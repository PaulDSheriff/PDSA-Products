Overview of this Sample
--------------------------------------
This sample uses the following tables and generated classes
- Customer
- OrderHeader
- OrderLineItem

You need to choose "Generate Dynamic SQL?" and "Generate Foreign Key Methods" options when creating the project
