﻿using System;
using System.Data;
using System.Text;
using System.Windows;

using PDSA.DataLayer.DataClasses;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;
using Sample.Project.BusinessLayer;
 
namespace StoredProcExecute
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Execute Sample
    private void btnExecute_Click(object sender, RoutedEventArgs e)
    {
      ExecuteSQLHardCoded();
      //ExecuteSQLSample();
    }

    private void ExecuteSQLSample()
    {
      ProductInsertManager mgr;

      try
      {
        mgr = new ProductInsertManager();
        
        mgr.Entity = ucProdInfo.GetInfo();

        mgr.DataObject.Execute();

        txtData.Text = "Return Value=" + mgr.Entity.RETURNVALUE.ToString();
        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Insert Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region ExecuteSQLHardCoded Method
    private void ExecuteSQLHardCoded()
    {
      ProductInsertManager mgr;

      try
      {
        mgr = new ProductInsertManager();

        mgr.Entity.ProductName = "New Product";
        mgr.Entity.IntroductionDate = DateTime.Now;
        mgr.Entity.Cost = 100;
        mgr.Entity.Price = 200;
        mgr.Entity.IsDiscontinued = false;

        mgr.DataObject.Execute();

        txtData.Text = "Return Value=" + mgr.Entity.RETURNVALUE.ToString();
        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Insert Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Execute With Output
    private void btnExecuteWithOutput_Click(object sender, RoutedEventArgs e)
    {
      ExecuteWithOutputSample();
    }

    private void ExecuteWithOutputSample()
    {
      ProductInsertWithOutputManager mgr;
      string ret;

      try
      {
        mgr = new ProductInsertWithOutputManager();
        mgr.Entity = ucProdInfo.GetInfoForOutput();

        mgr.DataObject.Execute();

        ret = "Return Value=" + mgr.Entity.RETURNVALUE.ToString() + Environment.NewLine;
        ret += "Product ID=" + mgr.Entity.ProductId.ToString() + Environment.NewLine;
        ret += "Rows Inserted=" + mgr.Entity.RowsInserted.ToString() + Environment.NewLine;

        txtData.Text = ret;
        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Insert Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }

    }
    #endregion

    #region Execute Pass Nulls
    private void btnExecutePassNulls_Click(object sender, RoutedEventArgs e)
    {
      ExecutePassNulls();
    }

    private void ExecutePassNulls()
    {
      ProductInsertManager mgr;

      try
      {
        mgr = new ProductInsertManager();

        mgr.Entity.ProductName = "New Product with Nulls";
        mgr.Entity.IntroductionDate = DateTime.Now;
        mgr.Entity.Price = 200;
        // Set cost to null
        mgr.DataObject.AllParameters.GetByName(ProductInsertData.ParameterNames.Cost).SetAsNull = true;
        mgr.Entity.IsDiscontinued = false;

        mgr.DataObject.Execute();

        txtData.Text = "Return Value=" + mgr.Entity.RETURNVALUE.ToString();
        tbSQL.Text = mgr.DataObject.SQL;

        MessageBox.Show("Insert Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region AllColumns Sample
    private void btnAllParameters_Click(object sender, RoutedEventArgs e)
    {
      AllParameters();
    }

    private void AllParameters()
    {
      ProductInsertManager mgr;
      PDSADataParameter param = new PDSADataParameter();

      mgr = new ProductInsertManager();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(param.GetPropertiesAsPropertyHeaderCollection());
      lstData.DataContext = mgr.DataObject.AllParameters;
      tbSQL.Text = mgr.DataObject.SQL;
    }
    #endregion

    private void btnCheckBusinessRules_Click(object sender, RoutedEventArgs e)
    {
      CheckBusinessRules();
    }

    private void CheckBusinessRules()
    {
      ProductInsertManager mgr;

      try
      {
        mgr = new ProductInsertManager();

        mgr.Entity = ucProdInfo.GetInfo();

        if (mgr.Validator.CheckBusinessRules() == PDSAValidationRuleStatus.Passed)
          MessageBox.Show("Business Rules Passed");
        else
          MessageBox.Show(mgr.Validator.Properties.BusinessRuleMessages.ToString());
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnClassName_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductInsertManager();

      sb.Append("Entity Class Name: " + mgr.Entity.ClassName + Environment.NewLine);
      sb.Append("Manager Class Name: " + mgr.ClassName + Environment.NewLine);
      sb.Append("Data Class Name: " + mgr.DataObject.ClassName + Environment.NewLine);
      //sb.Append("Validator Class Name: " + mgr.Validator.ClassName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnCommandTimeout_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;

      mgr = new ProductInsertManager();

      txtData.Text = "Command Timeout: " + mgr.DataObject.CommandTimeout.ToString();
    }

    private void btnDBObjectName_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;

      mgr = new ProductInsertManager();

      txtData.Text = "Data Object Name: " + mgr.DataObject.DBObjectName;
    }

    private void btnDBObjectNameOnly_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;

      mgr = new ProductInsertManager();

      txtData.Text = "Data Object Name Only: " + mgr.DataObject.DBObjectNameOnly;
    }

    private void btnSchemaName_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;

      mgr = new ProductInsertManager();

      txtData.Text = "Schema Name: " + mgr.DataObject.SchemaName;
    }

    private void btnPDSALoginName_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new ProductInsertManager();

      sb.Append("Entity Login Name: " + mgr.Entity.PDSALoginName + Environment.NewLine);
      sb.Append("Manager Login Name: " + mgr.PDSALoginName + Environment.NewLine);
      sb.Append("Data Login Name: " + mgr.DataObject.PDSALoginName + Environment.NewLine);
      //sb.Append("Validator Login Name: " + mgr.Validator.PDSALoginName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnBuildExec_Click(object sender, RoutedEventArgs e)
    {
      ProductInsertManager mgr;
      
      mgr = new ProductInsertManager();
      mgr.Entity.ProductName = "Hello There";
      mgr.Entity.Cost = 100;
      mgr.Entity.Price = 200;


      txtData.Text = mgr.DataObject.BuildExecCall();
    }
  }
}
