﻿using System;
using System.Windows;
using System.Windows.Controls;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;

namespace StoredProcExecute
{
  public partial class ucProductInsertInfo : UserControl
  {
    public ucProductInsertInfo()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      txtProductId.Text = "1";
      txtProductName.Text = "A New Product";
      txtCost.Text = "10";
      txtPrice.Text = "20";
      txtIntroductionDate.Text = DateTime.Now.ToShortDateString();
    }

    public int GetKey()
    {
      if (txtProductId.Text.Trim() != string.Empty)
        return Convert.ToInt32(txtProductId.Text);
      else
        return -1;
    }

    public void SetKey(int productId)
    {
      txtProductId.Text = productId.ToString();
    }

    public ProductInsert GetInfo()
    {
      ProductInsert prod = new ProductInsert();

      prod.ProductName = txtProductName.Text;
      if (txtCost.Text.Trim() != string.Empty)
        prod.Cost = Convert.ToDecimal(txtCost.Text);
      if (txtPrice.Text.Trim() != string.Empty)
        prod.Price = Convert.ToDecimal(txtPrice.Text);
      if (txtIntroductionDate.Text.Trim() != string.Empty)
        prod.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      prod.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      return prod;
    }

    public ProductInsertWithOutput GetInfoForOutput()
    {
      ProductInsertWithOutput prod = new ProductInsertWithOutput();

      prod.ProductName = txtProductName.Text;
      if (txtCost.Text.Trim() != string.Empty)
        prod.Cost = Convert.ToDecimal(txtCost.Text);
      if (txtPrice.Text.Trim() != string.Empty)
        prod.Price = Convert.ToDecimal(txtPrice.Text);
      if (txtIntroductionDate.Text.Trim() != string.Empty)
        prod.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      prod.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      return prod;
    }

    public void SetInfo(ProductInsert prod)
    {
      txtProductName.Text = prod.ProductName;
      txtCost.Text = prod.Cost.ToString();
      txtPrice.Text = prod.Price.ToString();
      txtIntroductionDate.Text = prod.IntroductionDate.ToShortDateString();
      chkIsDiscontinued.IsChecked = prod.IsDiscontinued;
    }
  }
}
