using System;
using System.Data;
using System.Diagnostics;

using PDSA;
using PDSA.Common;
using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.DataLayer;

namespace Sample.Project.BusinessLayer
{
  /// <summary>
  /// This class is used to call the stored procedure ProductInsert
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// You may add additional methods to this class.
  /// </summary>
  public partial class ProductInsertManager
  {
    #region Your Custom Properties and Methods
    
    #endregion
  }
}

