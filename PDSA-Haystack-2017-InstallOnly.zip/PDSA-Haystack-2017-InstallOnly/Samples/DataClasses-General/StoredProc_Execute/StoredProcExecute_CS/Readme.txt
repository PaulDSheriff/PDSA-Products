Overview of this Sample
--------------------------------------
This sample shows how to use stored proc classes

Stored Procs Used From PDSASamples Database
--------------------------------------------
ProductInsert
ProductInsertWithOutput