﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

using PDSA.Common;
using PDSA.DataLayer;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.ValidationLayer;

namespace StoredProcOnly
{
  /// <summary>
  /// Interaction logic for winProductSample.xaml
  /// </summary>
  public partial class winProductSample : Window
  {
    public winProductSample()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();
      ucProdInfo.DataContext = App.CreateDefaultProduct();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(mgr.DataObject.GetColumnsAsPropertyHeaderCollection());
    }

    #region LoadByPK Methods
    private void btnLoadByPK_Click(object sender, RoutedEventArgs e)
    {
      LoadARecord();
    }

    private void LoadARecord()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        if (mgr.DataObject.LoadByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;

          MessageBox.Show("Product Loaded");
        }
        else
          MessageBox.Show("Product Primary Key NOT Found");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadAll Methods
    private void btnLoadAll_Click(object sender, RoutedEventArgs e)
    {
      LoadAllSample();
    }

    private void LoadAllSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        // Load all rows
        mgr.DataObject.Load();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          // Use the DataSetObject property to retrieve the rows
          lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataSet Methods
    private void btnGetDataSet_Click(object sender, RoutedEventArgs e)
    {
      GetDataSet();
    }

    private void GetDataSet()
    {
      ProductManager mgr;
      DataSet ds;

      try
      {
        mgr = new ProductManager();

        ds = mgr.DataObject.GetDataSet();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataSet, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = ds.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataTable
    private void btnGetDataTable_Click(object sender, RoutedEventArgs e)
    {
      GetDataTable();
    }

    private void GetDataTable()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = dt;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataReader
    private void btnGetDataReader_Click(object sender, RoutedEventArgs e)
    {
      GetDataReader();
    }

    private void GetDataReader()
    {
      ProductManager mgr;
      ProductCollection coll = new ProductCollection();
      Product entity;
      SqlDataReader dr = null;

      try
      {
        mgr = new ProductManager();

        dr = (SqlDataReader)mgr.DataObject.GetDataReader();
        tbSQL.Text = mgr.DataObject.SQL;

        if (dr.HasRows)
        {
          while (dr.Read())
          {
            entity = new Product();

            // Use the PDSAString.GetData() method to avoid Null values
            entity.ProductId = Convert.ToInt32(PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductId], "0"));
            entity.ProductName = PDSAString.GetData(dr[ProductValidator.ColumnNames.ProductName], "");
            entity.Cost = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Cost], "0"));
            entity.Price = Convert.ToDecimal(PDSAString.GetData(dr[ProductValidator.ColumnNames.Price], "0"));
            entity.IsDiscontinued = Convert.ToBoolean(PDSAString.GetData(dr[ProductValidator.ColumnNames.IsDiscontinued], "false"));
            entity.IntroductionDate = Convert.ToDateTime(PDSAString.GetData(dr[ProductValidator.ColumnNames.IntroductionDate], DateTime.Now.ToString()));

            coll.Add(entity);
          }
        }

        lstData.DataContext = coll;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }
    #endregion

    #region BuildCollection Methods
    private void btnBuildCollection_Click(object sender, RoutedEventArgs e)
    {
      BuildCollection();
    }

    private void BuildCollection()
    {
      ProductManager mgr;
      ProductCollection coll;

      try
      {
        mgr = new ProductManager();

        // After the Call to BuildCollection, the RowsAffected Property is Set
        coll = mgr.BuildCollection();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = coll;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertSample();
    }

    private void InsertSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        mgr.Entity = (Product)ucProdInfo.DataContext;
        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        mgr.DataObject.Insert();

        tbSQL.Text = mgr.DataObject.SQL;
        tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;

        MessageBox.Show("Data Inserted");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Update Methods
    private void btnUpdateByPK_Click(object sender, RoutedEventArgs e)
    {
      UpdateSample();
    }

    private void UpdateSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.DataObject.UseAuditTracking = (bool)chkUseAudit.IsChecked;
        if (Convert.ToBoolean(chkUseAudit.IsChecked))
        {
          // If using Audit Tracking, need to load the record from the database first
          mgr.DataObject.LoadByPK(Convert.ToInt32(ucProdInfo.txtProductId.Text));
        }

        // Now get the new data to update
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // Update the Data. 
        // Calling the Update method will update just the current record because the default UpdateFilter=PrimaryKey
        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.PrimaryKey;
        if (mgr.DataObject.Update() == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;

          MessageBox.Show("Data Updated");
        }
        else
          MessageBox.Show("Data NOT Updated");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DeleteByPK Method
    private void btnDeleteByPK_Click(object sender, RoutedEventArgs e)
    {
      DeleteSample();
    }

    private void DeleteSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.UseAuditTracking = Convert.ToBoolean(chkUseAudit.IsChecked);
        if (mgr.DataObject.DeleteByPK(mgr.Entity.ProductId) == 1)
        {
          tbSQL.Text = mgr.DataObject.SQL;
          tbAuditXml.Text = mgr.DataObject.AuditRowAsXml;

          MessageBox.Show("Data Deleted");
        }
        else
          MessageBox.Show("Data NOT Deleted");
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToXml Methods
    private void btnDataRowToXml_Click(object sender, RoutedEventArgs e)
    {
      DataRowToXml();
    }

    private void DataRowToXml()
    {
      ProductManager mgr;
      DataTable dt;

      try
      {
        mgr = new ProductManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          tbAuditXml.Text = mgr.DataObject.DataSetRowToXml(1);

          MessageBox.Show("XML Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Create Entity From DataRow
    private void btnCreateEntityFromDataRow_Click(object sender, RoutedEventArgs e)
    {
      EntityFromDataRow();
    }

    private void EntityFromDataRow()
    {
      ProductManager mgr;
      Product entity;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          entity = mgr.DataObject.CreateEntityFromDataRow(dr);

          MessageBox.Show("Entity Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToProperties Sample
    private void btnDataRowToProperties_Click(object sender, RoutedEventArgs e)
    {
      DataRowToPropertiesSample();
    }

    private void DataRowToPropertiesSample()
    {
      ProductManager mgr;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          // Set the internal properties
          mgr.DataObject.DataRowToProperties(dr);

          MessageBox.Show("DataRow Put Into Properties");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount sample
    private void btnRowCount_Click(object sender, RoutedEventArgs e)
    {
      RowCountSample();
    }

    private void RowCountSample()
    {
      ProductManager mgr;

      try
      {
        mgr = new ProductManager();

        MessageBox.Show("Total Record Count is " + mgr.DataObject.RowCount().ToString());
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GenerateException Method
    private void btnGenException_Click(object sender, RoutedEventArgs e)
    {
      GenerateException();
    }

    private void GenerateException()
    {
      ProductManager mgr;
      IDbCommand cmd;
      string sql;

      sql = "UPDATE PDSASample.Product SET InroductionDate = @IntroductionDate";
      sql += " WHERE ProductId = @ProductId";

      try
      {
        mgr = new ProductManager();
        mgr.Entity = (Product)ucProdInfo.DataContext;

        mgr.DataObject.LoadByPK(mgr.Entity.ProductId);
        mgr.Entity.IntroductionDate = DateTime.Now;

        cmd = new PDSADataManager().Provider.CreateCommand();
        mgr.DataObject.CommandObject = cmd;
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@IntroductionDate", DbType.String, mgr.Entity.IntroductionDate));
        mgr.DataObject.CommandObject.Parameters.Add(new PDSADataManager().Provider.CreateParameter("@ProductId", DbType.Int32, mgr.Entity.ProductId));

        mgr.DataObject.UpdateFilter = ProductData.UpdateFilters.Custom;
        mgr.DataObject.UpdateCustom = sql;

        mgr.DataObject.Update();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion
  }
}