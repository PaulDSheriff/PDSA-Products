Overview of this Sample
--------------------------------------
This sample shows how to use the Product Table using Stored Procedures only

You need to choose "Generate Stored Procedures?" option only when creating the project to generate the Product table

You will need to add the stored procedures generated in the Product.sql file to your PDSASamples database