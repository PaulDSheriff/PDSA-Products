﻿using System.Windows;

namespace StoredProcOnly
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Product Table Samples
    private void btnProductCRUD_Click(object sender, RoutedEventArgs e)
    {
      winProductSample win = new winProductSample();

      win.Show();
    }

    private void btnProductMetaData_Click(object sender, RoutedEventArgs e)
    {
      winProductMetaData win = new winProductMetaData();

      win.Show();
    }
    #endregion
  }
}
