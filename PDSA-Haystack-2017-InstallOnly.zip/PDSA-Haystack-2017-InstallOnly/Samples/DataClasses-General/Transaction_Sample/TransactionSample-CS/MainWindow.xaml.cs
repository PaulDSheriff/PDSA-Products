using System;
using System.Windows;
using System.Collections.Generic;

using PDSA.DataLayer.DataClasses;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;

namespace TransactionSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Product Objects
    private Product _Product1 = new Product();
    private Product _Product2 = new Product();
    #endregion

    #region Order / Order Line Item Objects
    private OrderHeader _OrderHeader = new OrderHeader();
    private OrderLineItem _OrderLine1 = new OrderLineItem();
    private OrderLineItem _OrderLine2 = new OrderLineItem();
    #endregion

    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _Product1 = App.CreateDefaultProduct();
      _Product2 = App.CreateDefaultProduct();

      _Product1.ProductName += " 1";
      _Product2.ProductName += " 2";
      _Product2.Cost *= 2;
      _Product2.Price *= 2;
      _Product2.IntroductionDate = DateTime.Now;

      Product1.DataContext = _Product1;
      Product2.DataContext = _Product2;

      // Set Order Header Info
      _OrderHeader.CustomerId = 1;
      _OrderHeader.OrderDate = DateTime.Now;
      _OrderHeader.Notes = "Please deliver to back door.";
      orderDetailUC.grdHeader.DataContext = _OrderHeader;
      // Set Order Line Item 1 Info
      _OrderLine1.ProductName = "1st product";
      _OrderLine1.UnitPrice = 10;
      _OrderLine1.Quantity = 1;
      orderDetailUC.grdLine1.DataContext = _OrderLine1;
      // Set Order Line Item 2 Info
      _OrderLine2.ProductName = "2nd product";
      _OrderLine2.UnitPrice = 20;
      _OrderLine2.Quantity = 2;
      orderDetailUC.grdLine2.DataContext = _OrderLine2;
    }
    #endregion

    #region Two Inserts
    private void btnTwoInserts_Click(object sender, RoutedEventArgs e)
    {
      ProductManager prodMgr1 = new ProductManager();
      ProductManager prodMgr2 = new ProductManager();
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      prodMgr2.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prodMgr1.Entity = (Product)Product1.DataContext;
        prodMgr2.Entity = (Product)Product2.DataContext;

        prodMgr1.DataObject.TransactionType = PDSATransactionType.Insert;
        prodMgr2.DataObject.TransactionType = PDSATransactionType.Insert;

        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Insert Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {        
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Two Updates
    private void btnTwoUpdates_Click(object sender, RoutedEventArgs e)
    {
      ProductManager prodMgr1 = new ProductManager();
      ProductManager prodMgr2 = new ProductManager();
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      prodMgr2.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prodMgr1.Entity = (Product)Product1.DataContext;
        prodMgr2.Entity = (Product)Product2.DataContext;

        prodMgr1.DataObject.TransactionType = PDSATransactionType.Update;
        prodMgr2.DataObject.TransactionType = PDSATransactionType.Update;

        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Update Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Two Deletes
    private void btnTwoDeletes_Click(object sender, RoutedEventArgs e)
    {
      ProductManager prodMgr1 = new ProductManager();
      ProductManager prodMgr2 = new ProductManager();
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      prodMgr2.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prodMgr1.Entity = (Product)Product1.DataContext;
        prodMgr2.Entity = (Product)Product2.DataContext;

        prodMgr1.DataObject.TransactionType = PDSATransactionType.Delete;
        prodMgr2.DataObject.TransactionType = PDSATransactionType.Delete;

        // When doing a delete, you must set the DeleteFilter when using Stored Procs
        if (prodMgr1.DataObject.UseStoredProcs)
          prodMgr1.DataObject.DeleteFilter = ProductData.DeleteFilters.DeleteByPK;
        else
          prodMgr1.DataObject.WhereFilter = ProductData.WhereFilters.PrimaryKey;
        if (prodMgr2.DataObject.UseStoredProcs)
          prodMgr2.DataObject.DeleteFilter = ProductData.DeleteFilters.DeleteByPK;
        else
          prodMgr2.DataObject.WhereFilter = ProductData.WhereFilters.PrimaryKey;

        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Delete Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Insert and Update
    private void btnInsertUpdate_Click(object sender, RoutedEventArgs e)
    {
      ProductManager prodMgr1 = new ProductManager();
      ProductManager prodMgr2 = new ProductManager();
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      prodMgr2.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prodMgr1.Entity = (Product)Product1.DataContext;
        prodMgr2.Entity = (Product)Product2.DataContext;

        prodMgr1.DataObject.TransactionType = PDSATransactionType.Insert;
        prodMgr2.DataObject.TransactionType = PDSATransactionType.Update;


        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Insert / Update Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Data Class and Stored Procedure
    private void btnDataClassStoredProc_Click(object sender, RoutedEventArgs e)
    {
      ProductManager prodMgr1 = new ProductManager();
      Product_InsertManager prodMgr2 = new Product_InsertManager();
      Product prod;
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prodMgr1.Entity = (Product)Product1.DataContext;
        prod = (Product)Product2.DataContext;
        prodMgr2.Entity.ProductName = prod.ProductName;
        prodMgr2.Entity.IsDiscontinued = prod.IsDiscontinued;
        prodMgr2.Entity.IntroductionDate = prod.IntroductionDate;
        prodMgr2.Entity.Price = prod.Price;
        prodMgr2.Entity.Cost = prod.Cost;        

        prodMgr1.DataObject.TransactionType = PDSATransactionType.Insert;
        
        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Insert DataClass/Stored Proc Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Order / Order Line Items Transaction Methods
    private PDSATransaction _OrderTran;
    private int _OrderId = 0;

    private void btnSubmitOrder_Click(object sender, RoutedEventArgs e)
    {
      InsertOrder();
    }

    private void InsertOrder()
    {
      OrderHeaderManager headerMgr = new OrderHeaderManager();
      OrderLineItemManager lineMgr1 = new OrderLineItemManager();
      OrderLineItemManager lineMgr2 = new OrderLineItemManager();

      _OrderTran = new PDSATransaction();

      _OrderTran.BeforeSubmit += new PDSATransaction.BeforeSubmitEventHandler(OrderTran_BeforeSubmit);
      _OrderTran.AfterSubmit += new PDSATransaction.AfterSubmitEventHandler(OrderTran_AfterSubmit);

      try
      {
        headerMgr.Entity = _OrderHeader;
        lineMgr1.Entity = _OrderLine1;
        lineMgr2.Entity = _OrderLine2;

        _OrderTran.Add(headerMgr.DataObject);
        _OrderTran.Add(lineMgr1.DataObject);
        _OrderTran.Add(lineMgr2.DataObject);
        _OrderTran.Execute();

        MessageBox.Show("Inserting Order/Line Items in Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }

    void OrderTran_AfterSubmit(object sender, PDSATransactionEventArgs e)
    {
      // Get the SQL Identity generated and store into local variable
      if (e.ClassName == "OrderHeaderData")        
        _OrderId = ((OrderHeader)e.DataClassTable.EntityObject).OrderId;
    }

    void OrderTran_BeforeSubmit(object sender, PDSATransactionEventArgs e)
    {
      // Put local order id into line item objects prior to submitting INSERT statement
      if (e.ClassName == "OrderLineItemData")
        ((OrderLineItem)e.DataClassTable.EntityObject).OrderId = _OrderId;
    }

    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion

    #region Stored Procs Only Sample
    private void btnTwoStoredProcs_Click(object sender, RoutedEventArgs e)
    {
      TwoStoredProcsOnly();
    }

    private void TwoStoredProcsOnly()
    {
      Product_InsertManager prodMgr1 = new Product_InsertManager();
      Product_InsertManager prodMgr2 = new Product_InsertManager();
      Product prod;
      PDSATransaction tran;

      prodMgr1.DataObject.UseStoredProcs = chkUseStoredProcs.IsChecked.Value;
      try
      {
        prod = (Product)Product1.DataContext;
        prodMgr1.Entity.ProductName = prod.ProductName;
        prodMgr1.Entity.IsDiscontinued = prod.IsDiscontinued;
        prodMgr1.Entity.IntroductionDate = prod.IntroductionDate;
        prodMgr1.Entity.Price = prod.Price;
        prodMgr1.Entity.Cost = prod.Cost;
                
        prod = (Product)Product2.DataContext;
        prodMgr2.Entity.ProductName = prod.ProductName;
        prodMgr2.Entity.IsDiscontinued = prod.IsDiscontinued;
        prodMgr2.Entity.IntroductionDate = prod.IntroductionDate;
        prodMgr2.Entity.Price = prod.Price;
        prodMgr2.Entity.Cost = prod.Cost;

        tran = new PDSATransaction();
        tran.Add(prodMgr1.DataObject);
        tran.Add(prodMgr2.DataObject);
        tran.Execute();

        MessageBox.Show("Insert 2 Stored Procs Transaction Successful");
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.ToString());
      }
      catch (PDSATransactionException ex)
      {
        DisplayException(ex);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion
  }
}
