using System;

using PDSA.Validation;

using Sample.Project.EntityLayer;

namespace Sample.Project.ValidationLayer
{
  /// <summary>
  /// Used to validate all parameters of the Product_Insert class.
  /// This class is generated using the Haystack Code Generator for .NET.
  /// You should NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class Product_InsertValidator : PDSAValidatorBase
  {
    #region Public Entity Property
    /// <summary>
    /// Get/Set the Entity class with the properties to validate
    /// </summary>
    private Product_Insert _Entity = null;

    /// <summary>
    /// Get/Set the Entity class with the properties to validate
    /// </summary>
    public new Product_Insert Entity
    {
      get { return _Entity; }
      set
      {
        _Entity = value;
        base.Entity = value;
      }
    }
    #endregion
    
    #region Clone Entity Class
    /// <summary>
    /// Clones the current Product_Insert
    /// </summary>
    /// <returns>A cloned Product_Insert object</returns>
    public Product_Insert CloneEntity()
    {
      return CloneEntity(this.Entity);
    }
    
    /// <summary>
    /// Clones the passed in Product_Insert
    /// </summary>
    /// <param name="entityToClone">The Product_Insert entity to clone</param>
    /// <returns>A cloned Product_Insert object</returns>
    public Product_Insert CloneEntity(Product_Insert entityToClone)
    {
      Product_Insert newEntity = new Product_Insert();


      return newEntity;
    }
    #endregion

    #region CreateProperties Method
    /// <summary>
    /// Creates the collection of PDSAProperty objects. These are used to control validation and null handling.
    /// </summary>
    /// <returns>A collection of PDSAProperty objects</returns>
    public override PDSAProperties CreateProperties()
    {
      PDSAProperties props = new PDSAProperties();
      
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.ProductName, GetResourceMessage("PDSASample_Product_Insert_ProductName_Header", "Product Name"), false, typeof(string), 8000, GetResourceMessage("PDSASample_Product_Insert_ProductName_Req", PDSAValidationMessages.MustBeFilledIn), null, null, 0, string.Empty, @"", ""));
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.IntroductionDate, GetResourceMessage("PDSASample_Product_Insert_IntroductionDate_Header", "Introduction Date"), false, typeof(DateTime), 0, GetResourceMessage("PDSASample_Product_Insert_IntroductionDate_Req", PDSAValidationMessages.MustBeFilledIn), Convert.ToDateTime("1753-01-01 00:00:00", System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat), Convert.ToDateTime("9999-12-31 23:59:59", System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat), 0, Convert.ToDateTime("1753-1-1", System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat), @"", ""));
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.Cost, GetResourceMessage("PDSASample_Product_Insert_Cost_Header", "Cost"), false, typeof(decimal), 0, GetResourceMessage("PDSASample_Product_Insert_Cost_Req", PDSAValidationMessages.MustBeFilledIn), Convert.ToDecimal("-79228162514264337593543950335"), Convert.ToDecimal("79228162514264337593543950335"), 0, 0, @"", ""));
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.Price, GetResourceMessage("PDSASample_Product_Insert_Price_Header", "Price"), false, typeof(decimal), 0, GetResourceMessage("PDSASample_Product_Insert_Price_Req", PDSAValidationMessages.MustBeFilledIn), Convert.ToDecimal("-79228162514264337593543950335"), Convert.ToDecimal("79228162514264337593543950335"), 0, 0, @"", ""));
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.IsDiscontinued, GetResourceMessage("PDSASample_Product_Insert_IsDiscontinued_Header", "Is Discontinued"), false, typeof(bool?), 0, GetResourceMessage("PDSASample_Product_Insert_IsDiscontinued_Req", PDSAValidationMessages.MustBeFilledIn), null, null, 0, null, @"", ""));
      props.Add(PDSAProperty.Create(Product_InsertValidator.ParameterNames.RETURNVALUE, GetResourceMessage("PDSASample_Product_Insert_RETURNVALUE_Header", "return value"), false, typeof(int), 0, GetResourceMessage("PDSASample_Product_Insert_RETURNVALUE_Req", PDSAValidationMessages.MustBeFilledIn), Convert.ToInt32("-2147483648"), Convert.ToInt32("2147483647"), 0, 0, @"", ""));
      
      return props;
    }
    #endregion
    
    #region InitProperties Method
    /// <summary>
    /// Called by the constructor to create the PDSAProperties collection of all properties that will be validated.
    /// </summary>
    protected override void InitProperties()
    {
      // Set the Properties collection to the collection of Entity Properties
      Properties = CreateProperties();
    }
    #endregion

    #region EntityDataToProperties Method
    /// <summary>
    /// Moves the Entity class data into the Properties collection.
    /// </summary>
    protected override void EntityDataToProperties()
    {
      if (Properties == null)
      {
        InitProperties();
      }
      
      Properties.GetByName(Product_InsertValidator.ParameterNames.ProductName).Value = Entity.ProductName;
      Properties.GetByName(Product_InsertValidator.ParameterNames.IntroductionDate).Value = Entity.IntroductionDate;
      Properties.GetByName(Product_InsertValidator.ParameterNames.Cost).Value = Entity.Cost;
      Properties.GetByName(Product_InsertValidator.ParameterNames.Price).Value = Entity.Price;
      Properties.GetByName(Product_InsertValidator.ParameterNames.IsDiscontinued).Value = Entity.IsDiscontinued;
      Properties.GetByName(Product_InsertValidator.ParameterNames.RETURNVALUE).Value = Entity.RETURNVALUE;
    }

    /// <summary>
    /// Moves the Properties collection objects into the Entity properties
    /// </summary>
    protected override void PropertiesToEntityData()
    {
      if (Properties == null)
      {
        InitProperties();
      }

      if(Properties.GetByName(Product_InsertValidator.ParameterNames.ProductName).IsNull == false)
        Entity.ProductName = Properties.GetByName(Product_InsertValidator.ParameterNames.ProductName).GetAsString();
      if(Properties.GetByName(Product_InsertValidator.ParameterNames.IntroductionDate).IsNull == false)
        Entity.IntroductionDate = Properties.GetByName(Product_InsertValidator.ParameterNames.IntroductionDate).GetAsDate();
      if(Properties.GetByName(Product_InsertValidator.ParameterNames.Cost).IsNull == false)
        Entity.Cost = Properties.GetByName(Product_InsertValidator.ParameterNames.Cost).GetAsDecimal();
      if(Properties.GetByName(Product_InsertValidator.ParameterNames.Price).IsNull == false)
        Entity.Price = Properties.GetByName(Product_InsertValidator.ParameterNames.Price).GetAsDecimal();
      if(Properties.GetByName(Product_InsertValidator.ParameterNames.IsDiscontinued).IsNull == false)
        Entity.IsDiscontinued = Properties.GetByName(Product_InsertValidator.ParameterNames.IsDiscontinued).GetValueAsBoolean();
      if(Properties.GetByName(Product_InsertValidator.ParameterNames.RETURNVALUE).IsNull == false)
        Entity.RETURNVALUE = Properties.GetByName(Product_InsertValidator.ParameterNames.RETURNVALUE).GetAsInteger();
    }
    #endregion

    #region ParameterNames Class
    /// <summary>
    /// Contains static string properties that represent the name of each property in the Product_Insert class.
    /// This class is generated by the Haystack Code Generator for .NET.
    /// Do not modify this class or add methods as it is intended to be able to be re-generated at any time.
    /// </summary>
    public class ParameterNames
    {
    /// <summary>
    /// Returns '@ProductName'
    /// </summary>
    public static string ProductName = "@ProductName";
    /// <summary>
    /// Returns '@IntroductionDate'
    /// </summary>
    public static string IntroductionDate = "@IntroductionDate";
    /// <summary>
    /// Returns '@Cost'
    /// </summary>
    public static string Cost = "@Cost";
    /// <summary>
    /// Returns '@Price'
    /// </summary>
    public static string Price = "@Price";
    /// <summary>
    /// Returns '@IsDiscontinued'
    /// </summary>
    public static string IsDiscontinued = "@IsDiscontinued";
    /// <summary>
    /// Returns '@RETURN_VALUE'
    /// </summary>
    public static string RETURNVALUE = "@RETURN_VALUE";
    }
    #endregion
  }
}
