Overview of this Sample
--------------------------------------
This sample shows how to use transactions when using the Haystack generated data classes

You need to choose "Generate Dynamic SQL?" and "Generate Stored Procedures?" options when creating the project

Tables Used
-------------
OrderHeader
OrderLineItem
Product

Stored Procs Used
-----------------
ProductInsert