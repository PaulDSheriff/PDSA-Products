﻿using System;
using System.Windows.Controls;

namespace TransactionSample
{
  /// <summary>
  /// Interaction logic for ucProductInfo.xaml
  /// </summary>
  public partial class ucProductInfo : UserControl
  {
    public ucProductInfo()
    {
      InitializeComponent();
    }
  }
}