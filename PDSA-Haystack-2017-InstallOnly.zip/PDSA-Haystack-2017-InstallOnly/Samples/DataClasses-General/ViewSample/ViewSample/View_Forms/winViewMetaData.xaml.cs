﻿using System;
using System.Text;
using System.Windows;

using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.WPF;

using Sample.Project;
using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;

namespace ViewSample_CS
{
  public partial class winViewMetaData : Window
  {
    public winViewMetaData()
    {
      InitializeComponent();
    }

    #region AllColumns Sample
    private void btnAllColumns_Click(object sender, RoutedEventArgs e)
    {
      AllColumns();
    }

    private void AllColumns()
    {
      vwProduct_SelectAllManager mgr;
      PDSADataColumn col = new PDSADataColumn();
      
      mgr = new vwProduct_SelectAllManager();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(col.GetPropertiesAsPropertyHeaderCollection());
      lstData.DataContext = mgr.DataObject.AllColumns;
    }
    #endregion

    private void btnClassName_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new vwProduct_SelectAllManager();

      sb.Append("Entity Class Name: " + mgr.Entity.ClassName + Environment.NewLine);
      sb.Append("Manager Class Name: " + mgr.ClassName + Environment.NewLine);
      sb.Append("Data Class Name: " + mgr.DataObject.ClassName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }

    private void btnCommandTimeout_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "Command Timeout: " + mgr.DataObject.CommandTimeout.ToString();
    }

    private void btnDBObjectName_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "Data Object Name: " + mgr.DataObject.DBObjectName;
    }

    private void btnDBObjectNameOnly_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "Data Object Name Only: " + mgr.DataObject.DBObjectNameOnly;
    }

    private void btnOrderByClauseSQL_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      mgr.DataObject.OrderByFilter = vwProduct_SelectAllData.OrderByFilters.ProductName;

      txtData.Text = "ORDER BY SQL: " + mgr.DataObject.OrderByClauseSQL();
    }

    private void btnRowCountSQL_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "Row Count SQL: " + mgr.DataObject.RowCountSQL();
    }

    private void btnSchemaName_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "Schema Name: " + mgr.DataObject.SchemaName;
    }

    private void btnSelectSQL_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      txtData.Text = "SELECT SQL: " + mgr.DataObject.SelectSQL();
    }

    private void btnWhereSQL_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;

      mgr = new vwProduct_SelectAllManager();

      mgr.DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.LikeProductName;

      txtData.Text = "WHERE SQL: " + mgr.DataObject.WhereClauseSQL();
    }

    private void btnPDSALoginName_Click(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr;
      StringBuilder sb = new StringBuilder(1024);

      mgr = new vwProduct_SelectAllManager();

      sb.Append("Entity Login Name: " + mgr.Entity.PDSALoginName + Environment.NewLine);
      sb.Append("Manager Login Name: " + mgr.PDSALoginName + Environment.NewLine);
      sb.Append("Data Login Name: " + mgr.DataObject.PDSALoginName + Environment.NewLine);

      txtData.Text = sb.ToString();
    }
  }
}
