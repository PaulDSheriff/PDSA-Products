﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

using PDSA.Common;
using PDSA.DataLayer;
using PDSA.Validation;
using PDSA.WPF;

using Sample.Project;
using Sample.Project.BusinessLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.EntityLayer;
using Sample.Project.DataLayer;

namespace ViewSample_CS
{
  public partial class winViewSample : Window
  {
    public winViewSample()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      vwProduct_SelectAllManager mgr = new vwProduct_SelectAllManager();

      // Build the GridView Collection
      lstData.View = PDSAWPFListView.CreateGridViewColumns(mgr.DataObject.GetColumnsAsPropertyHeaderCollection());
    }

    #region LoadAll Methods
    private void btnLoadAll_Click(object sender, RoutedEventArgs e)
    {
      LoadAllSample();
    }

    private void LoadAllSample()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // Load all rows
        mgr.DataObject.Load();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          // Use the DataSetObject property to retrieve the rows
          lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region LoadUsingWhere Methods
    private void btnLoadWhere_Click(object sender, RoutedEventArgs e)
    {
      LoadUsingWhere();
    }

    private void LoadUsingWhere()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // Set a Where Filter
        mgr.DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.LikeProductName;
        mgr.Entity.ProductName = txtProductName.Text.Trim();

        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          mgr.Entity.ProductName += new PDSADataManager().Provider.LikeOperator;
          mgr.DataObject.Load();
          tbSQL.Text = mgr.DataObject.SQL;

          if (mgr.DataObject.RowsAffected > 0)
          {
            // Use the DataSetObject property to retrieve the rows
            lstData.DataContext = mgr.DataObject.DataSetObject.Tables[0];
          }
          else
            MessageBox.Show("No Records Match Search Criteria");
        }
        else
        {
          MessageBox.Show("Please fill in a Product Name before Running this Method");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataSet Methods
    private void btnGetDataSet_Click(object sender, RoutedEventArgs e)
    {
      GetDataSet();
    }

    private void GetDataSet()
    {
      vwProduct_SelectAllManager mgr;
      DataSet ds;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        ds = mgr.DataObject.GetDataSet();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataSet, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = ds.Tables[0];
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataTable
    private void btnGetDataTable_Click(object sender, RoutedEventArgs e)
    {
      GetDataTable();
    }

    private void GetDataTable()
    {
      vwProduct_SelectAllManager mgr;
      DataTable dt;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = dt;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GetDataReader
    private void btnGetDataReader_Click(object sender, RoutedEventArgs e)
    {
      GetDataReader();
    }

    private void GetDataReader()
    {
      vwProduct_SelectAllManager mgr;
      vwProduct_SelectAllCollection coll = new vwProduct_SelectAllCollection();
      vwProduct_SelectAll entity;
      SqlDataReader dr = null;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        dr = (SqlDataReader)mgr.DataObject.GetDataReader();
        tbSQL.Text = mgr.DataObject.SQL;

        if (dr.HasRows)
        {
          while (dr.Read())
          {
            entity = new vwProduct_SelectAll();

            // Use the PDSAString.GetData() method to avoid Null values
            entity.ProductId = Convert.ToInt32(PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.ProductId], "0"));
            entity.ProductName = PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.ProductName], "");
            entity.Cost = Convert.ToDecimal(PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.Cost], "0"));
            entity.Price = Convert.ToDecimal(PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.Price], "0"));
            entity.IsDiscontinued = Convert.ToBoolean(PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.IsDiscontinued], "false"));
            entity.IntroductionDate = Convert.ToDateTime(PDSAString.GetData(dr[vwProduct_SelectAllValidator.ColumnNames.IntroductionDate], DateTime.Now.ToString()));

            coll.Add(entity);
          }
        }

        lstData.DataContext = coll;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }
    #endregion

    #region BuildCollection Methods
    private void btnBuildCollection_Click(object sender, RoutedEventArgs e)
    {
      BuildCollection();
    }

    private void BuildCollection()
    {
      vwProduct_SelectAllManager mgr;
      vwProduct_SelectAllCollection coll;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // After the Call to BuildCollection, the RowsAffected Property is Set
        coll = mgr.BuildCollection();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = coll;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToXml Methods
    private void btnDataRowToXml_Click(object sender, RoutedEventArgs e)
    {
      DataRowToXml();
    }

    private void DataRowToXml()
    {
      vwProduct_SelectAllManager mgr;
      DataTable dt;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          tbXml.Text = mgr.DataObject.DataSetRowToXml(0);

          MessageBox.Show("XML Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Create Entity From DataRow
    private void btnCreateEntityFromDataRow_Click(object sender, RoutedEventArgs e)
    {
      EntityFromDataRow();
    }

    private void EntityFromDataRow()
    {
      vwProduct_SelectAllManager mgr;
      vwProduct_SelectAll entity;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // After the Call to GetDataTable, the RowsAffected Property is Set
        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          entity = mgr.DataObject.CreateEntityFromDataRow(dr);

          MessageBox.Show("Entity Created");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DataRowToProperties Sample
    private void btnDataRowToProperties_Click(object sender, RoutedEventArgs e)
    {
      DataRowToPropertiesSample();
    }

    private void DataRowToPropertiesSample()
    {
      vwProduct_SelectAllManager mgr;
      DataTable dt;
      DataRow dr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        dt = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;

        // After the Call to GetDataTable, the RowsAffected Property is Set
        if (mgr.DataObject.RowsAffected > 0)
        {
          dr = dt.Rows[0];

          // Set the internal properties
          mgr.DataObject.DataRowToProperties(dr);

          MessageBox.Show("DataRow Put Into Properties");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount sample
    private void btnRowCount_Click(object sender, RoutedEventArgs e)
    {
      RowCountSample();
    }

    private void RowCountSample()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        MessageBox.Show("Total Record Count is " + mgr.DataObject.RowCount().ToString());
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region RowCount using WHERE sample
    private void btnRowCountUsingWhere_Click(object sender, RoutedEventArgs e)
    {
      RowCountUsingWhere();
    }

    private void RowCountUsingWhere()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();
        mgr.Entity.ProductName = txtProductName.Text.Trim();

        // Set a Where Filter
        if (mgr.Entity.ProductName.Trim() != string.Empty)
        {
          mgr.DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.LikeProductName;
          mgr.Entity.ProductName += new PDSADataManager().Provider.LikeOperator;

          MessageBox.Show("Record Count is " + mgr.DataObject.RowCount().ToString());
          tbSQL.Text = mgr.DataObject.SQL;
        }
        else
        {
          MessageBox.Show("Please fill in a Partial Product Name");
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom SELECT sample
    private void btnCustomSelect_Click(object sender, RoutedEventArgs e)
    {
      CustomSelect();
    }

    private void CustomSelect()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        mgr.DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom WHERE sample
    private void btnCustomWhere_Click(object sender, RoutedEventArgs e)
    {
      CustomWhereSample();
    }

    private void CustomWhereSample()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        mgr.DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        mgr.DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.Custom;
        mgr.DataObject.WhereCustom = " WHERE " + vwProduct_SelectAllValidator.ColumnNames.Price + " > 20";

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region Custom ORDER BY sample
    private void btnCustomOrderBy_Click(object sender, RoutedEventArgs e)
    {
      CustomOrderBySample();
    }

    private void CustomOrderBySample()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();


        mgr.DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM " + mgr.DataObject.DBObjectNameOnly;

        mgr.DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.Custom;
        mgr.DataObject.WhereCustom = " WHERE " + vwProduct_SelectAllValidator.ColumnNames.Price + " > 20";

        mgr.DataObject.OrderByFilter = vwProduct_SelectAllData.OrderByFilters.Custom;
        mgr.DataObject.OrderByCustom = " ORDER BY " + vwProduct_SelectAllValidator.ColumnNames.Price + " DESC";

        lstData.DataContext = mgr.DataObject.GetDataTable();
        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region GenerateException Method
    private void btnGenException_Click(object sender, RoutedEventArgs e)
    {
      GenerateException();
    }

    private void GenerateException()
    {
      vwProduct_SelectAllManager mgr;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        mgr.DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.Custom;
        mgr.DataObject.SelectCustom = "SELECT * FROM viewBad";

        lstData.DataContext = mgr.DataObject.GetDataTable();

        tbSQL.Text = mgr.DataObject.SQL;
      }
      catch (PDSAValidationException ex)
      {
        MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

    #region DisplayException Method
    private void DisplayException(Exception ex)
    {
      tbException.Text = ex.ToString();

      MessageBox.Show("Exception Occurred. Check the Exception Tab for More Info.");
    }
    #endregion

    #region Check for Null
    private void btnCheckNull_Click(object sender, RoutedEventArgs e)
    {
      CheckForNull();
    }

    private void CheckForNull()
    {
      vwProduct_SelectAllManager mgr;
      vwProduct_SelectAllCollection coll;

      try
      {
        mgr = new vwProduct_SelectAllManager();

        // After the Call to BuildCollection, the RowsAffected Property is Set
        coll = mgr.BuildCollection();
        tbSQL.Text = mgr.DataObject.SQL;

        // You can check for null using the following:
        mgr.Entity = coll[0];
        System.Diagnostics.Debugger.Break();
        if (mgr.Entity.IsValueNull("Cost"))
          tbException.Text = "Cost is null";
        // or you can also check for null using:
        if (coll[2].IsValueNull("Cost"))
          tbException.Text = "Cost is null";

        if (mgr.DataObject.RowsAffected > 0)
        {
          lstData.DataContext = coll;
        }
      }
      catch (Exception ex)
      {
        DisplayException(ex);
      }
    }
    #endregion

  }
}