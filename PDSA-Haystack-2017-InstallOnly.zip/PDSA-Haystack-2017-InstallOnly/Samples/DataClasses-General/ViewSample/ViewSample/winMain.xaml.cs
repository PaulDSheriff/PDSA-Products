﻿using System.Windows;

namespace ViewSample_CS
{
  /// <summary>
  /// Interaction logic for winMain.xaml
  /// </summary>
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnProductSample_Click(object sender, RoutedEventArgs e)
    {
      winViewSample win = new winViewSample();

      win.Show();
    }

    private void btnProductMetaData_Click(object sender, RoutedEventArgs e)
    {
      winViewMetaData win = new winViewMetaData();
            
      win.Show();
    }
  }
}
