using System;
using System.Collections.Generic;
using System.Data;

using PDSA;
using PDSA.Common;
using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.DataLayer;

namespace Sample.Project.BusinessLayer
{
  /// <summary>
  /// This class should be used when you need to select data for the vwProduct_SelectAll view.
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// DO NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class vwProduct_SelectAllManager : PDSADataClassManagerReadOnlyBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for the vwProduct_SelectAllManager class
    /// </summary>
    public vwProduct_SelectAllManager()
    {
      Init();
    }

    /// <summary>
    /// Constructor for the vwProduct_SelectAllManager class
    /// </summary>
    /// <param name="dataProvider">An instance of a PDSADataProvider</param>
    public vwProduct_SelectAllManager(PDSADataProvider dataProvider)
    {
      DataProvider = dataProvider;
      
      Init();
    }

    /// <summary>
    /// Constructor for the vwProduct_SelectAllManager class
    /// </summary>
    /// <param name="dataProviderName">The name of the DataProvider to use for all data access</param>
    public vwProduct_SelectAllManager(string dataProviderName) : base(dataProviderName)
    {
      // The base constructor calls the Init() method
    }
    #endregion

    #region Private variables
    private vwProduct_SelectAll _Entity = null;
    private vwProduct_SelectAll _SearchEntity = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the entity class. This is the class that contains one property for each column in the table.
    /// </summary>
    public vwProduct_SelectAll Entity
    {
      get { return _Entity; }
      set
      {
        _Entity = value;
        if (Validator != null)
          Validator.Entity = value;
        if (DataObject != null)
          DataObject.Entity = value;
      }
    }
    
    /// <summary>
    /// Get/Set the Entity class used for searching
    /// </summary>
    public vwProduct_SelectAll SearchEntity
    {
      get
      {
        // Create Search Entity Class if not created
        if (_SearchEntity == null)
        {
          _SearchEntity = new vwProduct_SelectAll();
          InitSearchFilter();
        }

        return _SearchEntity;
      }
      set { _SearchEntity = value; }
    }

    /// <summary>
    /// Get/Set the validator class. This is the class that contains the business rules for the Entity class.
    /// </summary>
    public vwProduct_SelectAllValidator Validator { get; set; }
    /// <summary>
    /// Get/Set the data class that contains the CRUD logic for loading the Entity class
    /// </summary>
    public vwProduct_SelectAllData DataObject { get; set; }
    #endregion

    #region Init Method
    /// <summary>
    /// Initialize this class to a valid start state
    /// </summary>
    protected override void Init()
    {
      // Create Entity Class if not created
      if(Entity == null)
      {
        Entity = new vwProduct_SelectAll();

        // Set any default values on the Entity object
        InitEntityObject();
      }

      // Create Validator Class
      if(Validator == null)
        Validator = new vwProduct_SelectAllValidator(Entity);

      // Create Data Class if not created
      if(DataObject == null)
        DataObject = new vwProduct_SelectAllData(DataProvider, Entity, Validator);
      else
      {
        DataObject.DataProvider = DataProvider;
        DataObject.ValidatorObject = Validator;
        DataObject.Entity = Entity;
      }
        
      ClassName = "vwProduct_SelectAllManager";
    }
    #endregion

    #region DictionaryToEntity Method
    /// <summary>
    /// Takes the filled Dictionary object and puts the values into the Entity object
    /// </summary>
    /// <param name="values">A Dictionary object</param>
    /// <returns>An EmployeeType object</returns>
    public vwProduct_SelectAll DictionaryToEntity(Dictionary<string, string> values)
    {
      vwProduct_SelectAll ret = new vwProduct_SelectAll();

      // Initialize Entity Object
      InitEntityObject(ret);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.ProductId))
        ret.ProductId = Convert.ToInt32(values[vwProduct_SelectAllValidator.ColumnNames.ProductId]);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.ProductName))
        ret.ProductName = PDSAString.ConvertToStringTrim(values[vwProduct_SelectAllValidator.ColumnNames.ProductName]);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.IntroductionDate))
        ret.IntroductionDate = Convert.ToDateTime(values[vwProduct_SelectAllValidator.ColumnNames.IntroductionDate]);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.Cost))
        ret.Cost = Convert.ToDecimal(values[vwProduct_SelectAllValidator.ColumnNames.Cost]);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.Price))
        ret.Price = Convert.ToDecimal(values[vwProduct_SelectAllValidator.ColumnNames.Price]);

      if (values.ContainsKey(vwProduct_SelectAllValidator.ColumnNames.IsDiscontinued))
        ret.IsDiscontinued = Convert.ToBoolean(values[vwProduct_SelectAllValidator.ColumnNames.IsDiscontinued]);

      return ret;
    }
    #endregion

    #region BuildCollection Method
    /// <summary>
    /// Returns a collection of vwProduct_SelectAll classes based on the filters set
    /// You can set the SearchEntity object with values to search on partial data
    /// prior to calling this method to filter the results
    /// </summary>
    /// <returns>vwProduct_SelectAllCollection</returns>
    public vwProduct_SelectAllCollection BuildCollection()
    {
      vwProduct_SelectAllCollection coll = new vwProduct_SelectAllCollection();
      vwProduct_SelectAll entity = null;
      DataSet ds;

      try
      {
        DataObject.Entity = Entity;
        ds = DataObject.GetDataSet();

        if (ds.Tables.Count > 0)
        {
          foreach (DataRow dr in ds.Tables[ds.Tables.Count - 1].Rows)
          {
            entity = DataObject.CreateEntityFromDataRow(dr);
          
            // You can set any additional properties here
          
            coll.Add(entity);
          }
        }
      }
      catch (Exception ex)
      {
        // This is here for design time exceptions
        System.Diagnostics.Debug.WriteLine(ex.Message);
      }

      return coll;
    }

    /// <summary>
    /// Build collection from a DataSet returned from a stored procedure
    /// </summary>
    /// <param name="ds">A DataSet</param>
    /// <returns>A collection of vwProduct_SelectAll objects</returns>
    public vwProduct_SelectAllCollection BuildCollection(DataSet ds)
    {
      vwProduct_SelectAllCollection coll = new vwProduct_SelectAllCollection();

      if (ds != null)
      {
        if (ds.Tables.Count > 0)
        {
          foreach (DataRow item in ds.Tables[0].Rows)
          {
            coll.Add(DataObject.CreateEntityFromDataRow(item));
          }
        }
      }

      return coll;
    }
    
    /// <summary>
    /// Build collection from a DataTable returned from a stored procedure
    /// </summary>
    /// <param name="dt">A DataTable</param>
    /// <returns>A collection of vwProduct_SelectAll objects</returns>
    public vwProduct_SelectAllCollection BuildCollection(DataTable dt)
    {
      DataSet ds = new DataSet();

      ds.Tables.Add(dt);

      return BuildCollection(ds);
    }
    #endregion

    #region GetCollectionAsJSON Method
    /// <summary>
    /// Returns a collection of vwProduct_SelectAll objects as a JSON formatted string
    /// </summary>
    /// <returns>A JSON formatted string</returns>
    public string GetCollectionAsJSON()
    {
      return PDSAString.GetAsJSON(typeof(vwProduct_SelectAllCollection), BuildCollection());
    }
    #endregion

    #region GetDataSet Method
    /// <summary>
    /// Get DataSet with all rows or with any filters you have set
    /// </summary>
    /// <returns>A DatSet object</returns>
    public DataSet GetDataSet()
    {
      return DataObject.GetDataSet();
    }

    /// <summary>
    /// Get DataSet using the SearchEntity object
    /// </summary>
    /// <returns>A DatSet object</returns>
    public DataSet GetDataSetUsingSearchFilters()
    {
      DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.Search;

      // Create connection
      DataObject.CommandObject.Connection = DataProvider.CreateConnection(DataProvider.ConnectString);

      return DataProvider.GetDataSet(DataObject.CommandObject);
    }
    #endregion

    #region InitSearchFilter Method
    /// <summary>
    /// Re-Initialize a 'SearchEntity' property
    /// </summary>
    public void InitSearchFilter()
    {
      // Initialize Search Entity
      SearchEntity = InitSearchFilter(SearchEntity);
    }

    /// <summary>
    /// Re-Initialize a Search Entity object
    /// Usually you will use this to set the SearchEntity object
    /// 
    /// vwProduct_SelectAll.SearchEntity = mgr.InitSearchFilter(vwProduct_SelectAll.SearchEntity);
    /// </summary>
    /// <param name="searchEntity">A vwProduct_SelectAll object</param>
    /// <returns>An vwProduct_SelectAll object</returns>
    public vwProduct_SelectAll InitSearchFilter(vwProduct_SelectAll searchEntity)
    {
      searchEntity.ProductName  = string.Empty;

      searchEntity.IsDirty = false;

      DataObject.SelectFilter = vwProduct_SelectAllData.SelectFilters.All;
     
      return searchEntity;
    }
    #endregion
    
    #region GetvwProduct_SelectAllsByProductName Method
    /// <summary>
    /// Sets the specified WhereFilter and calls the BuildCollection() method
    /// Assumes you have set the appropriate column(s) in the Entity object
    /// prior to calling this method. Ex. mgr.Entity.'ColumName' = 'Value'
    /// </summary>
    public vwProduct_SelectAllCollection GetvwProduct_SelectAllsByProductName()
    {
      DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.ProductName;

      return BuildCollection();
    }
    #endregion
    
    #region GetvwProduct_SelectAllsByLikeProductName Method
    /// <summary>
    /// Sets the specified WhereFilter and calls the BuildCollection() method
    /// Assumes you have set the appropriate column(s) in the Entity object
    /// prior to calling this method. Ex. mgr.Entity.'ColumName' = 'Value'
    /// </summary>
    public vwProduct_SelectAllCollection GetvwProduct_SelectAllsByLikeProductName()
    {
      DataObject.WhereFilter = vwProduct_SelectAllData.WhereFilters.LikeProductName;

      return BuildCollection();
    }
    #endregion

    #region Clone Entity Class
    /// <summary>
    /// Clones the current vwProduct_SelectAll
    /// </summary>
    /// <returns>A cloned vwProduct_SelectAll object</returns>
    public vwProduct_SelectAll CloneEntity()
    {
      return CloneEntity(this.Entity);
    }
    
    /// <summary>
    /// Clones the passed in vwProduct_SelectAll
    /// </summary>
    /// <param name="entityToClone">The vwProduct_SelectAll entity to clone</param>
    /// <returns>A cloned vwProduct_SelectAll object</returns>
    public vwProduct_SelectAll CloneEntity(vwProduct_SelectAll entityToClone)
    {
      vwProduct_SelectAll newEntity = new vwProduct_SelectAll();

      newEntity.ProductId = entityToClone.ProductId;
      newEntity.ProductName = entityToClone.ProductName;
      newEntity.IntroductionDate = entityToClone.IntroductionDate;
      newEntity.Cost = entityToClone.Cost;
      newEntity.Price = entityToClone.Price;
      newEntity.IsDiscontinued = entityToClone.IsDiscontinued;

      return newEntity;
    }
    #endregion
  }
}
