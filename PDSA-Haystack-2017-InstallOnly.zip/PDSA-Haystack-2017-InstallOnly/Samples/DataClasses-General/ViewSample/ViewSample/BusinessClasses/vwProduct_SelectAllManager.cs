using System;
using System.Collections.Generic;
using System.Data;

using PDSA;
using PDSA.Common;
using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.DataLayer;

namespace Sample.Project.BusinessLayer
{
  /// <summary>
  /// This class should be used when you need to select data for the vwProduct_SelectAll view.
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// You may add additional methods to this class.
  /// </summary>
  public partial class vwProduct_SelectAllManager
  {
    #region Your Custom Properties and Methods
    
    #endregion
   
    #region InitEntityObject Method
    /// <summary>
    /// Call this method to initialize the 'Entity' object with any default values
    /// </summary>
    public void InitEntityObject()
    {
      InitEntityObject(Entity);
    }

    /// <summary>
    /// Call this method to initialize an vwProduct_SelectAll object with any default values
    /// </summary>
    /// <param name="entity">An vwProduct_SelectAll object</param>
    public void InitEntityObject(vwProduct_SelectAll entity)
    {
      // TODO: Set any defaults here
      // Below is an Example 
      // entity.StartDate = DateTime.Now;

    }
    #endregion
  }
}
