Overview of this Sample
--------------------------------------
This sample shows how to use Views generated from Haystack

Views Used
--------------------------
vwProduct_SelectAll
