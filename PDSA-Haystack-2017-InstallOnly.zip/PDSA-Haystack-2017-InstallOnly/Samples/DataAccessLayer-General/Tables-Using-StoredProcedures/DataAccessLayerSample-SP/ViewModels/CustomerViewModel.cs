using PDSA.UI;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using Sample.Project;


namespace Sample.Project
{
  public partial class CustomerViewModel : PDSAMVCViewModelBase
  {
    #region Constructor
    /// <summary>
    /// Constructor for CustomerViewModel.
    /// </summary>
    public CustomerViewModel()
      : base()
    {
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// A collection of Customer objects
    /// </summary>
    public List<Customer> DataCollection { get; set; }

    /// <summary>
    /// The currently selected Customer object
    /// </summary>
    public Customer DetailData { get; set; }

    /// <summary>
    /// Get/Set the original entity read from the database.
    /// Used for undo and auditing
    /// </summary>
    public Customer OriginalEntity = null;
   
    /// <summary>
    /// Get/Set the CustomerSearch object
    /// </summary>
    public CustomerSearch SearchEntity { get; set; }
    #endregion
    
    #region Manager Object
    /// <summary>
    /// Get/Set the Manager object
    /// </summary>
    public CustomerManager _Manager = null;
    #endregion

    #region CreateManagerObject Method
    /// <summary>
    /// Create the Manager object for use in this view model
    /// </summary>
    /// <returns>A CustomerManager object</returns>
    private CustomerManager CreateManagerObject()
    {
      if (_Manager == null) {
        _Manager = new CustomerManager();
        _Manager.PDSALoginName = PDSALoginName;

        // Add any additional settings here to Manager class
        // _Manager.UseAuditTracking = true;
      }

      return _Manager;
    }
    #endregion

    #region Init Method
    /// <summary>
    /// Initialize the View Model
    /// </summary>
    public override void Init() {
      base.Init();

      RecordName = "Customer";
      RecordNamePlural = "Customers";
      SortExpression = CustomerManager.PropertyNames.CompanyName;
      ResetMessages();
      
      DataCollection = new List<Customer>();
      DetailData = new Customer();
      OriginalEntity = new Customer();
      SearchEntity = new CustomerSearch();

      IsPrimaryKeyAutoNumber = true;
    }
    #endregion
    
    #region HandleRequest Method
    /// <summary>
    /// Call this method after setting the EventCommand property
    /// This method can call all other methods within this ViewModel
    /// </summary>
    public override void HandleRequest()
    {
      // Make sure we have a valid event command
      EventCommand = (EventCommand == null ? "" : EventCommand.ToLower());

      // Call base class HandleRequest method
      base.HandleRequest();

      // Check if we are sorting
      if (EventCommand == "sort")
      {
        // Check to see if we need to change the sort order 
        // because the sort expression changed
        SetSortDirection();
      }

      // Process the event
      switch (EventCommand)
      {
        case "page":
          BuildCollection();
          SortData();
          break;

        case "search":
          Pager.PageIndex = 0;
          BuildCollection();
          SortData();
          break;

        case "resetsearch":
          Pager.PageIndex = 0;
          ResetSearch();
          BuildCollection();
          SortData();
          break;

        case "add":
          AddMode();
          CreateNewEntity();
          break;

        case "edit":
          EditMode();
          LoadByPK(Convert.ToInt32(EventArgument));
          break;

        case "delete":
          DeleteByPK(Convert.ToInt32(EventArgument));
          EventArgument = string.Empty; 
          ResetSearch();
          BuildCollection();
          SortData();
          break;

        case "save":
          // Save the data
          DataSave();
          break;

        case "cancel":
          NormalMode();
          BuildCollection();
          SortData();
          break;

        default:
          BuildCollection();
          SortData();
          break;
      }

      if (IsPagingAllowed)
      {
        // Build paging info & get current page of records
        if (DataCollection.Count > 0)
        {
          // Setup Pager Object
          SetPagerObject(DataCollection.Count);

          DataCollection = new List<Customer>(DataCollection.Skip(Pager.StartingRow).Take(Pager.PageSize));
        }
      }
    }
    #endregion

    #region BuildCollection Method
    /// <summary>
    /// Create a Collection of Customer objects.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> BuildCollection()
    {
      Customer search = new Customer();
      DataCollection.Clear();

      // Fill in search information
      search.CompanyName = SearchEntity.CompanyName;

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Do any search here
        DataCollection = _Manager.BuildCollection(search);

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;

        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;
        if (TotalRecords == 0)
          SetViewStateMode(PDSAUIState.NoRecords);
        else
          SetViewStateMode(PDSAUIState.ListOnly);
      }
      catch (Exception ex) {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region GetDataSet Method
    /// <summary>
    /// Return a DataSet
    /// </summary>
    /// <returns>A DataSet object</returns>
    public DataSet GetDataSet()
    {
      DataSet ret = new DataSet();

      try {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        ret = _Manager.GetDataSet();

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;

        // Set the Total Records Retrieved
        TotalRecords = _Manager.RowsAffected;
        if (TotalRecords == 0)
          SetViewStateMode(PDSAUIState.NoRecords);
        else
          SetViewStateMode(PDSAUIState.ListOnly);
      }
      catch (Exception ex) {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion
    
    #region SortData Method
    /// <summary>
    /// Sorts the data in the DataCollection property
    /// </summary>
    protected virtual void SortData()
    {
      // Sort the data
      DataCollection = Sort<Customer>(DataCollection.AsQueryable());
    }
    #endregion

    #region LoadByPK Method
    /// <summary>
    /// Load a single Customer object by primary key
    /// </summary>
    /// <param name="customerId">The primary key to find</param>
    /// <returns>A Customer object</returns>
    public Customer LoadByPK(int? customerId)
    {
      LastException = null;
      try {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        DetailData = _Manager.Load(customerId);

        // Set total records found
        TotalRecords = _Manager.RowsAffected;

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;
      }
      catch (Exception ex) {
        LastException = ex;
        if (HandleCustomExceptions(ex) == false)
          HandleValidationMessages(LastException.Message);
      }

      return DetailData;
    }
    #endregion

    #region ResetSearch Method
    /// <summary>
    /// Reset all Search Criteria to default values
    /// </summary>
    public override void ResetSearch()
    {
      // Reset Search Properties
      SearchEntity = new CustomerSearch();
    }
    #endregion

    #region CreateNewEntity Method
    /// <summary>
    /// Creates a new Entity object with default values and assigns to DetailData property
    /// </summary>
    /// <returns>A Customer Object</returns>
    public Customer CreateNewEntity()
    {
      // Create blank Entity Object
      DetailData = new Customer();

      // Set defaults for each field
      DetailData.CustomerId = null;
      DetailData.CompanyName = null;
      DetailData.FirstName = null;
      DetailData.LastName = null;
      DetailData.Title = null;
      DetailData.Address1 = null;
      DetailData.Address2 = null;
      DetailData.TotalSales = null;
      DetailData.City = null;
      DetailData.StateCode = null;
      DetailData.PostalCode = null;
      DetailData.Country = null;
      DetailData.Phone = null;
      DetailData.Fax = null;
      DetailData.EmailAddress = null;
      DetailData.InsertName = this.PDSALoginName;
      DetailData.InsertDate = DateTime.Now;
      DetailData.UpdateName = this.PDSALoginName;
      DetailData.UpdateDate = DateTime.Now;
      DetailData.ConcurrencyValue = 1;

      return DetailData;
    }
    #endregion

    #region DataSave Methods
    /// <summary>
    /// Inserts or Updates the passed in entity object
    /// Calls the DataSave method in the base class, which in turn calls either DataInsert or DataUpdate methods based on what state the UI is in.
    /// </summary>
    /// <param name="entity">The entity to save</param>
    /// <returns>True if successful, false is not</returns>
    public bool DataSave(Customer entity)
    {
      DetailData = entity;

      return DataSave();
    }
    
    /// <summary>
    /// Inserts or Updates the passed in entity object
    /// Calls the DataSave method in the base class, which in turn calls either DataInsert or DataUpdate methods based on what state the UI is in.
    /// </summary>
    /// <returns>True if successful, false is not</returns>
    public override bool DataSave() {
      bool ret = false;

      IsAddMode = (UIState == PDSAUIState.Add);
      IsEditMode = (UIState == PDSAUIState.Edit);

      ret = base.DataSave();

      if (ret) {
        SetViewStateMode(PDSAUIState.ListOnly);
        IsValid = true;
        BuildCollection();
        SortData();
      }
      else {
        if (!string.IsNullOrEmpty(LastExceptionMessage)) {
          SetViewStateMode(PDSAUIState.Exception);
        }
        else if (ValidationFailed) {
          // We have a validation error
          SetViewStateMode(PDSAUIState.ValidationFailed);
          SetModeAfterValidation();
        }
      }

      return ret;
    }    
    #endregion

    #region DataInsert Methods
    /// <summary>
    /// Inserts the current entity into the data store
    /// </summary>
    /// <param name="entity">The entity to insert</param>
    /// <returns>bool</returns>
    public bool DataInsert(Customer entity)
    {
      DetailData = entity;

      return DataInsert();
    }

    /// <summary>
    /// Inserts the current entity into the data store
    /// Called by the DataSave method
    /// </summary>
    /// <returns>bool</returns>
    public override bool DataInsert()
    {
      bool ret = false;

      LastException = null;
      LastExceptionMessage = string.Empty;
      ValidationRuleFailures = new PDSAValidationRules();
      try {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Update Standard Fields
        DetailData.InsertName = this.PDSALoginName;        
        DetailData.InsertDate = DateTime.Now;        
        DetailData.UpdateName = this.PDSALoginName;        
        DetailData.UpdateDate = DateTime.Now;        
        DetailData.ConcurrencyValue = 1;        

        // Perform the Insert
        ret = _Manager.Insert(DetailData);
        
        // Update total records affected
        TotalRecords = _Manager.RowsAffected;

        // Get XML Audit String
        XmlAuditString = _Manager.AuditRowAsXml;

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;
        if (ret) {
          // In case anything was changed in the Insert
          DetailData = _Manager.LastUpdatedEntity;

          // Add new entity to the collection
          DataCollection.Add(DetailData);
          TotalRecords = DataCollection.Count;
        }
        else {
          // Check to see if validation rules failed
          if (_Manager.ValidationFailed) {
            IsValid = false;
            ValidationFailed = true;
            ValidationRuleFailures.AddRange(_Manager.ValidationRuleFailures);
          }
          else {
            LastException = new Exception(base.NoRowsAffectedMessageInsert);
            HandleExceptionMessages(LastException.Message);
          }
        }
      }
      catch (Exception ex) {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion

    #region DataUpdate Methods
    /// <summary>
    /// Updates the current Entity to the data store
    /// Called by the DataSave method
    /// </summary>
    /// <param name="entity">The entity to update</param>
    /// <returns>boolean</returns>
    public bool DataUpdate(Customer entity)
    {
      DetailData = entity;

      return DataUpdate();
    }

    /// <summary>
    /// Updates the current Entity to the data store
    /// Called by the DataSave method
    /// </summary>
    /// <returns>boolean</returns>
    public override bool DataUpdate()
    {
      bool ret = false;

      LastException = null;
      LastExceptionMessage = string.Empty;
      ValidationRuleFailures = new PDSAValidationRules();
      try {
        // Get Manager Object
        _Manager = CreateManagerObject();

         // Reload Data From Table
        Customer changed = _Manager.Load(DetailData.CustomerId);
        // For audit tracking
        Customer oldEntity = changed.CopyObject();

        // Update the input fields changed by the user
        changed.CompanyName = DetailData.CompanyName;
        changed.FirstName = DetailData.FirstName;
        changed.LastName = DetailData.LastName;
        changed.Title = DetailData.Title;
        changed.Address1 = DetailData.Address1;
        changed.Address2 = DetailData.Address2;
        changed.TotalSales = DetailData.TotalSales;
        changed.City = DetailData.City;
        changed.StateCode = DetailData.StateCode;
        changed.PostalCode = DetailData.PostalCode;
        changed.Country = DetailData.Country;
        changed.Phone = DetailData.Phone;
        changed.Fax = DetailData.Fax;
        changed.EmailAddress = DetailData.EmailAddress;
        // Update Standard Fields (if any)
        changed.UpdateName = this.PDSALoginName;        
        changed.UpdateDate = DateTime.Now;        

        // Perform the Update using Audit Tracking
        ret = _Manager.Update(changed, oldEntity);
        
        // Update total records affected
        TotalRecords = _Manager.RowsAffected;

        // Get XML Audit String
        XmlAuditString = _Manager.AuditRowAsXml;

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;
        if (ret) {
          // In case anything was changed in the Update
          DetailData = _Manager.LastUpdatedEntity;
        }
        else {
           // Check to see if validation rules failed
          if (_Manager.ValidationFailed) {
            IsValid = false;
            ValidationFailed = true;
            ValidationRuleFailures.AddRange(_Manager.ValidationRuleFailures);
          }
          else {
            LastException = new Exception(base.NoRowsAffectedMessageUpdate);
            HandleExceptionMessages(LastException.Message);
          }
        }
      }
      catch (Exception ex) {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion
    
    #region DeleteByPK Method
    /// <summary>
    /// Deletes the entity creating an entity with the primary keys filled in and calling the overloaded DataDelete method.
    /// </summary>
    /// <param name="customerId">The primary key to delete</param>
    /// <returns>1 if deleted, otherwise zero</returns>
    public int DeleteByPK(int? customerId)
    {
      DetailData = new Customer();

      // Load old entity in case you wish to do audit tracking after deleting
      DetailData = LoadByPK(customerId);

      return DataDelete();
    }
    #endregion

    #region DataDelete Methods
    /// <summary>
    /// Sets the DetailData property and calls the DataDelete method.
    /// </summary>
    /// <param name="entity">The record(s) to delete</param>
    /// <returns># of rows deleted, or zero if no rows deleted</returns>
    public int DataDelete(Customer entity) {
      DetailData = new Customer();

      // Fill in DetailData with search information to delete
      DetailData = entity;

      return DataDelete();
    }

    /// <summary>
    /// Deletes the entity contained in the DetailData object
    /// </summary>
    /// <returns>1 if deleted, otherwise zero</returns>
    public int DataDelete()
    {
      LastException = null;
      LastExceptionMessage = string.Empty;
      try {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Delete the Record(s)
        TotalRecords = _Manager.Delete(DetailData);
               
        // Get XML Audit String
        XmlAuditString = _Manager.AuditRowAsXml;

        // Set the SQL string for debugging
        SqlString = _Manager.SQL;
        if (TotalRecords >= 1) {
          // Delete a single item from the Collection
          DataCollection.Remove(DetailData);
        }
        else {
          LastException = new Exception(base.NoRowsAffectedMessageDelete);
          HandleExceptionMessages(LastException.Message);
        }
      }
      catch (Exception ex) {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return TotalRecords;
    }
    #endregion

    #region SaveCurrent Method
    /// <summary>
    /// Clones the currently selected Entity object. 
    /// Call this prior editing the current record.
    /// If you wish to undo the changes made, call the Undo() method
    /// </summary>
    public void SaveCurrent()
    {
      if (DetailData != null) {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        OriginalEntity = DetailData.CopyObject();
      }
    }
    #endregion

    #region Undo Method
    /// <summary>
    /// Restores the original data back to the current entity
    /// </summary>
    public void Undo()
    {
      if (OriginalEntity != null) {
        _Manager = new CustomerManager();

        DetailData = OriginalEntity.CopyObject();

        SetViewStateMode(PDSAUIState.ListOnly);
      }
    }
    #endregion

    #region Handle Custom Exceptions
    /// <summary>
    /// Call this method to handle any specific exceptions and display your own custom messages
    /// </summary>
    /// <param name="ex">An Exception object</param>
    /// <returns>False if you have NOT handled the exception.</returns>
    protected bool HandleCustomExceptions(Exception ex)
    {
      bool ret = false;

      // Check to see if you want to handle any exceptions yourself.
      // The following is an example of checking for a duplicate primary key error in SQL Server
      //if (ex.InnerException is System.Data.SqlClient.SqlException)
      //{
      //  System.Data.SqlClient.SqlException sqlEx = (System.Data.SqlClient.SqlException)ex.InnerException;
      //  if (sqlEx.Number == 2627) // Primary key Violation from SQL Server
      //    this.AddBusinessRuleMessage("OrderId", "You have entered duplicate data for this record.");

      //  ret = true;
      //}

      return ret;
    }
    #endregion

    #region HandleExceptionMessages Method
    /// <summary>
    /// Sets an exception object into the LastException property of this ViewModel class
    /// </summary>
    /// <param name="ex">An exception object</param>
    protected override void HandleExceptionMessages(Exception ex)
    {
      base.HandleExceptionMessages(ex);

      // Add your own exception logging here
    }

    /// <summary>
    /// Sets an exception message into the LastExceptionMessage property of this ViewModel class 
    /// </summary>
    /// <param name="message">The message to set</param>
    protected override void HandleExceptionMessages(string message)
    {
      base.HandleExceptionMessages(message);

      // Add your own exception logging here
    }
    #endregion

  }
}
