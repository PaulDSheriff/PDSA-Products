using PDSA.UI;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Sample.Project
{
  /// <summary>
  /// All your controllers should inherit from this controller
  /// </summary>
  public class AppController : Controller
  {
    /// <summary>
    /// Add custom validation or state messages to the model state collection
    /// </summary>
    /// <param name="viewModel">An instance of a View Model</param>
    protected void CheckViewModelState(PDSAUIViewModelBase viewModel) {
      // This helps us determine if any business rules are duplicated 
      // between data annotations and your business rules
      List<ModelError> modelErrors = ModelState.Values.SelectMany(e => e.Errors).ToList();

      if (viewModel.ValidationFailed || ModelState.IsValid == false) {
        foreach (PDSAValidationRule item in viewModel.ValidationRuleFailures) {
          if (modelErrors.Any(e => e.ErrorMessage == item.Message) == false) {
            this.ModelState.AddModelError(item.PropertyName, item.Message);
          }
        }
      }
    }
  }
}
