using PDSA.Common;
using PDSA.DataAccess;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace Sample.Project
{
  #region Person Class
  /// <summary>
  /// This class contains properties that map to each field in the PDSASample.Person table.
  /// </summary>
  
  [DataContract]
  public partial class Person : PDSADataEntityBase
  {
    #region Person Constructors
    /// <summary>
    /// Constructor for Person class
    /// </summary>
    public Person() : base()
    {
    }

    /// <summary>
    /// Constructor for Person class
    /// </summary>
    /// <param name="loginName">A login name to initialize the PDSALoginName property</param>
    public Person(string loginName) : base(loginName)
    {
    }
    #endregion

    #region Private Variables
    private int? _PersonId  = null;
    private string _FirstName  = null;
    private string _LastName  = null;
    private string _EmailAddress  = null;
    private string _InsertName  = null;
    private DateTime? _InsertDate  = null;
    private string _UpdateName  = null;
    private DateTime? _UpdateDate  = null;
    private short? _ConcurrencyValue  = null;
    #endregion
    
    #region Public Properties
    /// <summary>
    /// Get/Set the PersonId value
    /// </summary>
    [DataMember]
    [Display(Description = "Person Id")]

    public int? PersonId 
    { 
      get { return _PersonId; }
      set 
      { 
        _PersonId = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the FirstName value
    /// </summary>
    [DataMember]
    [Display(Description = "First Name")]
[Required(ErrorMessage = "First Name must be filled in.")]

    public string FirstName 
    { 
      get { return _FirstName; }
      set 
      { 
        _FirstName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the LastName value
    /// </summary>
    [DataMember]
    [Display(Description = "Last Name")]
[Required(ErrorMessage = "Last Name must be filled in.")]

    public string LastName 
    { 
      get { return _LastName; }
      set 
      { 
        _LastName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the EmailAddress value
    /// </summary>
    [DataMember]
    [Display(Description = "Email Address")]

    public string EmailAddress 
    { 
      get { return _EmailAddress; }
      set 
      { 
        _EmailAddress = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the InsertName value
    /// </summary>
    [DataMember]
    [Display(Description = "Insert Name")]
[Required(ErrorMessage = "Insert Name must be filled in.")]

    public string InsertName 
    { 
      get { return _InsertName; }
      set 
      { 
        _InsertName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the InsertDate value
    /// </summary>
    [DataMember]
    [Display(Description = "Insert Date")]
[Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "Insert Date must be between {1} and {2}")]

    public DateTime? InsertDate 
    { 
      get { return _InsertDate; }
      set 
      { 
        _InsertDate = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the UpdateName value
    /// </summary>
    [DataMember]
    [Display(Description = "Update Name")]
[Required(ErrorMessage = "Update Name")]

    public string UpdateName 
    { 
      get { return _UpdateName; }
      set 
      { 
        _UpdateName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the UpdateDate value
    /// </summary>
    [DataMember]
    [Display(Description = "Update Date")]
[Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "Update Date must be between {1} and {2}")]

    public DateTime? UpdateDate 
    { 
      get { return _UpdateDate; }
      set 
      { 
        _UpdateDate = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the ConcurrencyValue value
    /// </summary>
    [DataMember]
    [Display(Description = "Concurrency Value")]

    public short? ConcurrencyValue 
    { 
      get { return _ConcurrencyValue; }
      set 
      { 
        _ConcurrencyValue = value; 
        IsDirty = true;
      } 
    }
    

    #endregion
  }
  #endregion

  #region PersonSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  
  [DataContract]
  public partial class PersonSearch : PDSADataEntityBase
  {
    #region PersonSearch Constructor
    /// <summary>
    /// Constructor for PersonSearch class
    /// </summary>
    public PersonSearch() : base()
    {
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the FirstName value for searching
    /// </summary>
    [DataMember]
    [Display(Description = "First Name")]
    public string FirstName { get; set; }
    #endregion
  }
  #endregion

  #region PersonManager Class
  /// <summary>
  /// This class is used to list, add, edit, delete, and search for data in the PDSASample.Person table.
  /// This class is generated by the Haystack Code Generator for .NET.
  /// DO NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class PersonManager : PDSADataManagerBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for PersonManager class
    /// </summary>
    public PersonManager() : base()
    {
      InitSql();
    }

    /// <summary>
    /// Constructor for PersonManager class
    /// <param name="provider">A PDSADataProvider object</param>
    /// </summary>
    public PersonManager(PDSADataProviderBase provider) : base(provider)
    {
      InitSql();
    }
    #endregion
    
    #region Public Properties
    /// <summary>
    /// Get/Set the last Entity values after Insert or Update
    /// </summary>
    public Person LastUpdatedEntity { get; set; }
    #endregion

    #region DataTableToList Method
    /// <summary>
    /// Convert a DataTable to a List of Person objects
    /// </summary>
    /// <param name="dt">A DataTable object from which to build a list</param>
    /// <returns>A List of Person objects</returns>
    public virtual List<Person> DataTableToList(DataTable dt)
    {
      List<Person> ret = new List<Person>();

      var query =
        (from dr in dt.AsEnumerable()
         select new Person
         {
           PersonId = dr.GetDataAs<int?>("PersonId"),
           FirstName = dr.GetDataAs<string>("FirstName"),
           LastName = dr.GetDataAs<string>("LastName"),
           EmailAddress = dr.GetDataAs<string>("EmailAddress"),
           InsertName = dr.GetDataAs<string>("InsertName"),
           InsertDate = dr.GetDataAs<DateTime?>("InsertDate"),
           UpdateName = dr.GetDataAs<string>("UpdateName"),
           UpdateDate = dr.GetDataAs<DateTime?>("UpdateDate"),
           ConcurrencyValue = dr.GetDataAs<short?>("ConcurrencyValue"),
           IsDirty=false
         });

      if (query != null)
      {
        ret = query.ToList();
      }

      return ret;
    }
    #endregion

    #region BuildCollection Methods
    /// <summary>
    /// Return a collection of Person objects
    /// </summary>
    /// <returns>A List of Person objects</returns>
    public virtual List<Person> BuildCollection()
    {
      return BuildCollection(new Person());
    }

    /// <summary>
    /// Return a collection of Person objects
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A List of Person objects</returns>
    public virtual List<Person> BuildCollection(Person search)
    {
      DataSet ds = null;
      DataTable dt = null;
      List<Person> ret = new List<Person>();

      ds = GetDataSet(search);

      if (ds.Tables.Count > 0) {
        dt = ds.Tables[0];
        ret = DataTableToList(dt);
        RowsAffected = ret.Count;
      }

      return ret;
    }
    #endregion

    #region GetDataTable Methods
    /// <summary>
    /// Return a DataTable of Person objects
    /// </summary>
    /// <returns>A DataTable of Person objects, or null if no data found</returns>
    public override DataTable GetDataTable()
    {
      return GetDataTable(new Person());
    }

    /// <summary>
    /// Return a DataTable of Person objects
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A DataTable of Person objects</returns>
    public virtual DataTable GetDataTable(Person search)
    {
      return base.GetDataTable<Person>(search);
    }
    #endregion

    #region GetDataSet Methods
    /// <summary>
    /// Return a DataSet of Person objects
    /// </summary>
    /// <returns>A DataSet of Person objects</returns>
    public override DataSet GetDataSet()
    {
      return GetDataSet(new Person());
    }

    /// <summary>
    /// Return a DataSet of Person objects
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A DataSet of Person objects</returns>
    public virtual DataSet GetDataSet(Person search)
    {
      return base.GetDataSet<Person>(search);
    }
    #endregion
    
    #region GetDataAsJSON Methods
    /// <summary>
    /// Calls BuildCollection to get collection of Person objects to serialize as JSON
    /// </summary>
    /// <returns>A JSON array of Person objects</returns>
    public virtual string GetDataAsJSON() {
      return GetDataAsJSON(new Person());
    }

    /// <summary>
    /// Calls BuildCollection to get collection of Person objects to serialize as JSON
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A JSON array of Person objects</returns>
    public virtual string GetDataAsJSON(Person search) {
      string ret = string.Empty;
     
      try {
        ret = PDSAString.GetAsJSON<Person>(typeof(List<Person>), BuildCollection(search));
      }
      catch (Exception ex) {
        base.ErrorOccurred = true;
        base.Message = ex.ToString();

        // Handle the error from the caller
        throw ex;
      }

      return ret;
    }
    #endregion

    #region GetDataAsXML Methods
    /// <summary>
    /// Return an XML string of Person objects
    /// </summary>
    /// <returns>An XML string of Person objects</returns>
    public virtual string GetDataAsXML() {
      return GetDataAsXML(new Person());
    }

    /// <summary>
    /// Return an XML string of Person objects
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>An XML string of Person objects</returns>
    public virtual string GetDataAsXML(Person search) {
      string ret = string.Empty;
      DataSet ds = new DataSet();

      ds = GetDataSet(search);
      ret = ds.GetDataSetAsXml();

      return ret;
    }
    #endregion

    #region GetDataAsExcelString Methods
    /// <summary>
    /// Return a comma-delimited string suitable for Excel of Person objects
    /// </summary>
    /// <returns>A comma-delimited string suitable for Excel of Person objects</returns>
    public virtual string GetDataAsExcelString() {
      return GetDataAsExcelString(new Person());
    }

    /// <summary>
    /// Return a comma-delimited string suitable for Excel of Person objects
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A comma-delimited string suitable for Excel of Person objects</returns>
    public virtual string GetDataAsExcelString(Person search) {
      string ret = string.Empty;
      DataSet ds = new DataSet();

      ds = GetDataSet(search);
      ret = ds.GetDataSetAsExcelString();

      return ret;
    }
    #endregion

    #region Load Method
    /// <summary>
    /// Get a single Person based on the primary key passed in.
    /// If the row is not found, the primary key property in the returned object will be null.
    /// </summary>
    /// <param name="personId">The value of the primary key of the row to load</param>
    /// <returns>A Person object</returns>
    public virtual Person Load(int? personId)
    {
      DataTable dt = new DataTable();
      Person ret = new Person();

      base.Init();
      
      // Reinitialize SQL Builder
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLSelect = "PDSASample.Person_SelectByPK";
      SqlBuilder.SelectWhereItems.Clear();
      SqlBuilder.OrderByItems.Clear();
      SqlBuilder.AddSelectWhereItem(PersonManager.PropertyNames.PersonId, PersonManager.ColumnNames.PersonId, PDSASQLBuilder.EQUAL_TO);
      
      ret.PersonId = personId;

      var list = BuildCollection(ret);

      if (list.Count > 0) {
         ret = list[0];
         RowsAffected = 1;
      }
      else {
         ret.PersonId = null;
      }

      return ret;
    }
    #endregion

    #region RowCount Methods
    /// <summary>
    /// Count all records in the PDSASample.Person table
    /// </summary>
    /// <returns>A count of total records</returns>
    public override int RowCount()
    {     
      return RowCount(new Person());
    }

    /// <summary>
    /// Count all records in the PDSASample.Person table using search parameters
    /// </summary>
    /// <param name="search">An instance of a Person object with values to search upon</param>
    /// <returns>A count of records in the search</returns>
    public virtual int RowCount(Person search)
    {
      return base.RowCount<Person>(search);
    }
    #endregion

    #region InitSql Method
    /// <summary>
    /// Initialize the SqlBuilder object to a default start sate
    /// </summary>
    protected override void InitSql()
    {
      // Initialize SqlBuilder object
      base.InitSql();

      // Initialize for Selecting
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLSelect = "PDSASample.Person_Search";
      SqlBuilder.AddSelectWhereItem(PersonManager.PropertyNames.FirstName, PersonManager.ColumnNames.FirstName, "LIKE", PDSAWildCard.WildCardAfter);
      SqlBuilder.AddOrderByItem(PersonManager.ColumnNames.FirstName);
    }
    #endregion
        
    #region InitRowCountSql Method
    /// <summary>
    /// Initialize the SELECT COUNT(*) statement
    /// </summary>
    protected override void InitRowCountSql() {
      base.InitRowCountSql();

      // Initialize for Row Count
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLRowCount = "PDSASample.Person_RowCount";
    }
    #endregion

    #region InitInsertSql Method
    /// <summary>
    /// Initialize the INSERT statement
    /// </summary>
    protected override void InitInsertSql() {
      base.InitInsertSql();

      // Initialize for Inserting      
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLInsert = "PDSASample.Person_Insert";
    }
    #endregion

    #region InitUpdateSql Method
    /// <summary>
    /// Initialize the UPDATE statement
    /// </summary>
    protected override void InitUpdateSql() {
      base.InitUpdateSql();

      // Initialize for Updating
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLUpdate = "PDSASample.Person_Update";
    }
    #endregion
    
    #region InitDeleteSql Method
    /// <summary>
    /// Initialize the DELETE statement
    /// </summary>
    protected override void InitDeleteSql() {
      base.InitDeleteSql();

      // Initialize for Deleting
      SqlBuilder.IsStoredProc = true;
      SqlBuilder.SQLDelete = "PDSASample.Person_DeleteByPK";
    }
    #endregion

    #region InitInsertParameters Method
    /// <summary>
    /// Initialize all parameters for the INSERT statement
    /// </summary>
    protected override void InitInsertParameters() {
      base.InitInsertParameters();

      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.FirstName, PersonManager.PropertyNames.FirstName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.LastName, PersonManager.PropertyNames.LastName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.EmailAddress, PersonManager.PropertyNames.EmailAddress));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.InsertName, PersonManager.PropertyNames.InsertName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.InsertDate, PersonManager.PropertyNames.InsertDate));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.UpdateName, PersonManager.PropertyNames.UpdateName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.UpdateDate, PersonManager.PropertyNames.UpdateDate));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.ConcurrencyValue, PersonManager.PropertyNames.ConcurrencyValue));
    }
    #endregion
    
    #region InitUpdateParameters Method
    /// <summary>
    /// Initialize all parameters for the UPDATE statement
    /// </summary>
    protected override void InitUpdateParameters() {
      base.InitUpdateParameters();

      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.FirstName, PersonManager.PropertyNames.FirstName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.LastName, PersonManager.PropertyNames.LastName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.EmailAddress, PersonManager.PropertyNames.EmailAddress));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.UpdateName, PersonManager.PropertyNames.UpdateName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.UpdateDate, PersonManager.PropertyNames.UpdateDate));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.PersonId, PersonManager.PropertyNames.PersonId));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(PersonManager.PropertyNames.ConcurrencyValue, PersonManager.PropertyNames.ConcurrencyValue));
    }
    #endregion
            
    #region InitDeleteParameters Method
    /// <summary>
    /// Initialize all parameters for the DELETE statement
    /// </summary>
    protected override void InitDeleteParameters() {
      base.InitDeleteParameters();

      SqlBuilder.AddDeleteWhereItem(PersonManager.PropertyNames.PersonId, PersonManager.ColumnNames.PersonId, "=");
      SqlBuilder.AddDeleteWhereItem(PersonManager.PropertyNames.ConcurrencyValue, PersonManager.ColumnNames.ConcurrencyValue, "=");
    }
    #endregion

    #region Insert Method
    /// <summary>
    /// Insert a new Person object
    /// </summary>
    /// <param name="entity">The Person object with the information of which Person object to insert</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Insert(Person entity)
    {
      bool ret = false;
      PersonValidator validator = new PersonValidator(entity);
      
      // Set last updated entity
      LastUpdatedEntity = entity;
      
      // Insert the data
      ret = base.Insert<Person>(entity, validator);

      if (RowsAffected > 0 || SqlBuilder.IsStoredProc) {        
        // Get Generated IDENTITY column
        if (LastIdentity != null) {
          entity.PersonId =
              Convert.ToInt32(LastIdentity);
        }
      }

      return ret;
    }
    #endregion

    #region Update Method
    /// <summary>
    /// Update an existing Person object
    /// </summary>
    /// <param name="entity">The Person object with the information to update</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Update(Person entity) {
      return Update(entity, entity);
    }

    /// <summary>
    /// Update an existing Person object using Audit tracking.
    /// </summary>
    /// <param name="entity">The Person object with the information to update</param>
    /// <param name="oldEntity">The original data to be updated (used for Audit tracking)</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Update(Person entity, Person oldEntity)
    {
      bool ret = false;
      PersonValidator validator = new PersonValidator(entity);

      // Set last updated entity
      LastUpdatedEntity = entity;
           
      // Update the data
      ret = Update<Person>(entity, oldEntity, validator);
      // Increment concurrency field
      entity.ConcurrencyValue += 1;
    
      return ret;
    }
    #endregion

    #region Delete Method
    /// <summary>
    /// Delete existing Person object(s)
    /// </summary>
    /// <param name="entity">The Person object with the information of which Person object(s) to delete</param>
    /// <returns>Total Number of Rows Deleted</returns>
    public virtual int Delete(Person entity)
    {
      return base.Delete<Person>(entity);
    }
    #endregion

    #region InitXmlAuditProperties Method
    /// <summary>
    /// Build the collection of properties that will participate in auditing
    /// </summary>
    protected override void InitXmlAuditProperties()
    {
      // Only use properties marked as Auditable in Haystack
      XmlAuditProperties.Add("PersonId");
      XmlAuditProperties.Add("FirstName");
      XmlAuditProperties.Add("LastName");
      XmlAuditProperties.Add("EmailAddress");
      XmlAuditProperties.Add("InsertName");
      XmlAuditProperties.Add("InsertDate");
      XmlAuditProperties.Add("UpdateName");
      XmlAuditProperties.Add("UpdateDate");
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Creates an instance of the PersonValidator object
    /// using the Person object passed to this method
    /// Validates all Data Annotations on the Person object
    /// and any custom rules you define in the PersonValidator.Validate() method
    /// </summary>
    /// <param name="entity">A Person object</param>
    /// <returns>True if all validations pass</returns>
    public virtual bool Validate(Person entity)
    {
      return base.Validate(new PersonValidator(entity));
    }
    #endregion
    
    #region ColumnNames Class
    /// <summary>
    /// Contains static string properties that represent the name of each column in the table referenced by Person class.
    /// This class is generated by the Haystack Code Generator for .NET.
    /// DO NOT modify this class as it is intended to be able to be re-generated at any time.
    /// </summary>
    public class ColumnNames
    {
    /// <summary>
    /// Returns 'PersonId'
    /// </summary>
    public static string PersonId = "PersonId";
    /// <summary>
    /// Returns 'FirstName'
    /// </summary>
    public static string FirstName = "FirstName";
    /// <summary>
    /// Returns 'LastName'
    /// </summary>
    public static string LastName = "LastName";
    /// <summary>
    /// Returns 'EmailAddress'
    /// </summary>
    public static string EmailAddress = "EmailAddress";
    /// <summary>
    /// Returns 'InsertName'
    /// </summary>
    public static string InsertName = "InsertName";
    /// <summary>
    /// Returns 'InsertDate'
    /// </summary>
    public static string InsertDate = "InsertDate";
    /// <summary>
    /// Returns 'UpdateName'
    /// </summary>
    public static string UpdateName = "UpdateName";
    /// <summary>
    /// Returns 'UpdateDate'
    /// </summary>
    public static string UpdateDate = "UpdateDate";
    /// <summary>
    /// Returns 'ConcurrencyValue'
    /// </summary>
    public static string ConcurrencyValue = "ConcurrencyValue";
    }
    #endregion
        
    #region PropertyNames Partial Class
    /// <summary>
    /// Contains static string properties that represent the name of each property in the Person class.
    /// This class is generated by the Haystack Code Generator for .NET.
    /// DO NOT modify this class as it is intended to be able to be re-generated at any time.
    ///
    /// NOTE: You can add additional property names in the PropertyNames class located in the PersonValidator class.
    /// </summary>
    public partial class PropertyNames
    {
    /// <summary>
    /// Returns 'PersonId'
    /// </summary>
    public static string PersonId = "PersonId";
    /// <summary>
    /// Returns 'FirstName'
    /// </summary>
    public static string FirstName = "FirstName";
    /// <summary>
    /// Returns 'LastName'
    /// </summary>
    public static string LastName = "LastName";
    /// <summary>
    /// Returns 'EmailAddress'
    /// </summary>
    public static string EmailAddress = "EmailAddress";
    /// <summary>
    /// Returns 'InsertName'
    /// </summary>
    public static string InsertName = "InsertName";
    /// <summary>
    /// Returns 'InsertDate'
    /// </summary>
    public static string InsertDate = "InsertDate";
    /// <summary>
    /// Returns 'UpdateName'
    /// </summary>
    public static string UpdateName = "UpdateName";
    /// <summary>
    /// Returns 'UpdateDate'
    /// </summary>
    public static string UpdateDate = "UpdateDate";
    /// <summary>
    /// Returns 'ConcurrencyValue'
    /// </summary>
    public static string ConcurrencyValue = "ConcurrencyValue";
    }
    #endregion
  }
  #endregion

  #region PersonValidator Class
  /// <summary>
  /// Used to validate all properties of the Person class.
  /// This class is generated by the Haystack Code Generator for .NET.
  /// You should NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class PersonValidator : PDSADataValidatorBase
  {
    /// <summary>
    /// Constructor for PersonValidator class
    /// <param name="provider">A Person object to validate</param>
    /// </summary>
    public PersonValidator(Person entity) : base()
    {
      EntityToValidate = entity;
    }

    private Person EntityToValidate;
  }
  #endregion
}
