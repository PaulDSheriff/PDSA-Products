﻿Running this Sample
----------------------------------------------------------
You may need to modify the connection string in the Web.config file.
You can find the stored procedures for the generated classes in the \SqlScripts folder of this sample.


This sample was created from a normal ASP.NET MVC Web Application.
This sample contains generated code from Haystack.
We chose the "Generate Stored Procedures" radio button when setting up the project.

