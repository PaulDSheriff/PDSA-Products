﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DataAccessLayerSample.Startup))]
namespace DataAccessLayerSample
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
