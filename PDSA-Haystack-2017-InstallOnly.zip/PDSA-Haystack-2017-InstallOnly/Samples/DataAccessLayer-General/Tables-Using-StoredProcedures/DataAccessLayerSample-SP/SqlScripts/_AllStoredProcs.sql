/************************************************************
'* This stored procedure is used to retrieve all rows & columns from the
'* PDSASample.Customer table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_Search]
GO

CREATE PROCEDURE PDSASample.[Customer_Search]
@CompanyName varchar(75) 
AS

declare @ret int;
select @ret = 0;

SELECT 
CustomerId
,CompanyName
,FirstName
,LastName
,Title
,Address1
,Address2
,TotalSales
,City
,StateCode
,PostalCode
,Country
,Phone
,Fax
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
FROM PDSASample.Customer
WHERE 
(@CompanyName IS NULL OR CompanyName LIKE @CompanyName + '%')

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to retrieve all columns from
'* the PDSASample.Customer table 
'* for a single row of data based on the primary key passed in
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_SelectByPK]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_SelectByPK]
GO
CREATE PROCEDURE PDSASample.[Customer_SelectByPK]
@CustomerId int 
AS

declare @ret int;
select @ret = 0;

SELECT 
CustomerId
,CompanyName
,FirstName
,LastName
,Title
,Address1
,Address2
,TotalSales
,City
,StateCode
,PostalCode
,Country
,Phone
,Fax
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
FROM PDSASample.Customer
WHERE 
CustomerId = @CustomerId

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to count all rows in the 
'* PDSASample.Customer table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_RowCount]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_RowCount]
GO
CREATE PROCEDURE PDSASample.[Customer_RowCount]
AS

declare @ret int;
select @ret = 0;

SELECT Count(*) As NumRecs FROM PDSASample.Customer

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to INSERT all columns into the 
'* PDSASample.Customer table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_Insert]
GO
CREATE PROCEDURE PDSASample.[Customer_Insert]
@CompanyName varchar(75) 
,@FirstName varchar(50) 
,@LastName varchar(100) 
,@Title varchar(100)  = null
,@Address1 varchar(255) 
,@Address2 varchar(255)  = null
,@TotalSales money  = null
,@City varchar(100) 
,@StateCode varchar(25) 
,@PostalCode varchar(25) 
,@Country varchar(35)  = null
,@Phone varchar(255) 
,@Fax varchar(255)  = null
,@EmailAddress varchar(150) 
,@InsertName varchar(50) 
,@InsertDate datetime 
,@UpdateName varchar(50) 
,@UpdateDate datetime 
,@ConcurrencyValue smallint 
AS

declare @ret int;
select @ret = 0;

INSERT INTO PDSASample.Customer
(
CompanyName
,FirstName
,LastName
,Title
,Address1
,Address2
,TotalSales
,City
,StateCode
,PostalCode
,Country
,Phone
,Fax
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
) 
VALUES 
(
@CompanyName
,@FirstName
,@LastName
,@Title
,@Address1
,@Address2
,@TotalSales
,@City
,@StateCode
,@PostalCode
,@Country
,@Phone
,@Fax
,@EmailAddress
,@InsertName
,@InsertDate
,@UpdateName
,@UpdateDate
,@ConcurrencyValue
)

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to UPDATE all columns in the
'* PDSASample.Customer table for a single row of data based on a primary key.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_Update]
GO
CREATE PROCEDURE PDSASample.[Customer_Update]
@CustomerId int 
,@CompanyName varchar(75)
,@FirstName varchar(50)
,@LastName varchar(100)
,@Title varchar(100)
,@Address1 varchar(255)
,@Address2 varchar(255)
,@TotalSales money
,@City varchar(100)
,@StateCode varchar(25)
,@PostalCode varchar(25)
,@Country varchar(35)
,@Phone varchar(255)
,@Fax varchar(255)
,@EmailAddress varchar(150)
,@UpdateName varchar(50)
,@UpdateDate datetime
,@ConcurrencyValue smallint
AS

declare @ret int;
select @ret = 0;

UPDATE PDSASample.Customer
SET 
CompanyName = @CompanyName
,FirstName = @FirstName
,LastName = @LastName
,Title = @Title
,Address1 = @Address1
,Address2 = @Address2
,TotalSales = @TotalSales
,City = @City
,StateCode = @StateCode
,PostalCode = @PostalCode
,Country = @Country
,Phone = @Phone
,Fax = @Fax
,EmailAddress = @EmailAddress
,UpdateName = @UpdateName
,UpdateDate = @UpdateDate
,ConcurrencyValue = ConcurrencyValue + 1
WHERE
CustomerId = @CustomerId
 And (ConcurrencyValue = @ConcurrencyValue OR ConcurrencyValue is null)

IF @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @@ERROR;
GO

/***************************************************************
'* This stored procedure is used to DELETE a single row from the 
'* PDSASample.Customer table based on the primary key value passed in.
'***************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Customer_DeleteByPK]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Customer_DeleteByPK]
GO
CREATE PROCEDURE PDSASample.[Customer_DeleteByPK]
@CustomerId int
,@ConcurrencyValue smallint
AS

declare @ret int;
select @ret = 0;

DELETE FROM PDSASample.Customer
WHERE
CustomerId = @CustomerId
 And (ConcurrencyValue = @ConcurrencyValue OR ConcurrencyValue is null)

if @@ROWCOUNT = 0
  SELECT @ret = -1;
  
RETURN @ret;
GO




/************************************************************
'* This stored procedure is used to retrieve all rows & columns from the
'* PDSASample.Person table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_Search]
GO

CREATE PROCEDURE PDSASample.[Person_Search]
@FirstName varchar(50) 
AS

declare @ret int;
select @ret = 0;

SELECT 
PersonId
,FirstName
,LastName
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
FROM PDSASample.Person
WHERE 
(@FirstName IS NULL OR FirstName LIKE @FirstName + '%')

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to retrieve all columns from
'* the PDSASample.Person table 
'* for a single row of data based on the primary key passed in
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_SelectByPK]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_SelectByPK]
GO
CREATE PROCEDURE PDSASample.[Person_SelectByPK]
@PersonId int 
AS

declare @ret int;
select @ret = 0;

SELECT 
PersonId
,FirstName
,LastName
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
FROM PDSASample.Person
WHERE 
PersonId = @PersonId

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to count all rows in the 
'* PDSASample.Person table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_RowCount]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_RowCount]
GO
CREATE PROCEDURE PDSASample.[Person_RowCount]
AS

declare @ret int;
select @ret = 0;

SELECT Count(*) As NumRecs FROM PDSASample.Person

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to INSERT all columns into the 
'* PDSASample.Person table.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_Insert]
GO
CREATE PROCEDURE PDSASample.[Person_Insert]
@FirstName varchar(50) 
,@LastName varchar(50) 
,@EmailAddress varchar(250)  = null
,@InsertName nvarchar(50) 
,@InsertDate datetime 
,@UpdateName nvarchar(50) 
,@UpdateDate datetime 
,@ConcurrencyValue smallint 
AS

declare @ret int;
select @ret = 0;

INSERT INTO PDSASample.Person
(
FirstName
,LastName
,EmailAddress
,InsertName
,InsertDate
,UpdateName
,UpdateDate
,ConcurrencyValue
) 
VALUES 
(
@FirstName
,@LastName
,@EmailAddress
,@InsertName
,@InsertDate
,@UpdateName
,@UpdateDate
,@ConcurrencyValue
)

if @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @ret;
GO

/************************************************************
'* This stored procedure is used to UPDATE all columns in the
'* PDSASample.Person table for a single row of data based on a primary key.
'************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_Update]
GO
CREATE PROCEDURE PDSASample.[Person_Update]
@PersonId int 
,@FirstName varchar(50)
,@LastName varchar(50)
,@EmailAddress varchar(250)
,@UpdateName nvarchar(50)
,@UpdateDate datetime
,@ConcurrencyValue smallint
AS

declare @ret int;
select @ret = 0;

UPDATE PDSASample.Person
SET 
FirstName = @FirstName
,LastName = @LastName
,EmailAddress = @EmailAddress
,UpdateName = @UpdateName
,UpdateDate = @UpdateDate
,ConcurrencyValue = ConcurrencyValue + 1
WHERE
PersonId = @PersonId
 And (ConcurrencyValue = @ConcurrencyValue OR ConcurrencyValue is null)

IF @@ROWCOUNT = 0
  SELECT @ret = -1;

RETURN @@ERROR;
GO

/***************************************************************
'* This stored procedure is used to DELETE a single row from the 
'* PDSASample.Person table based on the primary key value passed in.
'***************************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PDSASample.[Person_DeleteByPK]') AND type in (N'P', N'PC'))
DROP PROCEDURE PDSASample.[Person_DeleteByPK]
GO
CREATE PROCEDURE PDSASample.[Person_DeleteByPK]
@PersonId int
,@ConcurrencyValue smallint
AS

declare @ret int;
select @ret = 0;

DELETE FROM PDSASample.Person
WHERE
PersonId = @PersonId
 And (ConcurrencyValue = @ConcurrencyValue OR ConcurrencyValue is null)

if @@ROWCOUNT = 0
  SELECT @ret = -1;
  
RETURN @ret;
GO




