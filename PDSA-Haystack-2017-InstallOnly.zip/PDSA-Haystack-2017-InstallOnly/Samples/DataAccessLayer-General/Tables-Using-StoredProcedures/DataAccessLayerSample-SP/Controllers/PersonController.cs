using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

using Sample.Project;

namespace Sample.Project
{
   public class PersonController : AppController
   {
      #region Constructor
      /// <summary>
      /// Constructor for PersonController class
      /// </summary>
      /// <returns>An ActionResult that contains an instance of PersonViewModel</returns>
      public PersonController() : base()
      {
      }
      #endregion

      /// <summary>
      /// Executes when browser issues a Get request for /Person and 
      /// directs to the Index view
      /// </summary>
      /// <returns>An ActionResult that contains an instance of PersonViewModel</returns>
      public ActionResult Person()
      {
        PersonViewModel vm = new PersonViewModel();
        ActionResult ret = View(vm);

        vm.HandleRequest();

        return ret;
      }

      /// <summary>
      /// Handles the browser Post request for Person form
      /// </summary>
      /// <param name="vm">A PersonViewModel instance for the entry</param>
      /// <returns>An ActionResult that either navigates to the index or stays on this view and displays errors</returns>
      [HttpPost]
      public ActionResult Person(PersonViewModel vm)
      {
        ActionResult ret = View(vm);
        if (!ModelState.IsValid && vm.EventCommand == "save")
        {
          vm.IsValid = false;
          vm.UIState = PDSA.UI.PDSAUIState.Unknown;
          vm.SetModeAfterValidation();
        }
        else
        {
          // Handle the cause of the post-back
          vm.HandleRequest();

          // If validation errors, add errors to ModelState
          CheckViewModelState(vm);

          if (vm.ValidationFailed == false)
          {
             // NOTE: Must clear the model state in order to bind
             //       the @Html helpers to the new model values
             ModelState.Clear();
          }
        }

        return ret;
      }
   }
}
