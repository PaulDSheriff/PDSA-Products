﻿Running this Sample
-----------------------------------------
You may need to modify the connection string in the Web.Config file

This sample was created from a normal ASP.NET MVC Web Application.
We then added the generated classes from Haystack and modified them using the changes documented below.


Changes Made to Generated Classes
=================================

CustomerManager.cs
------------------------------
Added method to load customers with orders
public List<Customer> GetCustomersWithOrders() {
  List<Customer> ret = new List<Customer>();

  SqlBuilder.Init();
  SqlBuilder.SelectWhereItems.Clear();
  SqlBuilder.SQLSelect = "SELECT * FROM PDSASample.Customer WHERE CustomerId IN (SELECT CustomerId FROM PDSASample.OrderHeader)";

  ret = BuildCollection();      

  return ret;
}


CustomerViewModel.cs
------------------------------
Added method to load customers with orders

public void GetCustomersWithOrders() {
  CustomerManager mgr = new CustomerManager();

  DataCollection = mgr.GetCustomersWithOrders();

  if (DataCollection.Count > 0) {
    if (DetailData.CustomerId == null) {
      DetailData = DataCollection[0];
    }

    LoadOrderHeaderCollection();
  }
}

CustomerController.cs
------------------------------
public ActionResult Customer() {
  CustomerViewModel vm = new CustomerViewModel();
  ActionResult ret = View(vm);

  vm.GetCustomersWithOrders();

  return ret;
}

[HttpPost]
public ActionResult Customer(CustomerViewModel vm) {
  ActionResult ret = View(vm);

  vm.GetCustomersWithOrders();
  vm.LoadOrderHeaderCollection();

  return ret;
}
