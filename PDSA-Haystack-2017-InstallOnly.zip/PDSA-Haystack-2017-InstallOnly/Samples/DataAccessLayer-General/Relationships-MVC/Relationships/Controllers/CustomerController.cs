using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

using Relationships;

namespace Relationships
{
  public class CustomerController : AppController
  {
    #region Constructor
    /// <summary>
    /// Constructor for CustomerController class
    /// </summary>
    /// <returns>An ActionResult that contains an instance of CustomerViewModel</returns>
    public CustomerController() : base() {
    }
    #endregion

    /// <summary>
    /// Executes when browser issues a Get request for /Customer and 
    /// directs to the Index view
    /// </summary>
    /// <returns>An ActionResult that contains an instance of CustomerViewModel</returns>
    [HttpGet]
    public ActionResult Customer() {
      CustomerViewModel vm = new CustomerViewModel();
      ActionResult ret = View(vm);

      vm.GetCustomersWithOrders();

      return ret;
    }

    /// <summary>
    /// Handles the browser Post request for Customer form
    /// </summary>
    /// <param name="vm">A CustomerViewModel instance for the entry</param>
    /// <returns>An ActionResult that either navigates to the index or stays on this view and displays errors</returns>
    [HttpPost]
    public ActionResult Customer(CustomerViewModel vm) {
      ActionResult ret = View(vm);

      vm.GetCustomersWithOrders();
      vm.LoadOrderHeaderCollection();

      return ret;
    }
  }
}
