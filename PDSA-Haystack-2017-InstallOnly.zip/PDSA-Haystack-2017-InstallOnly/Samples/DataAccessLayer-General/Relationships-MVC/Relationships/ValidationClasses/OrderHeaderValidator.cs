using System;
using PDSA.DataAccess;
using PDSA.Validation;

namespace Relationships
{
  /// <summary>
  /// This class is for your to modify if you need add more business rules
  /// </summary>
  public partial class OrderHeaderValidator
  {
    #region Init Method
    public override void Init() {
      base.Init();

      // Do any initialization here
      ClassName = "OrderHeaderValidator";

    }
    #endregion

    /// <summary>
    /// Validate all Data Annotations on OrderHeader object
    /// Validate any additional business rules defined here
    /// </summary>
    /// <returns>True if valid, False if not</returns>
    public override bool Validate()
    {
      IsValid = false;
      ValidationRuleFailures.Clear();
      
      // Leave the following line to check for Data Annotations
      base.Validate(EntityToValidate);

      
      //**********************************************************
      // Fill in any additional business rules here
      //**********************************************************
      
      // SAMPLE BUSINESS RULE (You can remove this comment)
      //if (EntityToValidate.Price < EntityToValidate.Cost)
      //{
      //  AddValidationMessage("Price", "Price must be less than the cost.");
      //}
      
      IsValid = (ValidationRuleFailures.Count == 0);
      
      // Check to see if we should throw an exception
      if (!IsValid && ThrowExceptionWhenValidationFails) {
        throw new PDSADataValidationException(
          string.Format(PDSAValidationMessages.BusinessRulesFailed, 
          "OrderHeader"),
          "OrderHeader", ValidationRuleFailures);
      }

      return IsValid;
    }
  }
}
