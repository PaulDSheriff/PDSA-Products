using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.WPF;
using PDSA.UI;

using Relationships.ViewModel;


namespace Relationships
{
  /// <summary>
  /// The user control for Add/Edit/Delete functionality
  /// </summary>
  public partial class ucOrderLineItemGrid : UserControl
  {
    /// <summary>
    /// The ViewModel used for all data access
    /// </summary>
    private OrderLineItemViewModel _ViewModel = null;

    #region Constructor
    /// <summary>
    /// Set the ViewModel variable by retrieving it from the XAML Resources
    /// </summary>
    public ucOrderLineItemGrid()
    {
      InitializeComponent();
      
      // Grab the Instance of the ViewModel
      _ViewModel = (OrderLineItemViewModel)this.FindResource("viewModel");
    }
    #endregion

    #region Loaded Event for User Control
    /// <summary>
    /// Fired when the user Control is first loaded.
    /// </summary>
    private void UserControlLoaded(object sender, RoutedEventArgs e)
    {
      // Load all Records
      LoadAll();

    }
    #endregion


    #region LoadAll Method
    /// <summary>
    /// Load all records by retrieving data from the ViewModel
    /// </summary>
    private void LoadAll()
    {
      _ViewModel.LoadAll();

      if (_ViewModel.DataCollection.Count > 0)
        lstData.SelectedIndex = 0;  // Select First Row
    }
    #endregion

    #region Edit Button Click Event
    /// <summary>
    /// Fired when the Edit button/image is clicked in the ListView
    /// Since the button clicked may not be the same one that is currently selected
    /// you must first locate the row of the one clicked on and set that to the current row
    /// </summary>
    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Display the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;

      _ViewModel.SetViewStateMode(PDSAUIState.Edit);
    }
    #endregion

    #region Delete Button Click Event
    /// <summary>
    /// Fired when the Delete button/image is clicked in the ListView
    /// Since the button clicked may not be the same one that is currently selected
    /// you must first locate the row of the one clicked on and set that to the current row
    /// </summary>
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      int index;

      // Display the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;
      index = lstData.SelectedIndex;

      // Ask to delete this Record
      if (MessageBox.Show("Delete this " + _ViewModel.RecordName + "?", "Delete " + _ViewModel.RecordName, MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No, MessageBoxOptions.None) == MessageBoxResult.Yes)
      {
        // Perform the Delete
        _ViewModel.DeleteByPK();

        // Reposition to next record
        PDSAWPFListView.Reposition(lstData, index);
      }
    }
    #endregion

    #region Add Event
    /// <summary>
    /// Fired when the Add button is clicked
    /// Set any default values in the CreateNewEntity method of the View Model
    /// </summary>
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.CreateNewEntity();

      // TODO: Set Cursor on first Control
      //txtFirstControl.Focus();
    }
    #endregion

    #region Save Event
    /// <summary>
    /// Fired when the Save button/image is clicked
    /// </summary>
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.DataSave();
         
      // add this to refresh the lstData items
      lstData.Items.Refresh();

      // Position to current item
      lstData.SelectedIndex = _ViewModel.DataCollection.IndexOf(_ViewModel.DetailData);
      lstData.ScrollIntoView(_ViewModel.DetailData);
    }
    #endregion
    
    #region Cancel Event
    /// <summary>
    /// Fired when the Cancel button/image is clicked
    /// Reverts back to original object and selects that item
    /// </summary>
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Store original data as we lose it after an Undo
      int index = lstData.SelectedIndex;
      bool editMode = (_ViewModel.UIState == PDSAUIState.Edit);

      // Return back to original values
      _ViewModel.Undo();
      if(_ViewModel.DataCollection.Count > 0)
      {
        if (editMode)
          // Update Collection 
          _ViewModel.DataCollection[index] = _ViewModel.DetailData;
        if (index == -1)
          lstData.SelectedIndex = 0;
        else
          // For some reason, WPF ListView loses the selected index after a cancel, so we need to reset
          lstData.SelectedIndex = index;
      }
      else
      {
        LoadAll();
      }
    }
    #endregion

    #region ListView SelectionChanged Event
    /// <summary>
    /// Fired when the user clicks on a new row in the ListView
    /// or if the the SelectedIndex property is set programmatically.
    /// </summary>
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Clone existing entity in case of Cancel
      _ViewModel.SaveCurrent();
    }
    #endregion

    #region Data Has Changed Methods
    /// <summary>
    /// Fired when any text box or other text content is changed by the user
    /// </summary>
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        _ViewModel.SetViewStateMode(PDSAUIState.Edit);
    }
    
    /// <summary>
    /// Fired when any check box/radio button's 'check' is changed by the user
    /// </summary>
    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        _ViewModel.SetViewStateMode(PDSAUIState.Edit);
    }
    #endregion
        
    #region Search Events
    /// <summary>
    /// Fired when the Search button/image is clicked
    /// </summary>
    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Search();
    }

    /// <summary>
    /// Fired when the Reset Search button/image is clicked
    /// </summary>
    private void btnResetSearch_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.ResetSearch();
    }
    #endregion

    #region Close Exception and Validation Click Events
    private void btnCloseValidation_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.ValidationFailed = false;
    }

    private void btnCloseException_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.ExceptionOccurred = false;
    }
    #endregion
  }
}
