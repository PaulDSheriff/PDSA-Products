using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using PDSA.DataAccess;

namespace OneToMany
{
  /// <summary>
  /// This class is for you to extend the CustomerManager class
  /// </summary>
  public partial class CustomerManager
  {
    #region Init Method
    public override void Init() {
      base.Init();

      // Do any initialization here
      ClassName = "CustomerManager";

    }
    #endregion

    #region HandleException Method
    public override void HandleException(Exception ex) {
      base.HandleException(ex);

      // TODO: Publish your exception here.
      // The properties LastException and Message contain the error information

      // Throw the exception so you can handle it from the caller
      // NOTE: You can remove this if you want
      throw ex;
    }
    #endregion

    #region TrackChanges Method
    /// <summary>
    /// Implement your change tracking logic here
    /// </summary>
    /// <param name="action">Can be 'Insert', 'Update', 'Delete', or anything you want</param>
    /// <param name="entity">The entity with values to track</param>
    /// <typeparam name="T">The type of the 'entity'</typeparam>
    public override void TrackChanges<T>(string action, T entity)
    {
    }
    #endregion
   
    #region GetMocks Method
    //public virtual List<Customer> GetMocks()
    //{
    //  List<Customer> ret = new List<Customer>();
    //  Customer entity = new Customer();
    //
    //  for (int index = 1; index <= 30; index++)
    //  {
    //    entity = new Customer();
    //
    //    ret.Add(entity);
    //  }
    //
    //  return ret;
    //}
    #endregion

    #region PropertyNames Partial Class
    // Add any additional properties here you wish to use with the PDSASqlBuilder
    public partial class PropertyNames
    {
      /// <summary>
      /// Returns 'Example1'
      /// </summary>
      // public static string Example1 = "Example1";
    }
    #endregion   
  }
}
