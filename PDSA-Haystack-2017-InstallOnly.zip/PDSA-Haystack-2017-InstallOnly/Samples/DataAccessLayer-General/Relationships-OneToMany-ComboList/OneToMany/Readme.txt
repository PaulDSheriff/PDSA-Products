﻿Running this Sample
-----------------------------------------
You may need to modify the connection string in the App.Config file

This sample was created from a normal WPF Application.
We then added the generated classes from Haystack and wrote code in the MainWindows.xaml.cs

See Chapter 10 for more information.