using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace OneToMany
{
  /// <summary>
  /// This class is for you to add additional properties to the Customer class
  /// </summary>
  public partial class Customer
  {
    #region Add Your Own Properties Here
    // Use this area to define...
    //   - Input and output properties to pass to stored procedures
    //   - Properties to use for searching
    //   - Any other properties you need
    #endregion
    
    #region Init Method
    /// <summary>
    /// Initialize properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize properties
      ClassName = "Customer";


      InsertName = this.PDSALoginName;
      InsertDate = DateTime.Now;
      UpdateName = this.PDSALoginName;
      UpdateDate = DateTime.Now;
      ConcurrencyValue = 1;
    }
    #endregion

    #region Properties for use with Stored Procedures
    /// <summary>
    /// Get/Set the RETURNVALUE from a stored procedure
    /// If you do not use Stored Procedures, feel free to comment this out
    /// </summary>
    public long RETURNVALUE { get; set; }
    #endregion

    #region CopyObject Method
    /// <summary>
    /// Create a clone of the current object
    /// </summary>
    /// <returns>A copy of an Customer object</returns>
    public Customer CopyObject()
    {
      return (Customer)this.MemberwiseClone();
    }
    #endregion
            
    #region Override of ToString()
    /// <summary>
    /// Override the ToString() to display fields and field values.
    /// This helps when viewing Collection classes in Visual Studio
    /// </summary>
    /// <returns>A string with data from this class</returns>
    public override string ToString()
    {
      string ret = string.Empty;

      ret += "CustomerId: " + CustomerId.ToString() + " ";
      
      return ret;
    }
    #endregion
  }
 
  #region CustomerSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  public partial class CustomerSearch
  {
    #region Public Properties
    // Add Your Own Search Properties Here

    #endregion

    #region Init Method
    /// <summary>
    /// Initialize search properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize search properties
      ClassName = "CustomerSearch";


    }
    #endregion
  }
  #endregion
}
