using PDSA.Common;
using PDSA.DataAccess;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;

namespace OneToMany
{
  #region Customer Class
  /// <summary>
  /// This class contains properties that map to each field in the PDSASample.Customer table.
  /// </summary>
  
  [DataContract]
  public partial class Customer : PDSADataEntityBase
  {
    #region Customer Constructors
    /// <summary>
    /// Constructor for Customer class
    /// </summary>
    public Customer() : base()
    {
    }

    /// <summary>
    /// Constructor for Customer class
    /// </summary>
    /// <param name="loginName">A login name to initialize the PDSALoginName property</param>
    public Customer(string loginName) : base(loginName)
    {
    }
    #endregion

    #region Private Variables
    private int? _CustomerId  = null;
    private string _CompanyName  = null;
    private string _FirstName  = null;
    private string _LastName  = null;
    private string _Title  = null;
    private string _Address1  = null;
    private string _Address2  = null;
    private decimal? _TotalSales  = null;
    private string _City  = null;
    private string _StateCode  = null;
    private string _PostalCode  = null;
    private string _Country  = null;
    private string _Phone  = null;
    private string _Fax  = null;
    private string _EmailAddress  = null;
    private string _InsertName  = null;
    private DateTime? _InsertDate  = null;
    private string _UpdateName  = null;
    private DateTime? _UpdateDate  = null;
    private short? _ConcurrencyValue  = null;
    #endregion
    
    #region Public Properties
    /// <summary>
    /// Get/Set the CustomerId value
    /// </summary>
    [DataMember]
    [Display(Description = "Customer Id")]

    public int? CustomerId 
    { 
      get { return _CustomerId; }
      set 
      { 
        _CustomerId = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the CompanyName value
    /// </summary>
    [DataMember]
    [Display(Description = "Company Name")]
[Required(ErrorMessage = "Company Name must be filled in.")]

    public string CompanyName 
    { 
      get { return _CompanyName; }
      set 
      { 
        _CompanyName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the FirstName value
    /// </summary>
    [DataMember]
    [Display(Description = "First Name")]
[Required(ErrorMessage = "First Name must be filled in.")]

    public string FirstName 
    { 
      get { return _FirstName; }
      set 
      { 
        _FirstName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the LastName value
    /// </summary>
    [DataMember]
    [Display(Description = "Last Name")]
[Required(ErrorMessage = "Last Name must be filled in.")]

    public string LastName 
    { 
      get { return _LastName; }
      set 
      { 
        _LastName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Title value
    /// </summary>
    [DataMember]
    [Display(Description = "Title")]

    public string Title 
    { 
      get { return _Title; }
      set 
      { 
        _Title = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Address1 value
    /// </summary>
    [DataMember]
    [Display(Description = "Address 1")]
[Required(ErrorMessage = "Address 1 must be filled in.")]

    public string Address1 
    { 
      get { return _Address1; }
      set 
      { 
        _Address1 = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Address2 value
    /// </summary>
    [DataMember]
    [Display(Description = "Address 2")]

    public string Address2 
    { 
      get { return _Address2; }
      set 
      { 
        _Address2 = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the TotalSales value
    /// </summary>
    [DataMember]
    [Display(Description = "Total Sales")]

    public decimal? TotalSales 
    { 
      get { return _TotalSales; }
      set 
      { 
        _TotalSales = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the City value
    /// </summary>
    [DataMember]
    [Display(Description = "City")]
[Required(ErrorMessage = "City must be filled in.")]

    public string City 
    { 
      get { return _City; }
      set 
      { 
        _City = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the StateCode value
    /// </summary>
    [DataMember]
    [Display(Description = "State Code")]
[Required(ErrorMessage = "State Code must be filled in.")]

    public string StateCode 
    { 
      get { return _StateCode; }
      set 
      { 
        _StateCode = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the PostalCode value
    /// </summary>
    [DataMember]
    [Display(Description = "Postal Code")]
[Required(ErrorMessage = "Postal Code must be filled in.")]

    public string PostalCode 
    { 
      get { return _PostalCode; }
      set 
      { 
        _PostalCode = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Country value
    /// </summary>
    [DataMember]
    [Display(Description = "Country")]

    public string Country 
    { 
      get { return _Country; }
      set 
      { 
        _Country = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Phone value
    /// </summary>
    [DataMember]
    [Display(Description = "Phone")]
[Required(ErrorMessage = "Phone must be filled in.")]

    public string Phone 
    { 
      get { return _Phone; }
      set 
      { 
        _Phone = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the Fax value
    /// </summary>
    [DataMember]
    [Display(Description = "Fax")]

    public string Fax 
    { 
      get { return _Fax; }
      set 
      { 
        _Fax = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the EmailAddress value
    /// </summary>
    [DataMember]
    [Display(Description = "Email Address")]
[Required(ErrorMessage = "Email Address must be filled in.")]

    public string EmailAddress 
    { 
      get { return _EmailAddress; }
      set 
      { 
        _EmailAddress = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the InsertName value
    /// </summary>
    [DataMember]
    [Display(Description = "Insert Name")]
[Required(ErrorMessage = "Insert Name must be filled in.")]

    public string InsertName 
    { 
      get { return _InsertName; }
      set 
      { 
        _InsertName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the InsertDate value
    /// </summary>
    [DataMember]
    [Display(Description = "Insert Date")]
[Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "Insert Date must be between {1} and {2}")]

    public DateTime? InsertDate 
    { 
      get { return _InsertDate; }
      set 
      { 
        _InsertDate = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the UpdateName value
    /// </summary>
    [DataMember]
    [Display(Description = "Update Name")]
[Required(ErrorMessage = "Update Name")]

    public string UpdateName 
    { 
      get { return _UpdateName; }
      set 
      { 
        _UpdateName = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the UpdateDate value
    /// </summary>
    [DataMember]
    [Display(Description = "Update Date")]
[Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "Update Date must be between {1} and {2}")]

    public DateTime? UpdateDate 
    { 
      get { return _UpdateDate; }
      set 
      { 
        _UpdateDate = value; 
        IsDirty = true;
      } 
    }
    
    /// <summary>
    /// Get/Set the ConcurrencyValue value
    /// </summary>
    [DataMember]
    [Display(Description = "Concurrency Value")]

    public short? ConcurrencyValue 
    { 
      get { return _ConcurrencyValue; }
      set 
      { 
        _ConcurrencyValue = value; 
        IsDirty = true;
      } 
    }
    

    #endregion
  }
  #endregion

  #region CustomerSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  
  [DataContract]
  public partial class CustomerSearch : PDSADataEntityBase
  {
    #region CustomerSearch Constructor
    /// <summary>
    /// Constructor for CustomerSearch class
    /// </summary>
    public CustomerSearch() : base()
    {
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the CompanyName value for searching
    /// </summary>
    [DataMember]
    [Display(Description = "Company Name")]
    public string CompanyName { get; set; }
    #endregion
  }
  #endregion

  #region CustomerManager Class
  /// <summary>
  /// This class is used to list, add, edit, delete, and search for data in the PDSASample.Customer table.
  /// This class is generated by the Haystack Code Generator for .NET.
  /// DO NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class CustomerManager : PDSADataManagerBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for CustomerManager class
    /// </summary>
    public CustomerManager() : base()
    {
      InitSql();
    }

    /// <summary>
    /// Constructor for CustomerManager class
    /// <param name="provider">A PDSADataProvider object</param>
    /// </summary>
    public CustomerManager(PDSADataProviderBase provider) : base(provider)
    {
      InitSql();
    }
    #endregion
    
    #region Public Properties
    /// <summary>
    /// Get/Set the last Entity values after Insert or Update
    /// </summary>
    public Customer LastUpdatedEntity { get; set; }
    #endregion

    #region DataTableToList Method
    /// <summary>
    /// Convert a DataTable to a List of Customer objects
    /// </summary>
    /// <param name="dt">A DataTable object from which to build a list</param>
    /// <returns>A List of Customer objects</returns>
    public virtual List<Customer> DataTableToList(DataTable dt)
    {
      List<Customer> ret = new List<Customer>();

      var query =
        (from dr in dt.AsEnumerable()
         select new Customer
         {
           CustomerId = dr.GetDataAs<int?>("CustomerId"),
           CompanyName = dr.GetDataAs<string>("CompanyName"),
           FirstName = dr.GetDataAs<string>("FirstName"),
           LastName = dr.GetDataAs<string>("LastName"),
           Title = dr.GetDataAs<string>("Title"),
           Address1 = dr.GetDataAs<string>("Address1"),
           Address2 = dr.GetDataAs<string>("Address2"),
           TotalSales = dr.GetDataAs<decimal?>("TotalSales"),
           City = dr.GetDataAs<string>("City"),
           StateCode = dr.GetDataAs<string>("StateCode"),
           PostalCode = dr.GetDataAs<string>("PostalCode"),
           Country = dr.GetDataAs<string>("Country"),
           Phone = dr.GetDataAs<string>("Phone"),
           Fax = dr.GetDataAs<string>("Fax"),
           EmailAddress = dr.GetDataAs<string>("EmailAddress"),
           InsertName = dr.GetDataAs<string>("InsertName"),
           InsertDate = dr.GetDataAs<DateTime?>("InsertDate"),
           UpdateName = dr.GetDataAs<string>("UpdateName"),
           UpdateDate = dr.GetDataAs<DateTime?>("UpdateDate"),
           ConcurrencyValue = dr.GetDataAs<short?>("ConcurrencyValue"),
           IsDirty=false
         });

      if (query != null)
      {
        ret = query.ToList();
      }

      return ret;
    }
    #endregion

    #region BuildCollection Methods
    /// <summary>
    /// Return a collection of Customer objects
    /// </summary>
    /// <returns>A List of Customer objects</returns>
    public virtual List<Customer> BuildCollection()
    {
      return BuildCollection(new Customer());
    }

    /// <summary>
    /// Return a collection of Customer objects
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A List of Customer objects</returns>
    public virtual List<Customer> BuildCollection(Customer search)
    {
      List<Customer> ret = new List<Customer>();
      DataSet ds = null;
      DataTable dt = null;

      try {
        ds = GetDataSet(search);

        if (ds.Tables.Count > 0) {
          dt = ds.Tables[0];
          ret = DataTableToList(dt);
          RowsAffected = ret.Count;
        }
      }
      catch (Exception ex)
      {
        HandleException(ex);
      }
      return ret;
    }
    #endregion

    #region GetDataTable Methods
    /// <summary>
    /// Return a DataTable of Customer objects
    /// </summary>
    /// <returns>A DataTable of Customer objects, or null if no data found</returns>
    public override DataTable GetDataTable()
    {
      return GetDataTable(new Customer());
    }

    /// <summary>
    /// Return a DataTable of Customer objects
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A DataTable of Customer objects</returns>
    public virtual DataTable GetDataTable(Customer search)
    {
      return base.GetDataTable<Customer>(search);
    }
    #endregion

    #region GetDataSet Methods
    /// <summary>
    /// Return a DataSet of Customer objects
    /// </summary>
    /// <returns>A DataSet of Customer objects</returns>
    public override DataSet GetDataSet()
    {
      return GetDataSet(new Customer());
    }

    /// <summary>
    /// Return a DataSet of Customer objects
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A DataSet of Customer objects</returns>
    public virtual DataSet GetDataSet(Customer search)
    {
      return base.GetDataSet<Customer>(search);
    }
    #endregion
    
    #region GetDataAsJSON Methods
    /// <summary>
    /// Calls BuildCollection to get collection of Customer objects to serialize as JSON
    /// </summary>
    /// <returns>A JSON array of Customer objects</returns>
    public virtual string GetDataAsJSON() {
      return GetDataAsJSON(new Customer());
    }

    /// <summary>
    /// Calls BuildCollection to get collection of Customer objects to serialize as JSON
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A JSON array of Customer objects</returns>
    public virtual string GetDataAsJSON(Customer search) {
      string ret = string.Empty;
     
      try {
        ret = PDSAString.GetAsJSON<Customer>(typeof(List<Customer>), BuildCollection(search));
      }
      catch (Exception ex) {
        HandleException(ex);
      }

      return ret;
    }
    #endregion

    #region GetDataAsXML Methods
    /// <summary>
    /// Return an XML string of Customer objects
    /// </summary>
    /// <returns>An XML string of Customer objects</returns>
    public virtual string GetDataAsXML() {
      return GetDataAsXML(new Customer());
    }

    /// <summary>
    /// Return an XML string of Customer objects
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>An XML string of Customer objects</returns>
    public virtual string GetDataAsXML(Customer search) {
      string ret = string.Empty;
      DataSet ds = new DataSet();

      ds = GetDataSet(search);
      ret = ds.GetDataSetAsXml();

      return ret;
    }
    #endregion

    #region GetDataAsExcelString Methods
    /// <summary>
    /// Return a comma-delimited string suitable for Excel of Customer objects
    /// </summary>
    /// <returns>A comma-delimited string suitable for Excel of Customer objects</returns>
    public virtual string GetDataAsExcelString() {
      return GetDataAsExcelString(new Customer());
    }

    /// <summary>
    /// Return a comma-delimited string suitable for Excel of Customer objects
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A comma-delimited string suitable for Excel of Customer objects</returns>
    public virtual string GetDataAsExcelString(Customer search) {
      string ret = string.Empty;
      DataSet ds = new DataSet();

      ds = GetDataSet(search);
      ret = ds.GetDataSetAsExcelString();

      return ret;
    }
    #endregion

    #region Load Method
    /// <summary>
    /// Get a single Customer based on the primary key passed in.
    /// If the row is not found, the primary key property in the returned object will be null.
    /// </summary>
    /// <param name="customerId">The value of the primary key of the row to load</param>
    /// <returns>A Customer object</returns>
    public virtual Customer Load(int? customerId)
    {
      DataTable dt = new DataTable();
      Customer ret = new Customer();

      base.Init();
      
      // Reinitialize SQL Builder
      InitSql();
      SqlBuilder.SelectWhereItems.Clear();
      SqlBuilder.OrderByItems.Clear();
      SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.CustomerId, CustomerManager.ColumnNames.CustomerId, PDSASQLBuilder.EQUAL_TO);
      
      ret.CustomerId = customerId;

      var list = BuildCollection(ret);

      if (list.Count > 0) {
         ret = list[0];
         RowsAffected = 1;
      }
      else {
         ret.CustomerId = null;
      }

      return ret;
    }
    #endregion

    #region RowCount Methods
    /// <summary>
    /// Count all records in the PDSASample.Customer table
    /// </summary>
    /// <returns>A count of total records</returns>
    public override int RowCount()
    {     
      return RowCount(new Customer());
    }

    /// <summary>
    /// Count all records in the PDSASample.Customer table using search parameters
    /// </summary>
    /// <param name="search">An instance of a Customer object with values to search upon</param>
    /// <returns>A count of records in the search</returns>
    public virtual int RowCount(Customer search)
    {
      return base.RowCount<Customer>(search);
    }
    #endregion

    #region InitSql Method
    /// <summary>
    /// Initialize the SqlBuilder object to a default start sate
    /// </summary>
    protected override void InitSql()
    {
      // Initialize SqlBuilder object
      base.InitSql();

      // Initialize for Selecting
      SqlBuilder.SQLSelect = "SELECT CustomerId,CompanyName,FirstName,LastName,Title,Address1,Address2,TotalSales,City,StateCode,PostalCode,Country,Phone,Fax,EmailAddress,InsertName,InsertDate,UpdateName,UpdateDate,ConcurrencyValue FROM PDSASample.Customer ";
      SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.CompanyName, CustomerManager.ColumnNames.CompanyName, "LIKE", PDSAWildCard.WildCardAfter);
      SqlBuilder.AddOrderByItem(CustomerManager.ColumnNames.CompanyName);
    }
    #endregion
        
    #region InitRowCountSql Method
    /// <summary>
    /// Initialize the SELECT COUNT(*) statement
    /// </summary>
    protected override void InitRowCountSql() {
      base.InitRowCountSql();

      // Initialize for Row Count
      SqlBuilder.SQLRowCount = "SELECT Count(*) FROM PDSASample.Customer ";
    }
    #endregion

    #region InitInsertSql Method
    /// <summary>
    /// Initialize the INSERT statement
    /// </summary>
    protected override void InitInsertSql() {
      base.InitInsertSql();

      // Initialize for Inserting      
      SqlBuilder.SQLInsert = "INSERT INTO PDSASample.Customer (CompanyName,FirstName,LastName,Title,Address1,Address2,TotalSales,City,StateCode,PostalCode,Country,Phone,Fax,EmailAddress,InsertName,InsertDate,UpdateName,UpdateDate,ConcurrencyValue) VALUES (@CompanyName,@FirstName,@LastName,@Title,@Address1,@Address2,@TotalSales,@City,@StateCode,@PostalCode,@Country,@Phone,@Fax,@EmailAddress,@InsertName,@InsertDate,@UpdateName,@UpdateDate,@ConcurrencyValue)";
    }
    #endregion

    #region InitUpdateSql Method
    /// <summary>
    /// Initialize the UPDATE statement
    /// </summary>
    protected override void InitUpdateSql() {
      base.InitUpdateSql();

      // Initialize for Updating
      SqlBuilder.SQLUpdate = "UPDATE PDSASample.Customer SET CompanyName = @CompanyName,FirstName = @FirstName,LastName = @LastName,Title = @Title,Address1 = @Address1,Address2 = @Address2,TotalSales = @TotalSales,City = @City,StateCode = @StateCode,PostalCode = @PostalCode,Country = @Country,Phone = @Phone,Fax = @Fax,EmailAddress = @EmailAddress,UpdateName = @UpdateName,UpdateDate = @UpdateDate,ConcurrencyValue = ConcurrencyValue + 1";
      SqlBuilder.AddUpdateWhereItem(CustomerManager.PropertyNames.CustomerId, CustomerManager.ColumnNames.CustomerId, "=");
      SqlBuilder.AddUpdateWhereItem(CustomerManager.PropertyNames.ConcurrencyValue, CustomerManager.ColumnNames.ConcurrencyValue, "=");
    }
    #endregion
    
    #region InitDeleteSql Method
    /// <summary>
    /// Initialize the DELETE statement
    /// </summary>
    protected override void InitDeleteSql() {
      base.InitDeleteSql();

      // Initialize for Deleting
      SqlBuilder.SQLDelete = "DELETE FROM PDSASample.Customer ";
    }
    #endregion

    #region InitInsertParameters Method
    /// <summary>
    /// Initialize all parameters for the INSERT statement
    /// </summary>
    protected override void InitInsertParameters() {
      base.InitInsertParameters();

      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.CompanyName, CustomerManager.PropertyNames.CompanyName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.FirstName, CustomerManager.PropertyNames.FirstName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.LastName, CustomerManager.PropertyNames.LastName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Title, CustomerManager.PropertyNames.Title));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Address1, CustomerManager.PropertyNames.Address1));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Address2, CustomerManager.PropertyNames.Address2));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.TotalSales, CustomerManager.PropertyNames.TotalSales));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.City, CustomerManager.PropertyNames.City));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.StateCode, CustomerManager.PropertyNames.StateCode));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.PostalCode, CustomerManager.PropertyNames.PostalCode));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Country, CustomerManager.PropertyNames.Country));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Phone, CustomerManager.PropertyNames.Phone));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Fax, CustomerManager.PropertyNames.Fax));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.EmailAddress, CustomerManager.PropertyNames.EmailAddress));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.InsertName, CustomerManager.PropertyNames.InsertName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.InsertDate, CustomerManager.PropertyNames.InsertDate));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.UpdateName, CustomerManager.PropertyNames.UpdateName));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.UpdateDate, CustomerManager.PropertyNames.UpdateDate));
      SqlBuilder.InsertParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.ConcurrencyValue, CustomerManager.PropertyNames.ConcurrencyValue));
    }
    #endregion
    
    #region InitUpdateParameters Method
    /// <summary>
    /// Initialize all parameters for the UPDATE statement
    /// </summary>
    protected override void InitUpdateParameters() {
      base.InitUpdateParameters();

      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.CompanyName, CustomerManager.PropertyNames.CompanyName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.FirstName, CustomerManager.PropertyNames.FirstName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.LastName, CustomerManager.PropertyNames.LastName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Title, CustomerManager.PropertyNames.Title));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Address1, CustomerManager.PropertyNames.Address1));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Address2, CustomerManager.PropertyNames.Address2));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.TotalSales, CustomerManager.PropertyNames.TotalSales));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.City, CustomerManager.PropertyNames.City));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.StateCode, CustomerManager.PropertyNames.StateCode));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.PostalCode, CustomerManager.PropertyNames.PostalCode));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Country, CustomerManager.PropertyNames.Country));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Phone, CustomerManager.PropertyNames.Phone));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.Fax, CustomerManager.PropertyNames.Fax));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.EmailAddress, CustomerManager.PropertyNames.EmailAddress));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.UpdateName, CustomerManager.PropertyNames.UpdateName));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.UpdateDate, CustomerManager.PropertyNames.UpdateDate));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.CustomerId, CustomerManager.PropertyNames.CustomerId));
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.ConcurrencyValue, CustomerManager.PropertyNames.ConcurrencyValue));
    }
    #endregion
            
    #region InitDeleteParameters Method
    /// <summary>
    /// Initialize all parameters for the DELETE statement
    /// </summary>
    protected override void InitDeleteParameters() {
      base.InitDeleteParameters();

      SqlBuilder.AddDeleteWhereItem(CustomerManager.PropertyNames.CustomerId, CustomerManager.ColumnNames.CustomerId, "=");
      SqlBuilder.AddDeleteWhereItem(CustomerManager.PropertyNames.ConcurrencyValue, CustomerManager.ColumnNames.ConcurrencyValue, "=");
    }
    #endregion

    #region Insert Method
    /// <summary>
    /// Insert a new Customer object
    /// </summary>
    /// <param name="entity">The Customer object with the information of which Customer object to insert</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Insert(Customer entity)
    {
      bool ret = false;
      CustomerValidator validator = new CustomerValidator(entity);
      
      // Set last updated entity
      LastUpdatedEntity = entity;
      
      // Insert the data
      ret = base.Insert<Customer>(entity, validator);

      if (RowsAffected > 0 || SqlBuilder.IsStoredProc) {        
        // Get Generated IDENTITY column
        if (LastIdentity != null) {
          entity.CustomerId =
              Convert.ToInt32(LastIdentity);
        }
      }

      return ret;
    }
    #endregion

    #region Update Method
    /// <summary>
    /// Update an existing Customer object
    /// </summary>
    /// <param name="entity">The Customer object with the information to update</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Update(Customer entity) {
      return Update(entity, entity);
    }

    /// <summary>
    /// Update an existing Customer object using Audit tracking.
    /// </summary>
    /// <param name="entity">The Customer object with the information to update</param>
    /// <param name="oldEntity">The original data to be updated (used for Audit tracking)</param>
    /// <returns>True if successful, False if not</returns>
    public virtual bool Update(Customer entity, Customer oldEntity)
    {
      bool ret = false;
      CustomerValidator validator = new CustomerValidator(entity);

      // Set last updated entity
      LastUpdatedEntity = entity;
           
      // Update the data
      ret = Update<Customer>(entity, oldEntity, validator);
      // Increment concurrency field
      entity.ConcurrencyValue += 1;
    
      return ret;
    }
    #endregion

    #region Delete Method
    /// <summary>
    /// Delete existing Customer object(s)
    /// </summary>
    /// <param name="entity">The Customer object with the information of which Customer object(s) to delete</param>
    /// <returns>Total Number of Rows Deleted</returns>
    public virtual int Delete(Customer entity)
    {
      return base.Delete<Customer>(entity);
    }
    #endregion

    #region InitXmlAuditProperties Method
    /// <summary>
    /// Build the collection of properties that will participate in auditing
    /// </summary>
    protected override void InitXmlAuditProperties()
    {
      // Only use properties marked as Auditable in Haystack
      XmlAuditProperties.Add("CustomerId");
      XmlAuditProperties.Add("CompanyName");
      XmlAuditProperties.Add("FirstName");
      XmlAuditProperties.Add("LastName");
      XmlAuditProperties.Add("Title");
      XmlAuditProperties.Add("Address1");
      XmlAuditProperties.Add("Address2");
      XmlAuditProperties.Add("TotalSales");
      XmlAuditProperties.Add("City");
      XmlAuditProperties.Add("StateCode");
      XmlAuditProperties.Add("PostalCode");
      XmlAuditProperties.Add("Country");
      XmlAuditProperties.Add("Phone");
      XmlAuditProperties.Add("Fax");
      XmlAuditProperties.Add("EmailAddress");
      XmlAuditProperties.Add("InsertName");
      XmlAuditProperties.Add("InsertDate");
      XmlAuditProperties.Add("UpdateName");
      XmlAuditProperties.Add("UpdateDate");
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Creates an instance of the CustomerValidator object
    /// using the Customer object passed to this method
    /// Validates all Data Annotations on the Customer object
    /// and any custom rules you define in the CustomerValidator.Validate() method
    /// </summary>
    /// <param name="entity">A Customer object</param>
    /// <returns>True if all validations pass</returns>
    public virtual bool Validate(Customer entity)
    {
      return base.Validate(new CustomerValidator(entity));
    }
    #endregion
    
    #region ColumnNames Class
    /// <summary>
    /// Contains static string properties that represent the name of each column in the table referenced by Customer class.
    /// This class is generated by the Haystack Code Generator for .NET.
    /// DO NOT modify this class as it is intended to be able to be re-generated at any time.
    /// </summary>
    public class ColumnNames
    {
    /// <summary>
    /// Returns 'CustomerId'
    /// </summary>
    public static string CustomerId = "CustomerId";
    /// <summary>
    /// Returns 'CompanyName'
    /// </summary>
    public static string CompanyName = "CompanyName";
    /// <summary>
    /// Returns 'FirstName'
    /// </summary>
    public static string FirstName = "FirstName";
    /// <summary>
    /// Returns 'LastName'
    /// </summary>
    public static string LastName = "LastName";
    /// <summary>
    /// Returns 'Title'
    /// </summary>
    public static string Title = "Title";
    /// <summary>
    /// Returns 'Address1'
    /// </summary>
    public static string Address1 = "Address1";
    /// <summary>
    /// Returns 'Address2'
    /// </summary>
    public static string Address2 = "Address2";
    /// <summary>
    /// Returns 'TotalSales'
    /// </summary>
    public static string TotalSales = "TotalSales";
    /// <summary>
    /// Returns 'City'
    /// </summary>
    public static string City = "City";
    /// <summary>
    /// Returns 'StateCode'
    /// </summary>
    public static string StateCode = "StateCode";
    /// <summary>
    /// Returns 'PostalCode'
    /// </summary>
    public static string PostalCode = "PostalCode";
    /// <summary>
    /// Returns 'Country'
    /// </summary>
    public static string Country = "Country";
    /// <summary>
    /// Returns 'Phone'
    /// </summary>
    public static string Phone = "Phone";
    /// <summary>
    /// Returns 'Fax'
    /// </summary>
    public static string Fax = "Fax";
    /// <summary>
    /// Returns 'EmailAddress'
    /// </summary>
    public static string EmailAddress = "EmailAddress";
    /// <summary>
    /// Returns 'InsertName'
    /// </summary>
    public static string InsertName = "InsertName";
    /// <summary>
    /// Returns 'InsertDate'
    /// </summary>
    public static string InsertDate = "InsertDate";
    /// <summary>
    /// Returns 'UpdateName'
    /// </summary>
    public static string UpdateName = "UpdateName";
    /// <summary>
    /// Returns 'UpdateDate'
    /// </summary>
    public static string UpdateDate = "UpdateDate";
    /// <summary>
    /// Returns 'ConcurrencyValue'
    /// </summary>
    public static string ConcurrencyValue = "ConcurrencyValue";
    }
    #endregion
        
    #region PropertyNames Partial Class
    /// <summary>
    /// Contains static string properties that represent the name of each property in the Customer class.
    /// This class is generated by the Haystack Code Generator for .NET.
    /// DO NOT modify this class as it is intended to be able to be re-generated at any time.
    ///
    /// NOTE: You can add additional property names in the PropertyNames class located in the CustomerValidator class.
    /// </summary>
    public partial class PropertyNames
    {
    /// <summary>
    /// Returns 'CustomerId'
    /// </summary>
    public static string CustomerId = "CustomerId";
    /// <summary>
    /// Returns 'CompanyName'
    /// </summary>
    public static string CompanyName = "CompanyName";
    /// <summary>
    /// Returns 'FirstName'
    /// </summary>
    public static string FirstName = "FirstName";
    /// <summary>
    /// Returns 'LastName'
    /// </summary>
    public static string LastName = "LastName";
    /// <summary>
    /// Returns 'Title'
    /// </summary>
    public static string Title = "Title";
    /// <summary>
    /// Returns 'Address1'
    /// </summary>
    public static string Address1 = "Address1";
    /// <summary>
    /// Returns 'Address2'
    /// </summary>
    public static string Address2 = "Address2";
    /// <summary>
    /// Returns 'TotalSales'
    /// </summary>
    public static string TotalSales = "TotalSales";
    /// <summary>
    /// Returns 'City'
    /// </summary>
    public static string City = "City";
    /// <summary>
    /// Returns 'StateCode'
    /// </summary>
    public static string StateCode = "StateCode";
    /// <summary>
    /// Returns 'PostalCode'
    /// </summary>
    public static string PostalCode = "PostalCode";
    /// <summary>
    /// Returns 'Country'
    /// </summary>
    public static string Country = "Country";
    /// <summary>
    /// Returns 'Phone'
    /// </summary>
    public static string Phone = "Phone";
    /// <summary>
    /// Returns 'Fax'
    /// </summary>
    public static string Fax = "Fax";
    /// <summary>
    /// Returns 'EmailAddress'
    /// </summary>
    public static string EmailAddress = "EmailAddress";
    /// <summary>
    /// Returns 'InsertName'
    /// </summary>
    public static string InsertName = "InsertName";
    /// <summary>
    /// Returns 'InsertDate'
    /// </summary>
    public static string InsertDate = "InsertDate";
    /// <summary>
    /// Returns 'UpdateName'
    /// </summary>
    public static string UpdateName = "UpdateName";
    /// <summary>
    /// Returns 'UpdateDate'
    /// </summary>
    public static string UpdateDate = "UpdateDate";
    /// <summary>
    /// Returns 'ConcurrencyValue'
    /// </summary>
    public static string ConcurrencyValue = "ConcurrencyValue";
    }
    #endregion
  }
  #endregion

  #region CustomerValidator Class
  /// <summary>
  /// Used to validate all properties of the Customer class.
  /// This class is generated by the Haystack Code Generator for .NET.
  /// You should NOT modify this class as it is intended to be re-generated.
  /// </summary>
  public partial class CustomerValidator : PDSADataValidatorBase
  {
    /// <summary>
    /// Constructor for CustomerValidator class
    /// <param name="provider">A Customer object to validate</param>
    /// </summary>
    public CustomerValidator(Customer entity) : base()
    {
      EntityToValidate = entity;
    }

    private Customer EntityToValidate;
  }
  #endregion
}
