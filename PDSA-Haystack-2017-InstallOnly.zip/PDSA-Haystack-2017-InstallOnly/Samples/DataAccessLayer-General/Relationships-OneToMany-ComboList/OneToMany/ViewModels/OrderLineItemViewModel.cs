using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

using PDSA.Validation;
using PDSA.WPF;
using PDSA.UI;
using PDSA.DataAccess;


namespace OneToMany.ViewModel
{
  /// <summary>
  /// The ViewModel used for all data access
  /// </summary>
  public class OrderLineItemViewModel : PDSAViewModelBase
  {
    #region Constructor
    /// <summary>
    /// Constructor for OrderLineItemViewModel Class
    /// </summary>
    public OrderLineItemViewModel() : base()
    {
      RecordName = "Order Line Item";
      RecordNamePlural = "Order Line Items";

      ResetMessages();

      IsPrimaryKeyAutoNumber = true;
      _DataCollection = new ObservableCollection<OrderLineItem>();
    }
    #endregion
    
    #region DataCollection Property
    private ObservableCollection<OrderLineItem> _DataCollection = new ObservableCollection<OrderLineItem>();
    
    /// <summary>
    /// An Observable collection of OrderLineItem objects
    /// </summary>
    public ObservableCollection<OrderLineItem> DataCollection
    {
      get { return _DataCollection; }
      set 
      { 
        _DataCollection = value; 
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    private OrderLineItem _DetailData = new OrderLineItem();
    
    /// <summary>
    /// The currently selected OrderLineItem object
    /// </summary>
    public OrderLineItem DetailData
    {
      get { return _DetailData; }
      set 
      { 
        _DetailData = value; 
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region SearchEntity Property
    /// <summary>
    /// Get/Set the Entity class used for searching
    /// </summary>
    private OrderLineItem _SearchEntity = new OrderLineItem();
    public OrderLineItem SearchEntity
    {
     get { return _SearchEntity; }
     set 
     { 
        _SearchEntity = value; 
        RaisePropertyChanged("SearchEntity");
      }
    }
    #endregion


    #region Old Entity for Undo Functionality
    private OrderLineItem _OriginalEntity = null;
    #endregion

    #region Manager Object
    private OrderLineItemManager _Manager = null;
    #endregion
        
    #region CreateManagerObject Method
    private OrderLineItemManager CreateManagerObject()
    {
      if(_Manager == null)
      {
        _Manager = new OrderLineItemManager();

      }
      
      return _Manager;
    }
    #endregion
        
    #region Init Method
    /// <summary>
    /// Initialize the View Model
    /// </summary>
    public override void Init() {
      base.Init();

    }
    #endregion
    
    #region LoadAll Method
    /// <summary>
    /// Load all entities into the DataCollection property
    /// </summary>
    public void LoadAll()
    {
      DataCollection = new ObservableCollection<OrderLineItem>();
      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Turn collection into ObservableCollection
        DataCollection = new ObservableCollection<OrderLineItem>(_Manager.BuildCollection());
        SetTotalRecords();

        if (_Manager.ErrorOccurred) {
          HandleExceptionMessages(_Manager.LastException);
        }
      }
      catch (Exception ex)
      {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region Search Methods
    /// <summary>
    /// Search for values based on search criteria and load into DataCollection property
    /// </summary>
    public void Search()
    {
      DataCollection = new ObservableCollection<OrderLineItem>();
      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Get Filtered Data & turn Collection into ObservableCollection
        DataCollection = new ObservableCollection<OrderLineItem>(_Manager.BuildCollection(SearchEntity));
        SetTotalRecords();

        if (_Manager.ErrorOccurred) {
          HandleExceptionMessages(_Manager.LastException);
        }
      }
      catch (Exception ex)
      {
        HandleExceptionMessages(ex);
      }
    }

    /// <summary>
    /// Reset all Search Criteria to default values
    /// </summary>
    public override void ResetSearch()
    {
      base.ResetSearch();

      // Create New Search Object
      _SearchEntity = new OrderLineItem();

      // Load all Records
      LoadAll();
    }
    #endregion

    #region DeleteByPK Method
    /// <summary>
    /// Deletes the currently selected entity
    /// </summary>
    public int DeleteByPK()
    {
      int ret = 0;

      LastException = null;
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        
        // Delete the Record
        ret = _Manager.Delete(DetailData);
        
        if(ret >= 1)
        {
          // Delete from the Collection
          DataCollection.Remove(DetailData);
          SetTotalRecords();
        }
        else
        {
          HandleExceptionMessages(new Exception(base.NoRowsAffectedMessageDelete));
        }
      }
      catch (Exception ex)
      {
        HandleExceptionMessages(ex);
      }
      
      return ret;
    }
    #endregion

    #region CreateNewEntity Method
    /// <summary>
    /// Creates a new Entity object with default values and assigns to DetailData property
    /// </summary>
    public void CreateNewEntity()
    {
      // Create blank Entity Object
      DetailData = new OrderLineItem();

      // Set defaults for each field
      DetailData.OrderLineItemId = null;
      DetailData.OrderId = null;
      DetailData.ProductName = null;
      DetailData.UnitPrice = null;
      DetailData.Quantity = null;


      // Set Window UI State
      SetViewStateMode(PDSAUIState.Add);
    }
    #endregion
  
    #region DataInsert Method
    /// <summary>
    /// Inserts the current entity into the data store
    /// </summary>
    /// <returns>bool</returns>
    public override bool DataInsert()
    {
      bool ret = false;

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        // Perform the Insert
        if (_Manager.Insert(DetailData))
        {
          // In case anything was changed in the Insert
          DetailData = _Manager.LastUpdatedEntity;

          // Add new entity to the collection
          DataCollection.Add(DetailData);
          SetTotalRecords();

          ret = true;
        }
        else
        {
          if (_Manager.ValidationFailed) {
            ValidationFailed = true;
            ValidationRuleFailures.AddRange(_Manager.ValidationRuleFailures);
          }
          else if (_Manager.ErrorOccurred) {
            HandleExceptionMessages(new Exception(base.NoRowsAffectedMessageInsert));
          }
        }
      }
      catch (Exception ex)
      {
        HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion

    #region DataUpdate Method
    /// <summary>
    /// Updates the current Entity to the data store
    /// </summary>
    /// <returns>boolean</returns>
    public override bool DataUpdate()
    {
      bool ret = false;

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        
        // Set the new data
        if (_Manager.Update(DetailData))
        {
          // In case anything was changed in the Update
          DetailData = _Manager.LastUpdatedEntity;

          ret = true;
        }
        else
        {
          if (_Manager.ValidationFailed) {
            ValidationFailed = true;
            ValidationRuleFailures.AddRange(_Manager.ValidationRuleFailures);
          }
          else if (_Manager.ErrorOccurred) {
            HandleExceptionMessages(new Exception(base.NoRowsAffectedMessageUpdate));
          }
        }
      }
      catch (Exception ex)
      {
        HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion

    #region SaveCurrent Method
    /// <summary>
    /// Clones the currently selected Entity object. 
    /// Call this prior editing the current record.
    /// If you wish to undo the changes made, call the Undo() method
    /// </summary>
    public void SaveCurrent()
    {
      if (DetailData != null)
      {        
        _OriginalEntity = _DetailData.CopyObject();
      }
    }
    #endregion

    #region Undo Method
    /// <summary>
    /// Restores the original data back to the current entity
    /// </summary>
    public void Undo()
    {
      if (_OriginalEntity != null)
      {
        DetailData = _OriginalEntity.CopyObject();

        SetViewStateMode(PDSAUIState.ListAndDetail);
      }
    }
    #endregion
    
    #region Handle Custom Exceptions
    /// <summary>
    /// Call this method to handle any specific exceptions and display your own custom messages
    /// </summary>
    /// <param name="ex">An Exception object</param>
    /// <returns>False if you have NOT handled the exception.</returns>
    protected bool HandleCustomExceptions(Exception ex)
    {
      bool ret = false;

      // Check to see if you want to handle any exceptions yourself.
      // The following is an example of checking for a duplicate primary key error in SQL Server
      //if (ex.InnerException is System.Data.SqlClient.SqlException)
      //{
      //  System.Data.SqlClient.SqlException sqlEx = (System.Data.SqlClient.SqlException)ex.InnerException;
      //  if (sqlEx.Number == 2627) // Primary key Violation from SQL Server
      //    this.HandleValidationMessages("You have entered duplicate data for this record.");

      //  ret = true;
      //}

      return ret;
    }
    #endregion

    #region HandleExceptionMessages Method
    /// <summary>
    /// Sets an exception object into the LastException property of this ViewModel class
    /// </summary>
    /// <param name="ex">An exception object</param>
    protected override void HandleExceptionMessages(Exception ex)
    {
      base.HandleExceptionMessages(ex);

      // Add your own exception logging here
    }
    #endregion

    #region SetTotalRecords
    private void SetTotalRecords()
    {
      TotalRecords = DataCollection.Count;
      if (TotalRecords == 0)
        SetViewStateMode(PDSAUIState.NoRecords);
      else
        SetViewStateMode(PDSAUIState.ListAndDetail);
    }
    #endregion
  }
}
