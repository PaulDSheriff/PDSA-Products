using PDSA.DataAccess;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{

  #region Manager Class
  /// <summary>
  /// This class is used to call the stored procedure ProductReadOnlyInOutParams
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// </summary>
  public partial class ProductReadOnlyInOutParamsManager : PDSADataManagerBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for the ProductReadOnlyInOutParamsManager class
    /// </summary>
    public ProductReadOnlyInOutParamsManager() : base()
    {
    }
    #endregion
        
    #region BuildCollection Method
    /// <summary>
    /// Call Stored Procedure and build list of entity objects
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> BuildCollection(Product entity)
    {
      DataTable dt = new DataTable();
      List<Product> ret = new List<Product>();

      SQL = "PDSATest.ProductReadOnlyInOutParams";
    
      try
      {
        DataProvider.CreateCommand(SQL);
        DataProvider.Command.CommandType = CommandType.StoredProcedure;
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("ProductName", entity.ProductName));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("RowsRead", entity.RowsRead, ParameterDirection.Output, -1));

        // Set this so we can get any output variables
        DataProvider.KeepConnectionAlive = true;
        // Get the Data Table
        dt = DataProvider.GetDataTable(DataProvider.Command);

        var query =
           (from dr in dt.AsEnumerable()
            select new Product
            {
              ProductId = dr.GetDataAs<int?>("ProductId"),
              ProductName = dr.GetDataAs<string>("ProductName"),
              IntroductionDate = dr.GetDataAs<DateTime?>("IntroductionDate"),
              Cost = dr.GetDataAs<decimal?>("Cost"),
              Price = dr.GetDataAs<decimal?>("Price"),
              IsDiscontinued = dr.GetDataAs<bool>("IsDiscontinued"),
              IsDirty=false
            });

        if (query != null)
        {
          ret = query.ToList();

          // Move any output parameters into Entity class
          entity.RowsRead = DataProvider.Command.GetParameterAs<int?>("RowsRead");
        }
      }
      catch (Exception ex)
      {
        base.ErrorOccurred = true;
        base.Message = ex.ToString();

        // Handle the error from the caller
        throw ex;
      }
      finally
      {
        DataProvider.CleanUp();
      }

      return ret;
    }
    #endregion
  }
  #endregion
}
