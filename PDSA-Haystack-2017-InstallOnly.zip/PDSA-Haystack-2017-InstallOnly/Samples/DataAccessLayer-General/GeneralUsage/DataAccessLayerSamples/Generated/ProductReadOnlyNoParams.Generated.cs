using PDSA.DataAccess;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{

  #region Manager Class
  /// <summary>
  /// This class is used to call the stored procedure ProductReadOnlyNoParams
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// </summary>
  public partial class ProductReadOnlyNoParamsManager : PDSADataManagerBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for the ProductReadOnlyNoParamsManager class
    /// </summary>
    public ProductReadOnlyNoParamsManager() : base()
    {
    }
    #endregion

    #region BuildCollection Method
    /// <summary>
    /// Call Stored Procedure and build list of entity objects
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> BuildCollection()
    {
      DataTable dt = new DataTable();
      List<Product> ret = new List<Product>();
     
      SQL = "PDSATest.ProductReadOnlyNoParams";
      try
      {
        DataProvider.CreateCommand(SQL);
        DataProvider.Command.CommandType = CommandType.StoredProcedure;

        dt = DataProvider.GetDataTable(DataProvider.Command);

        var query =
          (from dr in dt.AsEnumerable()
          select new Product
          {
           ProductId = dr.GetDataAs<int?>("ProductId"),
           ProductName = dr.GetDataAs<string>("ProductName"),
           IntroductionDate = dr.GetDataAs<DateTime?>("IntroductionDate"),
           Cost = dr.GetDataAs<decimal?>("Cost"),
           Price = dr.GetDataAs<decimal?>("Price"),
           IsDiscontinued = dr.GetDataAs<bool>("IsDiscontinued"),
           IsDirty=false
          });

        if (query != null)
        {
          ret = query.ToList();
        }
      }
      catch (Exception ex)
      {
        base.ErrorOccurred = true;
        base.Message = ex.ToString();

        throw ex;
      }

      return ret;
    }
    #endregion
  }
  #endregion
}
