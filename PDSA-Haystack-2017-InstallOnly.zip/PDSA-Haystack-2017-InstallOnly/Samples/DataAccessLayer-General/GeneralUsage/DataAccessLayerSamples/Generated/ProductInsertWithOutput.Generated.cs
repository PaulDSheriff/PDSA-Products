using PDSA.DataAccess;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{

  #region Manager Class
  /// <summary>
  /// This class is used to call the stored procedure ProductInsertWithOutput
  /// This class is generated using the Haystack Code Generator for .NET Utility.
  /// </summary>
  public partial class ProductInsertWithOutputManager : PDSADataManagerBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for the ProductInsertWithOutputManager class
    /// </summary>
    public ProductInsertWithOutputManager() : base()
    {
    }
    #endregion
        
    #region Execute Method
    /// <summary>
    /// Execute the stored procedure and return the number of rows affected
    /// NOTE: If you use SET NOCOUNT ON in your stored procedure, the RowsAffected will always be -1
    /// </summary>
    /// <param name="entity">A Product object</param>
    /// <returns>The number of rows affected or -1</returns>
    public int Execute(Product entity)
    {
      RowsAffected = 0;
      SQL = "PDSATest.ProductInsertWithOutput";
      try
      {
        DataProvider.CreateCommand(SQL);
        DataProvider.Command.CommandType = CommandType.StoredProcedure;
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("ProductName", entity.ProductName));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("IntroductionDate", entity.IntroductionDate));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("Cost", entity.Cost));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("Price", entity.Price));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("IsDiscontinued", entity.IsDiscontinued));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("RowsInserted", entity.RowsInserted, ParameterDirection.Output, -1));
        DataProvider.Command.Parameters.Add(
          DataProvider.CreateParameter("ProductId", entity.ProductId, ParameterDirection.Output, -1));

        // Set this so we can get any output variables
        DataProvider.KeepConnectionAlive = true;
        // Execute the Stored Procedure
        RowsAffected = DataProvider.ExecuteNonQuery(DataProvider.Command);

        // Get the Return Value if set
        //entity.RETURNVALUE = DataProvider.Command.GetParameterAs<int?>("RETURNVALUE");
        // Move any output parameters into Entity class
        entity.RowsInserted = DataProvider.Command.GetParameterAs<int?>("RowsInserted");
        entity.ProductId = DataProvider.Command.GetParameterAs<int?>("ProductId");
      }
      catch (Exception ex)
      {
        base.ErrorOccurred = true;
        base.Message = ex.ToString();

        throw ex;
      }
      finally
      {
        DataProvider.CleanUp();
      }

      return RowsAffected;
    }
    #endregion
  }
  #endregion
}
