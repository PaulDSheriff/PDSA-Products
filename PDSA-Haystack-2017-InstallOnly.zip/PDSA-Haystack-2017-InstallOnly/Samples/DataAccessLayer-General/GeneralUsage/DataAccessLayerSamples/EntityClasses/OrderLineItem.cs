using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to add additional properties to the OrderLineItem class
  /// </summary>
  public partial class OrderLineItem
  {
    #region Add Your Own Properties Here
    // Use this area to define...
    //   - Input and output properties to pass to stored procedures
    //   - Properties to use for searching
    //   - Any other properties you need
    #endregion
    
    #region Init Method
    /// <summary>
    /// Initialize properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize properties
      ClassName = "OrderLineItem";


    }
    #endregion

    #region Properties for use with Stored Procedures
    /// <summary>
    /// Get/Set the RETURNVALUE from a stored procedure
    /// If you do not use Stored Procedures, feel free to comment this out
    /// </summary>
    public long RETURNVALUE { get; set; }
    #endregion

    #region CopyObject Method
    /// <summary>
    /// Create a clone of the current object
    /// </summary>
    /// <returns>A copy of an OrderLineItem object</returns>
    public OrderLineItem CopyObject()
    {
      return (OrderLineItem)this.MemberwiseClone();
    }
    #endregion
            
    #region Override of ToString()
    /// <summary>
    /// Override the ToString() to display fields and field values.
    /// This helps when viewing Collection classes in Visual Studio
    /// </summary>
    /// <returns>A string with data from this class</returns>
    public override string ToString()
    {
      string ret = string.Empty;

      ret += "OrderLineItemId: " + OrderLineItemId.ToString() + " ";
      
      return ret;
    }
    #endregion
  }
 
  #region OrderLineItemSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  public partial class OrderLineItemSearch
  {
    #region Public Properties
    // Add Your Own Search Properties Here

    #endregion

    #region Init Method
    /// <summary>
    /// Initialize search properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize search properties
      ClassName = "OrderLineItemSearch";


    }
    #endregion
  }
  #endregion
  
  #region OrderLineItemCollection Class
  /// <summary>
  /// This class is used when you wish to create a collection of OrderLineItem classes.
  /// You may add additional methods to this class.
  /// </summary>
  public class OrderLineItemCollection : List<OrderLineItem>
  {
    /// <summary>
    /// Find a OrderLineItem object
    /// </summary>
    /// <param name="orderLineItemId">The Order Line Item Id to find</param>
    /// <returns>A OrderLineItem object</returns>
    public OrderLineItem GetOrderLineItem(int? orderLineItemId)
    {
      return Find(x => x.OrderLineItemId == orderLineItemId);
    }
    
    /// <summary>
    /// Get all OrderLineItem objects where IsDirty=True
    /// </summary>
    /// <returns>A List of OrderLineItem Objects</returns>
    public List<OrderLineItem> GetChanged()
    {
      return (from item in this
              where item.IsDirty == true
              select item).ToList<OrderLineItem>();
    }
        
    /// <summary>
    /// Get all OrderLineItem objects where IsSelected=True
    /// </summary>
    /// <returns>A List of OrderLineItem Objects where IsSelected=True</returns>
    public List<OrderLineItem> GetSelected()
    {
      return (from item in this
              where item.IsSelected == true
              select item).ToList<OrderLineItem>();
    }

  }
  #endregion
}
