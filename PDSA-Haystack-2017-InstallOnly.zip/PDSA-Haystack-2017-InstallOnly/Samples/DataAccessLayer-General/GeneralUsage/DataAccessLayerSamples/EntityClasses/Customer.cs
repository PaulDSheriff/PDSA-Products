using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to add additional properties to the Customer class
  /// </summary>
  public partial class Customer
  {
    #region Add Your Own Properties Here
    // Use this area to define...
    //   - Input and output properties to pass to stored procedures
    //   - Properties to use for searching
    //   - Any other properties you need
    #endregion
    
    #region Init Method
    /// <summary>
    /// Initialize properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize properties
      ClassName = "Customer";


      InsertName = this.PDSALoginName;
      InsertDate = DateTime.Now;
      UpdateName = this.PDSALoginName;
      UpdateDate = DateTime.Now;
      ConcurrencyValue = 1;
    }
    #endregion

    #region Properties for use with Stored Procedures
    /// <summary>
    /// Get/Set the RETURNVALUE from a stored procedure
    /// If you do not use Stored Procedures, feel free to comment this out
    /// </summary>
    public long RETURNVALUE { get; set; }
    #endregion

    #region CopyObject Method
    /// <summary>
    /// Create a clone of the current object
    /// </summary>
    /// <returns>A copy of an Customer object</returns>
    public Customer CopyObject()
    {
      return (Customer)this.MemberwiseClone();
    }
    #endregion
            
    #region Override of ToString()
    /// <summary>
    /// Override the ToString() to display fields and field values.
    /// This helps when viewing Collection classes in Visual Studio
    /// </summary>
    /// <returns>A string with data from this class</returns>
    public override string ToString()
    {
      string ret = string.Empty;

      ret += "CustomerId: " + CustomerId.ToString() + " ";
      
      return ret;
    }
    #endregion
  }
 
  #region CustomerSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  public partial class CustomerSearch
  {
    #region Public Properties
    // Add Your Own Search Properties Here

    #endregion

    #region Init Method
    /// <summary>
    /// Initialize search properties to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      // Initialize search properties
      ClassName = "CustomerSearch";


    }
    #endregion
  }
  #endregion
  
  #region CustomerCollection Class
  /// <summary>
  /// This class is used when you wish to create a collection of Customer classes.
  /// You may add additional methods to this class.
  /// </summary>
  public class CustomerCollection : List<Customer>
  {
    /// <summary>
    /// Find a Customer object
    /// </summary>
    /// <param name="customerId">The Customer Id to find</param>
    /// <returns>A Customer object</returns>
    public Customer GetCustomer(int? customerId)
    {
      return Find(x => x.CustomerId == customerId);
    }
    
    /// <summary>
    /// Get all Customer objects where IsDirty=True
    /// </summary>
    /// <returns>A List of Customer Objects</returns>
    public List<Customer> GetChanged()
    {
      return (from item in this
              where item.IsDirty == true
              select item).ToList<Customer>();
    }
        
    /// <summary>
    /// Get all Customer objects where IsSelected=True
    /// </summary>
    /// <returns>A List of Customer Objects where IsSelected=True</returns>
    public List<Customer> GetSelected()
    {
      return (from item in this
              where item.IsSelected == true
              select item).ToList<Customer>();
    }

  }
  #endregion
}
