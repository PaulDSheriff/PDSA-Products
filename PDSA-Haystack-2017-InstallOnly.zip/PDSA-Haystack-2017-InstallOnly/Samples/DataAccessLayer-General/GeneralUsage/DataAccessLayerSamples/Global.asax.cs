﻿using PDSA.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace DataAccessLayerSamples
{
  public class MvcApplication : System.Web.HttpApplication
  {
    protected void Application_Start() {
      AreaRegistration.RegisterAllAreas();
      FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
      RouteConfig.RegisterRoutes(RouteTable.Routes);
      BundleConfig.RegisterBundles(BundleTable.Bundles);

      // Initialize Database Manager Object
      PDSADataManager.Instance = new PDSADataManager(
        new PDSADataSqlServer(
          ConfigurationManager.ConnectionStrings["PDSASamples"].ConnectionString));

      // Set the application name
      PDSADataManager.Instance.ApplicationName = "Data Access Layer Sample";
    }

    protected void Session_Start() {
      Session["LastCustomerId"] = 0;
    }
  }
}
