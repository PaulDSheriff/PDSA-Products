using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to extend the vwProduct_SelectAllManager class
  /// </summary>
  public partial class vwProduct_SelectAllManager
  {
    #region Init Method
    public override void Init() {
      base.Init();

      // Do any initialization here
      ClassName = "vwProduct_SelectAllManager";

    }
    #endregion

    // This area is for you to add additional methods

  }
}

