using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to extend the ProductReadOnlyInOutParamsManager class
  /// </summary>
  public partial class ProductReadOnlyInOutParamsManager
  {
    #region Init Method
    public override void Init() {
      base.Init();

      // Do any initialization here
      ClassName = "ProductReadOnlyInOutParamsManager";

    }
    #endregion

    #region Add Additional Methods Here
    // This area is for you to add additional methods

    #endregion
  }
}
