﻿Using this sample
------------------------
Modify the connection string in the Web.config

Refer to Chapter 9 for how each of these samples was built

Changes Added After Generating Code
-----------------------------------
I added the following files so I could re-generate all other classes when doing my testing. It was not necessary to do this. I could have just added the code to the appropriate classes.
Customer-Ext.cs
  Added properties for searching
  CustomerSearch.cs
    Added properties for searching
CustomerManager-Ext.cs
  Added methods to support samples
CustomerViewModel-Ext.cs
  Added methods and properties to support samples
PersonViewModel-Ext.cs
  Added methods and properties to support samples
Product-Ext.cs
  Added RowsRead and RowsInserted properties for use with stored procedures
ProductViewModel-Ext.cs
  Added methods and properties to support samples
vwProduct_SelectAllManager-Ext.cs
  Added methods and properties to support samples

Added the following in the Validate() method in ValidationClasses\ProductValidator.cs
      if (EntityToValidate.Price < EntityToValidate.Cost) {
        AddValidationMessage("Price", "Price must be less than the cost.");
      }
      // Check to see if the Introduction Date is greater than the year 2010
      if (EntityToValidate.IntroductionDate.HasValue && EntityToValidate.IntroductionDate < Convert.ToDateTime("1/1/2010")) {
        AddValidationMessage("IntroductionDate", "Introduction Date Must Be Greater than 1/1/2010.");
      }

      if (DataModificationAction == PDSADataModificationState.Insert) {
        if (EntityToValidate.Price == 0) {
          AddValidationMessage("Price", "When adding a new product, Price cannot be Zero (0).");
        }
      }


Data Access Layer Samples
------------------------------------------
SelectSample01 - Get All Customers - BuildCollection() Method
SelectSample02 - Select a Subset of Columns - Custom SELECT statement
SelectSample03 - Search By Company Name - Custom WHERE
SelectSample04 - Search and Sort by Total Sales - Custom WHERE, multiple properties
SelectSample05 - Load a Customer by ID - Load() Method

ScalarSample01 - Simple Row Count - RowCount() Method
ScalarSample02 - Row Count Using WHERE - RowCount() Method with Custom WHERE
ScalarSample03 - Row Count Using IS NULL - RowCount() Method with Custom WHERE
ScalarSample04 - Total Sales - Using SUM(TotalSales) - ExecuteScalar() Method

TransformSample01 - Get Customers as JSON - GetDataAsJSON() Method
TransformSample02 - Get Customers as XML - GetDataAsXML() Method
TransformSample03 - Get Customers as Excel String - GetDataAsExcelString() Method

ValidationSample01 - Built-in Validation - Validate() Method
ValidationSample02 - Validate and Throw Exception - Using ThrowExceptionWhenValidationFails propert
ValidationSample03 - Custom Validation - Add Custom Code to Validate() Method
ValidationSample04 - Using Data Modification Action Property

ModifySample01 - Insert a Customer - Insert() Method
ModifySample02 - Update a Customer - Update() Method
ModifySample03 - Delete a Customer - Delete() Method

ModifySample04 - Custom Bulk Update - UpdateBulk() Method
ModifySample05 - Update a Customer - UpdateBulk() Method
ModifySample06 - Delete a Customer - DeleteBulk() Method

TransactionSample01 - Insert Multiple Products in a Transaction
TransactionSample02 - Transaction that throws an Exception
TransactionSample03 - Order Header/Detail Transaction

SPSample01 - Get all products from a stored procedure - No Parameters
SPSample02 - Get all products from a stored procedure and return an output parameter
SPSample03 - Search for products using a stored procedure with input parameters, and also return output parameters
SPSample04 - Insert a product using a stored procedure
SPSample05 - Insert a product and get an output parameter back from a stored procedure

ViewSample01 - Get All Products
ViewSample02 - Select a Subset of Columns
ViewSample03 - Seach By Product Name
ViewSample04 - Simple Row Count

Generated Data Classes that Call Stored Procedures
---------------------------------------------------
TableSPSample01 - Get All Products
TableSPSample02 - Get A Product
TableSPSample03 - Row Count
TableSPSample04 - Insert
TableSPSample05 - Update
TableSPSample06 - Delete
