using System;
using System.Collections.Generic;


namespace DataAccessLayerSamples
{
  public partial class ProductSPViewModel
  {
    #region Public Properties
    public List<ProductSP> DataCollection { get; set; } = new List<ProductSP>();
    public ProductSP DetailData { get; set; } = new ProductSP();
    public string LastExceptionMessage { get; set; }
    public string XmlAuditString { get; set; }
    public int TotalRecords { get; set; }
    #endregion

    #region GetAllProducts Method
    public List<ProductSP> GetAllProducts() {
      ProductSPManager mgr = new ProductSPManager();

      DataCollection = mgr.BuildCollection();

      return DataCollection;
    }
    #endregion
    
    #region GetAProduct Method
    public List<ProductSP> GetAProduct() {
      ProductSPManager mgr = new ProductSPManager();

      DetailData = mgr.Load(DetailData.ProductId);

      return DataCollection;
    }
    #endregion

    #region GetAProduct Method
    public int SimpleRowCount() {
      ProductSPManager mgr = new ProductSPManager();

      TotalRecords = mgr.RowCount();

      return TotalRecords;
    }
    #endregion

    #region Insert Method
    public bool Insert() {
      ProductSPManager mgr = new ProductSPManager();
      bool ret = false;

      DetailData = new ProductSP();

      DetailData.ProductName = "New Product: " + DateTime.Now.ToLongDateString();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.Cost = 1;
      DetailData.Price = 2;
      DetailData.IsDiscontinued = false;

      mgr.UseAuditTracking = true;
      ret = mgr.Insert(DetailData);

      TotalRecords = mgr.RowsAffected;
      XmlAuditString = mgr.AuditRowAsXml;

      return ret;
    }
    #endregion
    
    #region Update Method
    public bool Update() {
      ProductSPManager mgr = new ProductSPManager();
      ProductSP changed;
      bool ret = false;

      DetailData = mgr.Load(DetailData.ProductId);
      // For Audit Tracking
      changed = DetailData.CopyObject();

      changed.ProductName += " - Changed";

      mgr.UseAuditTracking = true;
      ret = mgr.Update(changed, DetailData);

      TotalRecords = mgr.RowsAffected;
      XmlAuditString = mgr.AuditRowAsXml;

      return ret;
    }
    #endregion
    
    #region Delete Method
    public int Delete() {
      ProductSPManager mgr = new ProductSPManager();

      // Load all data for audit tracking
      DetailData = mgr.Load(DetailData.ProductId);

      mgr.UseAuditTracking = true;
      TotalRecords = mgr.Delete(DetailData);

      XmlAuditString = mgr.AuditRowAsXml;

      return TotalRecords;
    }
    #endregion
  }
}
