using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to add additional properties to the Customer class
  /// </summary>
  public partial class Customer
  {
    public decimal? TotalSalesMin { get; set; }
    public decimal? TotalSalesMax { get; set; }
  }

  #region CustomerSearch Class
  /// <summary>
  /// This class contains properties used for searching
  /// </summary>
  public partial class CustomerSearch
  {

    #region Public Properties
    // Add Your Own Search Properties Here

    /// <summary>
    /// Get/Set the Total Sales minimum value to search for
    /// </summary>
    [Display(Description = "Minimum Sales")]
    public decimal? TotalSalesMin { get; set; }
    /// <summary>
    /// Get/Set the Total Sales maximum value to search for
    /// </summary>
    [Display(Description = "Maximum Sales")]
    public decimal? TotalSalesMax { get; set; }

    #endregion
  }
  #endregion
}
