using System;
using System.Collections.Generic;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  public partial class CustomerViewModel
  {
    #region Public Properties  
    /// <summary>
    /// Get/Set the data for XML, JSON and Excel
    /// </summary>
    public string TheData { get; set; }
    /// <summary>
    /// Get/Set whether or not to cause a validation error
    /// </summary>
    public bool CauseValidationError { get; set; }
    /// <summary>
    /// Get/Set the total sales
    /// </summary>
    public decimal TotalSales { get; set; }
    #endregion

    #region GetAllCustomers Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on Company Name.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> GetAllCustomers() {
      CustomerManager mgr = null;

      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Create Collection of Customer Objects
        DataCollection = mgr.BuildCollection();
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region SelectSubsetOfColumns Method
    /// <summary>
    /// Create a Collection of Customer objects Using a Subset of Columns
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SelectSubsetOfColumns() {
      CustomerManager mgr = null;

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Create Collection of Customer Objects
        DataCollection = mgr.SelectSubsetOfColumns();

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region SimpleSearch Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on Company Name.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SimpleSearch() {
      CustomerManager mgr = null;
      Customer search = new Customer();

      // Move Search Parameters into Customer object
      search.CompanyName = SearchEntity.CompanyName;

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Create Collection of Customer Objects
        DataCollection = mgr.SearchByCompanyName(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region SearchAndSort Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on company name and total sales.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SearchAndSort() {
      CustomerManager mgr = null;
      Customer search = new Customer();

      // Set search parameters
      search.CompanyName = (string.IsNullOrWhiteSpace(SearchEntity.CompanyName) ? null : SearchEntity.CompanyName);
      search.TotalSalesMin = SearchEntity.TotalSalesMin;
      search.TotalSalesMax = SearchEntity.TotalSalesMax;

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Create Collection of Customer Objects
        DataCollection = mgr.SearchByCompanyNameAndTotalSales(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region SimpleRowCount Method
    /// <summary>
    /// Count records in customer table
    /// </summary>
    /// <returns>A count of Customers</returns>
    public int SimpleRowCount() {
      CustomerManager mgr = null;

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Get Total Records in Search Criteria
        TotalRecords = mgr.RowCount();

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TotalRecords;
    }
    #endregion

    #region RowCountUsingWhere Method
    /// <summary>
    /// Count records in customer table using Company Name and Total Sales
    /// </summary>
    /// <returns>A count of Customers</returns>
    public int RowCountUsingWhere() {
      CustomerManager mgr = null;
      Customer search = new Customer();

      // Set search parameters
      search.CompanyName = (string.IsNullOrWhiteSpace(SearchEntity.CompanyName) ? null : SearchEntity.CompanyName);
      search.TotalSalesMin = SearchEntity.TotalSalesMin;
      search.TotalSalesMax = SearchEntity.TotalSalesMax;

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Get Total Records in Search Criteria
        TotalRecords = mgr.CountByCompanyNameAndTotalSales(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TotalRecords;
    }
    #endregion

    #region GetTotalSales Method
    /// <summary>
    /// Get MAX(TotalSales) from Customer table
    /// </summary>
    public decimal GetTotalSales() {
      CustomerManager mgr = null;
      Customer search = new Customer();

      TotalSales = 0;
      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        // Set search parameters
        search.CompanyName = (string.IsNullOrWhiteSpace(SearchEntity.CompanyName) ? null : SearchEntity.CompanyName);
        search.TotalSalesMin = SearchEntity.TotalSalesMin;
        search.TotalSalesMax = SearchEntity.TotalSalesMax;

        // Get Total Records in Search Criteria
        TotalSales = mgr.GetTotalSales(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TotalSales;
    }
    #endregion

    #region RowCountUsingIsNull Method
    /// <summary>
    /// Count records in customer table
    /// </summary>
    /// <returns>A count of Customers</returns>
    public int RowCountUsingIsNull() {
      CustomerManager mgr = null;
      Customer search = new Customer();

      base.Init();
      try {
        // Create Manager Object
        mgr = new CustomerManager();

        mgr.SqlBuilder.Clear();
        mgr.SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.UpdateDate,
          CustomerManager.ColumnNames.UpdateDate,
          PDSASQLBuilder.IS_NULL,
          PDSAWildCard.None);

        search.UpdateDate = null;

        // Get Total Records in Search Criteria
        TotalRecords = mgr.RowCount(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TotalRecords;
    }
    #endregion

    #region UpdateTotalSalesOnly Method
    public void UpdateTotalSalesOnly() {
      CustomerManager mgr = new CustomerManager();

      base.Init();
      try {
        TotalRecords = mgr.UpdateTotalSalesOnly();

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region UpdateTotalSalesWhereNull Method
    public void UpdateTotalSalesWhereNull() {
      CustomerManager mgr = new CustomerManager();

      base.Init();
      try {
        TotalRecords = mgr.UpdateTotalSalesWhereNull(DetailData);

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region DeleteTotalSalesEqualValue Method
    public void DeleteTotalSalesEqualValue() {
      CustomerManager mgr = new CustomerManager();

      base.Init();
      try {
        TotalRecords = mgr.DeleteTotalSalesEqualValue(DetailData);

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region GetDataAsJSON Method
    /// <summary>
    /// Return a JSON string of Customer Data
    /// </summary>
    /// <returns>A JSON string</returns>
    public string GetDataAsJSON() {
      CustomerManager mgr = new CustomerManager();

      try {
        TheData = mgr.GetDataAsJSON();
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TheData;
    }
    #endregion

    #region GetDataAsXML Method
    /// <summary>
    /// Return an XML string of Customer Data
    /// </summary>
    /// <returns>An XML string</returns>
    public string GetDataAsXML() {
      CustomerManager mgr = new CustomerManager();

      try {
        TheData = mgr.GetDataAsXML();
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TheData;
    }
    #endregion

    #region GetDataAsExcelString Method
    /// <summary>
    /// Return a string suitable for Excel of Customer Data
    /// </summary>
    /// <returns>A string suitable for Excel</returns>
    public string GetDataAsExcelString() {
      CustomerManager mgr = new CustomerManager();

      try {
        TheData = mgr.GetDataAsExcelString();
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TheData;
    }
    #endregion
  }
}
