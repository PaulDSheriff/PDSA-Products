using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to extend the vwProduct_SelectAllManager class
  /// </summary>
  public partial class vwProduct_SelectAllManager
  {
    #region SelectSubsetOfColumns Method
    /// <summary>
    /// Create a Collection of vwProduct_SelectAll objects Using a Subset of Columns
    /// </summary>
    /// <returns>A list of vwProduct_SelectAll objects</returns>
    public List<vwProduct_SelectAll> SelectSubsetOfColumns(vwProduct_SelectAllSearch search) {
      DataSet ds = null;
      DataTable dt = null;
      List<vwProduct_SelectAll> ret = new List<vwProduct_SelectAll>();

      // Build SQL Statement with just the columns you want
      SqlBuilder.SQLSelect = "SELECT ProductId, ProductName FROM PDSASample.vwProduct_SelectAll ";
      // Set any search parameters to null if needed
      search.ProductName = (string.IsNullOrWhiteSpace(search.ProductName) ? null : search.ProductName);
      // Build SQL Statement
      SqlBuilder.BuildSQLForSelect();

      ds = GetDataSet(search);

      if (ds.Tables.Count > 0) {
        dt = ds.Tables[0];

        // Build Collection of Customer Objects
        var query =
         (from dr in dt.AsEnumerable()
          select new vwProduct_SelectAll {
            ProductId = dr.GetDataAs<int?>("ProductId"),
            ProductName = dr.GetDataAs<string>("ProductName")
          });

        if (query != null) {
          ret = query.ToList();
        }

        RowsAffected = ret.Count;
      }

      return ret;
    }
    #endregion
    
    #region SearchByProductName Method
    /// <summary>
    /// Create a Collection of Product objects by searching on Product Name.
    /// </summary>
    /// <returns>A list of vwProduct_SelectAll objects</returns>
    public List<vwProduct_SelectAll> SearchByProductName(vwProduct_SelectAll search) {
      List<vwProduct_SelectAll> ret = new List<vwProduct_SelectAll>();
      
      // Set any search parameters to null if needed
      search.ProductName = (string.IsNullOrWhiteSpace(search.ProductName) ? null : search.ProductName);

      ret = BuildCollection(search);

      return ret;
    }
    #endregion
  }
}

