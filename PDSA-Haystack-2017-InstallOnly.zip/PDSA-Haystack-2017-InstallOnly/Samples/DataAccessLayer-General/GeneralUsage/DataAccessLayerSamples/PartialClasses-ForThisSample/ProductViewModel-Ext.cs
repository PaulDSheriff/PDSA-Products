using System;
using System.Collections.Generic;


namespace DataAccessLayerSamples
{
  public partial class ProductViewModel
  {
    #region SPGetProducts Method
    public List<Product> SPGetProducts() {
      ProductReadOnlyNoParamsManager mgr = new ProductReadOnlyNoParamsManager();

      DataCollection = mgr.BuildCollection();

      return DataCollection;
    }
    #endregion

    #region SPGetProductsInputParam Method
    public List<Product> SPGetProductsInputParam() {
      ProductReadOnlyInputParamsManager mgr = new ProductReadOnlyInputParamsManager();

      // Move input into Product object
      // NOTE: You can either pass in the wildcard character to use, or you can put this into the SP
      DetailData.ProductName = SearchEntity.ProductName + "%";

      // Search using Product object
      DataCollection = mgr.BuildCollection(DetailData);

      return DataCollection;
    }
    #endregion

    #region SPGetProductsInputOutputParam Method
    public List<Product> SPGetProductsInputOutputParam() {
      int? rows = 0;
      List<Product> ret = new List<Product>();
      ProductReadOnlyInOutParamsManager mgr = new ProductReadOnlyInOutParamsManager();

      // Move input into Product object
      // NOTE: You can either pass in the wildcard character to use, or you can put this into the SP
      DetailData.ProductName = SearchEntity.ProductName + "%";

      // Search using Product object
      DataCollection = mgr.BuildCollection(DetailData);

      // Get the OUTPUT parameter
      rows = DetailData.RowsRead;

      return ret;
    }
    #endregion

    #region SPProductInsert Method
    public int SPProductInsert() {
      ProductInsertManager mgr = new ProductInsertManager();

      // NOTE: If you use SET NOCOUNT ON in your stored proc, TotalRecords will be -1
      TotalRecords = mgr.Execute(DetailData);
      if (mgr.ErrorOccurred) {
        // Retrieve the error message from the manager class
        LastExceptionMessage = mgr.Message;
      }
      else {
        TotalRecords = 1;
      }

      return TotalRecords;
    }
    #endregion

    #region SPProductInsertWithOutput Method
    public int SPProductInsertWithOutput() {
      ProductInsertWithOutputManager mgr = new ProductInsertWithOutputManager();
      int rows = 0;

      // NOTE: If you use SET NOCOUNT ON in your stored proc, TotalRecords will be -1
      mgr.Execute(DetailData);
      if (mgr.ErrorOccurred) {
        // Retrieve the error message from the manager class
        LastExceptionMessage = mgr.Message;
      }
      else {
        // NOTE: RowsInserted is the OUTPUT parameter from this stored procedure.
        // Get the OUTPUT parameter
        rows = DetailData.RowsInserted.Value;
      }

      return rows;
    }
    #endregion

    public List<vwProduct_SelectAll> ViewSelectAllCollection { get; set; } = new List<vwProduct_SelectAll>();

    #region ViewGetAll Method
    public void ViewGetAll() {
      vwProduct_SelectAllManager mgr = null;

      base.Init();
      try {
        mgr = new vwProduct_SelectAllManager();

        ViewSelectAllCollection = mgr.BuildCollection();
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region ViewSelectSubsetOfColumns Method
    public void ViewSelectSubsetOfColumns() {
      vwProduct_SelectAllManager mgr = null;
      vwProduct_SelectAllSearch search = new vwProduct_SelectAllSearch();

      base.Init();
      try {
        // Create Manager Object
        mgr = new vwProduct_SelectAllManager();

        // Create Collection of Product Objects
        ViewSelectAllCollection = mgr.SelectSubsetOfColumns(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region ViewSimpleSearch Method
    /// <summary>
    /// Create a Collection of Product objects by searching on Product Name.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<vwProduct_SelectAll> ViewSimpleSearch() {
      vwProduct_SelectAllManager mgr = null;
      vwProduct_SelectAll search = new vwProduct_SelectAll();

      // Move Search Parameters into Search object
      search.ProductName = SearchEntity.ProductName;

      base.Init();
      try {
        // Create Manager Object
        mgr = new vwProduct_SelectAllManager();

        // Create Collection of Customer Objects
        ViewSelectAllCollection = mgr.SearchByProductName(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;
        
        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return ViewSelectAllCollection;
    }
    #endregion

    #region ViewSimpleRowCount Method
    /// <summary>
    /// Count records in product table
    /// </summary>
    /// <returns>A count of Products</returns>
    public int ViewSimpleRowCount() {
      vwProduct_SelectAllManager mgr = null;
      vwProduct_SelectAll search = new vwProduct_SelectAll();

      base.Init();
      try {
        // Create Manager Object
        mgr = new vwProduct_SelectAllManager();

        // Get Total Records in Search Criteria
        TotalRecords = mgr.RowCount(search);

        // Set the SQL string for debugging
        SqlString = mgr.SQL;

        // Get any message to display
        LastExceptionMessage = mgr.Message;
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }

      return TotalRecords;
    }
    #endregion

    #region CustomValidation Method
    public void CustomValidation() {
      ProductValidator validator = null;
      Product entity = new Product();

      try {
        entity.IntroductionDate = Convert.ToDateTime("1/1/2009");
        entity.Cost = 10;
        entity.Price = 5;

        validator = new ProductValidator(entity);
        validator.Validate();

        ValidationRuleFailures.AddRange(validator.ValidationRuleFailures);
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region ValidationUsingDataModificationAction Method
    public void ValidationUsingDataModificationAction() {
      ProductValidator validator = null;
      Product entity = new Product();

      try {
        entity.IntroductionDate = Convert.ToDateTime("1/1/2009");
        entity.Price = 0;

        validator = new ProductValidator(entity);
        validator.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
        validator.Validate();

        ValidationRuleFailures.AddRange(validator.ValidationRuleFailures);
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region SimpleTransaction Method
    public bool SimpleTransaction() {
      List<Product> entities = new List<Product>();
      Product entity = new Product();

      entity.ProductName = "New Product 1";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 1;
      entity.Price = 2;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      entity = new Product();
      entity.ProductName = "New Product 2";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 2;
      entity.Price = 4;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      entity = new Product();
      entity.ProductName = "New Product 3";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 3;
      entity.Price = 6;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      return SimpleTransaction(entities);
    }

    /// <summary>
    /// This method shows how to create a transaction to insert multiple Product objects
    /// </summary>
    /// <param name="entities">A list of product entity objects</param>
    /// <returns></returns>
    public bool SimpleTransaction(List<Product> entities) {
      ProductManager mgr = new ProductManager();
      bool ret = false;

      try {
        //************************************************
        //*** BEGIN TRANSACTION
        //************************************************
        mgr.StartTransaction();

        // Loop through each entity and submit to the database
        foreach (Product item in entities) {
          switch (item.DataModificationAction) {
            case PDSA.Validation.PDSADataModificationState.Unknown:
              throw new Exception("Data Modification State for Entity " + item.ToString() + " was Unknown");
            case PDSA.Validation.PDSADataModificationState.Insert:
              ret = mgr.Insert(item);
              break;
            case PDSA.Validation.PDSADataModificationState.Update:
              ret = mgr.Update(item);
              break;
            case PDSA.Validation.PDSADataModificationState.Delete:
              ret = mgr.Delete(item) == 1;
              break;
          }
          if (ret == false) {
            // Get properties from Manager class     
            LastExceptionMessage = mgr.Message;
            ValidationFailed = mgr.ValidationFailed;
            ValidationRuleFailures.AddRange(mgr.ValidationRuleFailures);
            break;
          }
        }

        //************************************************
        //*** END OF TRANSACTION STUFF
        //************************************************
        if (ret) {
          // Commit the Transaction
          mgr.CommitTransaction();
        }
        else {
          // Roll back the transaction
          mgr.RollbackTransaction();
        }
      }
      catch (Exception ex) {
        mgr.RollbackTransaction();
        LastException = ex;
        LastExceptionMessage = ex.ToString();
      }
      finally {
        // Close and Dispose of everything
        mgr.CleanUp();
      }

      return ret;
    }
    #endregion

    #region SampleTransactionWithException Method
    public bool SampleTransactionWithException() {
      List<Product> entities = new List<Product>();
      Product entity = new Product();

      entity.ProductName = "New Product 1";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 1;
      entity.Price = 2;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      entity = new Product();
      // NOTE: Change ProductName to string.Empty to test a validation error
      entity.ProductName = "This is going to be a very long product name in order to test an exception and make sure we get back the correct exception message that we can display on the MVC page.";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 2;
      entity.Price = 4;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      entity = new Product();
      entity.ProductName = "New Product 3";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 3;
      entity.Price = 6;
      entity.DataModificationAction = PDSA.Validation.PDSADataModificationState.Insert;
      entities.Add(entity);

      return SampleTransactionWithException(entities);
    }

    /// <summary>
    /// This method shows how to create a transaction to insert multiple Product objects
    /// </summary>
    /// <param name="entities">A list of product entity objects</param>
    /// <returns></returns>
    public bool SampleTransactionWithException(List<Product> entities) {
      ProductManager mgr = new ProductManager();
      bool ret = false;

      if (entities != null && entities.Count > 0) {
        try {
          //************************************************
          //*** BEGIN TRANSACTION
          //************************************************
          mgr.StartTransaction();

          // Loop through each entity and submit to the database
          foreach (Product item in entities) {
            switch (item.DataModificationAction) {
              case PDSA.Validation.PDSADataModificationState.Unknown:
                throw new Exception("Data Modification State for Entity " + item.ToString() + " was Unknown.");
              case PDSA.Validation.PDSADataModificationState.Insert:
                ret = mgr.Insert(item);
                break;
              case PDSA.Validation.PDSADataModificationState.Update:
                ret = mgr.Update(item);
                break;
              case PDSA.Validation.PDSADataModificationState.Delete:
                ret = mgr.Delete(item) == 1;
                break;
            }
            if (ret == false) {
              // Get properties from Manager class     
              LastExceptionMessage = mgr.Message;
              ValidationFailed = mgr.ValidationFailed;
              ValidationRuleFailures.AddRange(mgr.ValidationRuleFailures);
              break;
            }
          }

          //************************************************
          //*** END OF TRANSACTION STUFF
          //************************************************
          if (ret) {
            // Commit the Transaction
            mgr.CommitTransaction();
          }
          else {
            // Roll back the transaction
            mgr.RollbackTransaction();
          }
        }
        catch (Exception ex) {
          mgr.RollbackTransaction();
          LastException = ex;
          LastExceptionMessage = ex.ToString();
        }
        finally {
          // Close and Dispose of everything
          mgr.CleanUp();
        }
      }

      return ret;
    }
    #endregion
  }
}
