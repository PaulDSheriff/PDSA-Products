using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to add additional properties to the Product class
  /// </summary>
  public partial class Product
  {
    public int? RowsRead { get; set; }
    public int? RowsInserted { get; set; }
  }
 
}
