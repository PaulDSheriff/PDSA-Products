using PDSA.UI;
using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using DataAccessLayerSamples;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  public partial class OrderHeaderViewModel : PDSAMVCViewModelBase
  {
    #region OrderHeaderDetailInsertInTransaction Methods
    public bool OrderHeaderDetailInsertInTransaction() {
      OrderHeader headerEntity = new OrderHeader();
      List<OrderLineItem> lineItems = new List<OrderLineItem>();
      OrderLineItem lineItem = new OrderLineItem();

      headerEntity.CustomerId = 1;
      headerEntity.OrderDate = DateTime.Now;
      headerEntity.Notes = "Special Delivery";
      headerEntity.DataModificationAction = PDSADataModificationState.Insert;

      lineItem = new OrderLineItem();
      lineItem.ProductName = "New Line Item 1";
      lineItem.Quantity = 1;
      lineItem.UnitPrice = 1;
      lineItem.DataModificationAction = PDSADataModificationState.Insert;
      lineItems.Add(lineItem);

      lineItem = new OrderLineItem();
      lineItem.ProductName = "New Line Item 2";
      lineItem.Quantity = 2;
      lineItem.UnitPrice = 2;
      lineItem.DataModificationAction = PDSADataModificationState.Insert;
      lineItems.Add(lineItem);

      return OrderHeaderDetailInsertInTransaction(headerEntity, lineItems);
    }

    public bool OrderHeaderDetailInsertInTransaction(OrderHeader headerEntity, List<OrderLineItem> lineItems) {
      bool ret = false;
      OrderHeaderManager mgrHeader = null;
      OrderLineItemManager mgrLines = null;

      try {
        mgrHeader = new OrderHeaderManager();
        mgrLines = new OrderLineItemManager();

        //************************************************
        //*** BEGIN TRANSACTION
        //************************************************
        mgrHeader.StartTransaction();

        // Assign transaction object to line items manager
        mgrLines.Transaction = mgrHeader.Transaction;

        // Insert order header
        ret = mgrHeader.Insert(headerEntity);
        if (ret) {
          // Loop through each line item and submit to the database
          foreach (OrderLineItem item in lineItems) {
            // Get OrderId from OrderHeader and assign to each line item
            item.OrderId = headerEntity.OrderId;
            // Insert Line Item record
            ret = mgrLines.Insert(item);
            if (ret == false) {
              // Get properties from Manager class     
              LastExceptionMessage = mgrLines.Message;
              ValidationFailed = mgrLines.ValidationFailed;
              ValidationRuleFailures.AddRange(mgrLines.ValidationRuleFailures);
              break;
            }
          }
        }
        else {
          // Get properties from Manager class     
          LastExceptionMessage = mgrHeader.Message;
          ValidationFailed = mgrHeader.ValidationFailed;
          ValidationRuleFailures.AddRange(mgrHeader.ValidationRuleFailures);
        }

        //************************************************
        //*** END OF TRANSACTION STUFF
        //************************************************
        if (ret) {
          // Commit the Transaction
          mgrHeader.CommitTransaction();
        }
        else {
          // Roll back the transaction
          mgrHeader.RollbackTransaction();
        }
      }
      catch (Exception ex) {
        mgrHeader.RollbackTransaction();
        LastException = ex;
      }
      finally {
        // Close and Dispose of everything
        mgrHeader.CleanUp();
        mgrLines.CleanUp();
      }

      return ret;
    }
    #endregion
  }
}
