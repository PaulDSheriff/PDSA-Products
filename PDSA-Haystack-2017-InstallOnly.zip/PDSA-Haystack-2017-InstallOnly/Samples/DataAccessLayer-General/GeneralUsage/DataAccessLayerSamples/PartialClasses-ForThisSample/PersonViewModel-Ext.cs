using PDSA.DataAccess;
using System;

namespace DataAccessLayerSamples
{
  public partial class PersonViewModel
  {
    #region ValidationSimple Method
    public void ValidationSimple() {
      PersonValidator validator = null;
      Person entity = new Person();

      try {
        validator = new PersonValidator(entity);
        validator.Validate();

        ValidationRuleFailures.AddRange(validator.ValidationRuleFailures);
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region ValidationThrowException Method
    public void ValidationThrowException() {
      PersonValidator validator = null;
      Person entity = new Person();

      try {
        validator = new PersonValidator(entity);
        validator.ThrowExceptionWhenValidationFails = true;
        validator.Validate();
      }
      catch (PDSADataValidationException ex) {
        ValidationRuleFailures.AddRange(ex.ValidationMessages);
      }
      catch (Exception ex) {
        HandleExceptionMessages(ex);
      }
    }
    #endregion

    #region InsertSimple Method
    public void InsertSimple() {
      bool isInserted = false;
      Person entity = new Person();
      PersonManager mgr = new PersonManager();

      entity.FirstName = "John";
      entity.LastName = "Kuhn";
      entity.EmailAddress = "support@pdsa.com";
      entity.InsertName = "dbo";
      entity.InsertDate = DateTime.Now;
      entity.UpdateName = "dbo";
      entity.UpdateDate = DateTime.Now;

      isInserted = mgr.Insert(entity);
    }
    #endregion

    #region UpdateSimple Method
    public void UpdateSimple() {
      bool isUpdated = false;
      Person entity = new Person();
      PersonManager mgr = new PersonManager();

      // Load the old data first
      entity = mgr.Load(1);

      // Modify the data you want to change
      entity.EmailAddress = "newsupport@pdsa.com";
      entity.UpdateName = "dbo";
      entity.UpdateDate = DateTime.Now;

      // Update the data
      isUpdated = mgr.Update(entity);
    }
    #endregion

    #region DeleteSimple Method
    public void DeleteSimple() {
      int rowsDeleted = 0;
      Person entity = new Person();
      PersonManager mgr = new PersonManager();

      // Fill in the primary key
      entity.PersonId = 1;

      // Delete the record
      rowsDeleted = mgr.Delete(entity);
    }
    #endregion
  }
}
