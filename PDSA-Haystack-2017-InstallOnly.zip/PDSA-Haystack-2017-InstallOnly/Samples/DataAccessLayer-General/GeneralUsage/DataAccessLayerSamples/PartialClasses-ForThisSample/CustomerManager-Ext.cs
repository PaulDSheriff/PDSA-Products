using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using PDSA.DataAccess;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for you to extend the CustomerManager class
  /// </summary>
  public partial class CustomerManager
  {
    #region SelectSubsetOfColumns Method
    /// <summary>
    /// Create a Collection of Customer objects Using a Subset of Columns
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SelectSubsetOfColumns() {
      DataTable dt = null;
      List<Customer> ret = new List<Customer>();

      // Build SQL Statement with just the columns you want
      SqlBuilder.SQLSelect = "SELECT CustomerId,CompanyName,FirstName,LastName,TotalSales ";
      SqlBuilder.SQLSelect += " FROM PDSASample.Customer ";
      // Build SQL Statement
      SqlBuilder.BuildSQLForSelect();

      // Build a Data Table
      dt = GetDataTable();

      if (dt != null) {
        // Build Collection of Customer Objects
        var query =
          (from dr in dt.AsEnumerable()
           select new Customer {
             CustomerId = dr.GetDataAs<int?>("CustomerId"),
             CompanyName = dr.GetDataAs<string>("CompanyName"),
             FirstName = dr.GetDataAs<string>("FirstName"),
             LastName = dr.GetDataAs<string>("LastName"),
             TotalSales = dr.GetDataAs<decimal?>("TotalSales"),
           });

        if (query != null) {
          ret = query.ToList();
        }

        RowsAffected = ret.Count;
      }

      return ret;
    }
    #endregion

    #region SearchByCompanyName Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on Company Name.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SearchByCompanyName(Customer search) {
      List<Customer> ret = new List<Customer>();

      // Set any search parameters to null if needed
      search.CompanyName = (string.IsNullOrWhiteSpace(search.CompanyName) ? null : search.CompanyName);

      ret = BuildCollection(search);

      return ret;
    }
    #endregion

    #region SearchByCompanyNameAndTotalSales Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on company name and total sales.
    /// </summary>
    /// <returns>A list of Customer objects</returns>
    public List<Customer> SearchByCompanyNameAndTotalSales(Customer search) {
      List<Customer> ret = new List<Customer>();

      // Clear Where and Order By 
      SqlBuilder.SelectWhereItems.Clear();
      SqlBuilder.OrderByItems.Clear();

      // Add search item filters
      SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.CompanyName,
        CustomerManager.ColumnNames.CompanyName, PDSASQLBuilder.LIKE, PDSAWildCard.WildCardAfter);
      SqlBuilder.AddSelectWhereItem("TotalSalesMin",
        CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.GREATER_THAN_EQUAL_TO, PDSAWildCard.None);
      SqlBuilder.AddSelectWhereItem("TotalSalesMax",
        CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.LESS_THAN_EQUAL_TO, PDSAWildCard.None);

      // Set SORT field and direction
      SqlBuilder.AddOrderByItem(CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.SORT_DESC);

      // Create Collection of Customer Objects
      ret = BuildCollection(search);

      return ret;
    }
    #endregion

    #region CountByCompanyNameAndTotalSales Method
    /// <summary>
    /// Create a Collection of Customer objects by searching on company name and total sales.
    /// </summary>
    /// <returns>Total Count of Records in Search</returns>
    public int CountByCompanyNameAndTotalSales(Customer search) {
      int ret = 0;

      // Set any search parameters to null if needed
      search.CompanyName = (string.IsNullOrWhiteSpace(search.CompanyName) ? null : search.CompanyName);

      // Clear Where Items 
      SqlBuilder.SelectWhereItems.Clear();

      // Add search item filters
      SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.CompanyName,
          CustomerManager.ColumnNames.CompanyName, PDSASQLBuilder.LIKE, PDSAWildCard.WildCardAfter);
      SqlBuilder.AddSelectWhereItem("TotalSalesMin",
          CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.GREATER_THAN_EQUAL_TO, PDSAWildCard.None);
      SqlBuilder.AddSelectWhereItem("TotalSalesMax",
          CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.LESS_THAN_EQUAL_TO, PDSAWildCard.None);

      // Create Collection of Customer Objects
      ret = RowCount(search);

      return ret;
    }
    #endregion

    #region GetTotalSales Method
    /// <summary>
    /// Return a single value using MAX(TotalSales)
    /// </summary>
    /// <returns>Total Sales</returns>
    public decimal GetTotalSales(Customer search) {
      object value = null;
      decimal ret = 0;

      // Initialize SQL Builder
      SqlBuilder.SQLSelect = "SELECT SUM(TotalSales) FROM PDSASample.Customer ";
      SqlBuilder.SelectWhereItems.Clear();

      // Add search item filters
      SqlBuilder.AddSelectWhereItem(CustomerManager.PropertyNames.CompanyName,
        CustomerManager.ColumnNames.CompanyName, PDSASQLBuilder.LIKE, PDSAWildCard.WildCardAfter);

      // Get Total Sales Amount
      value = ExecuteScalar<Customer>(search);
      if (value != null && value != DBNull.Value) {
        ret = (decimal)value;
      }

      return ret;
    }
    #endregion

    #region UpdateTotalSalesOnly Method
    public int UpdateTotalSalesOnly() {
      int ret = 0;

      Customer entity = new Customer();

      // Clear all update parameters as we will be adding our own
      SqlBuilder.UpdateParameters.Clear();
      // Clear all WHERE clauses as we will be adding our own
      SqlBuilder.UpdateWhereItems.Clear();
      // Build the UPDATE statement
      SqlBuilder.SQLUpdate = "UPDATE PDSASample.Customer SET TotalSales = TotalSales * 1.10";
      // Add WHERE clause to only update records WHERE TotalSales > ?
      SqlBuilder.UpdateWhereItems.Add(new PDSASQLBuilderWhereItem(CustomerManager.PropertyNames.TotalSales, CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.GREATER_THAN));
      // Add Update Parameter to match the value in the WHERE clause
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter(CustomerManager.PropertyNames.TotalSales, CustomerManager.PropertyNames.TotalSales));
      // Build the full UPDATE statement
      SqlBuilder.BuildSQLForUpdate();
      // Set the value for TotalSales > ?
      entity.TotalSales = 0;

      // Perform the bulk update
      ret = UpdateBulk<Customer>(entity);

      return ret;
    }
    #endregion

    #region UpdateTotalSalesWhereNull Method
    public int UpdateTotalSalesWhereNull(Customer entity) {
      int ret = 0;

      // Clear all update parameters as we will be adding our own
      SqlBuilder.UpdateParameters.Clear();
      // Clear all WHERE clauses as we will be adding our own
      SqlBuilder.UpdateWhereItems.Clear();
      // Build the UPDATE statement
      SqlBuilder.SQLUpdate = "UPDATE PDSASample.Customer SET TotalSales = @NewTotal";
      // Add WHERE clause to only select records WHERE TotalSales IS NULL
      SqlBuilder.UpdateWhereItems.Add(new PDSASQLBuilderWhereItem(CustomerManager.PropertyNames.TotalSales, CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.IS_NULL));
      // Add Update Parameter to match the value to set TotalSales to
      SqlBuilder.UpdateParameters.Add(new PDSASQLBuilderParameter("@NewTotal", CustomerManager.PropertyNames.TotalSales));
      // Build the full UPDATE statement
      SqlBuilder.BuildSQLForUpdate();

      // Perform the bulk update
      ret = UpdateBulk<Customer>(entity);

      return ret;
    }
    #endregion

    #region DeleteTotalSalesEqualValue Method
    public int DeleteTotalSalesEqualValue(Customer entity) {
      int ret = 0;

      // Clear all delete where items as we will be adding our own
      SqlBuilder.DeleteWhereItems.Clear();
      // Build the DELETE statement
      SqlBuilder.SQLDelete = "DELETE FROM PDSASample.Customer";
      // Add WHERE clause to only delete records WHERE TotalSales = ?
      SqlBuilder.DeleteWhereItems.Add(new PDSASQLBuilderWhereItem(CustomerManager.PropertyNames.TotalSales, CustomerManager.ColumnNames.TotalSales, PDSASQLBuilder.EQUAL_TO));
      // Build the full DELETE statement
      SqlBuilder.BuildSQLForDelete();

      // Perform the bulk Delete
      ret = DeleteBulk<Customer>(entity);

      return ret;
    }
    #endregion
  }
}
