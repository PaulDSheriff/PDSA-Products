﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DataAccessLayerSamples.Controllers
{
  public class HomeController : Controller
  {
    [HttpGet()]
    public ActionResult Index() {
      return View();
    }

    #region Select and Search Samples
    [HttpGet()]
    public ActionResult SelectSample01() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SelectSample01(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.GetAllCustomers();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SelectSample02() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SelectSample02(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SelectSubsetOfColumns();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SelectSample03() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SelectSample03(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SimpleSearch();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SelectSample04() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SelectSample04(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SearchAndSort();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SelectSample05() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.DetailData.CustomerId = 1;
      return View(vm);
    }

    [HttpPost()]
    public ActionResult SelectSample05(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.LoadByPK(Convert.ToInt32(vm.DetailData.CustomerId));

      return View(vm);
    }
    #endregion

    #region Scalar Value Samples
    [HttpGet()]
    public ActionResult ScalarSample01() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ScalarSample01(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SimpleRowCount();

      return View(vm);
    }


    [HttpGet()]
    public ActionResult ScalarSample02() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.DetailData.CustomerId = 1;
      return View(vm);
    }

    [HttpPost()]
    public ActionResult ScalarSample02(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.RowCountUsingWhere();

      return View(vm);
    }
  
    [HttpGet()]
    public ActionResult ScalarSample03() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ScalarSample03(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.RowCountUsingIsNull();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ScalarSample04() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ScalarSample04(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.GetTotalSales();

      return View(vm);
    }
    #endregion

    #region Transform Data Samples       
    [HttpGet()]
    public ActionResult TransformSample01() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransformSample01(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.GetDataAsJSON();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TransformSample02() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransformSample02(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.GetDataAsXML();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TransformSample03() {
      CustomerViewModel vm = new CustomerViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransformSample03(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.GetDataAsExcelString();

      return View(vm);
    }
    #endregion

    #region Modify Data Samples
    [HttpGet()]
    public ActionResult ModifySample01() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample01(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.DetailData.CompanyName = "A New Company - " + DateTime.Now.ToString();
      vm.DetailData.Address1 = "123 Any Street";
      vm.DetailData.City = "Nashville";
      vm.DetailData.StateCode = "TN";
      vm.DetailData.PostalCode = "37066";
      vm.DetailData.Country = "USA";

      if (!vm.CauseValidationError) {
        vm.DetailData.FirstName = "Don";
        vm.DetailData.LastName = "Jones";
        vm.DetailData.EmailAddress = "Someone@newcompany.com";
        vm.DetailData.Fax = "(615) 123-FAXI";
        vm.DetailData.Phone = "(615) 123-TELE";
        vm.DetailData.Title = "President";
        vm.DetailData.TotalSales = 123;
      }

      vm.DetailData.InsertDate = DateTime.Now;
      vm.DetailData.InsertName = vm.PDSALoginName;
      vm.DetailData.UpdateDate = DateTime.Now;
      vm.DetailData.UpdateName = vm.PDSALoginName;

      vm.DataInsert();

      Session["LastCustomerId"] = vm.DetailData.CustomerId;

      // Another sample located here:
      //PersonViewModel pvm = new PersonViewModel();
      //pvm.InsertSimple();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ModifySample02() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.PDSALoginName = User.Identity.Name;
      vm.DetailData.CustomerId = Convert.ToInt32(Session["LastCustomerId"]);

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample02(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.LoadByPK(vm.DetailData.CustomerId);

      vm.DetailData.CompanyName += " - CHANGED";

      if (vm.CauseValidationError) {
        vm.DetailData.CompanyName = string.Empty;
        vm.DetailData.FirstName = string.Empty;
        vm.DetailData.LastName = string.Empty;
      }
      else {
        vm.DetailData.FirstName += " - CHANGED";
      }
      vm.DetailData.UpdateDate = DateTime.Now;
      vm.DetailData.UpdateName = vm.PDSALoginName;

      vm.DataUpdate();

      // Another sample located here:
      //PersonViewModel pvm = new PersonViewModel();
      //pvm.UpdateSimple();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ModifySample03() {
      CustomerViewModel vm = new CustomerViewModel();
      
      vm.PDSALoginName = User.Identity.Name;
      vm.DetailData.CustomerId = Convert.ToInt32(Session["LastCustomerId"]);

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample03(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.LoadByPK(vm.DetailData.CustomerId);

      vm.DataDelete();

      // Another sample located here:
      //PersonViewModel pvm = new PersonViewModel();
      //pvm.DeleteSimple();

      return View(vm);
    }
    #endregion

    #region Bulk Modify Samples
    [HttpGet()]
    public ActionResult ModifySample04() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample04(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.UpdateTotalSalesOnly();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ModifySample05() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample05(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.UpdateTotalSalesWhereNull();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ModifySample06() {
      CustomerViewModel vm = new CustomerViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ModifySample06(CustomerViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.DeleteTotalSalesEqualValue();

      return View(vm);
    }
    #endregion

    #region Stored Procedure Samples
    [HttpGet()]
    public ActionResult SPSample01() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SPSample01(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SPGetProducts();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SPSample02() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SPSample02(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SPGetProductsInputParam();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SPSample03() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SPSample03(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SPGetProductsInputOutputParam();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SPSample04() {
      ProductViewModel vm = new ProductViewModel();

      vm.CreateNewEntity();
      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SPSample04(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SPProductInsert();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult SPSample05() {
      ProductViewModel vm = new ProductViewModel();

      vm.CreateNewEntity();
      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult SPSample05(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SPProductInsertWithOutput();

      return View(vm);
    }
    #endregion

    #region View Samples
    [HttpGet()]
    public ActionResult ViewSample01() {
      ProductViewModel vm = new ProductViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ViewSample01(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ViewGetAll();

      return View(vm);
    }
    
    [HttpGet()]
    public ActionResult ViewSample02() {
      ProductViewModel vm = new ProductViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ViewSample02(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ViewSelectSubsetOfColumns();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ViewSample03() {
      ProductViewModel vm = new ProductViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ViewSample03(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ViewSimpleSearch();

      return View(vm);
    }


    [HttpGet()]
    public ActionResult ViewSample04() {
      ProductViewModel vm = new ProductViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ViewSample04(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ViewSimpleRowCount();

      return View(vm);
    }

    #endregion

    #region Validation Samples
    [HttpGet()]
    public ActionResult ValidationSample01() {
      PersonViewModel vm = new PersonViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ValidationSample01(PersonViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ValidationSimple();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ValidationSample02() {
      PersonViewModel vm = new PersonViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ValidationSample02(PersonViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ValidationThrowException();

      return View(vm);
    }


    [HttpGet()]
    public ActionResult ValidationSample03() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ValidationSample03(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.CustomValidation();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult ValidationSample04() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult ValidationSample04(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.ValidationUsingDataModificationAction();

      return View(vm);
    }
    #endregion

    #region Transaction Samples
    [HttpGet()]
    public ActionResult TransactionSample01() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransactionSample01(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SimpleTransaction();
      
      return View(vm);
    }

    [HttpGet()]
    public ActionResult TransactionSample02() {
      ProductViewModel vm = new ProductViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransactionSample02(ProductViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.SampleTransactionWithException();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TransactionSample03() {
      OrderHeaderViewModel vm = new OrderHeaderViewModel();

      vm.PDSALoginName = User.Identity.Name;

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TransactionSample03(OrderHeaderViewModel vm) {
      vm.PDSALoginName = User.Identity.Name;

      vm.OrderHeaderDetailInsertInTransaction();

      return View(vm);
    }
    #endregion

    #region Table Using Stored Procedure Samples    
    [HttpGet()]
    public ActionResult TableSPSample01() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample01(ProductSPViewModel vm) {
      vm.GetAllProducts();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TableSPSample02() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample02(ProductSPViewModel vm) {
      vm.GetAProduct();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TableSPSample03() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample03(ProductSPViewModel vm) {
      vm.SimpleRowCount();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TableSPSample04() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample04(ProductSPViewModel vm) {
      vm.Insert();

      return View(vm);
    }

    [HttpGet()]
    public ActionResult TableSPSample05() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample05(ProductSPViewModel vm) {
      vm.Update();

      return View(vm);
    }
    
    [HttpGet()]
    public ActionResult TableSPSample06() {
      ProductSPViewModel vm = new ProductSPViewModel();

      return View(vm);
    }

    [HttpPost()]
    public ActionResult TableSPSample06(ProductSPViewModel vm) {
      vm.Delete();

      return View(vm);
    }
    #endregion
  }
}