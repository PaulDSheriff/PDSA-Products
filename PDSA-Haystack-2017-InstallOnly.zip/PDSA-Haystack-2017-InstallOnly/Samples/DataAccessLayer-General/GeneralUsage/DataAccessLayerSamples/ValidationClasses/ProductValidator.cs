using System;
using PDSA.DataAccess;
using PDSA.Validation;

namespace DataAccessLayerSamples
{
  /// <summary>
  /// This class is for your to modify if you need add more business rules
  /// </summary>
  public partial class ProductValidator
  {
    #region Init Method
    public override void Init() {
      base.Init();

      // Do any initialization here
      ClassName = "ProductValidator";

    }
    #endregion

    /// <summary>
    /// Validate all Data Annotations on Product object
    /// Validate any additional business rules defined here
    /// </summary>
    /// <returns>True if valid, False if not</returns>
    public override bool Validate() {
      IsValid = false;
      ValidationRuleFailures.Clear();

      // Leave the following line to check for Data Annotations
      base.Validate(EntityToValidate);

      //**********************************************************
      // Fill in any additional business rules here
      //**********************************************************
      if (EntityToValidate.Price < EntityToValidate.Cost) {
        AddValidationMessage("Price", "Price must be less than the cost.");
      }
      // Check to see if the Introduction Date is greater than the year 2010
      if (EntityToValidate.IntroductionDate.HasValue &&
          EntityToValidate.IntroductionDate < Convert.ToDateTime("1/1/2010")) {
        AddValidationMessage("IntroductionDate",
                              "Introduction Date Must Be Greater than 1/1/2010.");
      }

      if (DataModificationAction == PDSADataModificationState.Insert) {
        if (EntityToValidate.Price == 0) {
          AddValidationMessage("Price", "When adding a new product, Price cannot be Zero (0).");
        }
      }

      IsValid = (ValidationRuleFailures.Count == 0);

      // Check to see if we should throw an exception
      if (!IsValid && ThrowExceptionWhenValidationFails) {
        throw new PDSADataValidationException(
          string.Format(PDSAValidationMessages.BusinessRulesFailed,
          "Product"),
          "Product", ValidationRuleFailures);
      }

      return IsValid;
    }
  }
}
