﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;

namespace CheckBoxList
{
  public partial class Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        LoadTypes();
    }

    private void LoadTypes()
    {
      EmployeeTypeManager mgr = new EmployeeTypeManager();

      Session["EmpList"] = mgr.BuildCollection();

      clstTypes.DataTextField = EmployeeTypeValidator.ColumnNames.TypeDescription;
      clstTypes.DataValueField = EmployeeTypeValidator.ColumnNames.EmployeeTypeID;
      clstTypes.DataSource = Session["EmpList"];
      clstTypes.DataBind();
    }

    protected void btnGetChecked_Click(object sender, EventArgs e)
    {
      EmployeeTypeCollection coll = null;
      EmployeeTypeCollection selected = new EmployeeTypeCollection();

      // You should step through to see which ones are selected from the list
      System.Diagnostics.Debugger.Break();

      coll = (EmployeeTypeCollection)Session["EmpList"];
      foreach (ListItem item in clstTypes.Items)
      {
        if (item.Selected)
        {
          selected.Add(coll.First(type => type.EmployeeTypeID == Convert.ToInt32(item.Value)));
        }
      }

      // You can uncomment out the following to insert just the items selected
      //InsertSelected(selected);
    }

    private void InsertSelected(EmployeeTypeCollection selected)
    {
      EmployeeTypeManager mgr = new EmployeeTypeManager();

      foreach (EmployeeType item in selected)
      {
        mgr.Insert(item);
      }
    }
  }
}