Overview of this Sample
--------------------------------------
This sample allows you to step through the code to see which list members have been selected.

Tables Used - Only the Business and Entity Classes
---------------------------------------------------
EmployeeType

Note:
---------------------------------------------------
Seializable is not enabled in the EmployeeType.cs class because session is used.