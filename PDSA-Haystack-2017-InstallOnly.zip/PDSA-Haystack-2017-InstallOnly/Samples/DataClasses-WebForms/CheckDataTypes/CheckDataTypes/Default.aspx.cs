﻿using System;
using System.Web.UI;

using Sample.Project.EntityLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.ValidationLayer;

namespace CheckDataTypes
{
  public partial class Default : System.Web.UI.Page
  {
    protected void btnCheckDefaults_Click(object sender, EventArgs e)
    {
      CheckDataTypes();
    }

    private void CheckDataTypes()
    {
      ProductValidator validator = new ProductValidator(null);

      try
      {
        if (txtProductId.Text.Trim() != string.Empty)
          validator.Properties.GetByName(ProductValidator.ColumnNames.ProductId).Value = txtProductId.Text;
        if (txtProductName.Text.Trim() != string.Empty)
          validator.Properties.GetByName(ProductValidator.ColumnNames.ProductName).Value = txtProductName.Text;
        if (txtIntroductionDate.Text.Trim() != string.Empty)
          validator.Properties.GetByName(ProductValidator.ColumnNames.IntroductionDate).Value = txtIntroductionDate.Text;
        if (txtCost.Text.Trim() != string.Empty)
          validator.Properties.GetByName(ProductValidator.ColumnNames.Cost).Value = txtCost.Text;
        if (txtPrice.Text.Trim() != string.Empty)
          validator.Properties.GetByName(ProductValidator.ColumnNames.Price).Value = txtPrice.Text;
        validator.Properties.GetByName(ProductValidator.ColumnNames.IsDiscontinued).Value = chkIsDiscontinued.Checked;

        if (validator.Properties.CheckBusinessRules() == PDSA.Validation.PDSAValidationRuleStatus.Failed)
          lblMessages.Text = validator.Properties.BusinessRuleMessages.ToString().Replace(Environment.NewLine, "<br />");
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.WriteLine(ex.Message);
        System.Diagnostics.Debugger.Break();
      }
    }
  }
}