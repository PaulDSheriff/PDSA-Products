Overview of this Sample
--------------------------------------
This sample shows how the validation system will automatically check for valid data types.

Tables Used - Only the Business and Entity Classes
---------------------------------------------------
Product