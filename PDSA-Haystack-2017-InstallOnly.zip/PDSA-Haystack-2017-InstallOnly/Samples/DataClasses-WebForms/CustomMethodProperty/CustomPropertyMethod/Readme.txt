Overview of this Sample
--------------------------------------
This sample shows how to add a custom method and property to the Manager class and consume that from an ASP.NET ObjectDataSource class to feed data to a GridView.

Tables Used
-----------
Product - Dynamic SQL Only

Stored Procs Used
-----------------------------------------------------
ProductGetDiscontinuedItems - Map Entity to Product


How this Sample was Created
-----------------------------------------------------------
Created this stored proc in the PDSASample database:

CREATE PROC PDSASample.ProductGetDiscontinuedItems
AS
SELECT * FROM PDSASample.Product
WHERE IsDiscontinued <> 0;

Created a new Haystack Project pointing to the PDSASamples database

Generated the Product Table
Generated the ProductGetDiscontinuedItems Stored Procedure
  Set the "Map to Entity To" property to "Product"

Clicked Generate

Created a new ASP.NET project and add the appropriate PDSA DLLs

Add the Generated classes to this project

Opened the ProductManager class and added the following in the #Region "Your Custom Properties and Methods"


private ProductCollection mDiscontinuedItems = null;

public ProductCollection DiscontinuedItems {
	get {
		if (mDiscontinuedItems == null) {
			GetDiscontinuedItems();
		}

		return mDiscontinuedItems;
	}
	set { mDiscontinuedItems = value; }
}

public ProductCollection GetDiscontinuedItems()
{
	ProductGetDiscontinuedItemsManager mgr = new ProductGetDiscontinuedItemsManager();

	mDiscontinuedItems = mgr.BuildCollection();

	return mDiscontinuedItems;
}

On Default.aspx added a GridView control
Added an ObjectDataSource and set the data source to the ProductManager class
Chose the method GetDiscontinuedItems and bound it to your GridView Control