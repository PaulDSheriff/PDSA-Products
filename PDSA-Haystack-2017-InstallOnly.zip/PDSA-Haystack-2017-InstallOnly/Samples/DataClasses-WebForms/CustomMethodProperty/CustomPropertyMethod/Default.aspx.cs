﻿using System;
using System.Web.UI;

using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;

namespace CustomPropertyMethod
{
  public partial class _Default : System.Web.UI.Page
  {
  }
}
