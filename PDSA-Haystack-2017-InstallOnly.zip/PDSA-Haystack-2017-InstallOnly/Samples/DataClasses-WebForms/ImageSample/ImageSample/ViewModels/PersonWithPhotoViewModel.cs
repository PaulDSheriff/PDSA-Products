using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;

using PDSA.Common;
using PDSA.UI;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;


namespace Sample.Project.ViewModel
{
  public class PersonWithPhotoViewModel : PDSAWebViewModelBase
  {
    #region Constructor
    /// <summary>
    /// Constructor for PersonWithPhotoViewModel.
    /// </summary>
    public PersonWithPhotoViewModel() : base()
    {
      RecordName = "Person With Photo";
      RecordNamePlural = "Person With Photos";

      ResetMessages();

      IsPrimaryKeyAutoNumber = true;
    }
    #endregion

   
    #region DataCollection Property
    private ObservableCollection<PersonWithPhoto> _DataCollection = new ObservableCollection<PersonWithPhoto>();
    
    /// <summary>
    /// An Observable collection of PersonWithPhoto objects
    /// </summary>
    public ObservableCollection<PersonWithPhoto> DataCollection
    {
      get { return _DataCollection; }
      set 
      { 
        _DataCollection = value; 
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    private PersonWithPhoto _DetailData = new PersonWithPhoto();
    
    /// <summary>
    /// The currently selected PersonWithPhoto object
    /// </summary>
    public PersonWithPhoto DetailData
    {
      get { return _DetailData; }
      set 
      { 
        _DetailData = value; 
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region SearchEntity Property
    /// <summary>
    /// Get/Set the Entity class used for searching
    /// </summary>
    public PersonWithPhoto SearchEntity
    {
      get
      {
        // Create Manager Object if not created
        if (_Manager == null)
          CreateManagerObject();

        return _Manager.SearchEntity;
      }
      set 
      { 
        _Manager.SearchEntity = value; 
        RaisePropertyChanged("SearchEntity");
      }
    }
    #endregion
    
    #region Old Entity for Undo Functionality
    private PersonWithPhoto _OriginalEntity = null;
    #endregion

    #region Manager Object
    private PersonWithPhotoManager _Manager = null;
    #endregion
        
    #region CreateManagerObject Method
    private PersonWithPhotoManager CreateManagerObject()
    {
      if(_Manager == null)
      {
        _Manager = new PersonWithPhotoManager();
        _Manager.PDSALoginName = PDSALoginName;
        _Manager.SearchEntity = SearchEntity;

        // Add any additional settings here to Manager class
        // _Manager.Validator.Properties.SetAllSetAsNullToTrue();
        // _Manager.DataProvider.ConnectString = System.Configuration.ConfigurationManager.ConnectionStrings["YOURCONNECTSTRING"].ConnectionString;
        // _Manager.DataObject.UseStoredProcs = true;
        // _Manager.DataObject.UseAuditTracking = true;

      }
      
      return _Manager;
    }
    #endregion

    #region LoadAll Method
    /// <summary>
    /// Create a Collection of PersonWithPhoto objects.
    /// </summary>
    public ObservableCollection<PersonWithPhoto> LoadAll()
    {
      DataCollection.Clear();

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        _Manager.DataObject.SelectFilter = PersonWithPhotoData.SelectFilters.All;
        _Manager.DataObject.WhereFilter = PersonWithPhotoData.WhereFilters.None;

        // Apply Search if necessary
        if (_Manager.SearchEntity.IsDirty)
        {
          _Manager.Entity.FirstName = _Manager.SearchEntity.FirstName;
          // Initialize Search Filter
          _Manager.DataObject.SelectFilter = PersonWithPhotoData.SelectFilters.Search;
        }

        // Retrieve the collection from the Data Object
        DataCollection = new ObservableCollection<PersonWithPhoto>(_Manager.BuildCollection());
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;
        if (TotalRecords == 0)
          SetViewStateMode(PDSAUIState.NoRecords);
        else
          SetViewStateMode(PDSAUIState.ListOnly);
      }
      catch (Exception ex)
      {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return DataCollection;
    }
    #endregion

    #region GetDataSet Method
    /// <summary>
    /// Return a DataSet
    /// </summary>
    public DataSet GetDataSet()
    {
      DataSet ret = new DataSet();

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        _Manager.DataObject.SelectFilter = PersonWithPhotoData.SelectFilters.All;
        _Manager.DataObject.WhereFilter = PersonWithPhotoData.WhereFilters.None;

        // Apply Search if necessary
        if (_Manager.SearchEntity.IsDirty)
        {
          _Manager.Entity.FirstName = _Manager.SearchEntity.FirstName;
          // Initialize Search Filter
          _Manager.DataObject.SelectFilter = PersonWithPhotoData.SelectFilters.Search;
        }

        // Get the Data Set
        ret = _Manager.GetDataSet();
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
        // Set the Total Records Retrieved
        TotalRecords = DataCollection.Count;
        if (TotalRecords == 0)
          SetViewStateMode(PDSAUIState.NoRecords);
        else
          SetViewStateMode(PDSAUIState.ListOnly);
      }
      catch (Exception ex)
      {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion

    #region LoadByPK Method
    /// <summary>
    /// Load a single PersonWithPhoto object by primary key
    /// </summary>
    /// <param name="personId">The primary key to find</param>
    /// <returns>A PersonWithPhoto object</returns>
    public PersonWithPhoto LoadByPK(int personId)
    {
      LastException = null;
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        // Set Primary Key
        _Manager.Entity.PersonId = personId;
        
        _Manager.DataObject.SelectFilter = PersonWithPhotoData.SelectFilters.PrimaryKey;
        if (_Manager.DataObject.Load() == 1)
        {
          DetailData = _Manager.Entity;
        }
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
      }
      catch (Exception ex)
      {
        LastException = ex;
        if (HandleCustomExceptions(ex) == false)
          HandleValidationMessages(LastException.Message);
      }

      return DetailData;
    }
    #endregion

    #region ResetSearch Method
    /// <summary>
    /// Reset all Search Criteria to default values
    /// </summary>
    public void ResetSearch()
    {
      // Create/Get Manager Object
      _Manager = CreateManagerObject();

      // Reset Search Filter Properties
      _Manager.InitSearchFilter();
    }
    #endregion
    
    #region DeleteByPK Methods
    /// <summary>
    /// Deletes the entity creating an entity with the primary keys filled in and calling the overloaded DeleteByPK method.
    /// </summary>
    /// <param name="personId">The primary key to delete</param>
    /// <returns>1 if deleted, otherwise zero</returns>
    public int DeleteByPK(int personId)
    {
      DetailData = new PersonWithPhoto();

      // Load old entity in case you wish to do audit tracking after deleting
      DetailData = LoadByPK(personId);

      return DeleteByPK();      
    }

    /// <summary>
    /// Deletes the currently selected entity
    /// </summary>
    /// <returns>1 if deleted, otherwise zero</returns>
    public int DeleteByPK()
    {
      int ret = 0;

      LastException = null;
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        // Set Entity object with data to delete
        _Manager.Entity = DetailData;
        
        // Delete the Record
        _Manager.DataObject.DeleteFilter = PersonWithPhotoData.DeleteFilters.DeleteByPK;
        ret = _Manager.Delete(DetailData);
        // Set the Audit String in case you want to track the Delete
        XmlAuditString = _Manager.DataObject.AuditRowAsXml;
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
        if (ret >= 1)
        {
          // Delete from the Collection
          DataCollection.Remove(DetailData);
          TotalRecords = DataCollection.Count;
        }
        else
        {
          LastException = new Exception(base.NoRowsAffectedMessageDelete);
          HandleExceptionMessages(LastException.Message);
        }
      }
      catch (PDSA.DataLayer.DataClasses.PDSAZeroRowsException)
      {
        LastException = new Exception(base.NoRowsAffectedMessageDelete);
        HandleValidationMessages(base.NoRowsAffectedMessageDelete);
      }
      catch (Exception ex)
      {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }
      
      return ret;
    }
    #endregion

    #region CreateNewEntity Method
    /// <summary>
    /// Creates a new Entity object with default values and assigns to DetailData property
    /// </summary>
    /// <returns>A PersonWithPhoto Object</returns>
    public PersonWithPhoto CreateNewEntity()
    {
      // Create blank Entity Object
      DetailData = CreateManagerObject().Validator.CreateNewEntity();

      // TODO: Set any defaults here
      // Below is an Example 
      // DetailData.IntroductionDate = DateTime.Now;

      // Set UI State
      SetViewStateMode(PDSAUIState.Add);


      return DetailData;
    }
    #endregion

    //public object GetPhoto(int personId)
    //{
    //  PersonWithPhotoManager mgr = CreateManagerObject();

    //  //return mgr.GetPhoto(personId);
    //}

    #region DataSave Method
    /// <summary>
    /// Inserts or Updates the passed in entity object
    /// Calls the DataSave method in the base class, which in turn calls either DataInsert or DataUpdate methods based on what state the UI is in.
    /// </summary>
    /// <param name="entity">The entity to save</param>
    /// <returns>True if successful, false is not</returns>
    public bool DataSave(PersonWithPhoto entity)
    {
      bool ret = false;

      DetailData = entity;
      ret = base.DataSave();

      if (ret)
        SetViewStateMode(PDSAUIState.ListOnly);

      return ret;
    }
    #endregion

    #region DataInsert Methods
    /// <summary>
    /// Inserts the current entity into the data store
    /// </summary>
    /// <param name="entity">The entity to insert</param>
    /// <returns>bool</returns>
    public bool DataInsert(PersonWithPhoto entity)
    {
      DetailData = entity;

      return DataInsert();
    }

    /// <summary>
    /// Inserts the current entity into the data store
    /// Called by the DataSave method
    /// </summary>
    /// <returns>bool</returns>
    public override bool DataInsert()
    {
      bool ret = false;

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();
        // Set the data to Insert
        _Manager.Entity = DetailData;

        // Perform the Insert
        ret = (_Manager.Insert(DetailData) >= 1);

        // ADDED
        // Perform the Photo Update
        _Manager.InsertPhoto(DetailData);
        _Manager.InsertThumbnail(DetailData, 100, 100);

        // Set the Audit String in case you want to track the Delete
        XmlAuditString = _Manager.DataObject.AuditRowAsXml;
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
        if (ret)
        {
          // In case anything was changed in the Insert
          DetailData = _Manager.Entity;

          // Add new entity to the collection
          DataCollection.Add(DetailData);
          TotalRecords = DataCollection.Count;
        }
        else
        {
          LastException = new Exception(base.NoRowsAffectedMessageInsert);
          HandleExceptionMessages(LastException.Message);
        }
      }
      catch (PDSAValidationException ex)
      {
        ValidationRuleFailures = _Manager.Validator.Properties.BusinessRuleMessages;
        HandleValidationMessages(ex);
      }
      catch (Exception ex)
      {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion

    #region DataUpdate Methods
    /// <summary>
    /// Updates the current Entity to the data store
    /// Called by the DataSave method
    /// </summary>
    /// <param name="entity">The entity to update</param>
    /// <returns>boolean</returns>
    public bool DataUpdate(PersonWithPhoto entity)
    {
      DetailData = entity;

      return DataUpdate();
    }

    /// <summary>
    /// Updates the current Entity to the data store
    /// Called by the DataSave method
    /// </summary>
    /// <returns>boolean</returns>
    public override bool DataUpdate()
    {
      bool ret = false;

      LastException = null;
      ValidationRuleFailures = new PDSAValidationRules();
      try
      {
        // Get Manager Object
        _Manager = CreateManagerObject();
        // Set the data to update
        _Manager.Entity = DetailData;
        
        // Perform the Update
        _Manager.DataObject.UpdateFilter = PersonWithPhotoData.UpdateFilters.PrimaryKey;
        ret = (_Manager.Update(DetailData) >= 1);
        // Set the Audit String in case you want to track the Delete
        XmlAuditString = _Manager.DataObject.AuditRowAsXml;
        // Set the SQL string for debugging
        SqlString = _Manager.DataObject.SQL;
        if (ret)
        {
          // In case anything was changed in the Update
          DetailData = _Manager.Entity;
        }
        else
        {
          LastException = new Exception(base.NoRowsAffectedMessageUpdate);
          HandleExceptionMessages(LastException.Message);
        }        
      }
      catch (PDSAValidationException ex)
      {
        ValidationRuleFailures = _Manager.Validator.Properties.BusinessRuleMessages;
        HandleValidationMessages(ex);
      }
      catch (PDSA.DataLayer.DataClasses.PDSAZeroRowsException)
      {
        LastException = new Exception(base.NoRowsAffectedMessageUpdate);
        HandleExceptionMessages(base.NoRowsAffectedMessageUpdate);
      }
      catch (Exception ex)
      {
        if (HandleCustomExceptions(ex) == false)
          HandleExceptionMessages(ex);
      }

      return ret;
    }
    #endregion
    
    #region SaveCurrent Method
    /// <summary>
    /// Clones the currently selected Entity object. 
    /// Call this prior editing the current record.
    /// If you wish to undo the changes made, call the Undo() method
    /// </summary>
    public void SaveCurrent()
    {
      if (DetailData != null)
      {
        // Create/Get Manager Object
        _Manager = CreateManagerObject();

        _OriginalEntity = _Manager.Validator.CloneEntity(DetailData);
      }
    }
    #endregion

    #region Undo Method
    /// <summary>
    /// Restores the original data back to the current entity
    /// </summary>
    public void Undo()
    {
      if (_OriginalEntity != null)
      {
        _Manager = new PersonWithPhotoManager();

        DetailData = _Manager.Validator.CloneEntity(_OriginalEntity);

        SetViewStateMode(PDSAUIState.ListOnly);
      }
    }
    #endregion

    #region ValidateDataTypes Method
    /// <summary>
    /// Check all data to ensure they are the correct type
    /// </summary>
    /// <param name="values">A Dictionary of strings</param>
    /// <returns>True if valid data types</returns>
    public bool ValidateDataTypes(Dictionary<string, string> values)
    {
      bool ret = true;
      PersonWithPhotoValidator validator = new PersonWithPhotoValidator(null);
      
      // Load data into Validator Properties collection
      foreach(KeyValuePair<String,String> entry in values)
        validator.Properties.GetByName(entry.Key).Value = entry.Value;
      
      // Validate any other custom rules for this page
      ValidateCustomRules(validator);

      // Check all business rules
      if (validator.Properties.CheckBusinessRules() == PDSA.Validation.PDSAValidationRuleStatus.Failed)
      {
        ret = false;
        ValidationRuleFailures = validator.Properties.BusinessRuleMessages;
        HandleValidationMessages(validator.Properties.BusinessRuleMessages.ToString().Replace(Environment.NewLine, "<br />"));
      }

      return ret;
    }
    #endregion
  
    #region ValidateCustomRules
    /// <summary>
    /// Call this method to handle any custom validation rules
    /// </summary>
    /// <param name="validator">Your business rule validator object</param>
    public void ValidateCustomRules(PersonWithPhotoValidator validator)
    {
        // Handle any special validations
        //if(SOME_VARIABLE == SOME_CONDITION)
          //validator.Properties.BusinessRuleMessages.Add(new PDSAValidationRule("PROPERTY", "YOUR MESSAGE"));
    }
    #endregion
        
    #region Handle Custom Exceptions
    /// <summary>
    /// Call this method to handle any specific exceptions and display your own custom messages
    /// </summary>
    /// <param name="ex">An Exception object</param>
    /// <returns>False if you have NOT handled the exception.</returns>
    protected bool HandleCustomExceptions(Exception ex)
    {
      bool ret = false;

      // Check to see if you want to handle any exceptions yourself.
      // The following is an example of checking for a duplicate primary key error in SQL Server
      //if (ex.InnerException is System.Data.SqlClient.SqlException)
      //{
      //  System.Data.SqlClient.SqlException sqlEx = (System.Data.SqlClient.SqlException)ex.InnerException;
      //  if (sqlEx.Number == 2627) // Primary key Violation from SQL Server
      //    this.AddBusinessRuleMessage("OrderId", "You have entered duplicate data for this record.");

      //  ret = true;
      //}

      return ret;
    }
    #endregion

    #region HandleExceptionMessages Method
    /// <summary>
    /// Sets an exception object into the LastException property of this ViewModel class
    /// </summary>
    /// <param name="ex">An exception object</param>
    protected override void HandleExceptionMessages(Exception ex)
    {
      base.HandleExceptionMessages(ex);

      // Add your own exception logging here
    }   

    /// <summary>
    /// Sets an exception message into the LastExceptionMessage property of this ViewModel class 
    /// </summary>
    /// <param name="message">The message to set</param>
    protected override void HandleExceptionMessages(string message)
    {
      base.HandleExceptionMessages(message);

      // Add your own exception logging here
    }
    #endregion

    public object GetPhoto(int personId)
    {
       PersonWithPhotoManager mgr = CreateManagerObject();

       return mgr.GetPhoto(personId);
    }
  
  }
}
