﻿Upload and Display a Photo
------------------------------------------------------
By default, Haystack does not generate code to upload images or documents.
If you have a table with an 'image' data type, you can make some changes that will allow you to accomplish this.

Run the included SqlScript.sql script in SQL Server.

In the PDSASamples database, there is a table called PersonWithPhoto that this sample uses.

Generate code for the PersonWithPhoto table

Modify the PersonWithPhotoView.aspx 
======================================
Change the 
<asp:TextBox ID="txtPhoto" ReadOnly="false" ToolTip="" runat="server" />
to
<input type="file" id="txtPhoto" name="txtPhoto" runat="server" />

After changing this control, you will have some errors, so do a build and comment out all the lines that are in error.

Within the <asp:TemplateField HeaderText="Action" HeaderStyle-ForeColor="white" HeaderStyle-Width="50px"> add the following image button
   <asp:ImageButton ID="imgDisplay" runat="server"
                    ImageUrl="~/Images/Undo.png" ToolTip="Display Photo" CommandName="DisplayPhoto"
                    CssClass="actionsImage" PersonId='<%# Eval("PersonId") %>'></asp:ImageButton>

At the bottom of the web page add an Image control
<asp:Image ID="imgPerson" runat="server" />

Modify the PersonWithPhotoManager Class
================================================================================
using System.Data.SqlClient;
using System.IO;

Add a new method to get a photo from the 'image' type.

    public object GetPhoto(int personId)
    {
      byte[] picture = null;
      PDSADataManager mgr = new PDSADataManager();
      IDataParameter param;
      IDbCommand cmd = null;

      try
      {
        // Create Command Object
        cmd = mgr.Provider.CreateCommand("SELECT Photo FROM " + DataObject.DBObjectName + " WHERE PersonId = @PersonId");
        
        param = mgr.Provider.CreateParameter("@PersonId", DbType.Int32);
        param.Value = personId;
        cmd.Parameters.Add(param);

        // Create Connection
        cmd.Connection = mgr.Provider.CreateConnection();
        cmd.Connection.Open();
        // Execute Scalar to get Picture
        picture = (byte[])mgr.Provider.ExecuteScalar(cmd);
        return picture;
      }
      catch (Exception)
      {
        
      }
      finally
      {
        if (cmd != null)
        {
          cmd.Connection.Close();
          cmd.Connection.Dispose();
          cmd.Dispose();
        }
      }

      return picture;
    }

    
Add a new method to insert a photo
    /// <summary>
    /// NOTE: This needs to be called immediately after an INSERT or UPDATE so the entity is already filled in with the correct PK
    /// </summary>
    /// <param name="entity">A PersonWithPhoto</param>
    public void InsertPhoto(PersonWithPhoto entity)
    {
      IDbCommand cmd = null;
      PDSADataManager mgr = new PDSADataManager();
      SqlParameter param;
      string sql;

      sql = "UPDATE " + DataObject.DBObjectName + " SET Photo = @Photo WHERE " + PersonWithPhotoValidator.ColumnNames.PersonId + " = @PersonId";
      cmd = mgr.Provider.CreateCommand(sql);
      // Create 'Photo' Parameter
      // Have to cast to a SqlParameter because the generic DbType does not support "Image"
      param = (SqlParameter)mgr.Provider.CreateParameter("@Photo");
      param.SqlDbType = SqlDbType.Image;
      param.Value = (byte[])entity.Photo;
      cmd.Parameters.Add(param);

      param = (SqlParameter)mgr.Provider.CreateParameter("@PersonId", DbType.Int32);
      param.Value = entity.PersonId;
      cmd.Parameters.Add(param);

      // Create Connection
      cmd.Connection = mgr.Provider.CreateConnection();
      // Execute the SQL & Close the Connection
      mgr.Provider.ExecuteSQL(cmd, true);
    }

Modify the PersonWithPhotoViewModel Class
=====================================================================
Add a method to get a photo using the Manger class

    public object GetPhoto(int personId)
    {
      PersonWithPhotoManager mgr = CreateManagerObject();

      return mgr.GetPhoto(personId);
    }

Locate the DataInsert() method that says '// Perform the Insert and add code after to call the InsertPhoto() method in the Manager class

        // Perform the Insert
        ret = (_Manager.Insert(DetailData) >= 1);

        // ADDED
        // Perform the Photo Update
        _Manager.InsertPhoto(DetailData);



Modify the PersonWithPhotoView.aspx
========================================================================
Modify the btnSave_Click procedure to upload the file and turn is into a stream, the convert the stream into an array of bytes that you will store into the Photo property of the Entity class.

protected void btnSave_Click(object sender, ImageClickEventArgs e)
{
  PersonWithPhoto entity;
  bool ret = false;

  // ADDED 
  if ((txtPhoto.PostedFile != null) && (txtPhoto.PostedFile.ContentLength > 0))
  {
    try
    {
      if (ValidateDataTypes())
      {
        entity = GetData();
        
        // ADDED 
        MemoryStream stream = new MemoryStream();
        txtPhoto.PostedFile.InputStream.CopyTo(stream);
        entity.Photo = stream.ToArray();

        // Now Save the Data
        ret = _ViewModel.DataSave(entity);
        if (ret)
        {
          grdData.DataBind();
        }
      }
    }
    catch (Exception ex)
    {
      _ViewModel.ValidationRuleFailures.Add(new PDSAValidationRule("PhotoUpload", ex.Message));
    }
  }
  else
  {
    _ViewModel.ValidationRuleFailures.Add(new PDSAValidationRule("PhotoUpload", "Please select a file to upload."));
  }

  SetUIState();
}


Now modify the grdData_RowCommand event procedure to display the photo.
Add a new 'else if' statement as shown below.

  else if (e.CommandName == "DisplayPhoto")
      {
        // ADDED
        ImageButton btn;
        int id;

        btn = (ImageButton)e.CommandSource;

        id = Convert.ToInt32(btn.Attributes["PersonId"]);

        imgPerson.ImageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])_ViewModel.GetPhoto(id));
      }

