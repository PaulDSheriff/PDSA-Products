using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PDSA.Common;
using PDSA.UI;
using PDSA.Validation;

using Sample.Project.EntityLayer;
using Sample.Project.ValidationLayer;
using Sample.Project.BusinessLayer;
using Sample.Project.DataLayer;
using Sample.Project.ViewModel;

namespace Sample.Project
{
  public partial class PersonWithPhotoView : System.Web.UI.Page
  {
    private PersonWithPhotoViewModel _ViewModel = null;

    #region PDSALoginName Property
    private string PDSALoginName
    {
      get
      {
        string ret = string.Empty;

        ret = HttpContext.Current.User.Identity.Name;
        if (string.IsNullOrEmpty(ret))
          ret = PDSA.Common.PDSAUserIdentity.GetUserName();

        return ret;
      }
    }
    #endregion

    #region UIState Property
    private PDSAUIState UIState
    {
      get
      {
        if (ViewState["WebUIState"] == null)
          ViewState["WebUIState"] = PDSAUIState.Normal;

        return (PDSAUIState)ViewState["WebUIState"];
      }
      set { ViewState["WebUIState"] = value; }
    }
    #endregion

    #region EntityObject Property
    private PersonWithPhoto _EntityObject = null;
    private PersonWithPhoto EntityObject
    {
      get
      {
        if (ViewState["PersonWithPhotoEntity"] == null)
          ViewState["PersonWithPhotoEntity"] = PDSAString.GetAsJSON(typeof(PersonWithPhoto), new PersonWithPhoto());
        if (_EntityObject == null)
          _EntityObject = (PersonWithPhoto)PDSAString.GetFromJSON(typeof(PersonWithPhoto), ViewState["PersonWithPhotoEntity"].ToString());

        return (_EntityObject);
      }
      set
      {
        _EntityObject = value;
        ViewState["PersonWithPhotoEntity"] = PDSAString.GetAsJSON(typeof(PersonWithPhoto), value);
      }
    }
    #endregion

    #region Page Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
      _ViewModel = new PersonWithPhotoViewModel();
      // Get User Name
      _ViewModel.PDSALoginName = PDSALoginName;

      if (Page.IsPostBack)
      {
        // Need to restore state from previous settings
        _ViewModel.SetViewStateMode(UIState);
      }
      else
      {
        InitText();
        BindGridSizes();
        // Set initial state of page
        _ViewModel.SetViewStateMode(PDSAUIState.ListOnly);
        SetUIState();
      }
    }
    #endregion

    #region InitText Method
    /// <summary>
    /// Use this method to initialize all text, tooltips and any other 
    /// text data.
    /// </summary>
    private void InitText()
    {
      // Update text into appropriate controls
      lblRecordCount.Text = _ViewModel.RowCountText;
      lblPageTitle.Text = _ViewModel.ControlTitle;
      lblEditTitle.Text = _ViewModel.DetailHeader;
      lblFilterTitle.Text = _ViewModel.SearchAreaTitle;
      btnAdd.ToolTip = _ViewModel.AddToolTip;
      btnSave.ToolTip = _ViewModel.SaveToolTip;
      btnCancel.ToolTip = _ViewModel.CancelToolTip;
    }
    #endregion

    #region BindGridSizes Method
    private void BindGridSizes()
    {
      ddlGridSize.DataTextField = "Value";
      ddlGridSize.DataValueField = "Key";
      ddlGridSize.DataSource = _ViewModel.GridPageSizes;
      ddlGridSize.DataBind();
    }
    #endregion

    #region Grid RowCommand Event
    protected void grdData_RowCommand(Object sender, GridViewCommandEventArgs e)
    {
      if (e.CommandName == "Select")
      {
        ImageButton btn;

        btn = (ImageButton)e.CommandSource;

        _ViewModel.SetViewStateMode(PDSAUIState.Edit);
        EntityObject = _ViewModel.LoadByPK(Convert.ToInt32(btn.Attributes["PersonId"]));
        ShowData(EntityObject);
        SetUIState();
      }
      else if (e.CommandName == "Delete")
      {
        ImageButton btn;

        btn = (ImageButton)e.CommandSource;

        Delete(Convert.ToInt32(btn.Attributes["PersonId"]));
      }
      else if (e.CommandName == "DisplayPhoto")
      {
        // ADDED
        ImageButton btn;
        int id;

        btn = (ImageButton)e.CommandSource;

        id = Convert.ToInt32(btn.Attributes["PersonId"]);

        imgPerson.ImageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])_ViewModel.GetPhoto(id));
      }
    }
    #endregion

    #region Grid RemoveSelection Event
    protected void grdData_RemoveSelection(object sender, EventArgs e)
    {
      grdData.SelectedIndex = -1;
    }
    #endregion

    #region Delete Method
    private void Delete(int personId)
    {
      // Save Primary Key Info for Tracking Changes
      EntityObject.PersonId = personId;

      if (_ViewModel.DeleteByPK(personId) >= 1)
      {
        grdData.DataBind();
      }

      SetUIState();
    }
    #endregion

    #region ShowData Method
    private void ShowData(PersonWithPhoto entity)
    {
      txtFirstName.Text = PDSAString.ConvertToStringTrim(entity.FirstName);
      txtLastName.Text = PDSAString.ConvertToStringTrim(entity.LastName);
      //txtPhoto.PostedFile.FileName = PDSAString.ConvertToStringTrim(entity.Photo);
    }
    #endregion

    #region GetData Method
    private PersonWithPhoto GetData()
    {
      PersonWithPhoto entity;

      entity = EntityObject;
      entity.IsDirty = false;
      if (!string.IsNullOrEmpty(txtFirstName.Text.ToString()))
        entity.FirstName = PDSAString.ConvertToStringTrim(txtFirstName.Text);
      else
        entity.SetAsNullFlagForProperty(PersonWithPhotoValidator.ColumnNames.FirstName, true);
      if (!string.IsNullOrEmpty(txtLastName.Text.ToString()))
        entity.LastName = PDSAString.ConvertToStringTrim(txtLastName.Text);
      else
        entity.SetAsNullFlagForProperty(PersonWithPhotoValidator.ColumnNames.LastName, true);
      //if (!string.IsNullOrEmpty(txtPhoto.Text.ToString()))
      //  entity.Photo = (txtPhoto.Text);
      //else
      //  entity.SetAsNullFlagForProperty(PersonWithPhotoValidator.ColumnNames.Photo, true);

      return entity;
    }
    #endregion

    #region ControlsToDictionary Method
    private Dictionary<string, string> ControlsToDictionary()
    {
      Dictionary<string, string> values = new Dictionary<string, string>();

      // Gather data into dictionary of string objects
      // This will allow us to perform error checking on it 
      // in the ViewModel and the Validator classes
      values.Add(PersonWithPhotoValidator.ColumnNames.FirstName, txtFirstName.Text.ToString());
      values.Add(PersonWithPhotoValidator.ColumnNames.LastName, txtLastName.Text.ToString());
      //values.Add(PersonWithPhotoValidator.ColumnNames.Photo, txtPhoto.Text.ToString());

      return values;
    }
    #endregion

    #region ValidateDataTypes Method
    private bool ValidateDataTypes()
    {
      bool ret = false;
      Dictionary<string, string> values;

      // Get Controls into Dictionary Object
      values = ControlsToDictionary();

      // Validate the Data Types
      ret = _ViewModel.ValidateDataTypes(values);

      return ret;
    }
    #endregion

    #region Search Click Events
    protected void btnSearch_Click(object sender, ImageClickEventArgs e)
    {
      // Initialize Search Entity for new search
      _ViewModel.ResetSearch();

      if (!string.IsNullOrEmpty(txtFirstNameSearch.Text.ToString()))
        _ViewModel.SearchEntity.FirstName = PDSAString.ConvertToStringTrim(txtFirstNameSearch.Text);


      grdData.DataBind();
    }

    protected void btnResetSearch_Click(object sender, ImageClickEventArgs e)
    {
      // Clear SearchEntity Object
      _ViewModel.ResetSearch();

      // Reset UI
      txtFirstNameSearch.Text = PDSAString.ConvertToStringTrim(_ViewModel.SearchEntity.FirstName);


      grdData.DataBind();
    }
    #endregion

    #region Add Click Event
    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
      grdData.SelectedIndex = -1;
      EntityObject = _ViewModel.CreateNewEntity();
      ShowData(EntityObject);
      UIState = PDSAUIState.Add;
      _ViewModel.SetViewStateMode(PDSAUIState.Add);
      SetUIState();
    }
    #endregion

    #region Save Click Event
protected void btnSave_Click(object sender, ImageClickEventArgs e)
{
  PersonWithPhoto entity;
  bool ret = false;

  // NOTE: This code was changed to support uploading a file
  // Get Photo Upload
  if ((txtPhoto.PostedFile != null) && (txtPhoto.PostedFile.ContentLength > 0))
  {
    try
    {
      if (ValidateDataTypes())
      {
        entity = GetData();
        // ADDED 
        MemoryStream stream = new MemoryStream();
        txtPhoto.PostedFile.InputStream.CopyTo(stream);
        entity.Photo = stream.ToArray();
        // Now Save the Data
        ret = _ViewModel.DataSave(entity);
        if (ret)
        {
          grdData.DataBind();
        }
      }
    }
    catch (Exception ex)
    {
      _ViewModel.ValidationRuleFailures.Add(new PDSAValidationRule("PhotoUpload", ex.Message));
    }
  }
  else
  {
    _ViewModel.ValidationRuleFailures.Add(new PDSAValidationRule("PhotoUpload", "Please select a file to upload."));
  }

  SetUIState();
}
    #endregion

    #region Cancel Click Event
    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
      _ViewModel.SetViewStateMode(PDSAUIState.ListOnly);
      SetUIState();
    }
    #endregion

    #region SetUIState Method
    private void SetUIState()
    {
      UIState = _ViewModel.UIState;

      // Turn on and off appropriate controls
      pnlEdit.Visible = _ViewModel.IsDetailAreaVisible;
      pnlFilter.Visible = _ViewModel.IsSearchAreaVisible;
      pnlTitle.Visible = _ViewModel.IsTitleAreaVisible;
      btnAdd.Enabled = _ViewModel.IsAddEnabled;
      btnAdd.Visible = _ViewModel.IsAddVisible;
      btnSave.Enabled = _ViewModel.IsSaveEnabled;
      btnSave.Visible = _ViewModel.IsSaveVisible;
      btnSearch.Enabled = _ViewModel.IsSearchAreaEnabled;
      btnSearch.Visible = _ViewModel.IsSearchAreaVisible;
      btnResetSearch.Enabled = _ViewModel.IsSearchAreaEnabled;
      btnResetSearch.Visible = _ViewModel.IsSearchAreaVisible;
      btnCancel.Enabled = _ViewModel.IsCancelEnabled;
      btnCancel.Visible = _ViewModel.IsCancelVisible;
      lblRecordCount.Visible = _ViewModel.IsRecordCountVisible;
      ddlGridSize.Visible = _ViewModel.IsRecordCountVisible;

      // Setup Grid
      grdData.AllowPaging = _ViewModel.IsPagingAllowed;
      grdData.PageSize = _ViewModel.PageSize - 1;

      // Uncomment one of the following if you wish to 
      // make the grid invisible/disabled during edit
      //grdData.Visible = _ViewModel.IsListVisible;
      //grdData.Enabled = _ViewModel.IsListEnabled;

      // Set Validation, Info Messages and Exception Area info
      pnlValidation.Visible = _ViewModel.IsValidationVisible;
      if (_ViewModel.ValidationRuleFailures.Count > 0)
      {
        lstValidation.DataSource = _ViewModel.ValidationRuleFailures;
        lstValidation.DataBind();
      }
      pnlExceptions.Visible = _ViewModel.ExceptionOccurred;
      lblExceptions.Text = _ViewModel.LastExceptionMessage;
      pnlInfoMessage.Visible = _ViewModel.IsInfoMessageAreaVisible;
      lblInfoMessage.Text = _ViewModel.InfoMessage;
    }
    #endregion

    #region dsData_Selected Event
    protected void dsData_Selected(object sender, ObjectDataSourceStatusEventArgs e)
    {
      if (_ViewModel.ExceptionOccurred)
      {
        lblExceptions.Text = _ViewModel.LastExceptionMessage;
        pnlExceptions.Visible = true;
      }
    }
    #endregion

    #region dsData_ObjectCreating Event
    /// <summary>
    /// This event is used to create the ViewModel object used by the ObjectDataSource
    /// </summary>
    /// <param name="sender">ObjectDataSource</param>
    /// <param name="e">ObjectDataSourceEventArgs</param>
    protected void dsData_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
    {
      e.ObjectInstance = _ViewModel;
    }
    #endregion

    #region ddlGridSize_SelectedIndexChanged Event
    protected void ddlGridSize_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (PDSANumbers.CheckForNumericNonBlank(ddlGridSize.SelectedValue.ToString()))
      {
        _ViewModel.PageSize = Convert.ToInt32(ddlGridSize.SelectedValue);
        grdData.PageSize = _ViewModel.PageSize - 1;
        grdData.DataBind();
      }
    }
    #endregion
  }
}
