Add assemblies to your ASP.NET Web Forms projects from this folder.
