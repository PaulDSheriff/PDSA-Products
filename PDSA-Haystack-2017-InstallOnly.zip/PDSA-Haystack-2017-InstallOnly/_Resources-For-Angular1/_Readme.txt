Add the \Scripts folder to your project into which you have generated Angular v1

NOTE: You may also use NuGet package manager to load Angular into your project
