﻿// ***************************************************
// This function will convert a date into a WCF formatted date 
// which is the number of milliseconds since midnight, Jan. 1, 1970
// Example: /Date(1357027200000)/
// ***************************************************
Date.prototype.toMSDate = function () {
  // Convert date to UTC time
  var newDate = new Date(Date.UTC(this.getFullYear(),
                                  this.getMonth(),
                                  this.getDate(),
                                  this.getHours(),
                                  this.getMinutes(),
                                  this.getSeconds(),
                                  this.getMilliseconds()));

  // Create date in WCF format
  var date = '/Date(' + newDate.getTime() + ')/';

  return date;
};


// ***************************************************
// This function will display an AJAX error
// ***************************************************
function displayError(data, additionalInfo) {
  if (additionalInfo == null) {
    alert(data.statusText);
  }
  else {
    alert(data.statusText + additionalInfo);
  }
};


// ***************************************************
// Replace all tokens within a string
// ***************************************************
String.prototype.replaceAll = function (token, newToken) {
  var str = this + "";
  var i = -1;

  while ((i = str.toLowerCase().indexOf(token, i >= 0 ? i + newToken.length : 0)) !== -1) {
      str = str.substring(0, i) + newToken + str.substring(i + token.length);
  }

  return str;
};
