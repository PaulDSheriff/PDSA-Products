﻿// ***************************************************
// This function will convert a date into a WCF formatted date 
// which is the number of milliseconds since midnight, Jan. 1, 1970
// Example: /Date(1357027200000)/
// ***************************************************
Date.prototype.toMSDate = function () {
  // Convert date to UTC time
  var newDate = new Date(Date.UTC(this.getFullYear(),
                                  this.getMonth(),
                                  this.getDate(),
                                  this.getHours(),
                                  this.getMinutes(),
                                  this.getSeconds(),
                                  this.getMilliseconds()));

  // Create date in WCF format
  var date = '/Date(' + newDate.getTime() + ')/';

  return date;
};


// ***************************************************
// This function will display an AJAX error
// ***************************************************
function displayError(data, additionalInfo) {
  if (additionalInfo == null) {
    alert(data.statusText);
  }
  else {
    alert(data.statusText + additionalInfo);
  }
};

// ***************************************************
// Display Messages from Web API
// ***************************************************
function displayMessage(data) {
   var messages = data.d.FriendlyErrorMessage.split("\n");
   var list = document.getElementById("messages");
   clearMessages();

   for (var i = 0; i < messages.length - 1; i++) {
      var item = document.createElement("li");
      item.innerHTML = messages[i];
      list.appendChild(item);
   }
}
