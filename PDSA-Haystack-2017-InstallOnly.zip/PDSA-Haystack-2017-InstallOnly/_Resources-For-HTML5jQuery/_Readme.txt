Add the \Scripts folder to your project into which you have generated HTML 5 using jQuery
