Haystack Code Generator for .NET v2.0
----------------------------------------------------------
Welcome to Haystack Code Generator for .NET v2.0. We are sure you will find this product greatly increases the speed with which you can create SOA .NET applications.

Please read the ReleaseNotes.pdf file for the latest changes to Haystack.