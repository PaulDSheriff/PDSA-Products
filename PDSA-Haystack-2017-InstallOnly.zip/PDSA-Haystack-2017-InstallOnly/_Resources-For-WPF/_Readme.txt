Add assemblies to your WPF projects from this folder
