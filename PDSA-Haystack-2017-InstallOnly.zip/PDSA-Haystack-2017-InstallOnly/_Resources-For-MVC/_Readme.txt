Add assemblies to your ASP.NET MVC projects from this folder.
