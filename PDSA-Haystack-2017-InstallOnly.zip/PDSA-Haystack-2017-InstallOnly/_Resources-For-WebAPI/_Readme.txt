Add assemblies to your Web API projects from this folder.
