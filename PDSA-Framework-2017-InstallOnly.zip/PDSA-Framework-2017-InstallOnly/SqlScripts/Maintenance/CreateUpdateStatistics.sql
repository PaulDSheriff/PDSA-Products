-- Use this SQL to generate an UPDATE STATISTICS for the tables in your database
-- *** IMPORTANT ***
-- In Query Analyzer go to Query | Results in Text (Ctrl-T)
-- also be sure to go to Options | Results and set the maximum column length to 2048
SELECT 'print ''' + rtrim(TABLE_SCHEMA) + '.' + rtrim(TABLE_NAME) + ''' 
UPDATE STATISTICS ' + rtrim(TABLE_SCHEMA) + '.' + rtrim(TABLE_NAME) + '
Go'
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
