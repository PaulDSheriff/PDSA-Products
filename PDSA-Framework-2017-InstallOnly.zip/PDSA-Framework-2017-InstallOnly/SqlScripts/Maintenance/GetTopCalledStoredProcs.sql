SELECT TOP 100 qt.TEXT AS 'SP Name',
ao.name As ProcedureName,
qs.execution_count AS 'Execution Count',
qs.total_worker_time/qs.execution_count AS 'AvgWorkerTime',
qs.total_worker_time AS 'TotalWorkerTime',
qs.total_physical_reads AS 'PhysicalReads',
qs.creation_time 'CreationTime',
qs.execution_count/DATEDIFF(Second, qs.creation_time, GETDATE()) AS 'Calls/Second'
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
INNER JOIN sys.all_objects ao on ao.object_id = qt.objectid
WHERE qt.dbid = (
SELECT dbid
FROM sys.sysdatabases
WHERE name = 'PDSAFramework500')
ORDER BY qs.execution_count DESC