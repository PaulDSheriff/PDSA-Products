-- SET Date Range
DECLARE @FromDate DateTime
DECLARE @ToDate DateTime
SET @FromDate     = '01/01/2013'
SET @ToDate       = '12/13/2013'

-- Define table variable to convert LoginXML to xml datatype
DECLARE @Table as 
      TABLE
      (
      ResourceName varchar(2000), 
       ResourceKey varchar(2000), 
       LogInfoXML xml ,
      InsertName varchar(50),
      InsertDate datetime 
      )

-- SELECT rows per filter
INSERT @Table
      SELECT ResourceName, ResourceKey,  CAST(LogInfo as XML), InsertName, InsertDate    
      FROM [PDSA].[pdsaLog]
      WHERE LogType = 'AuditTrackUpdate'
      AND EntityId = 2
      AND ResourceName = 'SupplierJob.SupplierJob'
      AND dbo.DateOnly(InsertDate) BETWEEN @FromDate AND @ToDate 

  
  SELECT resourcename as TableName, resourcekey as PK, 
         '''' + T.c.value('@name', 'NVARCHAR(MAX)') + ''' column changed from ''' +  
       T.c.value('@oldValue', 'NVARCHAR(MAX)') + ''' to ''' + 
       T.c.value('@newValue', 'NVARCHAR(MAX)') + '''' as ChangeMessage
      ,T.c.value('@name', 'NVARCHAR(MAX)') as ColumnName
      ,T.c.value('@oldValue', 'NVARCHAR(MAX)') as OldValue
      ,T.c.value('@newValue', 'NVARCHAR(MAX)') as NewValue
      ,InsertName
      ,InsertDate 
  FROM @Table 
  CROSS APPLY
        LogInfoXML.nodes('/AuditRecord/Column') AS T(c) 
 
-- Eliminate row if NO CHANGE
-- We don't care about the INSERT/UPDATE TIME/USER. 
  WHERE  T.c.value('@oldValue', 'NVARCHAR(MAX)') <>  T.c.value('@newValue', 'NVARCHAR(MAX)')      
    AND  T.c.value('@name', 'NVARCHAR(MAX)') NOT IN ('InsertName','InsertDate','UpdateName','UpdateDate')   

  ORDER BY ResourceName, InsertDate
