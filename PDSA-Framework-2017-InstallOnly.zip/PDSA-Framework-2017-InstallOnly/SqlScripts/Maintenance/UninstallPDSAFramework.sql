SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS Off
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
----
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [FK_pdsaApplication_pdsaUserApplicationEntity]
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [FK_pdsaEntity_pdsaUserApplicationEntity]
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [FK_PDSARolePermissionPermissionId]
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [FK_PDSARolePermissionRoleId]
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [FK_PDSAPermissionCategoryId]
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [FK_pdsaUserRoleRoleId]
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [FK_pdsaUser_pdsaUsersOldPassword]
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [FK_pdsaUserRole_pdsaUserApplicationEntity]
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [FK_PDSAUserAttributeTypeId]
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [FK_PDSAUserAttributeUserId]
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [FK_pdsaEntity_pdsaRoleEntity]
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [FK_pdsaPermission_pdsaRoleEntity]
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [FK_PDSARoleApplicationId]
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [FK_pdsaRole_pdsaRole]
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [FK_pdsaApplication_pdsaRole]
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [FK_PDSAPermissionApplicationId]
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [FK_pdsaUserApplicationEntity_pdsaUser]
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [FK_PDSAPermissionCategoryApplicationId]
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [FK_PDSAMenuItemPermissionId]
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [FK_pdsaUserFilterState_pdsaUser]
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [FK_PDSASecurityControlApplicationId]
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [FK_pdsaUserFilterState_pdsaApplication]
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [FK_pdsaMenuItem_ParentMenuId]
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [FK_PDSAUserAttributeTypeApplicationId]
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [FK_PDSAEntityApplicationId]
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [FK_PDSAApplicationSettingApplicationId]
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [FK_PDSAMenuItemApplicationId]
GO

ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [FK_pdsaReferenceTable_pdsaApplication]
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [FK_PDSASerializedObjectApplicationId]
GO


-------------------
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [PK_PDSAApplicationId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_pdsaApplication_DefaultResourceLanguage]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_PDSAApplicationInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_PDSAApplicationInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_PDSAApplicationUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_PDSAApplicationUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplication]'
GO
ALTER TABLE [PDSA].[pdsaApplication] DROP CONSTRAINT [DF_PDSAApplicationConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [PK_pdsaApplicationSetting]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_pdsaApplicationSetting_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_PDSAApplicationSettingInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_PDSAApplicationSettingInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_PDSAApplicationSettingUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_PDSAApplicationSettingUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaApplicationSetting]'
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] DROP CONSTRAINT [DF_PDSAApplicationSettingConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [PK_PDSAEntityId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_pdsaEntity_IsDefault]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_pdsaEntity_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_PDSAEntityInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_PDSAEntityInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_PDSAEntityUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_PDSAEntityUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaEntity]'
GO
ALTER TABLE [PDSA].[pdsaEntity] DROP CONSTRAINT [DF_PDSAEntityConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [PK_pdsaLanguageId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_pdsaLanguage_IsDefault]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_PDSALanguageInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_PDSALanguageInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_PDSALanguageUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_PDSALanguageUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLanguage]'
GO
ALTER TABLE [PDSA].[pdsaLanguage] DROP CONSTRAINT [DF_PDSALanguageConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [PK_PDSALogId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [DF_pdsaLog_InsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [DF_pdsaLog_InsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [DF_pdsaLog_UpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [DF_pdsaLog_UpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaLog]'
GO
ALTER TABLE [PDSA].[pdsaLog] DROP CONSTRAINT [DF_pdsaLog_ConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [PK_PDSAMenuItemId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemDisplayOrder]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemIsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaMenuItem]'
GO
ALTER TABLE [PDSA].[pdsaMenuItem] DROP CONSTRAINT [DF_PDSAMenuItemConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [PK_PDSAPermissionId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_pdsaPermission_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_PDSAPermissionInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_PDSAPermissionInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_PDSAPermissionUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_PDSAPermissionUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermission]'
GO
ALTER TABLE [PDSA].[pdsaPermission] DROP CONSTRAINT [DF_PDSAPermissionConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [PK_PDSAPermissionCategoryId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_pdsaPermissionCategory_IsSystemCategory]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_pdsaPermissionCategory_IsSystemCategory1]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_PDSAPermissionCategoryInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_PDSAPermissionCategoryInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_PDSAPermissionCategoryUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_PDSAPermissionCategoryUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaPermissionCategory]'
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] DROP CONSTRAINT [DF_PDSAPermissionCategoryConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [PK_PDSAReferenceTableId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableIsActiveFlag]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaReferenceTable]'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] DROP CONSTRAINT [DF_PDSAReferenceTableConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [PK_pdsaResourceId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF__pdsaResourceMessageLanguage]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF_pdsaResourceInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF_pdsaResourceInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF_pdsaResourceUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF_pdsaResourceUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResource]'
GO
ALTER TABLE [PDSA].[pdsaResource] DROP CONSTRAINT [DF_pdsaResourceConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [PK_pdsaResourceGroupId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroup_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroupInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroupInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroupUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroupUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] DROP CONSTRAINT [DF_pdsaResourceGroupConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [PK_pdsaResourceGroupType]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_IsDefault]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_InsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_InsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_UpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_UpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceGroupType]'
GO
ALTER TABLE [PDSA].[pdsaResourceGroupType] DROP CONSTRAINT [DF_pdsaResourceGroupType_ConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [PK_pdsaResourceResourceGroupId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [DF_pdsaResourceResourceGroupInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [DF_pdsaResourceResourceGroupInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [DF_pdsaResourceResourceGroupUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [DF_pdsaResourceResourceGroupUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaResourceResourceGroup]'
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] DROP CONSTRAINT [DF_pdsaResourceResourceGroupConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [PK_PDSARoleId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_pdsaRole_IsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_PDSARoleInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_PDSARoleInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_PDSARoleUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_PDSARoleUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRole]'
GO
ALTER TABLE [PDSA].[pdsaRole] DROP CONSTRAINT [DF_PDSARoleConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [PK_pdsaRoleEntityId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [DF_pdsaRoleEntityInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [DF_pdsaRoleEntityInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [DF_pdsaRoleEntityUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [DF_pdsaRoleEntityUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRoleEntity]'
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] DROP CONSTRAINT [DF_pdsaRoleEntityConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [PK_PDSARolePermissionId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [DF_PDSARolePermissionInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [DF_PDSARolePermissionInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [DF_PDSARolePermissionUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [DF_PDSARolePermissionUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaRolePermission]'
GO
ALTER TABLE [PDSA].[pdsaRolePermission] DROP CONSTRAINT [DF_PDSARolePermissionConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [PK_PDSASecurityControlId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [DF_PDSASecurityControlInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [DF_PDSASecurityControlInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [DF_PDSASecurityControlUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [DF_PDSASecurityControlUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSecurityControl]'
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] DROP CONSTRAINT [DF_PDSASecurityControlConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [PK_PDSASerializedObjectId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [DF_PDSASerializedObjectInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [DF_PDSASerializedObjectInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [DF_PDSASerializedObjectUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [DF_PDSASerializedObjectUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaSerializedObject]'
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] DROP CONSTRAINT [DF_PDSASerializedObjectConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [PK_pdsaTableId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdNextId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaTableId]'
GO
ALTER TABLE [PDSA].[pdsaTableId] DROP CONSTRAINT [DF_PDSATableIdConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [PK_PDSAUserId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_pdsaUser_UserLanguage]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserIsLockedOut]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserIsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserResetPasswordFlag]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_pdsaUser_LastPasswordResetDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUser]'
GO
ALTER TABLE [PDSA].[pdsaUser] DROP CONSTRAINT [DF_PDSAUserConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [PK_PDSAUserApplicationEntityId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [DF_PDSAUserApplicationEntityInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [DF_PDSAUserApplicationEntityInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [DF_PDSAUserApplicationEntityUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [DF_PDSAUserApplicationEntityUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserApplicationEntity]'
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] DROP CONSTRAINT [DF_PDSAUserApplicationEntityConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [PK_PDSAUserAttributeId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [DF_PDSAUserAttributeInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [DF_PDSAUserAttributeInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [DF_PDSAUserAttributeUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [DF_PDSAUserAttributeUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttribute]'
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] DROP CONSTRAINT [DF_PDSAUserAttributeConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [PK_PDSAUserAttributeTypeId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeIsActive]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeIsForeignKey]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_pdsaUserAttributeType_DisplayOrder]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserAttributeType]'
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] DROP CONSTRAINT [DF_PDSAUserAttributeTypeConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [PK_PDSAFilterStateId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateIsDefault]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserFilterState]'
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] DROP CONSTRAINT [DF_PDSAFilterStateConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [PK_PDSAUserRoleId]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [DF_PDSAUserRoleInsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [DF_PDSAUserRoleInsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [DF_PDSAUserRoleUpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [DF_PDSAUserRoleUpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUserRole]'
GO
ALTER TABLE [PDSA].[pdsaUserRole] DROP CONSTRAINT [DF_PDSAUserRoleConcurrencyValue]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [PK_pdsaUsersOldPassword]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [DF_pdsaUsersOldPassword_InsertName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [DF_pdsaUsersOldPassword_InsertDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [DF_pdsaUsersOldPassword_UpdateName]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [DF_pdsaUsersOldPassword_UpdateDate]
GO
PRINT N'Dropping constraints from [PDSA].[pdsaUsersOldPassword]'
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] DROP CONSTRAINT [DF_pdsaUsersOldPassword_ConcurrencyValue]
GO
PRINT N'Dropping index [IX_pdsaApplicationApplicationName] from [PDSA].[pdsaApplication]'
GO
DROP INDEX [IX_pdsaApplicationApplicationName] ON [PDSA].[pdsaApplication]
GO
PRINT N'Dropping index [CI_pdsaResourceNameResourceLanguage] from [PDSA].[pdsaResource]'
GO
DROP INDEX [CI_pdsaResourceNameResourceLanguage] ON [PDSA].[pdsaResource]
GO
PRINT N'Dropping index [CI_pdsaRoleEntity] from [PDSA].[pdsaRoleEntity]'
GO
DROP INDEX [CI_pdsaRoleEntity] ON [PDSA].[pdsaRoleEntity]
GO
PRINT N'Dropping index [IX_pdsaUserEmailAddress] from [PDSA].[pdsaUser]'
GO
DROP INDEX [IX_pdsaUserEmailAddress] ON [PDSA].[pdsaUser]
GO
PRINT N'Dropping index [UI_pdsaUserLoginNameEmailAddress] from [PDSA].[pdsaUser]'
GO
DROP INDEX [UI_pdsaUserLoginNameEmailAddress] ON [PDSA].[pdsaUser]
GO
PRINT N'Dropping index [IX_pdsaUserLoginName] from [PDSA].[pdsaUser]'
GO
DROP INDEX [IX_pdsaUserLoginName] ON [PDSA].[pdsaUser]
GO
PRINT N'Dropping index [CI_pdsaApplicationSetting] from [PDSA].[pdsaApplicationSetting]'
GO
DROP INDEX [CI_pdsaApplicationSetting] ON [PDSA].[pdsaApplicationSetting]
GO
PRINT N'Dropping index [CI_pdsaEntity] from [PDSA].[pdsaEntity]'
GO
DROP INDEX [CI_pdsaEntity] ON [PDSA].[pdsaEntity]
GO
PRINT N'Dropping index [CI_pdsaPermission] from [PDSA].[pdsaPermission]'
GO
DROP INDEX [CI_pdsaPermission] ON [PDSA].[pdsaPermission]
GO
PRINT N'Dropping index [CI_pdsaPermissionCategory] from [PDSA].[pdsaPermissionCategory]'
GO
DROP INDEX [CI_pdsaPermissionCategory] ON [PDSA].[pdsaPermissionCategory]
GO
PRINT N'Dropping index [CI_pdsaReferenceTable] from [PDSA].[pdsaReferenceTable]'
GO
DROP INDEX [CI_pdsaReferenceTable] ON [PDSA].[pdsaReferenceTable]
GO
PRINT N'Dropping index [CI_pdsaRole] from [PDSA].[pdsaRole]'
GO
DROP INDEX [CI_pdsaRole] ON [PDSA].[pdsaRole]
GO
PRINT N'Dropping index [CI_pdsaRolePermission_RoleIdPermissionId] from [PDSA].[pdsaRolePermission]'
GO
DROP INDEX [CI_pdsaRolePermission_RoleIdPermissionId] ON [PDSA].[pdsaRolePermission]
GO
PRINT N'Dropping index [CI_pdsaSecurityControl] from [PDSA].[pdsaSecurityControl]'
GO
DROP INDEX [CI_pdsaSecurityControl] ON [PDSA].[pdsaSecurityControl]
GO
PRINT N'Dropping index [CI_pdsaSerializedObject] from [PDSA].[pdsaSerializedObject]'
GO
DROP INDEX [CI_pdsaSerializedObject] ON [PDSA].[pdsaSerializedObject]
GO
PRINT N'Dropping index [CI_pdsaTableId] from [PDSA].[pdsaTableId]'
GO
DROP INDEX [CI_pdsaTableId] ON [PDSA].[pdsaTableId]
GO
PRINT N'Dropping index [CI_pdsaUserApplicationEntity] from [PDSA].[pdsaUserApplicationEntity]'
GO
DROP INDEX [CI_pdsaUserApplicationEntity] ON [PDSA].[pdsaUserApplicationEntity]
GO
PRINT N'Dropping index [CI_pdsaUserAttribute] from [PDSA].[pdsaUserAttribute]'
GO
DROP INDEX [CI_pdsaUserAttribute] ON [PDSA].[pdsaUserAttribute]
GO
PRINT N'Dropping index [CI_pdsaUserAttributeType] from [PDSA].[pdsaUserAttributeType]'
GO
DROP INDEX [CI_pdsaUserAttributeType] ON [PDSA].[pdsaUserAttributeType]
GO
PRINT N'Dropping index [CI_pdsaUserRole] from [PDSA].[pdsaUserRole]'
GO
DROP INDEX [CI_pdsaUserRole] ON [PDSA].[pdsaUserRole]
GO
PRINT N'Unbinding types from columns'
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaMenuItem] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaMenuItem] ALTER COLUMN [UpdateName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttribute] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaRolePermission] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRolePermission] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRoleEntity] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaPermission] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaPermission] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserApplicationEntity] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaApplication] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaApplication] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserRole] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserRole] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [LoginName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaLanguage] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaLanguage] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaTableId] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaTableId] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaSerializedObject] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] ALTER COLUMN [InsertName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] ALTER COLUMN [UpdateName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] ALTER COLUMN [PrimaryKeyColumnName] nvarchar (64) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [ForeignKeyColumnName] nvarchar (64) NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [ForeignKeyValueColumnName] nvarchar (64) NULL
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] ALTER COLUMN [TableName] nvarchar (128) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [SchemaName] nvarchar (128) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [TableName] nvarchar (128) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [TablePKColumn] nvarchar (128) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [DisplayNameColumn] nvarchar (128) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [ResourceKeyColumn] nvarchar (128) NULL
GO
ALTER TABLE [PDSA].[pdsaTableId] ALTER COLUMN [TableName] nvarchar (128) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaReferenceTable] ALTER COLUMN [IsActive] bit NULL
GO
ALTER TABLE [PDSA].[pdsaMenuItem] ALTER COLUMN [IsActive] bit NOT NULL
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] ALTER COLUMN [IsActive] bit NOT NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [IsDefault] bit NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [IsActive] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] ALTER COLUMN [IsDefault] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [IsActive] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [IsForeignKey] bit NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [IsSystemCategory] bit NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [IsEntityCategory] bit NULL
GO
ALTER TABLE [PDSA].[pdsaPermission] ALTER COLUMN [IsActive] bit NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [IsActive] bit NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [IsTemplateRole] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [IsLockedOut] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [IsActive] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [ResetPasswordFlag] bit NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [ImportedFlag] bit NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [ResourceGroupName] nvarchar (100) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResourceGroup] ALTER COLUMN [ObjectNameDefault] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaApplicationSetting] ALTER COLUMN [SettingDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [EntityDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [PermissionCategoryDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaPermission] ALTER COLUMN [PermissionDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [RoleDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaApplication] ALTER COLUMN [ApplicationDescription] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaLanguage] ALTER COLUMN [Location] nvarchar (100) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [ObjectName] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaResourceResourceGroup] ALTER COLUMN [ObjectName] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaEntity] ALTER COLUMN [EntityName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [DisplayName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [KeyName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaPermissionCategory] ALTER COLUMN [PermissionCategoryName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaPermission] ALTER COLUMN [PermissionName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaRole] ALTER COLUMN [RoleName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaApplication] ALTER COLUMN [ApplicationName] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaLanguage] ALTER COLUMN [Name] nvarchar (50) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [ApplicationName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [EntityName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [UserName] nvarchar (50) NULL
GO
ALTER TABLE [PDSA].[pdsaUserFilterState] ALTER COLUMN [FormName] nvarchar (100) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaSecurityControl] ALTER COLUMN [FormName] nvarchar (100) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUserAttributeType] ALTER COLUMN [ForeignKeySQLCommand] nvarchar (2000) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [LogInfo] nvarchar (4000) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [SystemInfo] nvarchar (4000) NULL
GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [ExtraInfo] nvarchar (4000) NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [UserLanguage] nvarchar (8) NOT NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [UserPassword] nvarchar (1024) NULL
GO
ALTER TABLE [PDSA].[pdsaUsersOldPassword] ALTER COLUMN [Password] nvarchar (1024) NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [EmailAddress] nvarchar (254) NULL
GO
ALTER TABLE [PDSA].[pdsaUser] ALTER COLUMN [EmailAddress2] nvarchar (254) NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [ResourceName] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [ResourceClassName] nvarchar (100) NULL
GO
ALTER TABLE [PDSA].[pdsaResource] ALTER COLUMN [ResourceText] nvarchar (1200) NOT NULL
GO
PRINT N'Dropping [PDSA].[pdsaForm_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaForm_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaFormControl_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaFormControl_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUser_FindRolesInUsers]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_FindRolesInUsers]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_Update]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Find]
GO
PRINT N'Dropping [PDSA].[pdsaUsersOldPassword_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaUsersOldPassword_Find]
GO
PRINT N'Dropping [PDSA].[pdsaRole_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_Create]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_Create]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_SelectMenuAll]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_SelectMenuAll]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_FindByRoles]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_FindByRoles]
GO
PRINT N'Dropping [PDSA].[pdsaUser_ValidateByEmailPassword]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_ValidateByEmailPassword]
GO
PRINT N'Dropping [PDSA].[pdsaUser_ValidateByLoginPassword]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_ValidateByLoginPassword]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableValue_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTableValue_Get]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableValue_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTableValue_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableValue_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTableValue_Update]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Create]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_Find]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Get]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Find]
GO
PRINT N'Dropping [PDSA].[pdsaResource_GetResource]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_GetResource]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_FindPermissionForSecurityControl]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_FindPermissionForSecurityControl]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Find]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_GetMaxIdFromTable]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_GetMaxIdFromTable]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Search]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Search]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Search3]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Search3]
GO
PRINT N'Dropping [PDSA].[pdsaResource_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaResource_SelectListBox]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_SelectListBox]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Update]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Get]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_PermissionId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_PermissionId]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Create]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Create]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_DeleteAll]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_DeleteAll]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_FindPermissionsAssignedToUser]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_FindPermissionsAssignedToUser]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Get]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Update]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Select]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Select]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Validate]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Validate]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Create]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Update]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Update]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_PermissionCategoryId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_PermissionCategoryId]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_PermissionCategoryIdInApplication]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_PermissionCategoryIdInApplication]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserByEMail]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserByEMail]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_RoleEntity]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_RoleEntity]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserByLoginName]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserByLoginName]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserExistsInApplication]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserExistsInApplication]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserExistsInAppEntityByEMail]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserExistsInAppEntityByEMail]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_Update]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserExistsInAppEntityByLoginName]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserExistsInAppEntityByLoginName]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_Create]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_Get]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_FindAssignedUsers]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_FindAssignedUsers]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaRole_FindUsersInRole]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_FindUsersInRole]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_Update]
GO
PRINT N'Dropping [PDSA].[pdsaRole_GetUsersInRole]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_GetUsersInRole]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUser_ChangePassword]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_ChangePassword]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUsersOldPassword_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaUsersOldPassword_Create]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_Get]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUser_AddToEntity]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_AddToEntity]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUser_AddToRole]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_AddToRole]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Find]
GO
PRINT N'Dropping [PDSA].[pdsaUser_FindByApplication]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_FindByApplication]
GO
PRINT N'Dropping [PDSA].[pdsaUser_FindByEmailAddressLoginId]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_FindByEmailAddressLoginId]
GO
PRINT N'Dropping [PDSA].[pdsaUser_ExistsInUserRole]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_ExistsInUserRole]
GO
PRINT N'Dropping [PDSA].[pdsaUser_FindByLoginId]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_FindByLoginId]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Display]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Display]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Get]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_FindByAction]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_FindByAction]
GO
PRINT N'Dropping [PDSA].[pdsaUser_GetByEmailAddressLoginId]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_GetByEmailAddressLoginId]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Get]
GO
PRINT N'Dropping [PDSA].[pdsaUser_GetUserApplicationEntityId]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_GetUserApplicationEntityId]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Import]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Import]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Lock]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Lock]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_FindAssignedRoles]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_FindAssignedRoles]
GO
PRINT N'Dropping [PDSA].[pdsaUser_MakeActive]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_MakeActive]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_Get]
GO
PRINT N'Dropping [PDSA].[pdsaUser_MakeInactive]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_MakeInactive]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_RemoveFromRole]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_RemoveFromRole]
GO
PRINT N'Dropping [PDSA].[pdsaUser_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUser_SelectAllUsingFilter]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_SelectAllUsingFilter]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Unlock]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Unlock]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUser_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_Update]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Get]
GO
PRINT N'Dropping [PDSA].[pdsaLog_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_Create]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaLog_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_Validate]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_Validate]
GO
PRINT N'Dropping [PDSA].[pdsaLog_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_Find]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Find]
GO
PRINT N'Dropping [PDSA].[pdsaLog_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_Get]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Get]
GO
PRINT N'Dropping [PDSA].[pdsaLog_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Validate]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Validate]
GO
PRINT N'Dropping [PDSA].[pdsaLog_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaUserApplicationEntity_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaUserApplicationEntity_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaUserApplicationEntity_Get]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaUserApplicationEntity_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaRole_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_Find]
GO
PRINT N'Dropping [PDSA].[pdsaRole_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_Find]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_Get]
GO
PRINT N'Dropping [PDSA].[pdsaRole_FindAssignedEntities]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_FindAssignedEntities]
GO
PRINT N'Dropping [PDSA].[pdsaRole_FindAssignedPermissions]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_FindAssignedPermissions]
GO
PRINT N'Dropping [PDSA].[pdsa_UserFilterStateDelete]'
GO
DROP PROCEDURE [PDSA].[pdsa_UserFilterStateDelete]
GO
PRINT N'Dropping [PDSA].[pdsaRole_FindAssignedUsers]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_FindAssignedUsers]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_Create]
GO
PRINT N'Dropping [PDSA].[pdsaRole_FindRolesAssignedToUser]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_FindRolesAssignedToUser]
GO
PRINT N'Dropping [PDSA].[pdsaRole_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_Get]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaRole_GetPermissionsInRole]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_GetPermissionsInRole]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableValue_SelectList]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTableValue_SelectList]
GO
PRINT N'Dropping [PDSA].[pdsaRole_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_GetByUser]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_GetByUser]
GO
PRINT N'Dropping [PDSA].[pdsaRole_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_Update]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_Get]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_Update]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_Create]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_RemoveUser]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_RemoveUser]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_Update]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Get]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_GetAllForeignKeyList]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_GetAllForeignKeyList]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_GetForeignKeyList]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_GetForeignKeyList]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_Find]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Update]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_Get]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_Insert]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_Update]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Update]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_Get]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_MenuItemIdInApplication]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_MenuItemIdInApplication]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_PermissionIdInApplication]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_PermissionIdInApplication]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUser_FindAssignedRoles]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_FindAssignedRoles]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Update]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserAppEntity]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserAppEntity]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Create]
GO
PRINT N'Dropping [PDSA].[pdsaUser_RemoveFromEntity]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_RemoveFromEntity]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaUser_RemoveFromRole]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_RemoveFromRole]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_Update]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaResource_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_Get]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_GetByApplicationName]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_GetByApplicationName]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_GetDefaultEntityId]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_GetDefaultEntityId]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_RoleIdApplicationId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_RoleIdApplicationId]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_Create]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_Find]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_Get]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_SelectAllByApplicationId]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_SelectAllByApplicationId]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Find]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_Update]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_Find]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Create]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Create]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Delete]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserIsSystemAdmin]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserIsSystemAdmin]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Get]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_GetByAssignedUserId]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_GetByAssignedUserId]
GO
PRINT N'Dropping [PDSA].[pdsaRoleToUser]'
GO
DROP VIEW [PDSA].[pdsaRoleToUser]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_RemoveFromRole]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_RemoveFromRole]
GO
PRINT N'Dropping [PDSA].[pdsaResource_UpdateResourceText]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_UpdateResourceText]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaUsersOldPassword_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaUsersOldPassword_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_SelectAllByApplicationId]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_SelectAllByApplicationId]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_UserId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_UserId]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Update]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_Get]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_Validate]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_Validate]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaResource_GetCreateResource]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_GetCreateResource]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_Get]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_Get]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_Get]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_ApplicationId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_ApplicationId]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_ExistsInApplication]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_ExistsInApplication]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_Insert]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_Insert]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_EntityId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_EntityId]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_RoleId]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_RoleId]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_SelectAll]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_SelectAll]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_SelectMenu]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_SelectMenu]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_Update]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_Update]
GO
PRINT N'Dropping [PDSA].[pdsa_LU_ErrorMessage]'
GO
DROP PROCEDURE [PDSA].[pdsa_LU_ErrorMessage]
GO
PRINT N'Dropping [PDSA].[udf_pdsaGetResourceLanguage]'
GO
DROP FUNCTION [PDSA].[udf_pdsaGetResourceLanguage]
GO
PRINT N'Dropping [PDSA].[udf_pdsaGetResourceText]'
GO
DROP FUNCTION [PDSA].[udf_pdsaGetResourceText]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableSample]'
GO
DROP TABLE [PDSA].[pdsaReferenceTableSample]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaSerializedObject_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTableValue_Delete]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTableValue_Delete]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroupType_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_FullDelete]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_FullDelete]
GO
PRINT N'Dropping [PDSA].[pdsaResource_PopulateForAllActiveLanguages]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_PopulateForAllActiveLanguages]
GO
PRINT N'Dropping [PDSA].[pdsa_UserGetUserApplicationEntityInfo]'
GO
DROP VIEW [PDSA].[pdsa_UserGetUserApplicationEntityInfo]
GO
PRINT N'Dropping [PDSA].[pdsa_UserGetUsersNotInApplications]'
GO
DROP VIEW [PDSA].[pdsa_UserGetUsersNotInApplications]
GO
PRINT N'Dropping [PDSA].[pdsaSerializedObject]'
GO
DROP TABLE [PDSA].[pdsaSerializedObject]
GO
PRINT N'Dropping [PDSA].[pdsaApplication_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaApplication_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUserApplicationEntity_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaResource_PopulateForAllTables]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_PopulateForAllTables]
GO
PRINT N'Dropping [PDSA].[pdsaRole_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaRole_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaPermission_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaPermission_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaPermissionCategory_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaPermissionCategory]'
GO
DROP TABLE [PDSA].[pdsaPermissionCategory]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaSecurityControl_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaSecurityControl]'
GO
DROP TABLE [PDSA].[pdsaSecurityControl]
GO
PRINT N'Dropping [PDSA].[pdsaResource_PopulateForATable]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_PopulateForATable]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_Activate]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_Activate]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaLanguage_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaRoleEntity_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaResource_PopulateForATableColumn]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_PopulateForATableColumn]
GO
PRINT N'Dropping [PDSA].[pdsaResource_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaResource_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaLog_SelectType]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_SelectType]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaRolePermission_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaRolePermission]'
GO
DROP TABLE [PDSA].[pdsaRolePermission]
GO
PRINT N'Dropping [PDSA].[pdsa_GetAuditTrackingRecords]'
GO
DROP VIEW [PDSA].[pdsa_GetAuditTrackingRecords]
GO
PRINT N'Dropping [PDSA].[pdsaUser_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_Reload]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_Reload]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType]'
GO
DROP TABLE [PDSA].[pdsaUserAttributeType]
GO
PRINT N'Dropping [PDSA].[pdsaTableId_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaTableId_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUser_SetInactive]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_SetInactive]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Validate]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Validate]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttributeType_Find]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttributeType_Find]
GO
PRINT N'Dropping [PDSA].[pdsaTableId]'
GO
DROP TABLE [PDSA].[pdsaTableId]
GO
PRINT N'Dropping [PDSA].[pdsaLanguage]'
GO
DROP TABLE [PDSA].[pdsaLanguage]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUserFilterState_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUserFilterState]'
GO
DROP TABLE [PDSA].[pdsaUserFilterState]
GO
PRINT N'Dropping [PDSA].[udf_pdsaFindResourceText]'
GO
DROP FUNCTION [PDSA].[udf_pdsaFindResourceText]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceResourceGroup_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaLog_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaLog_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaLog]'
GO
DROP TABLE [PDSA].[pdsaLog]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUserAttribute_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUserAttribute]'
GO
DROP TABLE [PDSA].[pdsaUserAttribute]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_PopulateForSQLObjects]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_PopulateForSQLObjects]
GO
PRINT N'Dropping [PDSA].[pdsaApplication]'
GO
DROP TABLE [PDSA].[pdsaApplication]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaResourceGroup_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUserApplicationEntity]'
GO
DROP TABLE [PDSA].[pdsaUserApplicationEntity]
GO
PRINT N'Dropping [PDSA].[pdsaUserRole]'
GO
DROP TABLE [PDSA].[pdsaUserRole]
GO
PRINT N'Dropping [PDSA].[pdsaUser_EmailRowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaUser_EmailRowCount]
GO
PRINT N'Dropping [PDSA].[pdsaUser]'
GO
DROP TABLE [PDSA].[pdsaUser]
GO
PRINT N'Dropping [PDSA].[pdsaEntity_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaEntity_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaResource]'
GO
DROP TABLE [PDSA].[pdsaResource]
GO
PRINT N'Dropping [PDSA].[pdsaUsersOldPassword]'
GO
DROP TABLE [PDSA].[pdsaUsersOldPassword]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaApplicationSetting_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaApplicationSetting]'
GO
DROP TABLE [PDSA].[pdsaApplicationSetting]
GO
PRINT N'Dropping [PDSA].[pdsaEntity]'
GO
DROP TABLE [PDSA].[pdsaEntity]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroup]'
GO
DROP TABLE [PDSA].[pdsaResourceGroup]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaMenuItem_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaResourceGroupType]'
GO
DROP TABLE [PDSA].[pdsaResourceGroupType]
GO
PRINT N'Dropping [PDSA].[pdsaRole]'
GO
DROP TABLE [PDSA].[pdsaRole]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable_RowCount]'
GO
DROP PROCEDURE [PDSA].[pdsaReferenceTable_RowCount]
GO
PRINT N'Dropping [PDSA].[pdsaReferenceTable]'
GO
DROP TABLE [PDSA].[pdsaReferenceTable]
GO
PRINT N'Dropping [PDSA].[pdsaRoleEntity]'
GO
DROP TABLE [PDSA].[pdsaRoleEntity]
GO
PRINT N'Dropping [PDSA].[pdsaResourceResourceGroup]'
GO
DROP TABLE [PDSA].[pdsaResourceResourceGroup]
GO
PRINT N'Dropping [PDSA].[pdsaMenuItem]'
GO
DROP TABLE [PDSA].[pdsaMenuItem]
GO
PRINT N'Dropping [PDSA].[pdsaPermission]'
GO
DROP TABLE [PDSA].[pdsaPermission]
GO
PRINT N'Dropping [PDSA].[udf_pdsaParseNumericList]'
GO
DROP FUNCTION [PDSA].[udf_pdsaParseNumericList]
GO
PRINT N'Dropping types'
GO
DROP TYPE [PDSA].[udt_pdsaLoginName]
GO
DROP TYPE [PDSA].[udt_pdsaColumnName]
GO
DROP TYPE [PDSA].[udt_pdsaTableName]
GO
DROP TYPE [PDSA].[udt_pdsaFlag]
GO
DROP TYPE [PDSA].[udt_pdsaDescription]
GO
DROP TYPE [PDSA].[udt_pdsaName]
GO
DROP TYPE [PDSA].[udt_pdsaClassName (nvarchar(100), null)]
GO
DROP TYPE [PDSA].[udt_pdsaExtraInfo]
GO
DROP TYPE [PDSA].[udt_pdsaLongText]
GO
DROP TYPE [PDSA].[udt_pdsaLanguage]
GO
DROP TYPE [PDSA].[udt_pdsaPassword]
GO
DROP TYPE [PDSA].[udt_pdsaEmail]
GO
DROP TYPE [PDSA].[udt_pdsaErrorName]
GO
DROP TYPE [PDSA].[udt_pdsaErrorMessage]
GO
PRINT N'Dropping schemata'
GO
DROP SCHEMA [PDSA]
GO
