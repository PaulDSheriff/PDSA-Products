-- Use this SQL to generate a sp_recompile for all stored procedures in your database
-- *** IMPORTANT ***
-- In Query Analyzer go to Query | Results in Text (Ctrl-T)
-- also be sure to go to Options | Results and set the maximum column length to 2048
SELECT 'print ''' + rtrim(ROUTINE_SCHEMA) + '.' + rtrim(ROUTINE_NAME) + ''' 
EXEC sp_recompile ''' + rtrim(ROUTINE_SCHEMA) + '.' + rtrim(ROUTINE_NAME) + '''
Go'
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_TYPE = 'PROCEDURE'
