
/****** Object:  StoredProcedure [PDSA].[pdsaUser_FindAssignedRoles]    Script Date: 05/20/2013 08:51:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [PDSA].[pdsaUser_FindAssignedRoles]
	 @UserId int
	,@ApplicationId int = NULL
	,@EntityId int = NULL
	,@DisplaySARole bit = 0
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
DECLARE @SystemRoleId int;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

SELECT @ret = 0;
SET @SystemRoleId = 0;

IF @DisplaySARole = 0
  SELECT @SystemRoleId = SystemRoleId 
    FROM PDSA.pdsaApplication
		WHERE ApplicationId = @ApplicationId
-- Get the Roles for the Applications and Entities passed.  If Application is not null, get only the
-- Entities that are part of the Application.  If Entities are passes, get only that entity.  
-- Indicate whether the User passed is in the Role (1-Yes, 0-No)

SELECT N'Entity' as RoleType,
	 r.RoleId
	,r.ApplicationId
	,RoleName
	,RoleDescription
	,e.EntityId
	,EntityDescription
	,CASE WHEN ur.UserId IS NULL THEN N'false' ELSE N'true' END AS Assigned
	,ur.UserApplicationEntityId
	,ur.UserRoleId
	,ur.UserId
FROM PDSA.pdsaRole r
  INNER JOIN PDSA.pdsaRoleEntity re ON r.RoleId = re.RoleId
  INNER JOIN PDSA.pdsaEntity e ON e.EntityId = re.EntityId
  LEFT JOIN (SELECT RoleId,UserRoleId, UserId, ApplicationId, EntityId, ur1.UserApplicationEntityId FROM PDSA.pdsaUserRole ur1 
			  INNER JOIN PDSA.pdsaUserApplicationEntity uae ON uae.UserApplicationEntityId = ur1.UserApplicationEntityId
			    AND uae.UserId = @UserId AND uae.Entityid = @EntityId) ur ON ur.RoleId = r.RoleId AND @UserId = ur.UserId
WHERE (@ApplicationID IS NOT NULL AND r.ApplicationId = @ApplicationId) AND
	  (@ApplicationID IS NULL OR (e.EntityId IN (	SELECT EntityId 
													FROM PDSA.pdsaEntity 
													WHERE ApplicationId = @ApplicationId))) AND
		(@EntityId IS NULL OR @EntityId = e.EntityId) AND
		(r.RoleId <> @SystemRoleId)
ORDER BY RoleName

IF @@ROWCOUNT = 0
BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsReturned', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO
/****** Object:  StoredProcedure [PDSA].[pdsaReferenceTableValue_Insert]    Script Date: 05/20/2013 08:51:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER  PROCEDURE [PDSA].[pdsaReferenceTableValue_Insert]
	   @ReferenceTableId int,
       @PrimaryKeyValue int ,
       @Display nvarchar(50) ,
       @Description nvarchar(100) ,
       @Code nvarchar(50) ,
       @DisplayOrder int ,
       @IsDefault bit ,
       @IsActive bit ,
       @IsComplete bit ,
       @SystemKey nvarchar(50) ,
       @InsertName nvarchar(50) ,
       @InsertDate datetime ,
       @MessageLanguage PDSA.udt_pdsaLanguage = NULL,
       @ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT --add BT819544
AS 
DECLARE @sql nvarchar(4000),
		@IsIdentity bit,
		@update nvarchar(4000),
		@SchemaName PDSA.udt_pdsaTableName ,
		@TableNameShort PDSA.udt_pdsaTableName, 
		@TableName PDSA.udt_pdsaTableName ,
        @TableDisplayName nvarchar(50) ,
        @PrimaryKeyColumnName PDSA.udt_pdsaColumnName
       

Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, DEFAULT, DEFAULT)
   declare @ret int
	SELECT @ret = 0
SELECT @IsIdentity = 0
		
-- Get the table name and primary key names of the requested reference table
SELECT  @TableName = TableName,
        @TableDisplayName = TableDisplayName,
        @PrimaryKeyColumnName = PrimaryKeyColumnName
FROM    PDSA.pdsaReferenceTable
WHERE   ReferenceTableId = @ReferenceTableId

set @SchemaName = PARSENAME(@TableName,2)
set @TableNameShort = PARSENAME(@TableName,1)


    --see if table exists BT819544
     declare @rows as int = 0 
     select @rows = COUNT(*)  from sys.tables where name =  @TableName 
     
   

if @rows = 0 BEGIN --add BT819544
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
	@MessageName=N'ReferenceTableDoesNotExist', 
	@MessageLanguage=@MessageLanguage,
	@ErrorMessage=@ErrorMessage OUT;
   return -1
END --add BT819544
 
		


SELECT  @IsIdentity = sys.columns.is_identity
FROM    sys.columns
JOIN    sys.objects
        ON sys.columns.object_id = sys.objects.object_id
WHERE   sys.objects.type IN ( N'U' ) 
        AND sys.objects.name = PARSENAME(@TableName,1)
        AND SCHEMA_NAME(schema_id) = CASE WHEN PARSENAME(@TableName,2) IS NULL THEN N'dbo' else PARSENAME(@TableName,2) END
        AND sys.columns.name = @PrimaryKeyColumnName

IF @IsDefault = 1 
   BEGIN
         SET @update = N'UPDATE ' + @TableName + N' SET IsDefault = 0'
         EXEC (@update)
   END
   
SET @sql = N'INSERT INTO  ' + @TableName 
SET @sql = @sql + N' (' 

--IF (@IsIdentity = 1)
--	SET @sql = @sql + @PrimaryKeyColumnName + ', '
	
SET @sql = @sql + N'Display, ' 
SET @sql = @sql + N'Description, '
SET @sql = @sql + N'Code, '
SET @sql = @sql + N'DisplayOrder, '
SET @sql = @sql + N'IsDefault, '
SET @sql = @sql + N'IsActive, '
SET @sql = @sql + N'IsComplete, '
SET @sql = @sql + N'SystemKey, '
SET @sql = @sql + N'InsertName, '
SET @sql = @sql + N'InsertDate, '
SET @sql = @sql + N'UpdateName, '
SET @sql = @sql + N'UpdateDate, '
SET @sql = @sql + N'ConcurrencyValue) '
SET @sql = @sql + N'VALUES ('

--IF (@IsIdentity = 1)
--	SET @sql = @sql + ' ''' + CAST(@PrimaryKeyValue AS nvarchar(10)) + ''', '
	
SET @sql = @sql + N' ''' + @Display + ''','
SET @sql = @sql + N' ''' + @Description + ''','
SET @sql = @sql + N' ''' + @Code + ''','
SET @sql = @sql + N' ' + CAST(@DisplayOrder AS nvarchar(10)) + ', '
SET @sql = @sql + N' ' + CAST(@IsDefault AS nvarchar(3)) + ', '
SET @sql = @sql + N' ' + CAST(@IsActive AS nvarchar(3)) + ', '
SET @sql = @sql + N' ' + CAST(@IsComplete AS nvarchar(3)) + ', '
SET @sql = @sql + N' ''' + @SystemKey + ''','
SET @sql = @sql + N' ''' + @InsertName + ''','
SET @sql = @sql + N' ''' + CAST(@InsertDate AS nvarchar(22)) + ''','
SET @sql = @sql + N' ''' + @InsertName + ''','
SET @sql = @sql + N' ''' + CAST(@InsertDate AS nvarchar(22)) + ''','
SET @sql = @sql + N' 1 ) '
 
		BEGIN TRAN
			EXEC (@sql)
			SET @sql = N'EXEC pdsa.pdsaResource_PopulateForATable ''' + @SchemaName + ''', ''' + @TableNameShort + ''''
			EXEC (@sql)
		COMMIT TRAN
GO
/****** Object:  StoredProcedure [PDSA].[pdsaUser_GetByEmailAddressLoginId]    Script Date: 05/20/2013 08:51:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [PDSA].[pdsaUser_GetByEmailAddressLoginId]
@EmailAddress PDSA.udt_pdsaEmail = null,
@LoginName udt_pdsaLoginName = null,
@MessageLanguage PDSA.udt_pdsaLanguage = null,
@ErrorMessage PDSA.udt_pdsaErrorMessage OUT
AS

DECLARE @ret int = 0;
SET @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, DEFAULT, DEFAULT)

SELECT 
  UserId
	,FirstName
	,LastName
	,UserInitials
	,EmailAddress
	,EmailAddress2
	,LoginName
	,DisplayName
	,UserPassword
	,LastLoginDate
	,SecurityQuestion
	,SecurityAnswer
	,UserTheme
	,UserLanguage
	,IsLockedOut
	,IsActive
	,ResetPasswordFlag
	,InsertName
	,InsertDate
	,UpdateName
	,UpdateDate
FROM PDSA.pdsaUser
WHERE (@EmailAddress IS NULL OR EmailAddress = @EmailAddress) AND
	  (@LoginName IS NULL OR LoginName = @LoginName) 

IF @@ROWCOUNT = 0
BEGIN
  SELECT @ret = -1
  /* Get the Error Message */
  exec PDSA.pdsa_LU_ErrorMessage 
  @MessageName=N'ZeroRecordsReturned', 
  @MessageLanguage=@MessageLanguage,
  @ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO
/****** Object:  UserDefinedFunction [PDSA].[udf_pdsaGetResourceText]    Script Date: 05/20/2013 08:51:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [PDSA].[udf_pdsaGetResourceText]
(
	@ResourceLanguageKey	uniqueidentifier,
	@ResourceLanguage		PDSA.udt_pdsaLanguage,	
	@ApplicationId			int
)
RETURNS nvarchar(2000)
AS
BEGIN

	DECLARE @ResourceText nvarchar(2000)
	if @ResourceLanguage is null
		SELECT @ResourceLanguage = DefaultResourceLanguage 
					FROM PDSA.pdsaApplication 
					WHERE ApplicationId = @ApplicationId
					
	-- Test to see if the GUID is populated
	IF @ResourceLanguageKey is not null
	Begin
		-- Select the text from the message table using the GUID and used's language 
		SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
						WHERE  ResourceLanguage = @ResourceLanguage
							AND ResourceLanguageKey = @ResourceLanguageKey

		-- Make sure the text is populated
		IF @ResourceText IS NULL 
		BEGIN
				DECLARE @ResourceLanguageDefault PDSA.udt_pdsaLanguage
				
				-- Get the default Default Language
				SELECT @ResourceLanguageDefault = DefaultResourceLanguage 
					FROM PDSA.pdsaApplication 
					WHERE ApplicationId = @ApplicationId
			
				-- Get the text for the default language
				IF @ResourceLanguageDefault IS NOT NULL AND @ResourceLanguageDefault <> @ResourceLanguage
				BEGIN
						SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
							WHERE  ResourceLanguage = @ResourceLanguageDefault
								AND ResourceLanguageKey = @ResourceLanguageKey
				END

				-- if the text is still not populated, get the 
				-- english version (If it has not already been tryed)
				IF @ResourceText is null and 
				   @ResourceLanguage <> 'en-us' and 
				   @ResourceLanguageDefault <> 'en-us'
						SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
								WHERE  ResourceLanguage = @ResourceLanguage
								AND ResourceLanguageKey = 'en-us'

				-- No text on the table, put a missing text message
				IF @ResourceText is null
					SET @ResourceText = N'Missing Language text'
				
		END
	END
	ELSE
	BEGIN
		-- no GUID, put a missing GUID message
		SET @ResourceText = N'Missing Language Key'
	END		
	
	RETURN @ResourceText

END
GO
