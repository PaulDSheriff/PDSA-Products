
PRINT N'Altering [PDSA].[pdsaUser_Create]'
GO
/****** Object:  StoredProcedure [PDSA].[pdsaUser_Create]    Script Date: 6/9/2014 3:00:11 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [PDSA].[pdsaUser_Create]
	@ApplicationId int 
	,@EntityId int 
	,@FirstName nvarchar(30) 
	,@LastName nvarchar(50) 
	,@UserInitials nchar(3)  = null
	,@EmailAddress nvarchar(254)  = null
	,@EmailAddress2 nvarchar(254)  = null
	,@LoginName nvarchar(50) 
	,@DisplayName nvarchar(100)  = null
	,@UserPassword nvarchar(1024)  = null
	,@LastLoginDate datetime  = null
	,@SecurityQuestion nvarchar(255)  = null
	,@SecurityAnswer nvarchar(255)  = null
	,@UserTheme nvarchar(50)  = null
	,@UserLanguage nvarchar(8)  = null
	,@IsLockedOut bit  = null
	,@IsActive bit  = null
	,@ResetPasswordFlag bit  = null
	,@InsertName nvarchar(50) 
	,@InsertDate datetime 
	,@UserId int OUTPUT
	,@UserApplicationEntityId int OUTPUT
	,@MessageLanguage PDSA.udt_pdsaLanguage = null
	,@ErrorMessage PDSA.udt_pdsaErrorMessage OUT
AS
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)
DECLARE @ret int;
SELECT @ret = 0;

/* First check for a unique LoginName within App/Entity */
exec @ret = PDSA.pdsaUser_Get 
  @ApplicationId=@ApplicationId, 
  @EntityId=@EntityId,
  @LoginName=@LoginName,
  @MessageLanguage=@MessageLanguage,
  @ErrorMessage=@ErrorMessage;
  
IF @ret = 0
BEGIN
  SELECT @ret = -1
  /* Get the Error Message */
  exec PDSA.pdsa_LU_ErrorMessage 
  @MessageName=N'UserAlreadyExistsInAppEntity', 
  @MessageLanguage=@MessageLanguage,
  @ErrorMessage=@ErrorMessage OUT;
END
ELSE
BEGIN
  /* This is OK. User Does Not Exist */
	SELECT @ret = 0
END
  
IF @ret = 0
BEGIN
	BEGIN TRANSACTION

	INSERT INTO PDSA.pdsaUser
	(
		FirstName
		,LastName
		,UserInitials
		,EmailAddress
		,EmailAddress2
		,LoginName
		,DisplayName
		,UserPassword
		,LastLoginDate
		,SecurityQuestion
		,SecurityAnswer
		,UserTheme
		,UserLanguage
		,IsLockedOut
		,IsActive
		,ResetPasswordFlag
		,InsertName
		,InsertDate
		,UpdateName
		,UpdateDate
	) 
	VALUES 
	(
		@FirstName
		,@LastName
		,@UserInitials
		,@EmailAddress
		,@EmailAddress2
		,@LoginName
		,@DisplayName
		,@UserPassword
		,@LastLoginDate
		,@SecurityQuestion
		,@SecurityAnswer
		,@UserTheme
		,@UserLanguage
		,@IsLockedOut
		,@IsActive
		,@ResetPasswordFlag
		,@InsertName
		,@InsertDate
		,@InsertName
		,@InsertDate
	)

	IF @@ROWCOUNT = 1 
	BEGIN
		/* Get User Id */
		SELECT @UserId = @@IDENTITY;
		
		IF @EntityId > 0 
 	  BEGIN
 	  /* Add to App/Entity Table */
		EXECUTE @ret = PDSA.pdsaUserApplicationEntity_Create
			@ApplicationId
			,@EntityId
			,@UserId
			,@InsertName
			,@InsertDate
			,@UserApplicationEntityId OUT
			,@MessageLanguage
			,@ErrorMessage OUT
		END
		
		IF @ret = 0 
		BEGIN
		  COMMIT TRANSACTION
		END
		ELSE
		BEGIN
			ROLLBACK TRANSACTION
			SET @UserId = NULL
		END
	END
	ELSE
	   BEGIN
		   ROLLBACK TRANSACTION
		   SET @ret = -1
	   END
END

IF @ret = -1 AND (@ErrorMessage IS NULL OR @ErrorMessage = N'')
BEGIN
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsCreated', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO
