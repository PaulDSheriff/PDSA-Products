
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Creating [PDSA].[pdsaUser_SetInactive]'
GO
CREATE PROCEDURE [PDSA].[pdsaUser_SetInactive]
      @UserId int 
      ,@UpdateName nvarchar(50)
      ,@UpdateDate datetime
      ,@ConcurrencyValue smallint
      ,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
      ,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, DEFAULT, DEFAULT)

UPDATE PDSA.pdsaUser
SET 
      IsActive = 0
      ,UpdateName = @UpdateName
      ,UpdateDate = @UpdateDate
      ,ConcurrencyValue = ConcurrencyValue + 1
WHERE
      UserId = @UserId
      And ConcurrencyValue = @ConcurrencyValue

IF @@ROWCOUNT = 0
BEGIN
      SELECT @ret = -1;
      /* Get the Error Message */
      exec PDSA.pdsa_LU_ErrorMessage 
            @MessageName=N'ZeroRecordsUpdated', 
            @MessageLanguage=@MessageLanguage,
            @ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO
PRINT N'Creating [PDSA].[pdsaUserAttributeType_Validate]'
GO
CREATE PROCEDURE [PDSA].[pdsaUserAttributeType_Validate]
	@UserAttributeTypeId int 
	,@ApplicationId int
	,@DisplayName nvarchar(50)
	,@KeyName nvarchar(50)
	,@DefaultValue nvarchar(1024)
	,@AttributeType nvarchar(128)
	,@IsActive bit
	,@IsForeignKey bit
	,@ForeignKeySQLCommand nvarchar(2000)
	,@ForeignKeyColumnName nvarchar(64)
	,@ForeignKeyValueColumnName nvarchar(64)
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
AS


DECLARE @ret INT
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL

SELECT @ret = 0
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

DECLARE @Results TABLE
		(PropertyName NVARCHAR(50),
		MessageText   NVARCHAR(250))

-- Duplucate Display Name within an application is not allowed		
IF (SELECT COUNT(*) FROM PDSA.pdsaUserAttributeType
			WHERE ApplicationId = @ApplicationId
			AND DisplayName = @DisplayName
			AND UserAttributeTypeId <> @UserAttributeTypeId) > 0
Begin
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'UserAttributeTypeDuplicateDisplayName', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
					
	INSERT INTO	@Results
		(PropertyName, MessageText)
	VALUES
		(N'DisplayName', @ErrorMessage)  
END

-- Duplucate Key Name within an application is not allowed		
IF (SELECT COUNT(*) FROM PDSA.pdsaUserAttributeType
			WHERE ApplicationId = @ApplicationId
			AND KeyName = @KeyName
			AND UserAttributeTypeId <> @UserAttributeTypeId) > 0
Begin
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'UserAttributeTypeDuplicateKeyName', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
					
	INSERT INTO	@Results
		(PropertyName, MessageText)
	VALUES
		(N'KeyName', @ErrorMessage)  
END
		
SELECT * FROM @Results

RETURN @ret
GO
PRINT N'Creating [PDSA].[pdsaUserAttributeType_Find]'
GO
CREATE PROCEDURE [PDSA].[pdsaUserAttributeType_Find]
@ApplicationId int,
@DisplayName nvarchar(50) = null,
@KeyName nvarchar(50) = null,
@MessageLanguage PDSA.udt_pdsaLanguage = NULL,
@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, DEFAULT, DEFAULT)

SELECT 
	UserAttributeTypeId
	,ApplicationId
	,PDSA.udf_pdsaGetResourceText(DisplayNameResourceKey, @MessageLanguage, ApplicationId) as DisplayName
	,DisplayNameResourceKey
	,KeyName
	,DefaultValue
	,AttributeType
	,IsActive
	,IsForeignKey
	,ForeignKeySQLCommand
	,ForeignKeyColumnName
	,ForeignKeyValueColumnName
	,DisplayOrder
	,InsertName
	,InsertDate
	,UpdateName
	,UpdateDate
	,ConcurrencyValue
FROM PDSA.pdsaUserAttributeType
WHERE (ApplicationId = @ApplicationId)
	AND (@DisplayName IS NULL OR (1 = PDSA.[udf_pdsaFindResourceText](DisplayNameResourceKey, @MessageLanguage, @DisplayName)))
	AND (@KeyName IS NULL OR KeyName like @KeyName + '%')
	Order by DisplayOrder
	
IF @@ROWCOUNT = 0
	BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsReturned', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO




GO
ALTER TABLE [PDSA].[pdsaLog] ALTER COLUMN [LogInfo] [nvarchar] (max) Null
GO

ALTER FUNCTION [PDSA].[udf_pdsaGetResourceText]
(
	@ResourceLanguageKey	uniqueidentifier,
	@ResourceLanguage		PDSA.udt_pdsaLanguage,	
	@ApplicationId			int
)
RETURNS nvarchar(2000)
AS
BEGIN

	DECLARE @ResourceText nvarchar(2000)
	if @ResourceLanguage is null
		SELECT @ResourceLanguage = DefaultResourceLanguage 
					FROM PDSA.pdsaApplication 
					WHERE ApplicationId = @ApplicationId
					
	-- Test to see if the GUID is populated
	IF @ResourceLanguageKey is not null
	Begin
		-- Select the text from the message table using the GUID and used's language 
		SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
						WHERE  ResourceLanguage = @ResourceLanguage
							AND ResourceLanguageKey = @ResourceLanguageKey

		-- Make sure the text is populated
		IF @ResourceText IS NULL 
		BEGIN
				DECLARE @ResourceLanguageDefault PDSA.udt_pdsaLanguage
				
				-- Get the default Default Language
				SELECT @ResourceLanguageDefault = DefaultResourceLanguage 
					FROM PDSA.pdsaApplication 
					WHERE ApplicationId = @ApplicationId
			
				-- Get the text for the default language
				IF @ResourceLanguageDefault IS NOT NULL AND @ResourceLanguageDefault <> @ResourceLanguage
				BEGIN
						SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
							WHERE  ResourceLanguage = @ResourceLanguageDefault
								AND ResourceLanguageKey = @ResourceLanguageKey
				END

				-- if the text is still not populated, get the 
				-- english version (If it has not already been tryed)
				IF @ResourceText is null and 
				   @ResourceLanguage <> 'en-us' and 
				   @ResourceLanguageDefault <> 'en-us'
						SELECT @ResourceText = ResourceText FROM pdsa.pdsaResource
								WHERE  ResourceLanguageKey  = @ResourceLanguageKey 
								AND ResourceLanguage = 'en-us'

				-- No text on the table, put a missing text message
				IF @ResourceText is null
					SET @ResourceText = N'Missing Language text'
				
		END
	END
	ELSE
	BEGIN
		-- no GUID, put a missing GUID message
		SET @ResourceText = N'Missing Language Key'
	END		
	
	RETURN @ResourceText

END
GO
PRINT N'Altering [PDSA].[pdsaUserAttributeType_Update]'
GO
ALTER PROCEDURE [PDSA].[pdsaUserAttributeType_Update]
	@UserAttributeTypeId int 
	,@ApplicationId int
	,@DisplayName nvarchar(50)
	,@KeyName nvarchar(50)
	,@DefaultValue nvarchar(1024)
	,@AttributeType nvarchar(128)
	,@IsActive bit
	,@IsForeignKey bit
	,@ForeignKeySQLCommand nvarchar(2000)
	,@ForeignKeyColumnName nvarchar(64)
	,@ForeignKeyValueColumnName nvarchar(64)
	,@UpdateName nvarchar(50)
	,@UpdateDate datetime
	,@ConcurrencyValue smallint
	,@DisplayOrder int
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @DefaultResourceLanguage PDSA.udt_pdsaLanguage
DECLARE @DisplayNameResourceKey uniqueidentifier	

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)
select @DefaultResourceLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](DEFAULT, DEFAULT, DEFAULT)

if @DefaultResourceLanguage = @MessageLanguage
	UPDATE PDSA.pdsaUserAttributeType
	SET 
		ApplicationId = @ApplicationId
		,DisplayName = @DisplayName
		,KeyName = @KeyName
		,DefaultValue = @DefaultValue
		,AttributeType = @AttributeType
		,IsActive = @IsActive
		,IsForeignKey = @IsForeignKey
		,ForeignKeySQLCommand = @ForeignKeySQLCommand
		,ForeignKeyColumnName = @ForeignKeyColumnName
		,ForeignKeyValueColumnName = @ForeignKeyValueColumnName
		,UpdateName = @UpdateName
		,UpdateDate = @UpdateDate
		,ConcurrencyValue = ConcurrencyValue + 1
		,DisplayOrder = @DisplayOrder
	WHERE
		UserAttributeTypeId = @UserAttributeTypeId
		 And ConcurrencyValue = @ConcurrencyValue
ELSE
	UPDATE PDSA.pdsaUserAttributeType
	SET 
		ApplicationId = @ApplicationId
		,KeyName = @KeyName
		,DefaultValue = @DefaultValue
		,AttributeType = @AttributeType
		,IsActive = @IsActive
		,IsForeignKey = @IsForeignKey
		,ForeignKeySQLCommand = @ForeignKeySQLCommand
		,ForeignKeyColumnName = @ForeignKeyColumnName
		,ForeignKeyValueColumnName = @ForeignKeyValueColumnName
		,UpdateName = @UpdateName
		,UpdateDate = @UpdateDate
		,ConcurrencyValue = ConcurrencyValue + 1
	WHERE
		UserAttributeTypeId = @UserAttributeTypeId
		 And ConcurrencyValue = @ConcurrencyValue

IF @@ROWCOUNT = 0
BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsUpdated', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END
ELSE
BEGIN
	EXEC pdsa.pdsaResource_PopulateForATable 'PDSA', 'pdsaUserAttributeType'
	
	select	@DisplayNameResourceKey		=	DisplayNameResourceKey
		from PDSA.pdsaUserAttributeType
	WHERE
		UserAttributeTypeId = @UserAttributeTypeId

	EXEC pdsa.pdsaResource_UpdateResourceText @DisplayNameResourceKey, @MessageLanguage, @UserAttributeTypeId, @DisplayName
END

RETURN @ret;
GO
PRINT N'Altering [PDSA].[pdsaUserAttributeType_Insert]'
GO
ALTER PROCEDURE [PDSA].[pdsaUserAttributeType_Insert]
	@ApplicationId int 
	,@DisplayName nvarchar(50) 
	,@KeyName nvarchar(50) 
	,@DefaultValue nvarchar(1024)  = null
	,@AttributeType nvarchar(128)  = null
	,@IsActive bit  = null
	,@IsForeignKey bit  = null
	,@ForeignKeySQLCommand nvarchar(2000)  = null
	,@ForeignKeyColumnName nvarchar(64)  = null
	,@ForeignKeyValueColumnName nvarchar(64)  = null
	,@InsertName nvarchar(50) 
	,@InsertDate datetime 
	,@UpdateName nvarchar(50) 
	,@UpdateDate datetime 
	,@DisplayOrder int
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

INSERT INTO PDSA.pdsaUserAttributeType
(
	ApplicationId
	,DisplayName
	,KeyName
	,DefaultValue
	,AttributeType
	,IsActive
	,IsForeignKey
	,ForeignKeySQLCommand
	,ForeignKeyColumnName
	,ForeignKeyValueColumnName
	,InsertName
	,InsertDate
	,UpdateName
	,UpdateDate
	,DisplayOrder
) 
VALUES 
(
	@ApplicationId
	,@DisplayName
	,@KeyName
	,@DefaultValue
	,@AttributeType
	,@IsActive
	,@IsForeignKey
	,@ForeignKeySQLCommand
	,@ForeignKeyColumnName
	,@ForeignKeyValueColumnName
	,@InsertName
	,@InsertDate
	,@UpdateName
	,@UpdateDate
	,@DisplayOrder
)

IF @@ROWCOUNT = 0
BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsCreated', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END
ELSE
	EXEC [PDSA].[pdsaResource_PopulateForATable] 'PDSA', 'pdsaUserAttributeType'

RETURN @ret;

GO
PRINT N'Altering [PDSA].[pdsaLog_Create]'
GO
ALTER PROCEDURE [PDSA].[pdsaLog_Create]
	 @ApplicationId int  = null
	,@ApplicationName nvarchar(50)  = null
	,@EntityName nvarchar(50)  = null
	,@EntityId int  = null
	,@UserId int  = null
	,@UserName PDSA.udt_pdsaName = null
	,@LogType nvarchar(20)  = null
	,@ServerName nvarchar(100)  = null
	,@ClientName nvarchar(100)  = null
	,@ResourceName nvarchar(255)  = null
	,@ResourceKey nvarchar(500)  = null
	,@LogInfo nvarchar(MAX)  = null
	,@SystemInfo nvarchar(4000)  = null
	,@ExtraInfo nvarchar(4000)  = null
	,@InsertName nvarchar(50) 
	,@InsertDate datetime 
	,@LogId int = NULL OUTPUT
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

INSERT INTO PDSA.pdsaLog
(
	ApplicationId
	,ApplicationName
	,EntityName
	,EntityId
	,UserId
	,UserName
	,LogType
	,ServerName
	,ClientName
	,ResourceName
	,ResourceKey
	,LogInfo
	,SystemInfo
	,ExtraInfo
	,InsertName
	,InsertDate
	,UpdateName
	,UpdateDate
) 
VALUES 
(
	@ApplicationId
	,@ApplicationName
	,@EntityName
	,@EntityId
	,@UserId
	,@UserName
	,@LogType
	,@ServerName
	,@ClientName
	,@ResourceName
	,@ResourceKey
	,@LogInfo
	,@SystemInfo
	,@ExtraInfo
	,@InsertName
	,@InsertDate
	,@InsertName
	,@InsertDate
)

IF @@ROWCOUNT = 0
BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsCreated', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END
ELSE
  SELECT @LogId = SCOPE_IDENTITY()

RETURN @ret;
GO
PRINT N'Altering [PDSA].[pdsaUserAttributeType_Get]'
GO
ALTER PROCEDURE [PDSA].[pdsaUserAttributeType_Get]
	@UserAttributeTypeId int,
	@MessageLanguage PDSA.udt_pdsaLanguage = NULL,
	@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, DEFAULT, DEFAULT)

SELECT 
	UserAttributeTypeId
	,ApplicationId
	,PDSA.udf_pdsaGetResourceText(DisplayNameResourceKey, @MessageLanguage, ApplicationId) as DisplayName
	,DisplayNameResourceKey
	,KeyName
	,DefaultValue
	,AttributeType
	,IsActive
	,IsForeignKey
	,ForeignKeySQLCommand
	,ForeignKeyColumnName
	,ForeignKeyValueColumnName
	,InsertName
	,InsertDate
	,UpdateName
	,UpdateDate
	,ConcurrencyValue
	,DisplayOrder
FROM PDSA.pdsaUserAttributeType
WHERE 
	UserAttributeTypeId = @UserAttributeTypeId

IF @@ROWCOUNT = 0
	BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsReturned', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END

RETURN @ret;
GO
PRINT N'Altering [PDSA].[pdsaUser_Import]'
GO
ALTER PROCEDURE [PDSA].[pdsaUser_Import]
  @ApplicationId INT,
  @EntityId INT,
  @RoleId INT,
  @FirstName NVARCHAR(30),
  @LastName NVARCHAR(50),
  @UserInitials NCHAR(3) = NULL,
  @EmailAddress NVARCHAR(254) = NULL,
  @EmailAddress2 NVARCHAR(254) = NULL,
  @DisplayName NVARCHAR(100) = NULL,
  @LoginName NVARCHAR(50),
  @UserPassword NVARCHAR(1024) = NULL,
  @LastLoginDate DATETIME = NULL,
  @SecurityQuestion NVARCHAR(255) = NULL,
  @SecurityAnswer NVARCHAR(255) = NULL,
  @UserTheme NVARCHAR(50) = NULL,
  @UserLanguage NVARCHAR(8) = NULL,
  @IsLockedOut BIT = NULL,
  @IsActive BIT = NULL,
  @ResetPasswordFlag BIT = NULL,
  @ImportedFlag BIT = NULL,
  @InsertName NVARCHAR(50),
  @InsertDate DATETIME,
  @UserId INT OUTPUT,
  @UserApplicationEntityId INT OUTPUT,
  @MessageLanguage PDSA.udt_pdsaLanguage = NULL,
  @ErrorMessage PDSA.udt_pdsaErrorMessage OUT
AS 
SET @MessageLanguage = [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage,
                                                            @ApplicationId,
                                                            DEFAULT)
DECLARE @ret INT;
SELECT
  @ret = 0;

/* First check for a unique LoginName */
SET @UserId = 0
SELECT
  @UserId = ISNULL(UserId, 0)
FROM
  PDSA.pdsaUser
WHERE
  LoginName = @LoginName

/* If the user is on the table, check for a application/entity */
SET @UserApplicationEntityId = 0
IF @UserId <> 0 
  SELECT
    @UserApplicationEntityId = ISNULL(UserApplicationEntityId, 0)
  FROM
    PDSA.pdsaUserApplicationEntity
  WHERE
    UserId = @UserId
    AND ApplicationId = @ApplicationId
    AND EntityId = @EntityId

IF @UserLanguage IS NULL 
  SET @UserLanguage = @MessageLanguage

IF @UserId = 0
  OR @UserApplicationEntityId = 0 
  BEGIN
    IF @UserId = 0
      AND @UserApplicationEntityId = 0 
      BEGIN

        BEGIN TRANSACTION
            
        INSERT  INTO PDSA.pdsaUser
                (FirstName, LastName, UserInitials, EmailAddress,
                 EmailAddress2, LoginName, DisplayName, UserPassword,
                 LastLoginDate, SecurityQuestion, SecurityAnswer, UserTheme,
                 UserLanguage, IsLockedOut, IsActive, ResetPasswordFlag,
                 InsertName, InsertDate, UpdateName, UpdateDate, ImportedFlag)
        VALUES
                (@FirstName, @LastName, @UserInitials, @EmailAddress,
                 @EmailAddress2, @LoginName, @DisplayName, @UserPassword,
                 @LastLoginDate, @SecurityQuestion, @SecurityAnswer,
                 @UserTheme, @UserLanguage, @IsLockedOut, @IsActive,
                 @ResetPasswordFlag, @InsertName, @InsertDate, @InsertName,
                 @InsertDate, @ImportedFlag)

        IF @@ROWCOUNT = 1 
          BEGIN
                  /* Get User Id */
            SELECT
              @UserId = @@IDENTITY;
              
                  /* Add to App/Entity Table */
            EXECUTE @ret = PDSA.pdsaUserApplicationEntity_Create @ApplicationId,
              @EntityId, @UserId, @InsertName, @InsertDate,
              @UserApplicationEntityId OUT, @MessageLanguage,
              @ErrorMessage OUT
                  
            IF @ret = 0 
              BEGIN
                    /* Add to User/Role Table */
                EXECUTE @ret = PDSA.pdsaUser_AddToRole @ApplicationId, @RoleId,
                  @UserId, @EntityId, @MessageLanguage, @ErrorMessage OUT
              END
                  
            IF @ret = 0 
              BEGIN
                COMMIT TRANSACTION
              END
            ELSE 
              BEGIN
                ROLLBACK TRANSACTION
                SET @UserId = NULL
              END
          END
        ELSE 
          BEGIN
            ROLLBACK TRANSACTION
            SET @ret = -1
          END
      END

    ELSE 
      IF @UserApplicationEntityId = 0 
        BEGIN
      
          BEGIN TRANSACTION
      
          EXECUTE @ret = PDSA.pdsaUserApplicationEntity_Create @ApplicationId,
            @EntityId, @UserId, @InsertName, @InsertDate,
            @UserApplicationEntityId OUT, @MessageLanguage, @ErrorMessage OUT
            
          IF @ret = 0 
            BEGIN
              EXECUTE @ret = PDSA.pdsaUser_AddToRole @ApplicationId, @RoleId,
                @UserId, @EntityId, @MessageLanguage, @ErrorMessage OUT
            END
                            
          IF @ret = 0 
            BEGIN
              COMMIT TRANSACTION
            END
          ELSE 
            BEGIN
              ROLLBACK TRANSACTION
              SET @UserId = NULL
            END
        END
  END   

IF @ret = -1 
  BEGIN
      /* Get the Error Message */
    EXEC PDSA.pdsa_LU_ErrorMessage @MessageName = N'ZeroRecordsCreated',
      @MessageLanguage = @MessageLanguage, @ErrorMessage = @ErrorMessage OUT;
  END

RETURN @ret;
GO

CREATE PROC InsertUserRolesRecord
AS

DECLARE @PermissionId int ,
        @ParentMenuId int ,
        @ApplicationId int ,
        @DisplayOrder int ,
        @pdsaMenuItemId int

SELECT  @ParentMenuId = MenuItemId ,
        @ApplicationId = ApplicationId
FROM    [PDSA].[pdsaMenuItem]
WHERE   ParentMenuId IS NULL AND
        MenuTitle = 'Maintenance'

SELECT  @DisplayOrder = DisplayOrder ,
        @PermissionId = PermissionId
FROM    [PDSA].[pdsaMenuItem]
WHERE   MenuTitle = 'Users' AND
        ParentMenuId = @ParentMenuId AND
        ApplicationId = @ApplicationId

INSERT  [PDSA].[pdsaMenuItem]
        ( [ApplicationId] ,
          [PermissionId] ,
          [ParentMenuId] ,
          [MenuTitle] ,
          [MenuTitleResourceKey] ,
          [DisplayOrder] ,
          [IsActive] ,
          [MenuAction] ,
          [ActiveImage] ,
          [InactiveImage] ,
          [DisabledImage] ,
          [MenuSize] ,
          [InsertName] ,
          [InsertDate] ,
          [UpdateName] ,
          [UpdateDate] ,
          [ConcurrencyValue]
        )
VALUES  ( @ApplicationId ,
          @Permissionid ,
          @ParentMenuId ,
          'User Roles' ,
          '0683B052-2562-47AE-BF16-CC6788E31778' ,
          @DisplayOrder + 5 ,
          '1' ,
          '~/Security/PDSAUserRoles.aspx' ,
          '' ,
          '' ,
          '' ,
          0 ,
          'Admin' ,
          GETDATE() ,
          'Admin' ,
          GETDATE() ,
          1
        )

SELECT  @pdsaMenuItemId = SCOPE_IDENTITY()

INSERT  [PDSA].[pdsaResource]
        ( [ResourceName] ,
          [ResourceNumber] ,
          [ResourceClassName] ,
          [ResourceLanguageKey] ,
          [ResourceLanguage] ,
          [ResourceText] ,
          [ObjectName] ,
          [ObjectPrimaryKey] ,
          [InsertName] ,
          [InsertDate] ,
          [UpdateName] ,
         [UpdateDate] ,
          [ConcurrencyValue]
        )
VALUES  ( 'PDSA.pdsaMenuItem.MenuTitle' ,
          NULL ,
          NULL ,
          '0683B052-2562-47AE-BF16-CC6788E31778' ,
          'en-us' ,
          'User Roles' ,
          'PDSA.pdsaMenuItem' ,
          @pdsaMenuItemId ,
          'Admin' ,
          GETDATE() ,
          'Admin' ,
          GETDATE() ,
          1
        )

EXECUTE InsertUserRolesRecord
GO

DROP PROC InsertUserRolesRecord
GO




INSERT INTO [PDSA].[pdsaMenuItem] ([ApplicationId], [PermissionId], [ParentMenuId], [MenuTitle], [MenuTitleResourceKey], [DisplayOrder], [IsActive], [MenuAction], [ActiveImage], [InactiveImage], [DisabledImage], [MenuSize], [InsertName], [InsertDate], [UpdateName], [UpdateDate], [ConcurrencyValue]) 
 VALUES (1, 24, 2, N'User Att Types', 'f2be8c1b-52b5-4e9f-8314-a1518bfdff42', 100, 1, N'~/Security/pdsaUserAttributeTypes.aspx', N'', N'', N'', 0, N'Test1Admin', '2013-07-30 09:32:47.910', N'Test1Admin', '2013-07-31 07:04:30.307', 1)

INSERT INTO [PDSA].[pdsaResource] ([ResourceName], [ResourceNumber], [ResourceClassName], [ResourceLanguageKey], [ResourceLanguage], [ResourceText], [ObjectName], [ObjectPrimaryKey], [InsertName], [InsertDate], [UpdateName], [UpdateDate], [ConcurrencyValue]) 
 VALUES (N'PDSA.pdsaMenuItem.MenuTitle', NULL, NULL, 'f2be8c1b-52b5-4e9f-8314-a1518bfdff42', N'en-us', N'User Att Types', N'PDSA.pdsaMenuItem', 22, N'dbo', '2013-07-30 09:32:48.833', N'dbo', '2013-07-30 09:32:48.833', 0)
INSERT INTO [PDSA].[pdsaResource] ([ResourceName], [ResourceNumber], [ResourceClassName], [ResourceLanguageKey], [ResourceLanguage], [ResourceText], [ObjectName], [ObjectPrimaryKey], [InsertName], [InsertDate], [UpdateName], [UpdateDate], [ConcurrencyValue]) 
 VALUES (N'UserAttributeTypeDuplicateDisplayName', NULL, N'PDSA', NULL, N'en-US', N'The ''Display Name'' already exists in the database.', N'DBErrorMessages', NULL, N'Admin', '2011-11-01 08:51:42.627', N'Admin', '2011-11-01 08:51:42.627', 0)
INSERT INTO [PDSA].[pdsaResource] ([ResourceName], [ResourceNumber], [ResourceClassName], [ResourceLanguageKey], [ResourceLanguage], [ResourceText], [ObjectName], [ObjectPrimaryKey], [InsertName], [InsertDate], [UpdateName], [UpdateDate], [ConcurrencyValue]) 
 VALUES (N'UserAttributeTypeDuplicateKeyName', NULL, N'PDSA', NULL, N'en-US', N'The ''Key Name'' already exists in the database.', N'DBErrorMessages', NULL, N'Admin', '2011-11-01 08:51:42.627', N'Admin', '2011-11-01 08:51:42.627', 0)