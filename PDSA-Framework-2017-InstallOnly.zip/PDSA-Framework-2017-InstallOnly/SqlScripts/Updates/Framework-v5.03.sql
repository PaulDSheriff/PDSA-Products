
/****** Object:  StoredProcedure [PDSA].[pdsaUser_Find]    Script Date: 08/27/2012 06:41:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [PDSA].[pdsaUser_Find]  
@FirstName nvarchar(30) = NULL,  
@LastName nvarchar(50) = NULL,  
@EmailAddress nvarchar(254) = NULL,  
@LoginName nvarchar(50) = NULL, 
 @IsActive bit = NULL,  
 @ApplicationId int, 
  @EntityId int = NULL,  
  @DisplaySAUsers bit = 1,  
  @MessageLanguage PDSA.udt_pdsaLanguage = NULL,  
  @ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT 
  AS  
  DECLARE @ret int; 
  DECLARE @SystemRoleId int; 
  SET @ret = 0; 
  SET @SystemRoleId = 0; 
  Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)  
  if @DisplaySAUsers = 0  Select @SystemRoleId = SystemRoleId     FROM PDSA.pdsaApplication  
  
  Declare @Active PDSA.udt_pdsaErrorMessage 
  Declare @InActive PDSA.udt_pdsaErrorMessage  
  
  exec PDSA.pdsa_LU_ErrorMessage   @MessageName=N'ActiveInactive-Active',  
   @MessageLanguage=@MessageLanguage,  
   @ErrorMessage=@Active OUT; 
   
  exec PDSA.pdsa_LU_ErrorMessage   
   @MessageName=N'ActiveInactive-InActive', 
     @MessageLanguage=@MessageLanguage, 
      @ErrorMessage=@InActive OUT;   
      
  SELECT DISTINCT  u.UserId  ,FirstName  ,LastName  ,UserInitials  ,EmailAddress  ,
                   EmailAddress2  ,LoginName  ,DisplayName  ,UserPassword  ,
                   LastLoginDate  ,SecurityQuestion  ,SecurityAnswer  ,UserTheme  
                   ,UserLanguage  ,IsLockedOut  ,IsActive  ,
                   CASE WHEN IsActive = 1 THEN @Active ELSE @InActive END AS Status  ,
                   ResetPasswordFlag  ,LastPasswordResetDate  ,uae.UserApplicationEntityId  ,
                   u.InsertName  ,u.InsertDate  ,u.UpdateName  ,u.UpdateDate  ,
                   u.ConcurrencyValue  ,
                   (SELECT ApplicationName FROM PDSA.pdsaApplication 
                      WHERE ApplicationId = @ApplicationId) as ApplicationName,
                   Stuff((SELECT N', ' + r.RoleName FROM PDSA.pdsaUserRole ur1   
                          JOIN PDSA.pdsaRole r    ON ur1.RoleId = r.RoleId   
                          WHERE ur1.UserApplicationEntityId = uae.UserApplicationEntityId  
                          AND r.ApplicationId = @ApplicationId 
                          ORDER BY ur1.UserApplicationEntityId   
                          FOR XML PATH(N''),TYPE).value(N'text()[1]',N'nvarchar(max)'),1,2,N'') Roles 
                    FROM PDSA.pdsaUser u 
                    JOIN PDSA.pdsaUserApplicationEntity uae  
                    ON u.UserId = uae.UserId  AND 
                    (@ApplicationId Is Null or uae.ApplicationId = @ApplicationId )
                    AND (@EntityId Is null or uae.EntityId = @EntityId)
                    WHERE (@FirstName IS NULL OR FirstName LIKE @FirstName + N'%') 
                    AND   (@LastName IS NULL OR LastName LIKE @LastName + N'%') 
                    AND   (@EmailAddress IS NULL OR EmailAddress LIKE @EmailAddress + N'%') 
                    AND   (@LoginName IS NULL OR LoginName LIKE @LoginName + N'%') 
                    AND   (@IsActive IS NULL OR IsActive = @IsActive) 
                    AND   (u.UserId not in (select UserId from  PDSA.pdsaRoleToUser        
                      WHERE (@ApplicationId Is Null OR ApplicationId = @ApplicationId )        
                       AND RoleId = @SystemRoleId))                
            
              IF @@ROWCOUNT = 0  BEGIN  SELECT @ret = -1;   
               exec PDSA.pdsa_LU_ErrorMessage    
               @MessageName=N'ZeroRecordsReturned',    
               @MessageLanguage=@MessageLanguage,   
               @ErrorMessage=@ErrorMessage OUT;    
               END  
               RETURN @ret; 
 GO
 

/****** Object:  StoredProcedure [PDSA].[pdsaUser_FindByLoginId]    Script Date: 08/22/2012 09:02:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [PDSA].[pdsaUser_FindByLoginId]
	@LoginName nvarchar(50) = NULL,
	@ApplicationId int,
	@MessageLanguage PDSA.udt_pdsaLanguage = NULL,
	@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SET @ret = 0;

Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

SELECT DISTINCT
	u.UserId
FROM PDSA.pdsaUser u
JOIN PDSA.pdsaUserApplicationEntity uae
	ON u.UserId = uae.UserId
	AND uae.ApplicationId = @ApplicationId
WHERE(@LoginName IS NULL OR LoginName = @LoginName ) 


IF @@ROWCOUNT = 0
	BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsReturned', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
    END

RETURN @ret;

GO


/****** Object:  StoredProcedure [PDSA].[pdsaReferenceTable_Update]    Script Date: 08/22/2012 13:04:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [PDSA].[pdsaReferenceTable_Update]
	@ReferenceTableId int 
	,@ApplicationId int
	,@TableName nvarchar(128)
	,@TableDisplayName nvarchar(50)
	,@PrimaryKeyColumnName nvarchar(64)
	,@IsActive bit
	,@UpdateName nvarchar(50)
	,@UpdateDate datetime
	,@ConcurrencyValue smallint
	,@MessageLanguage PDSA.udt_pdsaLanguage = NULL
	,@ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
AS

DECLARE @ret int;
SELECT @ret = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

DECLARE @TableDisplayNameResourceKey uniqueidentifier
DECLARE @DefaultResourceLanguage PDSA.udt_pdsaLanguage

if @DefaultResourceLanguage = @MessageLanguage
	UPDATE PDSA.pdsaReferenceTable
	SET 
		ApplicationId = @ApplicationId
		,TableName = @TableName
		,TableDisplayName = @TableDisplayName
		,PrimaryKeyColumnName = @PrimaryKeyColumnName
		,IsActive = @IsActive
		,UpdateName = @UpdateName
		,UpdateDate = @UpdateDate
		,ConcurrencyValue = ConcurrencyValue + 1
	WHERE
		ReferenceTableId = @ReferenceTableId
		 And ConcurrencyValue = @ConcurrencyValue
ELSE
	UPDATE PDSA.pdsaReferenceTable
	SET 
		ApplicationId = @ApplicationId
		,TableName = @TableName
		,TableDisplayName = @TableDisplayName
		,PrimaryKeyColumnName = @PrimaryKeyColumnName
		,IsActive = @IsActive
		,UpdateName = @UpdateName
		,UpdateDate = @UpdateDate
		,ConcurrencyValue = ConcurrencyValue + 1
	WHERE
		ReferenceTableId = @ReferenceTableId
		 And ConcurrencyValue = @ConcurrencyValue
		 
IF @@ROWCOUNT = 0
BEGIN
	SELECT @ret = -1;
	/* Get the Error Message */
	exec PDSA.pdsa_LU_ErrorMessage 
		@MessageName=N'ZeroRecordsUpdated', 
		@MessageLanguage=@MessageLanguage,
		@ErrorMessage=@ErrorMessage OUT;
END
ELSE
BEGIN
	EXEC pdsa.pdsaResource_PopulateForATable 'PDSA', 'pdsaReferenceTable'

	select	@TableDisplayNameResourceKey	=	TableDisplayNameResourceKey
			from PDSA.pdsaReferenceTable
		WHERE
			ReferenceTableId = @ReferenceTableId
			
	EXEC pdsa.pdsaResource_UpdateResourceText @TableDisplayNameResourceKey, @MessageLanguage, @ReferenceTableId, @TableDisplayName

END

RETURN @@ERROR;
Go

/****** Object:  StoredProcedure [PDSA].[pdsaUser_FindByApplication]    Script Date: 10/04/2012 11:03:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [PDSA].[pdsaUser_FindByApplication]
  @FirstName NVARCHAR(30) = NULL,
  @LastName NVARCHAR(50) = NULL,
  @EmailAddress NVARCHAR(254) = NULL,
  @LoginName NVARCHAR(50) = NULL,
  @IsActive BIT = NULL,
  @ApplicationId INT,
  @UserId INT = NULL,
  @MessageLanguage PDSA.udt_pdsaLanguage = NULL,
  @ErrorMessage PDSA.udt_pdsaErrorMessage = NULL OUT
 AS 
 DECLARE @ret INT;
  DECLARE @SystemRoleId INT;
  SET @ret = 0;
  SET @SystemRoleId = 0;
  SET @MessageLanguage = [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage,
                                                              @ApplicationId,
                                                              DEFAULT)
 SELECT
  @SystemRoleId = SystemRoleId
 FROM
  PDSA.pdsaApplication 
  WHERE
  ApplicationId = @ApplicationId
                            
 DECLARE @Active PDSA.udt_pdsaErrorMessage
 DECLARE @InActive PDSA.udt_pdsaErrorMessage
 EXEC PDSA.pdsa_LU_ErrorMessage @MessageName = N'ActiveInactive-Active',
  @MessageLanguage = @MessageLanguage, @ErrorMessage = @Active OUT;
  EXEC PDSA.pdsa_LU_ErrorMessage @MessageName = N'ActiveInactive-InActive',
    @MessageLanguage = @MessageLanguage, @ErrorMessage = @InActive OUT;
  SELECT DISTINCT
    u.UserId, FirstName, LastName, EmailAddress, LoginName, IsActive,
    CASE WHEN IsActive = 1 THEN @Active
         ELSE @InActive
    END AS Status, uae.EntityId, 
    CASE WHEN ISNULL(uae.ApplicationId, 0) > 0 Then 1
    ELSE 0 END AS ApplicationId
  FROM
    PDSA.pdsaUser u
    LEFT JOIN PDSA.pdsaUserApplicationEntity uae ON u.UserId = uae.UserId
                                                    AND uae.ApplicationId = @ApplicationId
  WHERE
    (
    @FirstName IS NULL
    OR FirstName LIKE @FirstName + N'%'
    )
    AND (
    @LastName IS NULL
    OR LastName LIKE @LastName + N'%'
    )
    AND (
    @EmailAddress IS NULL
    OR EmailAddress LIKE @EmailAddress + N'%'
    )
    AND (
    @LoginName IS NULL
    OR LoginName LIKE @LoginName + N'%'
    )
    AND (
    @IsActive IS NULL
    OR IsActive = @IsActive
    )
                          
    AND (u.UserId NOT IN (SELECT
                            UserId
                          FROM
                            PDSA.pdsaRoleToUser
                          WHERE
                            ApplicationId = @ApplicationId
                            AND RoleId = @SystemRoleId))
    AND (
    @UserId IS NULL
    OR @UserId = 0
    OR u.UserId = @UserId
    )
 IF @@ROWCOUNT = 0 
  BEGIN
    SELECT
      @ret = -1;
      EXEC PDSA.pdsa_LU_ErrorMessage @MessageName = N'ZeroRecordsReturned',
        @MessageLanguage = @MessageLanguage, @ErrorMessage = @ErrorMessage OUT;
    END
 RETURN @ret;  
 GO

/****** Object:  StoredProcedure [PDSA].[pdsaUser_FindRolesInUsers]    Script Date: 10/04/2012 11:06:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [PDSA].[pdsaUser_FindRolesInUsers]
@UserId int,
@ApplicationId int,
@EntityId int,
@MessageLanguage PDSA.udt_pdsaLanguage = null,
@ErrorMessage PDSA.udt_pdsaErrorMessage OUT
AS

Set NoCount on

declare @ret int = 0;
Set @MessageLanguage =  [PDSA].[udf_pdsaGetResourceLanguage](@MessageLanguage, @ApplicationId, DEFAULT)

/* Check if Application Exists */
exec @ret = PDSA.pdsa_LU_ApplicationId
     @ApplicationId=@ApplicationId, 
     @MessageLanguage=@MessageLanguage,
     @ErrorMessage=@ErrorMessage OUT;

IF @ret = 0
BEGIN
  /* Check if Entity Exists */
  exec @ret = PDSA.pdsa_LU_EntityId
       @EntityId=@EntityId, 
       @MessageLanguage=@MessageLanguage,
       @ErrorMessage=@ErrorMessage OUT;
END

IF @ret = 0
BEGIN
  /* Check if User Exists in App/Entity */
  exec @ret = PDSA.pdsa_LU_UserAppEntity
       @UserId=@UserId, 
       @ApplicationId = @ApplicationId,
       @EntityId = @EntityId,
       @MessageLanguage=@MessageLanguage,
       @ErrorMessage=@ErrorMessage OUT;
END
  
IF @ret = 0
BEGIN
  SELECT PDSA.pdsaRole.* 
  FROM PDSA.pdsaRole
  INNER JOIN PDSA.pdsaUserRole 
	ON PDSA.pdsaRole.RoleId = PDSA.pdsaUserRole.RoleId
	AND PDSA.pdsaUserRole.UserApplicationEntityId IN (SELECT UserApplicationEntityId 
																FROM PDSA.pdsaUserApplicationEntity 
																	WHERE UserId		= 	@UserId
																	AND ApplicationId	= @ApplicationId
																	AND EntityId		= @EntityId)
  
  IF @@ROWCOUNT = 0
  BEGIN
    SELECT @ret = -1;
    /* Get the Error Message */
    exec PDSA.pdsa_LU_ErrorMessage 
    @MessageName=N'UserDoesNotHaveRolesForAppEntity', 
    @MessageLanguage=@MessageLanguage,
    @ErrorMessage=@ErrorMessage OUT;
  END
END

RETURN @ret;

GO