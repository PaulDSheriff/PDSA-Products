In this folder are .sql files that you can apply to your existing database where the PDSA Framework tables and stored procedures are located.

These .sql files will update tables and stored procs with the latest and greatest.

For example, if you had v5.0 of the FW that you used to create a Framework project, and we give you FW 5.1, then you would look for a .sql file that is 'Framework-v5.1.sql' and you would execute that in each PDSA Framework database.
