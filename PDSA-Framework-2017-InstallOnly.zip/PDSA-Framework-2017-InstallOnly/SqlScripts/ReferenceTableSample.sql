/**
Use this script to create a new Reference table for your application.
Search and Replace TABLE_NAME with the name of your new table.
**/
CREATE TABLE TABLE_NAME
(
	[TABLE_NAMEId] [int] IDENTITY(1,1) NOT NULL,
	[Display] [nvarchar](50) NOT NULL,
	[DisplayResourceKey] [uniqueidentifier] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[DescriptionResourceKey] [uniqueidentifier] NULL,
	[Code] [nvarchar](16) NOT NULL,
	[CodeResourceKey] [uniqueidentifier] NULL,
	[DisplayOrder] [int] NULL,
	[IsDefault] [bit] NULL,
	[IsActive] [bit] NULL,
	[IsComplete] [bit] NULL,
	[SystemKey] [varchar](50) NULL,
	[InsertName] [nvarchar](50) NOT NULL,
	[InsertDate] [datetime] NOT NULL,
	[UpdateName] [nvarchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[ConcurrencyValue] [smallint] NULL,
PRIMARY KEY NONCLUSTERED 
(
	[TABLE_NAMEId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT ((10)) FOR [DisplayOrder]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT ((0)) FOR [IsDefault]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT ((0)) FOR [IsComplete]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT (user_name()) FOR [InsertName]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT (getdate()) FOR [InsertDate]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT (user_name()) FOR [UpdateName]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT (getdate()) FOR [UpdateDate]
GO

ALTER TABLE TABLE_NAME ADD  DEFAULT ((1)) FOR [ConcurrencyValue]
GO
