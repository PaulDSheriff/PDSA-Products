﻿This project is where you put your Entity, Data, Business and Validation classes that you generate from Haystack or you create yourself.
