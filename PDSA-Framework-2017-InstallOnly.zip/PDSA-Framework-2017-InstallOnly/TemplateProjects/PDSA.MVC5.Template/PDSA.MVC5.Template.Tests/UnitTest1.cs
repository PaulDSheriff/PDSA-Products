﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PDSA.MVC5.Template.Tests
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestMethod1()
    {
    }
  }
}
