﻿The classes in this folder are used by the security, lookup and other pages developed by PDSA.
These classes can also be used and extended as necessary for your applications.

PermissionsValues - This is used by our security maintenance pages
                  - Also check out the /// <Summary> comments for more information.

