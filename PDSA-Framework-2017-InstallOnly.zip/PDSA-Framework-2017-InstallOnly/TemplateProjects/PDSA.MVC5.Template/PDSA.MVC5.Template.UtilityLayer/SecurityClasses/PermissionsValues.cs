﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PDSA.Framework.ViewModelLayer;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// You can add any names of permissions to this class that you might use programmatically
  /// For Example:
  ///  _ViewModel.IsSelectEntityVisible = this.Principal.HasPermission(PermissionValues.SAPageRoleEntitySelectVisible);
  /// So instead of hard-coding permission names, add those as static properties to this class.
  /// </summary>
  public class PermissionValues : PDSAPermissionsValues
  {
  }
}
