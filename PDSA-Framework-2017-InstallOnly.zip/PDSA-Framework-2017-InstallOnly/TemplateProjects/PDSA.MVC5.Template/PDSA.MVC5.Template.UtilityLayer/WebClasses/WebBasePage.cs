﻿using PDSA.Web;
using PDSA.Security;
using System.Web.UI;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is what you should use for to inherit from in all your web pages
  /// </summary>
  public class WebBasePage : PDSAPage
  {
    #region Protected Properties

    private WebUserSession _session;

    /// <summary>
    /// Get/Set the User Session information on a page
    /// </summary>
    protected WebUserSession UserSession
    {
      get
      {
        if (_session == null)
        {
          _session = new WebUserSession();
        }
        return _session;
      }
    }

    /// <summary>
    /// Get/Set the principal security object for the user.
    /// This is a PDSAPrincipal object so you can retrieve additional information from the PDSA Security System
    /// </summary>
    protected PDSAPrincipal Principal
    {
      get
      {
        return (PDSAPrincipal)Page.User;
      }
    }
    #endregion

    #region RestoreFilterState Method
    /// <summary>
    /// Restore the User's Filter State for this page
    /// </summary>
    /// <param name="container">The container control that contains the controls for filter state</param>
    /// <param name="filterSetName">The name of the filter to store in the database</param>
    /// <param name="excludeControls">Any controls to exclude from saving</param>
    /// <param name="restoreDefault">Set to true to restore the default set of filters</param>
    protected void RestoreFilterState(Control container,
                                  string filterSetName,
                                  string excludeControls,
                                  bool restoreDefault)
    {
      PDSAUserFilterState FilterState;

      try
      {
        FilterState = new PDSAUserFilterState();
        FilterState.Restore(container, filterSetName, excludeControls, restoreDefault);
      }
      catch
      {
        // Can add any exception handling you want here, but it is not critical
      }
    }
    #endregion

    #region SaveFilterState Method
    /// <summary>
    /// Save the current filters to the database
    /// </summary>
    /// <param name="container">The container control that contains the controls for filter state</param>
    /// <param name="filterSetName">The name of the filter to store in the database</param>
    /// <param name="excludeControls">Any controls to exclude from saving</param>
    protected void SaveFilterState(Control container,
                                   string filterSetName,
                                   string excludeControls)
    {
      PDSAUserFilterState FilterState;

      try
      {
        FilterState = new PDSAUserFilterState();
        FilterState.Save(container, filterSetName, excludeControls, string.Empty);
      }
      catch
      {
        // Can add any exception handling you want here, but it is not critical
      }
    }
    #endregion
  }
}
