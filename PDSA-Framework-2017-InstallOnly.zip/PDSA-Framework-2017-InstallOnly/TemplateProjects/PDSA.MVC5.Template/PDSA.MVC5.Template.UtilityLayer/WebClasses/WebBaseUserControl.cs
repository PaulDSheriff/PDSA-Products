﻿using PDSA.Web;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is used if you want to add additional properties or methods to every user control you create.
  /// Simply inherit from this control instead of the default User Control class from Microsoft
  /// </summary>
  public class WebBaseUserControl : PDSAUserControl
  {
    private WebUserSession _session = null;

    protected WebUserSession UserSession
    {
      get
      {
        if (_session == null)
        {
          _session = new WebUserSession();
        }
        return _session;
      }
    }
  }
}
