using System.Collections;
using System.Web.UI.WebControls;
using PDSA.Web;
using PDSA.Common;
using System.Collections.Generic;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// Wrapper class around the PDSADropDown class that allows you to customize and extend DropDown control binding
  /// </summary>
  public class DropDownAdapter
  {
    public static void Bind(DropDownList dropDown, string textField, string valueField, IEnumerable items)
    {
      PDSADropDown ddl = new PDSADropDown();
      ddl.Bind(dropDown, textField, valueField, items);
    }

    public static void Bind(DropDownList dropDown, string textField, string valueField, IEnumerable items, string defaultItem)
    {
      PDSADropDown ddl = new PDSADropDown();
      ddl.Bind(dropDown, textField, valueField, items);
      ddl.Insert(dropDown, defaultItem);
    }

    public static int GetSelectedValue(DropDownList dropDown)
    {
      PDSADropDown ddl = new PDSADropDown();
      return ddl.GetSelectedValue(dropDown);
    }

    public static string GetSelectedText(DropDownList dropDown)
    {
      PDSADropDown ddl = new PDSADropDown();
      return ddl.GetSelectedText(dropDown);
    }

    public static void SelectByValue(DropDownList dropDown, int value)
    {
      SelectByValue(dropDown, value.ToString());
    }

    public static void SelectByValue(DropDownList dropDown, string value)
    {
      PDSADropDown ddl = new PDSADropDown();
      ddl.SelectByValue(dropDown, value);
    }

    public static void SelectByText(DropDownList dropDown, string text)
    {
      PDSADropDown ddl = new PDSADropDown();
      ddl.SelectByText(dropDown, text);
    }
  }
}
