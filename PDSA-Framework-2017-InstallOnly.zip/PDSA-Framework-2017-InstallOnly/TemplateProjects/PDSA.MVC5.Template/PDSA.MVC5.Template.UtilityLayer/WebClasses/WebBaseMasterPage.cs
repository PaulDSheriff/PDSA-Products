﻿using PDSA.Web;
using PDSA.Security;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is used for all Master Pages to inherit from
  /// </summary>
  public class WebBaseMasterPage : PDSAMasterPage
  {  
    #region UserSession Property

    private WebUserSession _session;

    /// <summary>
    /// Get/Set the User Session information on a master page
    /// </summary>
    protected new WebUserSession UserSession
    {
      get
      {
        if (_session == null)
        {
          _session = new WebUserSession();
        }
        return _session;
      }
    }   
    #endregion

    public override void RefreshMenus()
    {     
    }
  }
}
