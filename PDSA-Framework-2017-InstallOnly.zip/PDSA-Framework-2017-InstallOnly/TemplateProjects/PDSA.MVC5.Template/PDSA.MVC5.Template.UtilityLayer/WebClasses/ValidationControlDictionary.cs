﻿using PDSA.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// A collection of validation markers to display on the UI
  /// </summary>
  public class ValidationControlDictionary : Dictionary<string, Panel>
  {
    /// <summary>
    /// Sets all the panels to normal
    /// </summary>
    protected virtual void Hide()
    {
      foreach (Panel pnl in this.Values)
      {
        pnl.CssClass = "form-group";
      }
    }

    /// <summary>
    /// Displays a marker with the property name and sets its message
    /// </summary>
    /// <param name="propertyName">A property name</param>
    /// <param name="message">Message to set</param>
    public virtual void Show(string propertyName, string message)
    {
      if (this.ContainsKey(propertyName))
      {
         this[propertyName].CssClass = "form-group has-error";
        this[propertyName].ToolTip = message;
      }
    }

    /// <summary>
    /// Displays all markers based on a collection of PDSAValidationRules
    /// </summary>
    /// <param name="errors">A collection of PDSAValidationRule objects</param>
    public virtual void Show(PDSAValidationRules errors)
    {
      this.Hide();
      foreach (PDSAValidationRule error in errors)
      {
        this.Show(error.PropertyName, error.Message);
      }
    }

    /// <summary>
    /// Displays all markers in a dictionary
    /// </summary>
    /// <param name="markers">A dictionary object</param>
    public virtual void Show(Dictionary<string, string> markers)
    {
      this.Hide();
      foreach (string propertyName in markers.Keys)
      {
        this.Show(propertyName, markers[propertyName]);
      }
    }

    /// <summary>
    /// Add a label control to the markers collection
    /// </summary>
    /// <param name="label">A Label control</param>
    public virtual void Add(Panel panel)
    {
      this.Add(panel.Attributes[this.ValidationMarkerAttribute], panel);
    }

    /// <summary>
    /// Gets the attribute used to identify validation marker controls
    /// </summary>
    protected virtual string ValidationMarkerAttribute
    {
      get
      {
        return "PropertyName";
      }
    }
  }
}
