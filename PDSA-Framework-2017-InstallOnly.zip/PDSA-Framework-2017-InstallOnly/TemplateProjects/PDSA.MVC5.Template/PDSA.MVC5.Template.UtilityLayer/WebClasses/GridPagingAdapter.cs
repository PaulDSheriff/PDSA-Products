﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace PDSA.MVC5.Template.UtilityLayer.WebClasses
{
  public class GridPagingAdapter
  {
    private GridView _gridView;

    public GridPagingAdapter(GridView gridView)
    {
      _gridView = gridView;
    }

    public void CreateControls()
    {
      GridViewRow row = null;
      PageItemCollection pages = null;
      HtmlGenericControl ul = null;
      HtmlGenericControl li = null;
      LinkButton lnk = null;

      if (_gridView.BottomPagerRow != null)
      {
        row = _gridView.BottomPagerRow;

        pages = new PageItemCollection(_gridView.PageCount, _gridView.PageIndex);

        ul = new HtmlGenericControl("ul");
        ul.Attributes.Add("class", "pagination pagination-sm");

        foreach (PageItem item in pages)
        {
          lnk = new LinkButton();
          lnk.ID = string.Format("lnkPagerControl{0}", item.ItemIndex);
          lnk.CommandName = "Page";
          lnk.CommandArgument = item.PageArgument;
          lnk.Text = item.PageText;

          li = new HtmlGenericControl("li");
          if (!string.IsNullOrWhiteSpace(item.CssClass))
          {
            li.Attributes.Add("class", item.CssClass);
          }
          li.Controls.Add(lnk);

          ul.Controls.Add(li);
        }

        row.Cells[0].Controls.Add(ul);
      }
    }
  }
}
