﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDSA.MVC5.Template.UtilityLayer.WebClasses
{
    public class PageItem
    {
        public PageItem(int pageCount, int pageIndex, int index)
        {
            int pageNumber = pageCount + 1;

            this.PageText = pageNumber.ToString();
            this.PageArgument = pageNumber.ToString();
            this.Selected = (pageCount == pageIndex);
            this.ItemIndex = index;
        }

        public PageItem(string text, string arg, bool disabled, int index)
        {
            this.PageText = text;
            this.PageArgument = arg;
            this.Selected = false;
            this.Disabled = disabled;
            this.ItemIndex = index;
        }

        public string PageText { get; set; }
        public string PageArgument { get; set; }
        public bool Selected { get; set; }
        public bool Disabled { get; set; }

        public string CssClass
        {
            get
            {
                string result = string.Empty;
                if (this.Selected)
                {
                    result = "active";
                }
                else if (this.Disabled)
                {
                    result = "disabled";
                }
                return result;
            }
        }

        public int ItemIndex { get; set; }
    }

    public class PageItemCollection : List<PageItem>
    {
        public PageItemCollection(int pageCount, int pageIndex)
        {
            int itemIndex = 0;
            bool firstPrevDisabled = false;
            bool nextLastDisabled = false;

            if (pageIndex == 0) firstPrevDisabled = true;

            this.Add(new PageItem("&lsaquo;", "Prev", firstPrevDisabled, itemIndex));
            itemIndex++;
            this.Add(new PageItem("&laquo;", "First", firstPrevDisabled, itemIndex));
            itemIndex++;

            for (int i = 0; i < pageCount; i++)
            {
                this.Add(new PageItem(i, pageIndex, itemIndex));
                itemIndex++;
            }

            if (pageCount - 1 == pageIndex) nextLastDisabled = true;

            this.Add(new PageItem("&raquo;", "Last", nextLastDisabled, itemIndex));
            itemIndex++;
            this.Add(new PageItem("&rsaquo;", "Next", nextLastDisabled, itemIndex));
            itemIndex++;
        }
    }
}
