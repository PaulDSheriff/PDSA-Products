using System;
using System.Web;

using PDSA.Web;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// Provides strongly-typed access to session variables.
  /// </summary>
  [Serializable]
  public class WebUserSession : PDSAWebSession
  {
    #region Constructor
    /// <summary>
    /// Constructor for the WebUserSession class
    /// Default constructor will use HttpContext.Current.Session as the session object 
    /// </summary>
    public WebUserSession()
    {
    }

    /// <summary>
    /// Constructor for the WebUserSession class
    /// override constructor when HttpContext.Current.Session is not valid.
    /// This happens in the Global.asax.
    /// </summary>
    public WebUserSession(System.Web.SessionState.HttpSessionState session)
      : base(session)
    {
    }
    #endregion

    #region Your Custom Properties
    // Add your own Properties Here

    /// <summary>
    /// Get/Set the Last Employee Name used
    /// NOTE: This is a sample only, you can remove this.
    /// </summary>
    public string LastEmployeeName
    {
      get { return this.GetString("LastEmployeeName"); }
      set { this["LastEmployeeName"] = value; }
    }

    #endregion
  }
}
