﻿The classes in this folder are used by the security, lookup and other pages developed by PDSA.
These classes can also be used and extended as necessary for your applications.

DropDownAdapter - Wrapper class around the PDSADropDown class that allows you to customize and extend DropDown control binding

WebBaseMasterPage - The Site.Master page inherits from this base class

WebBasePage - All of your ASP.NET Web Form pages inherit from this class in order to participate in security, get session values, etc.

WebBaseUserControl - This is the user control that all of your ASP.NET user controls should inherit from

WebUserSession - Use this class for all your "Session" variables. You should NOT use the ASP.NET Session variable. Instead just add properties to this class and use this for your session variables.
