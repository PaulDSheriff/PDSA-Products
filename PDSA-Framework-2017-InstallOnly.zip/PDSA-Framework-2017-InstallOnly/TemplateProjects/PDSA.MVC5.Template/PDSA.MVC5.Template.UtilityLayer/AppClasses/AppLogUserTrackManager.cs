﻿using System;
using System.Collections.Specialized;

using PDSA.Common;
using PDSA.Logging;
using PDSA.Framework;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is used to record User Logins, User Logouts, and User Visits to a Page/Form/Window/User Control.
  /// </summary>
  public class AppLogUserTrackManager
  {
    /// <summary>
    /// Record that a user logged into the application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    public static void Login(string userName)
    {
      Log(userName, string.Empty, string.Empty, PDSALoggingTypes.UserLogin);
    }

    /// <summary>
    /// Record that a user logged into the application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="clientName">The client machine name</param>
    public static void Login(string userName, string clientName)
    {
      Log(userName, string.Empty, clientName, PDSALoggingTypes.UserLogin);
    }

    /// <summary>
    /// Record that a user logged out of the application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    public static void Logout(string userName)
    {
      Log(userName, string.Empty, string.Empty, PDSALoggingTypes.UserLogout);
    }

    /// <summary>
    /// Record that a user logged out of the application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="clientName">The client machine name</param>
    public static void Logout(string userName, string clientName)
    {
      Log(userName, string.Empty, clientName, PDSALoggingTypes.UserLogout);
    }

    /// <summary>
    /// Record that a user visited a page/window/form/user control in this application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="pageName">The page name</param>
    public static void UserVisit(string userName, string pageName)
    {
      Log(userName, pageName, Environment.MachineName, PDSALoggingTypes.UserVisit);
    }

    /// <summary>
    /// Record that a user visited a page/window/form/user control in this application
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="pageName">The page name</param>
    /// <param name="clientName">The client machine name</param>
    public static void UserVisit(string userName, string pageName, string clientName)
    {
      Log(userName, pageName, clientName, PDSALoggingTypes.UserVisit);
    }

    #region Log Methods
    /// <summary>
    /// Record a user login/logout/visit in the log
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="pageName">The page name</param>
    /// <param name="clientName">The client machine name</param>
    /// <param name="logType">The type of log entry to record</param>
    public static void Log(string userName, string pageName, string clientName, PDSALoggingTypes logType)
    {
      NameValueCollection nvc;
      PDSALoggingManager mgr;

      // Get an instance of the Logging Manager
      mgr = AppLogCommon.LogManager;

      // Grab Standard NVC Values for logging in this Application
      nvc = AppLogCommon.BuildCommonNVC();

      if (string.IsNullOrEmpty(clientName))
        clientName = Environment.MachineName;

      // Log the User Tracking Information
      mgr.ConfigurationProviders.ClientName = clientName;
      switch (logType)
      {
        case PDSALoggingTypes.UserLogin:
          mgr.LogUserLogin(userName, nvc);
          break;
        case PDSALoggingTypes.UserLogout:
          mgr.LogUserLogout(userName, nvc);
          break;
        case PDSALoggingTypes.UserVisit:
          mgr.LogUserVisit(userName, pageName, nvc);
          break;
      }
    }

    /// <summary>
    /// Record a user login/logout/visit in the log
    /// </summary>
    /// <param name="userName">The user who logged in</param>
    /// <param name="pageName">The page name</param>
    /// <param name="clientName">The client machine name</param>
    /// <param name="nvc">A NameValueCollection Object</param>
    /// <param name="logType">The type of log entry to record</param>
    public static void Log(string userName, string pageName, string clientName, NameValueCollection nvc, PDSALoggingTypes logType)
    {
      PDSALoggingManager mgr;

      // Get an instance of the Logging Manager
      mgr = AppLogCommon.LogManager;

      // Add the passed in NVC values to the standard NVC
      nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

      // Log the User Tracking Information
      mgr.ConfigurationProviders.ClientName = clientName;
      mgr.ConfigurationProviders.ResourceName = pageName;
      switch (logType)
      {
        case PDSALoggingTypes.UserLogin:
          mgr.LogUserLogin(userName, nvc, mgr.EntityId);
          break;
        case PDSALoggingTypes.UserLogout:
          mgr.LogUserLogout(userName, nvc, mgr.EntityId);
          break;
        case PDSALoggingTypes.UserVisit:
          mgr.LogUserVisit(userName, pageName, nvc, mgr.EntityId);
          break;
      }
    }
    #endregion
  }
}
