﻿using System;
using PDSA.Framework;
using PDSA.Framework.EntityLayer;
using PDSA.Security;
using PDSA.Web.MVC;

namespace PDSA.MVC5.Template.UtilityLayer
{
   /// <summary>
   /// All your controllers should inherit from this controller
   /// </summary>
   public class AppController : PDSAControllerBase
   {
      #region Constants
      private const string MY_PROFILE = "My Profile";
      private const string MY_PROFILE_MENU_ACTION = "~/Security/PDSAUserProfile.aspx";
      #endregion

      #region Protected Properties
      private WebUserSession _session;

      /// <summary>
      /// Get/Set the User Session information on a page
      /// </summary>
      protected WebUserSession UserSession
      {
        get
        {
          if (_session == null) {
            _session = new WebUserSession();
          }
          return _session;
        }
      }
      #endregion

      #region Init Method
      /// <summary>
      /// Initialize any items needed by all controllers
      /// </summary>
      public override void Init()
      {
         // Initialize Security Principal, Permissions, Language, etc.
         base.Init();
         
         try {
            // Store menus in application cache
            if (AppCache.HierarchicalMenus.Count == 0) {
               AppCache.HierarchicalMenus = base.GetMenusInHierarchicalStructure();
            }

            SetUserProfileMenu();
         }
         catch (Exception ex) {
            // Most likely a connection error
            UserSession.WebMessage.DisplayError = true;
            UserSession.WebMessage = new PDSA.Web.PDSAWebMessage(ex, "We're sorry, but our website is currently experiencing technical issues. Please check back later");
            // AppLogExceptionManager.Log(ex);
         }
      }
      #endregion

      #region Set User Profile Menu
      /// <summary>
      /// Set user's name into the User Profile Menu
      /// </summary>
      public void SetUserProfileMenu()
      {
         // Locate the profile menu
         pdsaMenuItem mi = AppCache.HierarchicalMenus.Find(m => m.MenuTitle == MY_PROFILE | m.MenuAction == MY_PROFILE_MENU_ACTION);
         if (mi != null)
         {
            if (User != null)
            {
               if (User.Identity != null)
               {
                  mi.MenuTitle = User.Identity.Name;
               }
            }
         }
      }
      #endregion
   }
}