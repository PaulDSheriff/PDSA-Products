﻿using System;
using System.Collections.Specialized;
using PDSA.Logging;
using PDSA.Framework;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is for you to add common variables, session variables, application variables, etc. to your Logging manager.
  /// </summary>
  public class AppLogCommon
  {
     #region LogManager Property
     /// <summary>
     /// Gets the default Logging Manager and Provider.
     /// You can modify this code if you want to add or remove any providers.
     /// However, generally you control this thru the .Config file
     /// </summary>
     /// <returns>A PDSALoggingManager object</returns>
     public static PDSALoggingManager LogManager
     {
        get
        {
           PDSALoggingManager mgr = new PDSALoggingManager();

           return mgr;
        }
     }
     #endregion

     #region SetApplicationInfo Method
     /// <summary>
     /// Call this method whenever you change to a new application or group
     /// </summary>
     /// <param name="applicationId">The application Id</param>
     /// <param name="applicationName">The application name</param>
     /// <param name="userId">The User Id</param>
     /// <param name="userName">The User name</param>
     /// <param name="entityId">The Entity Id</param>
     /// <param name="entityName">The Entity Name</param>
     public static void SetApplicationInfo(int applicationId, string applicationName, int userId, string userName, int entityId, string entityName)
     {
        PDSASettings.AllValues.Application.Entities.DefaultEntityId = entityId;
        PDSASettings.AllValues.Application.General.ApplicationId = applicationId;
        PDSASettings.AllValues.Application.General.ApplicationName = applicationName;

        LogManager.SetApplicationInfo(applicationId, applicationName, userId, userName, entityId, entityName);
     }
     #endregion

     #region BuildCommonNVC Method
     /// <summary>
     /// Add your own variables to this method that you wish to store into the log
     /// These will be added to every log entry you make in this application
     /// </summary>
     /// <returns>A NameValueCollection Object</returns>
     public static NameValueCollection BuildCommonNVC()
     {
        NameValueCollection nvc = new NameValueCollection();

        // Add Your Key/Value pairs here. The following two are just samples...
        //nvc.Add("Client Machine", Environment.MachineName);
        //nvc.Add("User Name", Environment.UserName);

        // TODO: Add Looping thru all Session, Cache, Application and PDSA Cache items and get key/value pairs

        return nvc;
     }
     #endregion
  }
}
