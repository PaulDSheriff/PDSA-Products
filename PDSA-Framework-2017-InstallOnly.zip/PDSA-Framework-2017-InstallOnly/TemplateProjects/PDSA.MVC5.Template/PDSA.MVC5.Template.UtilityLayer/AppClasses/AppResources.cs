﻿using System;
using PDSA.Resource;
using PDSA.Framework.ViewModelLayer;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// Call this class to retrieve localized resources such as labels, messages
  /// </summary>
  public class AppResources
  {
     #region Constructor
     /// <summary>
     /// Constructor for AppResources class
     /// </summary>
     public AppResources()
     {
        Language = "en-US";
     }
     #endregion

     #region Public Static Properties
     /// <summary>
     /// Get/Set the PDSA Resource Manager object to use
     /// </summary>
     public static PDSAResourceManager ResourceManager
     {
        get
        {
           PDSAResourceManager mgr = new PDSAResourceManager();

           return mgr;
        }
     }

     /// <summary>
     /// Get/Set the Language to use to retrieve resources
     /// </summary>
     public static string Language
     {
        get { return AppResources.ResourceManager.Provider.ResourceLanguage; }
        set { AppResources.ResourceManager.Provider.ResourceLanguage = value; }
     }
     #endregion

     #region SetLanguage Method
     /// <summary>
     /// Call this method to set the language of the values to retrieve
     /// </summary>
     /// <param name="language">The language such as (en-US, es-MX, etc.)</param>
     public static void SetLanguage(string language)
     {
        AppResources.ResourceManager.Provider.ResourceLanguage = language;
     }
     #endregion

     #region ChangeLanguage Method
     /// <summary>
     /// Call this method to change the language of the values to retrieve
     /// <param name="language">The language such as (en-US, es-MX, etc.)</param>
     /// </summary>
     public static void ChangeLanguage(string language)
     {
        PDSAFrameworkViewModelMessages.Instance.ChangeMessages(language);
     }
     #endregion

     #region GetResource static Methods
     /// <summary>
     /// Gets a specified resource based on the unique resource name.
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="resourceName">The unique resource name</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     public static string GetResource(string resourceName, string defaultToReturn)
     {
        return GetResource(string.Empty, resourceName, Int32.MinValue, Int32.MinValue, defaultToReturn);
     }

     /// <summary>
     /// Gets a specified resource based on the class name and the unique resource name.
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="className">A class name</param>
     /// <param name="resourceName">The unique resource name</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     public static string GetResource(string className, string resourceName, string defaultToReturn)
     {
        return GetResource(className, resourceName, Int32.MinValue, Int32.MinValue, defaultToReturn);
     }

     /// <summary>
     /// Gets a specified resource based on the class name, unique resource name and unique resource number.
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="className">A class name</param>
     /// <param name="resourceName">The unique resource name</param>
     /// <param name="resourceNumber">The unique resource number (pass in Int32.MinValue to ignore this parameter)</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     public static string GetResource(string className, string resourceName, int resourceNumber, string defaultToReturn)
     {
        return GetResource(className, resourceName, resourceNumber, Int32.MinValue, defaultToReturn);
     }

     /// <summary>
     /// Gets a specified resource based on the class name, unique resource name and unique resource number.
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="resourceName">The unique resource name</param>
     /// <param name="resourceNumber">The unique resource number (pass in Int32.MinValue to ignore this parameter)</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     public static string GetResource(string resourceName, int resourceNumber, string defaultToReturn)
     {
        return GetResource(string.Empty, resourceName, resourceNumber, Int32.MinValue, defaultToReturn);
     }

     /// <summary>
     /// Gets a specified resource based on the unique Resource ID
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="resourceId">The unique resource ID (pass in Int32.MinValue to ignore this parameter)</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     public static string GetResource(int resourceId, string defaultToReturn)
     {
        return GetResource(string.Empty, string.Empty, Int32.MinValue, resourceId, defaultToReturn);
     }

     /// <summary>
     /// Gets a specified resource from the data store.
     /// If the value is not found in the data store, then the value in the 'defaultToReturn' parameter is returned
     /// </summary>
     /// <param name="className">A class name</param>
     /// <param name="resourceName">The unique resource name</param>
     /// <param name="resourceNumber">The unique resource number (pass in Int32.MinValue to ignore this parameter)</param>
     /// <param name="resourceId">The unique resource ID (pass in Int32.MinValue to ignore this parameter)</param>
     /// <param name="defaultToReturn">A default string to return if the resource is not found</param>
     /// <returns>A message</returns>
     protected static string GetResource(string className, string resourceName, int resourceNumber, int resourceId, string defaultToReturn)
     {
        string ret = string.Empty;

        try
        {
           ret = AppResources.ResourceManager.Provider.GetResource(className, resourceName, resourceNumber, resourceId, Language, defaultToReturn);
        }
        catch (Exception ex)
        {
           AppResources.ResourceManager.Provider.LastException = ex;
        }

        return ret;
     }
     #endregion
  }
}
