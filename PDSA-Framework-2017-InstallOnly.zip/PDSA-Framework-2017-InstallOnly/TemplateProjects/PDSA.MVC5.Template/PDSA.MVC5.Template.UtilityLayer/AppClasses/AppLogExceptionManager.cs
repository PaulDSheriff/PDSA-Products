﻿using System;
using System.Collections.Specialized;

using PDSA.Common;
using PDSA.Framework;
using PDSA.Logging;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// Use this class to log exceptions to the logging manager class.
  /// </summary>
  public class AppLogExceptionManager
  {
    /// <summary>
    /// Add an Exception to the log
    /// </summary>
    /// <param name="ex">An exception</param>
    public static void Log(Exception ex)
    {
      NameValueCollection nvc;
      PDSALoggingManager mgr;

      // Get an instance of the Logging Manager
      mgr = AppLogCommon.LogManager;

      // Grab Standard NVC Values for logging in this Application
      nvc = AppLogCommon.BuildCommonNVC();

      // Log the exception
      mgr.LogException(ex, nvc);
    }

    /// <summary>
    /// Add an Exception to the log
    /// </summary>
    /// <param name="ex">An exception</param>
    /// <param name="nvc">A NameValueCollection Object</param>
    public static void Log(Exception ex, NameValueCollection nvc)
    {
      PDSALoggingManager mgr;

      // Get an instance of the Logging Manager
      mgr = AppLogCommon.LogManager;

      // Add the passed in NVC values to the standard NVC
      nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

      // Log the exception
      mgr.LogException(ex, nvc);
    }
  }
}