using System;
using System.Collections.Specialized;
using PDSA.Logging;
using PDSA.Framework;
using PDSA.Common;

namespace PDSA.MVC5.Template.UtilityLayer
{
  /// <summary>
  /// This class is for you to add common variables, session variables, application variables, etc. to your Logging manager.
  /// </summary>
  public class AppLog
  {
     #region LogManager Property
     /// <summary>
     /// Gets the default Logging Manager and Provider.
     /// You can modify this code if you want to add or remove any providers.
     /// However, generally you control this thru the .Config file
     /// </summary>
     /// <returns>A PDSALoggingManager object</returns>
     public static PDSALoggingManager LogManager
     {
        get
        {
           PDSALoggingManager mgr = new PDSALoggingManager();

           return mgr;
        }
     }
     #endregion

     #region SetApplicationInfo Method
     /// <summary>
     /// Call this method whenever you change to a new application or group
     /// </summary>
     /// <param name="applicationId">The application Id</param>
     /// <param name="applicationName">The application name</param>
     /// <param name="userId">The User Id</param>
     /// <param name="userName">The User name</param>
     /// <param name="entityId">The Entity Id</param>
     /// <param name="entityName">The Entity Name</param>
     public static void SetApplicationInfo(int applicationId, string applicationName, int userId, string userName, int entityId, string entityName)
     {
        PDSASettings.AllValues.Application.Entities.DefaultEntityId = entityId;
        PDSASettings.AllValues.Application.General.ApplicationId = applicationId;
        PDSASettings.AllValues.Application.General.ApplicationName = applicationName;

        LogManager.SetApplicationInfo(applicationId, applicationName, userId, userName, entityId, entityName);
     }
     #endregion

     #region BuildCommonNVC Method
     /// <summary>
     /// Add your own variables to this method that you wish to store into the log
     /// These will be added to every log entry you make in this application
     /// </summary>
     /// <returns>A NameValueCollection Object</returns>
     public static NameValueCollection BuildCommonNVC()
     {
        NameValueCollection nvc = new NameValueCollection();

        // Add Your Key/Value pairs here. The following two are just samples...
        //nvc.Add("Client Machine", Environment.MachineName);
        //nvc.Add("User Name", Environment.UserName);

        // TODO: Add Looping thru all Session, Cache, Application and PDSA Cache items and get key/value pairs

        return nvc;
     }
     #endregion

     /// <summary>
     /// Log an Insert audit track record
     /// </summary>
     /// <param name="valueToLog">The XML value to log</param>
     /// <param name="tableName">The table name</param>
     /// <param name="key">A unique key (usually the PK of the table)</param>
     public static void Insert(string valueToLog, string tableName, string key)
     {
        Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackInsert);
     }

     /// <summary>
     /// Log an Update audit track record
     /// </summary>
     /// <param name="valueToLog">The XML value to log</param>
     /// <param name="tableName">The table name</param>
     /// <param name="key">A unique key (usually the PK of the table)</param>
     public static void Update(string valueToLog, string tableName, string key)
     {
        Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackUpdate);
     }

     /// <summary>
     /// Log a Delete audit track record
     /// </summary>
     /// <param name="valueToLog">The XML value to log</param>
     /// <param name="tableName">The table name</param>
     /// <param name="key">A unique key (usually the PK of the table)</param>
     public static void Delete(string valueToLog, string tableName, string key)
     {
        Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackDelete);
     }

     #region Log Methods
     /// <summary>
     /// Method to log anything. Called by the Insert(), Update() and Delete() methods
     /// This method also calls the AppLogCommon.BuildCommonNVC() method to gather any of your specific data you want to log.
     /// </summary>
     /// <param name="valueToLog">The XML value to log</param>
     /// <param name="tableName">The table name</param>
     /// <param name="key">A unique key (usually the PK of the table)</param>
     /// <param name="logType">The Log Type to Create</param>
     public static void Log(string valueToLog, string tableName, string key, PDSALoggingTypes logType)
     {
        NameValueCollection nvc;
        PDSALoggingManager mgr;

        // Get an instance of the Logging Manager
        mgr = AppLog.LogManager;

        // Grab Standard NVC Values for logging in this Application
        nvc = AppLog.BuildCommonNVC();

        switch (logType)
        {
           case PDSALoggingTypes.AuditTrackInsert:
              mgr.LogAuditTrackInsert(tableName, key, valueToLog);
              break;
           case PDSALoggingTypes.AuditTrackUpdate:
              mgr.LogAuditTrackUpdate(tableName, key, valueToLog);
              break;
           case PDSALoggingTypes.AuditTrackDelete:
              mgr.LogAuditTrackDelete(tableName, key, valueToLog);
              break;
        }
     }

     /// <summary>
     /// Method to log anything. You can also pass in your own Name/Value collection object
     /// </summary>
     /// <param name="valueToLog">The XML value to log</param>
     /// <param name="tableName">The table name</param>
     /// <param name="key">A unique key (usually the PK of the table)</param>
     /// <param name="logType">The Log Type to Create</param>
     /// <param name="nvc">A NameValueCollection Object</param>
     public static void Log(string valueToLog, string tableName, string key, PDSALoggingTypes logType, NameValueCollection nvc)
     {
        PDSALoggingManager mgr;

        // Get an instance of the Logging Manager
        mgr = AppLog.LogManager;

        // Add the passed in NVC values to the standard NVC
        nvc = PDSACollections.CombineNVCs(nvc, AppLog.BuildCommonNVC());

        switch (logType)
        {
           case PDSALoggingTypes.AuditTrackInsert:
              mgr.LogAuditTrackInsert(tableName, key, valueToLog);
              break;
           case PDSALoggingTypes.AuditTrackUpdate:
              mgr.LogAuditTrackUpdate(tableName, key, valueToLog);
              break;
           case PDSALoggingTypes.AuditTrackDelete:
              mgr.LogAuditTrackDelete(tableName, key, valueToLog);
              break;
        }
     }
     #endregion

     /// <summary>
     /// Add an Exception to the log
     /// </summary>
     /// <param name="ex">An exception</param>
     public static void Log(Exception ex)
     {
        NameValueCollection nvc;
        PDSALoggingManager mgr;

        // Get an instance of the Logging Manager
        mgr = AppLog.LogManager;

        // Grab Standard NVC Values for logging in this Application
        nvc = AppLog.BuildCommonNVC();

        // Log the exception
        mgr.LogException(ex, nvc);
     }

     /// <summary>
     /// Add an Exception to the log
     /// </summary>
     /// <param name="ex">An exception</param>
     /// <param name="nvc">A NameValueCollection Object</param>
     public static void Log(Exception ex, NameValueCollection nvc)
     {
        PDSALoggingManager mgr;

        // Get an instance of the Logging Manager
        mgr = AppLog.LogManager;

        // Add the passed in NVC values to the standard NVC
        nvc = PDSACollections.CombineNVCs(nvc, AppLog.BuildCommonNVC());

        // Log the exception
        mgr.LogException(ex, nvc);
     }

  }
}
