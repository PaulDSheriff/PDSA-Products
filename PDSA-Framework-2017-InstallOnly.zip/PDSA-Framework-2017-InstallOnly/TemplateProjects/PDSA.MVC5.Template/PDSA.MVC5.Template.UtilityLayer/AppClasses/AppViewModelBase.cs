﻿using System;

using PDSA.Framework;
using PDSA.Logging;
using PDSA.UI;
using PDSA.Web.MVC;

namespace PDSA.MVC5.Template.UtilityLayer
{
  [Serializable()]
  public class AppViewModelBase : PDSAFrameworkMVCViewModelBase
  {
    #region Constructor
    public AppViewModelBase()
      : base()
    {
    }
    #endregion

    #region Publish Method
    /// <summary>
    /// Logs an exception and then displays a generic message
    /// </summary>
    /// <param name="ex">An Exception object</param>
    public virtual void Publish(Exception ex)
    {
      PDSALoggingManager mgr = null;
      string message = string.Empty;

      try
      {
        mgr = new PDSALoggingManager();

        mgr.LogException(ex, PDSASettings.AllValues.Application.Entities.DefaultEntityId);

        if (PDSASettings.AllValues.Application.Website.Environment == PDSAEnvironmentType.Development)
        {
          message = "An error occurred while attempting to perform the last operation.  "
                  + "Details of the error have been recorded to the active log listeners. "
                  + "Here is an overview of the exception: "
                 + ex.ToString() + ex.Message + ex.StackTrace;
        }
        else
        {
          message = "An unexpected error occurred while attempting to perform the last operation.";
        }

        this.LastException = ex;
        this.LastExceptionMessage = message;
        this.Display(message);
      }
      catch (Exception exp)
      {
        message = "An error occurred trying to log the exception. Please contact your system administrator. "
                   + "Here is an overview of the exception: "
                  + exp.ToString() + exp.Message + exp.StackTrace; ;
      }
    }
    #endregion

    #region HandleExceptionMessages Method
    /// <summary>
    /// Sets an exception object into the LastException property of this ViewModel class
    /// </summary>
    /// <param name="ex">An exception object</param>
    protected override void HandleExceptionMessages(Exception ex)
    {
      base.HandleExceptionMessages(ex);

      // Call Exception Manager to publish exception
      AppLogExceptionManager.Log(ex);
    }

    /// <summary>
    /// Sets an exception message into the LastExceptionMessage property of this ViewModel class 
    /// </summary>
    /// <param name="message">The message to set</param>
    protected override void HandleExceptionMessages(string message)
    {
      base.HandleExceptionMessages(message);

      // Call Exception Manager to publish exception
      AppLogExceptionManager.Log(new Exception(message));
    }
    #endregion
  }
}
