﻿The classes in this folder are for you to use and extend as necessary for your applications.

AppCache - Call methods in this class to add items to a Cache. You may cache by user or by application. You may also specify a specific date/time to remove the data, or use a sliding expiration time.
  Ex: AppCache.Add("MyKey", "MyValue);

AppLogAuditTrackManager - Call methods in this class if you want to log any audit trail information
  Ex: Not generally called by you. The 'Manager' classes all handle the logging of Insert, Update and Delete statements for you.
AppLogCommon - This class creates an instance of the PDSA Logging Manager class. It also is where you might add any additional properties that you wish to log.
  Ex: You don't call this one directly. It is called from all the other AppLog* classes
AppLogDebugManager - Call methods in this class for 'debug' messages only. These messages are only reported when running in Debug mode in Visual Studio.
  Ex: AppLogDebugManager.Log("A Debug Entery To Log");
AppLogExceptionManager - This is a wrapper around the PDSA logging. Using this wrapper allows you to add on additional properties that you wish to log each time you record an exception
  Ex: AppLogExceptionManager.Log(ex);
AppLogInfoManager - Call methods in this class if you want to log any purely 'informational' messages.
  Ex: AppLogInfoManager.Log("A Value To Log");
AppLogUserTrackManager - Call methods in this class if you want to log any 'user tracking' messages.
  Ex: AppLogUserTrackManager.Login(User.Identity.Name);
  Ex: AppLogUserTrackManager.Logout(User.Identity.Name);
  Ex: AppLogUserTrackManager.UserVisit(User.Identity.Name, this.PageName);
AppLogWarningManager - Call methods in this class if you want to log any 'warning' messages.
  Ex: AppLogWarningManager.Log("A Warning to Log");

AppViewModelBase - All your View Models should inherit from this base class.