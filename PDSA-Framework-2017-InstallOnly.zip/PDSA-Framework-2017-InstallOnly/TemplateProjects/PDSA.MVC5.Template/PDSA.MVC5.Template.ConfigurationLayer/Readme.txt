﻿The classes in this folder are used by you in the development of your application.

AppSettings - Use this class to read in values from your Web.Config file.
            - You can also use this class for any "Global" variables that you want to keep around for the life of your application.

