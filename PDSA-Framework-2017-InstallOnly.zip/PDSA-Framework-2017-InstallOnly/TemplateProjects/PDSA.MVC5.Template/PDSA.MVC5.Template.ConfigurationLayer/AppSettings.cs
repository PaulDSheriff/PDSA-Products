﻿using System;

using PDSA.Common;
using PDSA.Configuration;
using PDSA.Framework;

namespace PDSA.MVC5.Template.ConfigurationLayer
{
  /// <summary>
  /// You may add additional properties to this class.
  /// Add properties to where you are storing your configuration settings.
  /// Then you add the same properties to this class.
  /// You could also use this class for just "Global" properties that are only valid while the application is running.
  /// </summary>
  public class AppSettings : PDSASettings
  {
    #region Private Variables
    private int _CustomerId = 0;
    private string _UserName = string.Empty;
    #endregion

    #region Static Instance Property
    private static AppSettings _Instance = null;

    /// <summary>
    /// Get/Set a specific instance of an AppSettings class
    /// </summary>
    public static AppSettings Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new AppSettings();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set User Name
    /// </summary>
    public string UserName
    {
      get { return _UserName; }
      set
      {
        if (_UserName != value)
        {
          _UserName = value;
        }
      }
    }
     
    /// <summary>
    /// Get/Set Customer ID
    /// </summary>
    public int CustomerId
    {
      get { return _CustomerId; }
      set
      {
        if (_CustomerId != value)
        {
          _CustomerId = value;
        }
      }
    }
    #endregion

    #region Load Method
    /// <summary>
    /// Call this method to load all your configuration settings for this application
    /// </summary>
    public override void Load()
    {
      PDSAConfigSettings settings;

      try
      {
        // Get all Settings
        settings = base.GetAllSettings();

        UserName = settings.GetByKey("UserName", "").Value;
        CustomerId = Convert.ToInt32(settings.GetByKey("CustomerId", "0").Value);
      }
      catch (Exception ex)
      {
        LastErrorMessage = ex.ToString();
      }
    }
    #endregion

    #region Save Method
    /// <summary>
    /// Save your application settings here
    /// </summary>
    public override void Save()
    {
      PDSAConfigSettings settings = new PDSAConfigSettings();

      try
      {
        settings.Add(new PDSAConfigSetting("UserName", UserName));
        settings.Add(new PDSAConfigSetting("CustomerId", CustomerId.ToString()));

        base.SaveAllSettings(settings);
      }
      catch (Exception ex)
      {
        LastErrorMessage = ex.ToString();
      }
    }
    #endregion
  }
}
