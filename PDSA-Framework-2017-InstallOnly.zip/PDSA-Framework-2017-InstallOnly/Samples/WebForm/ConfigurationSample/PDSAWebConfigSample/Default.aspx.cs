﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PDSA.Framework; 
using PDSA.Web;  

namespace PDSAWebConfigSample_CS
{
  public partial class _Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      ////string sTemp = PDSASettings.Application.CurrentConfiguration.AppSettings["CustomerId"];
      ////string connectionString = PDSASettings.Application.CurrentConfiguration.ConnectionStrings["SqlClient"];
      lblFrameworkVersion.Text = PDSASettings.AllValues.Application.Framework.Version;
      lblFrameworkLicenseKey.Text = PDSASettings.AllValues.Application.Framework.LicenseKey;
      lblGeneralApplicationId.Text = PDSASettings.AllValues.Application.General.ApplicationId.ToString();
      lblGeneralApplicationName.Text = PDSASettings.AllValues.Application.General.ApplicationName;
      lblGeneralApplicationType.Text = PDSASettings.AllValues.Application.General.ApplicationType;
      lblGeneralApplicationTitle.Text = PDSASettings.AllValues.Application.General.ApplicationTitle;
      lblGeneralAdminAuditTracking.Text = PDSASettings.AllValues.Application.General.AdminAuditTracking.ToString();
      lblMailSMTPServer.Text = PDSASettings.AllValues.Application.Mail.SmtpServer;
      lblMailUseSSL.Text = PDSASettings.AllValues.Application.Mail.UseSsl.ToString();
      lblMailNoReplyAddress.Text = PDSASettings.AllValues.Application.Mail.NoReplyAddress;
      lblEntitiesDefaultEntityId.Text = PDSASettings.AllValues.Application.Entities.DefaultEntityId.ToString();
      lblEntitiesMultipleEntities.Text = PDSASettings.AllValues.Application.Entities.MultipleEntities.ToString();
      lblEntitiesDisplayName.Text = PDSASettings.AllValues.Application.Entities.DisplayName;
      lblEntitiesDisplayNamePlural.Text = PDSASettings.AllValues.Application.Entities.DisplayNamePlural;
      lblWebsiteSiteName.Text = PDSASettings.AllValues.Application.Website.SiteName;
      lblWebsiteChangePasswordUrl.Text = PDSASettings.AllValues.Application.Website.ChangePasswordUrl;
      lblWebsiteForgotPasswordUrl.Text = PDSASettings.AllValues.Application.Website.ForgotPasswordUrl;
      lblWebsiteMessagePageUrl.Text = PDSASettings.AllValues.Application.Website.MessagePageUrl;
      lblWebsiteReturnPageUrl.Text = PDSASettings.AllValues.Application.Website.ReturnPageUrl;
      lblWebsiteEnvironment.Text = PDSASettings.AllValues.Application.Website.Environment.ToString();
      lblLoginShowUserList.Text = PDSASettings.AllValues.Security.Login.ShowUserList.ToString();
      lblLoginRememberMe.Text = PDSASettings.AllValues.Security.Login.RememberMe.ToString();
      lblLoginForgotPassword.Text = PDSASettings.AllValues.Security.Login.ForgotPassword.ToString();
      lblLoginTrackAttempts.Text = PDSASettings.AllValues.Security.Login.TrackAttempts.ToString();
      lblLoginMaxAttempts.Text = PDSASettings.AllValues.Security.Login.MaxAttempts.ToString();
      lblLoginShowEntityList.Text = PDSASettings.AllValues.Security.Login.ShowEntityList.ToString();
      lblLoginEntitySelectText.Text = PDSASettings.AllValues.Security.Login.EntitySelectText.ToString();
      lblLoginIsEntitySelectOneDisplayed.Text = PDSASettings.AllValues.Security.Login.EntitySelectOneText;
      lblLoginEntitySelectOneText.Text = PDSASettings.AllValues.Security.Login.EntitySelectOneText;
      lblAuthenticationType.Text = PDSASettings.AllValues.Security.Authentication.AuthenticationType.ToString();
      lblAuthenticationTimeout.Text = PDSASettings.AllValues.Security.Authentication.Timeout.ToString();
      lblAuthenticationInvalidCredentialsMessage.Text = PDSASettings.AllValues.Security.Authentication.InvalidCredentialsMessage;
      lblAuthenticationUserTracking.Text = PDSASettings.AllValues.Security.Authentication.UserTracking.ToString();
      lblAuthenticationCookieExpiration.Text = PDSASettings.AllValues.Security.Authentication.CookieExpiration.ToString();
      lblAuthorizationUsePagePermissions.Text = PDSASettings.AllValues.Security.Authorization.UsePagePermissions.ToString();
      lblAuthorizationUseControlPermissions.Text = PDSASettings.AllValues.Security.Authorization.UseControlPermissions.ToString();
      lblAuthorizationUseControlPermissions.Text = PDSASettings.AllValues.Security.Authorization.UseControlPermissions.ToString();
      lblUserAccountMinLength.Text = PDSASettings.AllValues.Security.UserAccount.MinLength.ToString();
      lblUserAccountMaxLength.Text = PDSASettings.AllValues.Security.UserAccount.MaxLength.ToString();
      lblUserAccountIsLockoutEnabled.Text = PDSASettings.AllValues.Security.UserAccount.IsLockoutEnabled.ToString();
      lblUserAccountMinutesToLockout.Text = PDSASettings.AllValues.Security.UserAccount.MinutesToLockout.ToString();
      lblUserAccountUseEmail.Text = PDSASettings.AllValues.Security.UserAccount.UseEmail.ToString();
      lblUserAccountRequireChangeNewPassword.Text = PDSASettings.AllValues.Security.UserAccount.RequireChangeNewPassword.ToString();
      lblUserAccountRequireQuestionAndAnswer.Text = PDSASettings.AllValues.Security.UserAccount.RequireQuestionAndAnswer.ToString();
      lblUserAccountSendPasswordEmail.Text = PDSASettings.AllValues.Security.UserAccount.SendPasswordEmail.ToString();
      lblUserAccountUniqueEmail.Text = PDSASettings.AllValues.Security.UserAccount.UniqueEmail.ToString();
      lblUserPasswordIsRequired.Text = PDSASettings.AllValues.Security.UserPassword.IsRequired.ToString();
      lblUserPasswordHistory.Text = PDSASettings.AllValues.Security.UserPassword.History.ToString();
      lblUserPasswordMinLength.Text = PDSASettings.AllValues.Security.UserPassword.MinLength.ToString();
      lblUserPasswordMaxLength.Text = PDSASettings.AllValues.Security.UserPassword.MaxLength.ToString();
      lblUserPasswordMinSpecialCharacters.Text = PDSASettings.AllValues.Security.UserPassword.MinSpecialCharacters.ToString();
      lblUserPasswordResetInterval.Text = PDSASettings.AllValues.Security.UserPassword.ResetInterval.ToString();
      lblUserPasswordRegularExpression.Text = PDSASettings.AllValues.Security.UserPassword.RegularExpression.ToString();
      lblUserPasswordEncryptionMethod.Text = PDSASettings.AllValues.Security.UserPassword.EncryptionMethod.ToString();
      lblUserPasswordEncryptionProvider.Text = PDSASettings.AllValues.Security.UserPassword.EncryptionProvider;
    }
  }
}