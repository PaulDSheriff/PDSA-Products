﻿PDSA Web Config Sample
----------------------------------------
This sample shows how to retrieve PDSA configuration settings from the Web.Config file
