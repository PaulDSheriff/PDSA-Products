﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PDSA.ReferenceTable.Web;
using PDSA.Web;
using PDSA.Framework;

namespace PDSAReferenceTableWebSample
{
   public partial class frmReferenceTableOverloads : System.Web.UI.Page
   {
      private PDSARowState rowState;
      private PDSASortMode sortMode;
      private PDSADisplayMode displayOrder;

      protected void Page_Load(object sender, EventArgs e)
      {

      }
      protected void btnGetReferenceTables_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindTables(ddlTablesList, 1, "[Select Table]", PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
      }

      protected void btnBindValuesBasic_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb referenceTable = new PDSAReferenceTableWeb();
         referenceTable.BindValues(ddlReferenceTableValues, txtReferenceTable.Text);
         UpdateReferenceTableTextBoxes();
      }

      protected void ddlTablesList_SelectedIndexChanged(object sender, EventArgs e)
      {
         PDSADropDown ddl = new PDSADropDown();
         PDSAReferenceTableWeb referenceTable = new PDSAReferenceTableWeb();
         referenceTable.BindValues(ddlReferenceTableValues, ddl.GetSelectedText(ddlTablesList));
         txtReferenceTable.Text = ddl.GetSelectedText(ddlTablesList);
         UpdateReferenceTableTextBoxes();
      }

      protected void UpdateReferenceTableTextBoxes()
      {
         txtReferenceTableOverload1.Text = txtReferenceTable.Text;
         txtReferenceTableOverload2.Text = txtReferenceTable.Text;
         txtReferenceTableOverload3.Text = txtReferenceTable.Text;
         txtReferenceTableOverload4.Text = txtReferenceTable.Text;
         txtReferenceTableOverload5.Text = txtReferenceTable.Text;
         txtReferenceTableOverload6.Text = txtReferenceTable.Text;
      }

      protected void btnBindValuesOverLoad1_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad1, txtReferenceTableOverload1.Text,
            txtSelectValueOverLoad1.Text == string.Empty ? 0 : Convert.ToInt32(txtSelectValueOverLoad1.Text), 
            txtPromptTextOverload1.Text);
      }

      protected void btnBindValuesOverLoad2_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad2, txtReferenceTableOverload2.Text, txtSelectValueOverLoad2.Text,
            txtPromptTextOverload2.Text);
      }

      protected void btnBindValuesOverLoad3_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad3, txtReferenceTableOverload3.Text,
            txtSelectValueOverLoad3.Text == string.Empty ? 0 : Convert.ToInt32(txtSelectValueOverLoad3.Text),
            txtPromptTextOverload3.Text, txtSystemKeyOverload3.Text);
      }

      protected void btnBindValuesOverLoad4_Click(object sender, EventArgs e)
      {
         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad4, txtReferenceTableOverload4.Text, txtSelectValueOverLoad4.Text,
            txtPromptTextOverload4.Text, txtSystemKeyOverload4.Text);
      }

      protected void btnBindValuesOverLoad5_Click(object sender, EventArgs e)
      {
         rowState = (PDSARowState)Enum.Parse(typeof(PDSARowState), rblStateOverload5.Text);
         sortMode = (PDSASortMode)Enum.Parse(typeof(PDSASortMode), rblSortModeOverload5.Text);
         displayOrder = (PDSADisplayMode)Enum.Parse(typeof(PDSADisplayMode), DisplayModeOverload5.Text);

         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad5, txtReferenceTableOverload5.Text,
            txtSelectValueOverLoad5.Text == string.Empty ? 0 : Convert.ToInt32(txtSelectValueOverLoad5.Text),
            txtPromptTextOverload5.Text, txtSystemKeyOverload5.Text, rowState, sortMode, displayOrder);
      }
      protected void btnBindValuesOverLoad6_Click(object sender, EventArgs e)
      {
         rowState = (PDSARowState)Enum.Parse(typeof(PDSARowState), rblStateOverload6.Text);
         sortMode = (PDSASortMode)Enum.Parse(typeof(PDSASortMode), rblSortModeOverload6.Text);
         displayOrder = (PDSADisplayMode)Enum.Parse(typeof(PDSADisplayMode), DisplayModeOverload6.Text);

         PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
         rtv.BindValues(ddlBindValuesOverLoad6, txtReferenceTableOverload6.Text, txtSelectValueOverLoad6.Text,
            txtPromptTextOverload6.Text, txtSystemKeyOverload6.Text, rowState, sortMode, displayOrder, PDSASettings.AllValues.Application.General.ApplicationId);
      }

      protected override void OnError(EventArgs e)
      {
         base.OnError(e);

         Exception ex = HttpContext.Current.Server.GetLastError();

         lblPageError.Text = ex.Message;
      }
   }
}