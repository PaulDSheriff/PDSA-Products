﻿using System;
using System.Web.UI.WebControls;
using System.Collections.Generic;

using PDSA.Web;
using PDSA.Framework;
using PDSA.Framework.DataLayer;
using PDSA.Framework.EntityLayer;
using PDSA.ReferenceTable.Web;
using PDSA.Cache;
using PDSA.ReferenceTable;

   
namespace PDSAReferenceTableWebSample
{
  public partial class frmReferenceTable : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnGetReferenceTables_Click(object sender, EventArgs e)
    {
      PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
      rtv.BindTables(ddlTablesList, 1, "[Select Table]", PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
    }

    protected void btnGetReferenceTableValues_Click(object sender, EventArgs e)
    {
      PDSAReferenceTableWeb referenceTable = new PDSAReferenceTableWeb();
      referenceTable.BindValues(ddlReferenceTableValues, txtReferenceTable.Text);
    }

    protected void ddlTablesList_SelectedIndexChanged(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb referenceTable = new PDSAReferenceTableWeb();
      string tableName;

      tableName = ddl.GetSelectedText(ddlTablesList);

      referenceTable.BindValues(ddlReferenceTableValues, tableName);
      txtReferenceTable.Text = tableName;
    }

    protected void btnGetComplete_Click(object sender, EventArgs e)
    {
      PDSAReferenceTableWeb rtw = new PDSAReferenceTableWeb();
      ddlComplete.DataSource = rtw.GetComplete(txtReferenceTable.Text, 1, PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
      ddlComplete.DataTextField = "Id";
      ddlComplete.DataBind();
    }

    protected void btnGetDisplay_Click(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb rtw = new PDSAReferenceTableWeb();
      txtDisplay.Text = rtw.GetDisplay(txtReferenceTable.Text, 1, Convert.ToInt32(ddl.GetSelectedValue(ddlReferenceTableValues)), PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
    }

    protected void btnGetDescription_Click(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb rtw = new PDSAReferenceTableWeb();
      txtDescription.Text = rtw.GetDescription(txtReferenceTable.Text, 1, Convert.ToInt32(ddl.GetSelectedValue(ddlReferenceTableValues)), PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
    }

    protected void btnGetCode_Click(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb rtw = new PDSAReferenceTableWeb();
      txtCode.Text = rtw.GetCode(txtReferenceTable.Text, 1, Convert.ToInt32(ddl.GetSelectedValue(ddlReferenceTableValues)), PDSASettings.AllValues.Application.General.IsMultiLingualProperty);

    }

    protected void btnGetDefault_Click(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb rtw = new PDSAReferenceTableWeb();
      txtDefault.Text = rtw.GetDefault(txtReferenceTable.Text, 1, PDSASettings.AllValues.Application.General.IsMultiLingualProperty).ToString();

    }

    protected void btnGetGridViewList_Click(object sender, EventArgs e)
    {
      PDSADropDown ddl = new PDSADropDown();
      PDSAReferenceTableWeb rtv = new PDSAReferenceTableWeb();
      rtv.BindValues(mGridView, txtReferenceTable.Text, 1, PDSASettings.AllValues.Application.General.IsMultiLingualProperty);
    }
  }
}