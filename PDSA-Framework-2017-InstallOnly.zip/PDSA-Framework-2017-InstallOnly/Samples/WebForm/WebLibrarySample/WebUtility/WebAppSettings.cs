﻿using System;
using System.Data;

using PDSA.Web;

namespace WebUtility
{
  [Serializable()]
  public class WebAppSettings
  {
    public static WebAppSettings Settings = new WebAppSettings();

    public string DefaultStateCode
    {
      get { return PDSAWebCache.GetApplicationVar("DefaultStateCode"); }
      set { PDSAWebCache.SetApplicationVar("DefaultStateCode", value); }
    }

    public DataSet ProductDataSet
    {
      get { return (DataSet)PDSAWebCache.GetCacheVarAsObject("ProductDataSet"); }
      set { PDSAWebCache.SetCacheVarWithSlidingTimeout("ProductDataSet", value, 30); }
    }
  }
}
