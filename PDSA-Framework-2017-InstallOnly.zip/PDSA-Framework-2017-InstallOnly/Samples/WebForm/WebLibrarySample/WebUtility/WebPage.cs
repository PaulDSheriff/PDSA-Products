﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PDSA.Web;
using PDSA.Framework.EntityLayer;
using System.Security.Principal;
using System.Web;
using PDSA.Security;

namespace WebUtility
{
   public class WebPage : PDSAPage
   {
      private WebUserSession _userSession = null;

      protected WebUserSession UserSession
      {
         get
         {
            if (_userSession == null)
            {
               _userSession = new WebUserSession();
            }
            return _userSession;
         }
      }

      // This OnInit is used only for samples in this website 

      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);

         // Set up a security principal for use when the page validates session
         pdsaRoleCollection roles = new pdsaRoleCollection();
         roles.Add(new pdsaRole { RoleId = 1, RoleName = "User" });

         pdsaPermissionCollection permissions = new pdsaPermissionCollection();
         permissions.Add(new pdsaPermission { PermissionId = 2, PermissionName = "Some Permission" });
         // Uncomment the next line to give the user permission to the permission check example
         // permissions.Add(new pdsaPermission { PermissionId = 1, PermissionName = "No Permission Necessary" });

         GenericIdentity identity = new GenericIdentity("1");
         HttpContext.Current.User = new PDSAPrincipal(identity, roles, permissions);

         this.IsPagePermissionEnabled = false;
         this.IsMessagePage = false;
         // this.IsSystemPage = true;
         this.IsUserTrackingEnabled = false;
         
      }
   }
}
