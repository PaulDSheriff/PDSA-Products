﻿using System;
using System.Web;
using PDSA.Web;

namespace WebUtility
{
   /// <summary>
   /// Provides strongly-typed access to session variables.
   /// </summary>
   [Serializable]
   public class WebUserSession : PDSAWebSession
   {
      public WebUserSession() { }

      public int CustomerId
      {
         get { return this.GetInteger("CustomerId"); }
         set { this["CustomerId"] = value; }
      }

      public string MyFirstName
      {
         get { return this.GetString("MyFirstName"); }
         set { this["MyFirstName"] = value; }
      }
   }
}
