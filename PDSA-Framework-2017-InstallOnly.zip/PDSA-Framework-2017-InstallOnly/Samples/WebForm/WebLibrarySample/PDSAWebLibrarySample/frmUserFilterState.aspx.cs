﻿using System;
using System.Web.UI;
using PDSA.Web;
using WebUtility;

namespace TemplateProject.Website
{
  public partial class frmUserFilterState : GenericPage
  {
    PDSAUserFilterState _filterState;

    private void InitSession()
    {
      PDSAWebSession session = new PDSAWebSession();
      session.EntityId = 1;
      session.ApplicationId = 1;
      session.UserId = 94;
    }

    private void BindEventHandlers()
    {
      // Bind the event handlers (optional)
      _filterState = new PDSAUserFilterState();
      _filterState.BeforeSaveState += new PDSAFilterStateEventHandler(_filterState_BeforeSaveState);
      _filterState.AfterSaveState += new PDSAFilterStateEventHandler(_filterState_AfterSaveState);
      _filterState.BeforeRestoreState += new PDSAFilterStateEventHandler(_filterState_BeforeRestoreState);
      _filterState.AfterRestoreState += new PDSAFilterStateEventHandler(_filterState_AfterRestoreState);
      _filterState.SaveUnknownControlType += new PDSAFilterStateEventHandler(_filterState_SaveUnknownControlType);
      _filterState.RestoreUnknownControlType += new PDSAFilterStateEventHandler(_filterState_RestoreUnknownControlType);
    }

    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
      this.InitSession();
      this.BindEventHandlers();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      // when the page loads for the first time, restore the previous state
      if (!this.IsPostBack)
      {
        try
        {
          // _filterState.Restore([Panel ID], [Filter Set Name], [IDs to Exclude], [Restore Default]);
          _filterState.Restore(pnlFilters, "frmUserFilterState", string.Empty, false);
        }
        catch (Exception ex)
        {
          lblMessage.Text = ex.Message;
        }
      }
    }

    void _filterState_RestoreUnknownControlType(object sender, PDSAUserFilterStateEventArgs e)
    {
      if (e.ControlId == "mHiddenField")
      {
        mHiddenField.Value = e.Value;
      }
    }

    void _filterState_SaveUnknownControlType(object sender, PDSAUserFilterStateEventArgs e)
    {
      // if a control is not a textbox, checkbox or drop-down, you can get the state and  
      // set the value so that it is stored
      if (e.ControlId == "mHiddenField")
      {
        e.Value = mHiddenField.Value;
      }
      else
      {
        e.Cancel = true;
      }
    }

    void _filterState_AfterSaveState(object sender, PDSAUserFilterStateEventArgs e)
    {
      // allows you to modify the value of a control after it is saved
    }

    void _filterState_BeforeSaveState(object sender, PDSAUserFilterStateEventArgs e)
    {
      // allows you to modify the state of a control before saving it
    }

    void _filterState_AfterRestoreState(object sender, PDSAUserFilterStateEventArgs e)
    {
      // allows you to modify the state of a control after it has been restored 
    }

    void _filterState_BeforeRestoreState(object sender, PDSAUserFilterStateEventArgs e)
    {
      // allows you to modify the stored value of a control before it is restored
    }

    protected override void OnPreRender(EventArgs e)
    {
      base.OnPreRender(e);

      try
      {
        // each time the page returns to the user, save the current state
        // _filterState.Save([Panel ID], [Filter Set Name], [IDs to Exclude], [Default State]);
        _filterState.Save(pnlFilters, "frmUserFilterState", string.Empty, string.Empty);
      }
      catch (Exception ex)
      {
        lblMessage.Text = ex.Message;
      }
    }
  }
}