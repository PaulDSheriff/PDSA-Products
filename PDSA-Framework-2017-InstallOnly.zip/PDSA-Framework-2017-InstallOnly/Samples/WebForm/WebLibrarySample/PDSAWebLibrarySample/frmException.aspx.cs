﻿using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using PDSA.Web;

public partial class frmException : PDSAPage
{
  protected void btnSimple_Click(object sender, EventArgs e)
  {
    PDSAExceptionManager.Publish(new ArgumentNullException("This is a sample exception"));
  }

  protected void btnPublishNameValue_Click(object sender, EventArgs e)
  {
    PDSAExceptionManager.Publish(new ArgumentNullException("This is a sample exception"), CreateCollectionItems());
  }

  protected void btnPublishWithStateBag_Click(object sender, EventArgs e)
  {
    SetStateBagInfo();

    PDSAExceptionManager.Publish(new ArgumentNullException("This is a sample exception"), CreateCollectionItems(), this.ViewState);
  }

  protected void btnPublishNoNVC_Click(object sender, EventArgs e)
  {
    SetStateBagInfo();

    PDSAExceptionManager.Publish(new ArgumentNullException("This is a sample exception"), null, this.ViewState);
  }
  
  protected void btnPublishJustBag_Click(object sender, EventArgs e)
  {
    SetStateBagInfo();

    PDSAExceptionManager.Publish(new ArgumentNullException("This is a sample exception"), this.ViewState);
  }

  #region Support Methods
  private void SetStateBagInfo()
  {
    ViewState["StateCode"] = "CA";
    ViewState["Customer"] = "Dana Island Yachts";
    base.PageMode = PDSAPageMode.Insert;
    base.PrimaryKey = 10;
    base.PrimaryKeyAsString = "20";
    base.ConcurrencyNumber = 3;
  }

  private NameValueCollection CreateCollectionItems()
  {
    NameValueCollection nvc = new NameValueCollection();

    nvc.Add("CustomerID", "2032");
    nvc.Add("CustomerName", "Dana Island Yachts");

    return nvc;
  }
  #endregion
}