﻿using System;
using PDSA.Common;
using PDSA.Framework;
using PDSA.Web;
using WebUtility;

namespace PDSAWebLibrarySample.Public
{
   public partial class frmMessage : WebPage
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         this.IsMessagePage = true;
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         this.ProcessQueryString();
         PDSAWebMessage message = this.UserSession.WebMessage;
         PDSASystemInfo si = new PDSASystemInfo();
         litInfo.Text = message.Message;
      }

      private void ProcessQueryString()
      {
         PDSAWebMessage webMessage;
         PDSASystemMessageType type = PDSASystemMessageType.Custom;
         string msg = string.Empty;
         string title = string.Empty;
         string value;

         if (Request.QueryString.Count == 0) return;

         foreach (string key in Request.QueryString.Keys)
         {
            value = Request.QueryString[key];

            switch (key)
            {
               case "type":
                  Enum.TryParse<PDSASystemMessageType>(value, out type);
                  break;
               case "msg":
                  msg = value;
                  break;
               case "title":
                  title = value;
                  break;
               // add any more query string options here...
               default:
                  break;
            }
         }

         webMessage = new PDSAWebMessage(type);

         if (msg.Length > 0)
            webMessage.Message = msg;

         if (title.Length > 0)
            webMessage.Title = title;

         this.UserSession.WebMessage = webMessage;
      }

   }
}