﻿using System;
using System.Runtime.Serialization;
using WebUtility;

namespace PDSAWebLibrarySample
{
   public partial class frmViewState : WebPage
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         // ViewState storage defaults to "Normal" --
         // Try each of the different approaches: File, Session, Cache, Normal
         // this.ViewStateStorage.Location = PDSAViewStateMode.File;
      }

      // Put some items into ViewState
      protected void btnInitViewState_Click(object sender, EventArgs e)
      {
         TestViewStateCustomer customer = 
            new TestViewStateCustomer { CustomerId = 1, CompanyName = "Test Customer" };

         ViewState["StateCode"] = "CA";
         ViewState["Customer"] = "Dana Island Yachts";
         ViewState["CustomerObject"] = customer;
         ViewState["EnumItem"] = TestViewStateEnum.ItemTwo;
      }

      // Get the current 'state' of ViewState as a string
      protected void btnGetAll_Click(object sender, EventArgs e)
      {
         lblInfo.Text = this.ViewStateStorage.GetAllVariables("<br />");
      }

      // Clear ViewState
      protected void btnClear_Click(object sender, EventArgs e)
      {
         this.ViewStateStorage.Clear();
         lblInfo.Text = string.Empty;
      }
   }

   [DataContract, Serializable]
   public class TestViewStateCustomer
   {
      [DataMember]
      public int CustomerId { get; set; }
      
      [DataMember]
      public string CompanyName { get; set; }
   }

   public enum TestViewStateEnum
   {
      ItemOne,
      ItemTwo
   }
}