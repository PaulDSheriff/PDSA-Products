﻿using System;
using WebUtility;

namespace PDSAWebLibrarySample
{
   public partial class frmSecurityControls : WebPage
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         this.IsControlSecurityEnabled = true;
      }     

      // No other code required!
   }
}
