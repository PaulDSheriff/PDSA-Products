﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using PDSA.Web;
using WebUtility;

namespace PDSAWebLibrarySample
{
   public partial class frmDropDown : WebPage
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Do nothing
      }

      private object GetProducts()
      {
         DataSet products = new DataSet();
         products.ReadXml(Server.MapPath("~/Xml/Product.xml"), XmlReadMode.InferSchema);
         DataTable result = products.Tables[0];
         return result;
      }

      protected void btnBindDropDown_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.Bind("ProductName", "ProductId", this.GetProducts());
      }

      protected void btnInsertText_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.Insert(txtTextToInsert.Text);
      }

      protected void btnInsertItem_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.Insert(txtItemValue.Text, txtItemKey.Text);
      }

      protected void btnAddItem_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.Add(txtAddItemValue.Text, txtAddItemKey.Text);
      }

      protected void btnFindText_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         ListItem item = adapter.FindText(txtTextToFind.Text);
         if (item != null)
         {
            lblFindTextResult.Text = string.Format("Item value is '{0}'.", item.Value);
         }
         else
         {
            lblFindTextResult.Text = string.Format("'{0}' was not found.", txtTextToFind.Text);
         }
      }

      protected void btnFindValue_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         ListItem item = adapter.FindValue(txtValueToFind.Text);
         if (item != null)
         {
            lblFindValueResult.Text = string.Format("Item text is '{0}'.", item.Text);
         }
         else
         {
            lblFindValueResult.Text = string.Format("'{0}' was not found.", txtTextToFind.Text);
         }
      }

      protected void btnGetSelectedValue_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         int value = adapter.GetSelectedValue();
         if (value > -1)
         {
            lblGetSelectedValueResult.Text = string.Format("Selected value is '{0}'.", value);
         }
         else
         {
            lblGetSelectedValueResult.Text = string.Format("No selected item.");
         }
      }

      protected void btnGetSelectedText_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         string value = adapter.GetSelectedText();
         if (value != string.Empty)
         {
            lblGetSelectedTextResult.Text = string.Format("Selected text is '{0}'.", value);
         }
         else
         {
            lblGetSelectedTextResult.Text = string.Format("No selected item.");
         }
      }

      protected void btnSelectByValue_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.SelectByValue(txtValueToSelect.Text);
      }

      protected void btnSelectByText_Click(object sender, EventArgs e)
      {
         PDSADropDown adapter = new PDSADropDown(ddlBindDropDown);
         adapter.SelectByText(txtTextToSelect.Text);
      }
   }
}