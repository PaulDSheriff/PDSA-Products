﻿using System;
using PDSA.Web;
using WebUtility;

namespace PDSAWebLibrarySample
{
    public partial class frmExceptionHandling : WebPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // Nothing to do
        }

        // handle an exception in a event handler

        protected void btnSample1_Click(object sender, EventArgs e)
        {
            try
            {
                int x = 1;
                int y = 0;
                int result = x / y;
            }
            catch (Exception ex)
            {
                PDSAExceptionManager.Publish(ex);
            }
        }

        // cause an exception, and it should go the message display page

        protected void btnSample2_Click(object sender, EventArgs e)
        {
            int x = 1;
            int y = 0;
            int result = x / y;
        }

  
        // look at the other methods. cook up samples.

    }
}