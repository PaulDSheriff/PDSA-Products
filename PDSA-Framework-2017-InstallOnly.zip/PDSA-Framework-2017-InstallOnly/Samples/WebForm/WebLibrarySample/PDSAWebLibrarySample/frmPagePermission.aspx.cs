﻿using System;
using System.Web;
using PDSA.Framework.EntityLayer;
using PDSA.Security;
using WebUtility;

namespace PDSAWebLibrarySample
{
   public partial class frmPagePermission : WebPage
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);

         // IsPagePermissionEnabled is set to true by default.
         // Set it to false here to bypass checking permission.
         this.IsPagePermissionEnabled = true;

         // Go to the WebPage OnInit method and uncomment the add a permission line
         // to grant the test user permission to this page.
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to do
      }

      protected override void  OnPreRender(EventArgs e)
      {
 	       base.OnPreRender(e);
          System.Diagnostics.Debug.WriteLine(
             "Should not hit this breakpoint when the user does not have permission...");
      }
   }
}