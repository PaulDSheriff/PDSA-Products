﻿using System;
using WebUtility;
using PDSA.Framework;
using PDSA.Logging;
  
namespace PDSAWebLibrarySample
{
   public partial class frmPageInfo : WebPage
   {
      protected void Page_Load(object sender, EventArgs e)
      {
        string pageProps;

         if (!this.IsPostBack)
         {
            pageProps = this.GetPageProperties("<br />");

            litInfo.Text = pageProps;
         }
      }
   }
}