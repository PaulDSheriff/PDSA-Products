﻿using System;
using WebUtility;
using PDSA.Framework.DataLayer;
using PDSA.DataLayer;
using System.Data;
using PDSA.Framework.EntityLayer;

namespace PDSAWebLibrarySample
{
   public partial class frmUserTrack : WebPage
   {
      private int ExecuteScalar(string sql)
      {
         int result = -1;
         PDSADataManager manager = new PDSADataManager();
         PDSADataProvider provider = manager.Provider;
         IDbConnection cnn = provider.CreateConnection(true);
         result = (int)provider.ExecuteScalar(sql, cnn);
         return result;
      }
      
      private int GetLogId()
      {
         string sql = "SELECT TOP 1 LogId FROM PDSA.pdsaLog ORDER BY InsertDate DESC";
         return this.ExecuteScalar(sql);
      }
      
      // User tracking is controlled by the userTracking="true/false" setting 
      // in the PDSASecurityConfiguration section of the web.config file 

      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         
         // override the web.config setting by setting the property to true
         // or false as required for your page
         this.IsUserTrackingEnabled = true;
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         pdsaLogManager manager = new pdsaLogManager();
         pdsaLog log = manager.Select(this.GetLogId());
         litInfo.Text = log.LogInfo.Replace(Environment.NewLine, "<br />");
      }
   }
}