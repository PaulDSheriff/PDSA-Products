﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebUtility;
using PDSA.Web;

namespace PDSAWebLibrarySample
{
   public partial class frmPageCache : WebPage
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);

         // Try each of the PDSAPageCacheMode options

         this.PageCacheMode = PDSAPageCacheMode.NoCache;
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to do
      }
   }
}