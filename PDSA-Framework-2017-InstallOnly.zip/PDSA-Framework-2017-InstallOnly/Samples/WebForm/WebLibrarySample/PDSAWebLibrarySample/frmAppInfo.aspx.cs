﻿using System;
using System.Web.UI;
using PDSA.Web;
using WebUtility;

namespace PDSAWebLibrarySample
{
   public partial class frmAppInfo : WebPage
   {
      protected void btnAppInfo_Click(object sender, EventArgs e)
      {
         PDSAWebApplication application = new PDSAWebApplication();
         lblInfo.Text = application.GetAllVariables("<br />");
      }

      protected void btnSystemInfo_Click(object sender, EventArgs e)
      {
         PDSA.Common.PDSASystemInfo ps = new PDSA.Common.PDSASystemInfo();
         lblInfo.Text = ps.GetAllSystemInfo("<br />");
      }

      protected void btnBrowserInfo_Click(object sender, EventArgs e)
      {
         PDSAUserAgent browser = new PDSAUserAgent();
         lblInfo.Text = browser.BuildUserAgentText("<br />", PDSAUserAgentTextMode.Long);
      }
   }
}