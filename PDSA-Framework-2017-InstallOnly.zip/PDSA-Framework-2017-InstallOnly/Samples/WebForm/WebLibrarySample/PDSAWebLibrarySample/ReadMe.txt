﻿PDSA Web Library Namespace Sample
--------------------------------------------------------------------------------
This sample contains the following examples: pageinfo, drop downs, filter state, exception handling, view state,
session, application info, security controls, page permission, page cache and user tracking.

Before running this sample, you must do the following:

1. Create a database named PDSAFramework500
2. Run [InstallFiles]\SqlScripts\SqlServer_PDSAFramework500.sql in the new database.
3. Run [InstallFiles]\SqlScripts\CreateFrameworkData.sql in the new database.
4. Adjust the ConnectionString as appropriate in the Web.Config to point to this database.
5. Set the start page as Default.aspx and run the sample

6. In the web.config under PDSASecurityConfiguration make sure the <authentication .../> looks like the following:
    <authentication type="ActiveDirectory"
                    timeout="20"
                    invalidCredentialsMessage="Invalid login and/or password."
                    userTracking="true"
                    trackLoginOut="false"
                    cookieExpiration="30" />
7. In the web.config under PDSAApplicationConfiguration make sure the messagePageUrl is set to "~/frmMessage.aspx" as shown below:
    <website siteName="PDSA.ASPNET.Template"
             isOffline="false"
             changePasswordUrl="~/Security/PDSAChangePassword.aspx"
             forgotPasswordUrl="~/Public/PDSAForgotPassword.aspx"
             messagePageUrl="~/frmMessage.aspx"
             returnPageUrl="~/Main/Default.aspx"
             environment="Development"
             useHttps="false" />