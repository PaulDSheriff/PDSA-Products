﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using PDSA.Web;
using WebUtility;
using PDSA.Framework;

namespace PDSAWebLibrarySample
{
   public class Global : PDSAHttpApplication
   {
      protected void Session_Start(object sender, EventArgs e)
      {
         WebUserSession session = new WebUserSession();
         session.ApplicationId = this.ApplicationId;
         this.SessionCount++;
      }

      protected void Session_End(object sender, EventArgs e)
      {
         this.SessionCount--;
         if (Application[Session.SessionID] != null)
         {
            // PDSAWebUtility.RecordLogOutDate(Convert.ToInt32(Application[Session.SessionID]));
            Application[Session.SessionID] = null;
         }
      }

      void Application_Start(object sender, EventArgs e)
      {
         bool success = false;
         this.SessionCount = 0;
         this.ApplicationId = PDSASettings.AllValues.Application.General.ApplicationId;

         // Check PDSASettings are correct
         try
         {
            // Attempt to access a config variable will cause the configuration system 
            // to load the settings and throw an exception if something is wrong.
            if (!string.IsNullOrEmpty(PDSASettings.AllValues.Application.General.ApplicationTitle))
            {
               success = true;
            }
         }
         catch (Exception ex)
         {
            PDSAWebNavigation.GoTo.ConfigurationErrorPage(ex, PDSASystemMessageType.PDSAConfiguration);
         }

         // Check whether your custom configuration variables are correct
         if (success)
         {
            try
            {
               //if (WebAppConfig.CustomerId >= -1)
               //{
               //   success = true;
               //}
            }
            catch (Exception ex)
            {
               PDSAWebNavigation.GoTo.ConfigurationErrorPage(ex, PDSASystemMessageType.CustomConfiguration);
            }
         }

         if (success)
         {
            // Do your additional custom application start processing here
         }
      }

      void Application_End(object sender, EventArgs e)
      {
         this.SessionCount = 0;
      }

      void Application_Error(object sender, EventArgs e)
      {
         // An error has occured, store the exception and navigate
         PDSAExceptionManager.HandleGlobalException();
      }
   }
}
