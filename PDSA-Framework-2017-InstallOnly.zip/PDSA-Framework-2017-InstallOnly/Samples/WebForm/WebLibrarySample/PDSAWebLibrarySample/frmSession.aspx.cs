﻿using System;
using System.Web;
using PDSA.Framework.EntityLayer;
using PDSA.Security;
using WebUtility;
using System.Security.Principal;

namespace PDSAWebLibrarySample
{
   public partial class frmSession : WebPage
   {     
      protected void btnInitVariables_Click(object sender, EventArgs e)
      {
         Session["StateCode"] = "CA";
         this.UserSession.CustomerId = 12;
         this.UserSession.MyFirstName = "Paul";
      }

      protected void btnGetVariables_Click(object sender, EventArgs e)
      {
         lblInfo.Text = this.UserSession.GetAllVariables("<br />");
         // lblInfo.Text = HttpContext.Current.Server.HtmlEncode(this.UserSession.GetAllVariablesAsXml());
      }

      protected void btnClearSession_Click(object sender, EventArgs e)
      {
         this.UserSession.Reset();
         lblInfo.Text = this.UserSession.GetAllVariables();
      }
   }
}