﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PDSASecurityProviderSample
{
   public partial class _Default : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Re-direct to a page in a secured folder will cause login
         Response.Redirect("~/Secured/frmSecure.aspx");
      }
   }
}
