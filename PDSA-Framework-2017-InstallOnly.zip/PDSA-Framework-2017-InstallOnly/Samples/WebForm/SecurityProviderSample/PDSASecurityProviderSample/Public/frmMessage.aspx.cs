﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PDSA.Web;

namespace PDSASecurityProviderSample.Public
{
   public partial class frmMessage : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         PDSAWebSession session = null;
         PDSAWebMessage message = null;

         if (!this.IsPostBack)
         {
            if (Request.QueryString.Count > 0)
            {
               if (Request.QueryString["type"] != null)
               {
                  litMessage.Text = Request.QueryString["type"];
               }
            }
            else
            {
               session = new PDSAWebSession();
               message = session.WebMessage;
               if (message != null)
               {
                  litMessage.Text = message.Message;
               }
            }
         }
      }
   }
}