﻿using System;
using System.Collections.Generic;
using System.Text;
using PDSA.Framework;
using PDSA.Security;
using PDSA.Validation;
using PDSA.Web;
using PDSA.Framework.EntityLayer;
using PDSA.DataLayer;
using System.Security.Principal;
using System.Threading;
using PDSA.Cache;

namespace PDSASecurityProviderSample.Public
{
   public partial class frmLogin : System.Web.UI.Page
   {
      #region Private variables

      private PDSASecurityContext _securityContext = null;
      private List<string> _messages;
      private PDSAWebSecurityContext _applicationContext;

      #endregion

      #region Protected properties

      protected PDSAWebSecurityContext ApplicationContext
      {
         get
         {
            PDSASettings settings = null;
            if (_applicationContext == null)
            {
               // Set up the PDSAWebSecurityContext for this application
               settings = new PDSASettings();
               _applicationContext = new PDSAWebSecurityContext(
                  settings.Application.Entities.DefaultEntityId,
                  settings.Application.General.ApplicationId);
            }
            return _applicationContext;
         }
      }

      protected PDSASecurityContext SecurityContext
      {
         get
         {
            if (_securityContext == null)
            {
               _securityContext = PDSASecurityContext.CreateContext(this.ApplicationContext);
            }
            return _securityContext;
         }
      }

      protected PDSAAuthenticationResponse AuthenticationResponse { get; set; }

      #endregion 

      #region Helper methods

      private void Navigate()
      {
         if (this.AuthenticationResponse.RedirectPageUrl != string.Empty)
         {
            Response.Redirect(this.AuthenticationResponse.RedirectPageUrl);
         }
         else
         {
            Response.Redirect(PDSASettings.AllValues.Application.Website.ReturnPageUrl);
         }
      }

      private void Display(PDSAValidationRules rules)
      {
         foreach (PDSAValidationRule item in rules)
         {
            this.Display(item.Message);
         }
      }

      private void Display(string message)
      {
         _messages.Add(message);
      }

      /// <summary>
      /// Clear messages from the message display control 
      /// </summary>
      private void ClearMessages()
      {
         litMessage.Text = string.Empty;
      }

      private string FormatMessages()
      {
         string result = string.Empty;
         StringBuilder sb = new StringBuilder(1024);
         sb.Append("<ul>");
         foreach (string message in _messages)
         {
            sb.AppendFormat("<li>{0}</li>", message);
         }
         sb.Append("</ul>");
         result = sb.ToString();
         return result;
      }

      #endregion 

      protected void TryAutoSignIn()
      {
         this.AuthenticationResponse = this.SecurityContext.Authenticate();
         if (this.AuthenticationResponse.AuthenticationResult == PDSAAuthenticationStatus.Success)
         {
            this.Navigate();
         }
         else
         {
            // Sign in using the controls on this form
         }
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         try
         {
            // Initialize the message collection
            _messages = new List<string>();

            // Clear messages on post back
            if (!this.IsPostBack)
            {
               this.TryAutoSignIn();
            }
            else
            {
               this.ClearMessages();
            }
         }
         catch (ThreadAbortException)
         {
            // ignore
         }
         catch (Exception ex)
         {
            this.Display(ex.Message);
         }
      }

      protected void btnSignIn_Click(object sender, EventArgs e)
      {
         this.SignIn();
      }


      
      /// <summary>
      /// Sign in using the PDSA Security Provider 
      /// </summary>
      private void SignIn()
      {
         // Authenticate using the user name and password entered on the form controls
         this.AuthenticationResponse = this.SecurityContext.Authenticate(txtLoginName.Text, txtPassword.Text);

         // NOTE: the messages below are for sample purposes only.  In a production 
         // application, you should never display the detailed reasons for login failure
         // beyond 'error', or 'invalid login'
         switch (this.AuthenticationResponse.AuthenticationResult)
         {
            case PDSAAuthenticationStatus.ErrorOccurred:
               this.Display("An error occurred while attempting to login.");
               break;
            case PDSAAuthenticationStatus.ForcePasswordChange:
               this.Display("You must change your password.");
               break;
            case PDSAAuthenticationStatus.InvalidEntries:
               this.Display(this.AuthenticationResponse.ValidationMessages);
               break;
            case PDSAAuthenticationStatus.InvalidPassword:
               this.Display(PDSASettings.AllValues.Security.Authentication.InvalidCredentialsMessage);
               break;
            case PDSAAuthenticationStatus.LockedOut:
               this.Display("Your account is locked out.");
               break;
            case PDSAAuthenticationStatus.LoginTriesExceeded:
               this.Display("You have exceeded the allowable number of login attempts.");
               break;
            case PDSAAuthenticationStatus.None:
               this.Display(PDSASettings.AllValues.Security.Authentication.InvalidCredentialsMessage);
               break;
            case PDSAAuthenticationStatus.Success:
               this.Navigate();
               break;
            case PDSAAuthenticationStatus.UserInactive:
               this.Display("Your account is inactive.");
               break;
            case PDSAAuthenticationStatus.UserNotFound:
               this.Display("Your account was not found.");
               break;
         }
      }

      protected override void OnPreRender(EventArgs e)
      {
         base.OnPreRender(e);
         try
         {
            litMessage.Text = this.FormatMessages();
         }
         catch (Exception ex)
         {
            litMessage.Text = ex.Message;
         }
      }
   }
}