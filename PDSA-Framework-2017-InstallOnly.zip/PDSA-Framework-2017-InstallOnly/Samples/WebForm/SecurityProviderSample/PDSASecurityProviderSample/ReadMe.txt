﻿PDSA Security Provider Namespace Sample
--------------------------------------------------------------------------------
Before running this sample, you must do the following:

1. Create a database named PDSAFramework500
2. Run [InstallFiles]\SqlScripts\SqlServer_PDSAFramework500.sql in the new database.
3. Run [InstallFiles]\SqlScripts\CreateFrameworkData.sql in the new database.
4. Adjust the ConnectionString as appropriate in the Web.Config to point to this database.
5. Perform the steps listed under each scenario below. 


There are four scenarios supported by the PDSA Framework security provider.  The
scenarios are Application (forms-based), ActiveDirectory, ApplicationSingleSignOn and 
ActiveDirectoryWithPDSARoles.  Each of these is described below.

Note: PDSA Framework supports multiple tenants on the same instance of an 
application created using the PDSA Framework. For purposes of this sample, there 
is only a single tenant, identified by the 'defaultEntityId' attribute in the 
web.config file.

--------------------------------------------------------------------------------
I. Application (forms-based)
--------------------------------------------------------------------------------
   The application uses a login form where the user enters a login name and 
   password, and then the provider validates the user's credentials against 
   the login name and password stored in the pdsaUser table.

   1. After creating a sample database and running the SQL script, set up the 
   Web.config file as follows:

     a) In the PDSASecurityConfiguration section, find the authentication 
	 element and set the type attribute to Application (type="Application")

	 b) In the PDSASecurityProviders section, ensure that each of the providers
	 (Users, Roles and Permissions) are set up for PDSASecuritySqlServer as
	 follows:

	    type="PDSA.Security.SqlServer.PDSASecuritySqlServer"
		assembly="PDSA.Security.SqlServer"
		dataProviderName="PDSASqlClient"

	c) Make sure the PDSASqlClient connection string in the connectionStrings
	section points to the new database.

	d) Make sure the authentication element in the web.config file is set up to 
	use Forms authentication, as follows:

	<authentication mode="Forms">
      <forms loginUrl="~/Public/frmLogin.aspx"
             name=".PDSAAuthForms"
             timeout="20"
             slidingExpiration="true"  /> 
    </authentication>

	e) Run the sample and login as user 'SysAdmin' with password 'password'

--------------------------------------------------------------------------------
II. Active Directory
--------------------------------------------------------------------------------

   There are two options with Active Directory:

   1. The application uses a login form where the user enters a login name and 
   password, and then the provider validates the user's credentials against 
   Active Directory.  After creating a sample database and running the SQL script, set up the 
   Web.config file as follows:

    a) In the PDSASecurityConfiguration section, find the authentication 
	element and set the type attribute to ActiveDirectory (type="ActiveDirectory").

	b) In the PDSASecurityProviders section, ensure that each of the providers
	(Users, Roles and Permissions) are set up for PDSASecuritySqlServer as
	follows:

	    type="PDSA.Security.ActiveDirectory.PDSASecurityActiveDirectory"
		assembly="PDSA.Security.Providers"

	c) Make sure the authentication element in the web.config file is set up to 
	use Forms authentication, as follows:

	<authentication mode="Forms">
      <forms loginUrl="~/Public/frmLogin.aspx"
             name=".PDSAAuthForms"
             timeout="20"
             slidingExpiration="true"  /> 
    </authentication>

	d) Run the sample and login as a domain user on your domain with the correct 
	password, without the domain name (e.g., "JSmith" and "P@ssw0rd").

   2. The site is configured in IIS for Windows Integrated authentication, and 
   the application automatically authenticates the user without presenting a
   login form.

    a) In the PDSASecurityConfiguration section, find the authentication 
	element and set the type attribute to ActiveDirectory (type="ActiveDirectory").

	b) In the PDSASecurityProviders section, ensure that each of the providers
	(Users, Roles and Permissions) are set up for PDSASecuritySqlServer as
	follows:

	    type="PDSA.Security.ActiveDirectory.PDSASecurityActiveDirectory"
		assembly="PDSA.Security.Providers"

    c) Modify the authentication element in the web.config file to use Windows
	authentication:

	    <authentication mode="Windows" />

	d) Run the sample.  The current user is automatically signed in and 
	re-directed to the secured page.

--------------------------------------------------------------------------------
III. Single Sign On
--------------------------------------------------------------------------------

   The site is configured in IIS for Windows Integrated authentication, and if 
   the user identifies that the user is a valid Active Directory user, then the 
   application automatically authenticates the user without presenting a
   login form.  Otherwise, the login form is displayed and the user enters a 
   login name and password, and then the provider validates the user's credentials 
   against the login name and password stored in the pdsaUser table.  In this case
   the user names of all Active Directory user permitted to use the application  
   must be registered in the pdsaUser table.

   1. After creating a sample database and running the SQL script, modify the
   values in the pdsaUser table as follows:

     a) Insert a new row in the pdsaUser table for your Active Directory account.
	 Modify the script below and replace [DOMAIN\User] with your domain and login
	 name, and then execute the script.
	  
	    DECLARE @UserId int
      DECLARE @UserApplicationEntityId int

	    INSERT [PDSA].[pdsaUser] 
	      ([FirstName], [LastName], [UserInitials], [EmailAddress], 
		    [EmailAddress2], [LoginName], [DisplayName], [UserPassword], 
		    [LastLoginDate], [SecurityQuestion], [SecurityAnswer], [UserTheme], 
		    [UserLanguage], [IsLockedOut], [IsActive], [ResetPasswordFlag], 
		    [LastPasswordResetDate], [InsertName], [InsertDate], [UpdateName], 
		    [UpdateDate], [ConcurrencyValue]) 
		  VALUES 
		    (N'First', N'Last', N'FL', N'me@mydomain.com', N'', N'[DOMAIN\User]', N'First Last', 
		    N'W6ph5Mm5Pz8GgiULbPgzG37mj9g=', GETDATE(), 
		    N'What is your favorite color?', N'Green', N'', N'en-us', 0, 1, 0, 
		    GETDATE(), 
		    N'Admin', CAST(0x00009F7400DB1DA4 AS DateTime), 
		    N'Admin', CAST(0x00009F8900DAAC06 AS DateTime), 14)

		  SET @UserId = @@IDENTITY

		  INSERT INTO [PDSA].[pdsaUserApplicationEntity]
        ([ApplicationId],[EntityId],[UserId],[InsertName],[InsertDate],
		    [UpdateName],[UpdateDate],[ConcurrencyValue])
      VALUES
		    (1, 1, @UserId, N'Admin', GETDATE(), N'Admin', GETDATE(), 0)

		  SET @UserApplicationEntityId = @@IDENTITY
     
      INSERT [PDSA].[pdsaUserRole] 
        ([UserApplicationEntityId], [RoleId], [InsertName], 
        [InsertDate], [UpdateName], [UpdateDate], [ConcurrencyValue]) 
      VALUES (@UserApplicationEntityId, 1,  N'Admin', GETDATE(),  N'Admin', GETDATE(), 0)
     
   2. Set up the Web.config file as follows:

     a) In the PDSASecurityConfiguration section, find the authentication 
	 element and set the type attribute to ApplicationSingleSignOn: 
	 
	    type="ApplicationWithSingleSignOn"

	 b) In the PDSASecurityProviders section, ensure that each of the providers
	 (Users, Roles and Permissions) are set up for PDSASecuritySqlServer as
	 follows:

	    type="PDSA.Security.SqlServer.PDSASecuritySqlServer"
		assembly="PDSA.Security.SqlServer"
		dataProviderName="PDSASqlClient"

	 c) Make sure the PDSASqlClient connection string in the connectionStrings
	 section points to the new database.

	 d) Make sure the authentication element in the web.config file is set up to 
	 use Forms authentication, as follows:

	  <authentication mode="Forms">
        <forms loginUrl="~/Public/frmLogin.aspx"
             name=".PDSAAuthForms"
             timeout="20"
             slidingExpiration="true"  /> 
      </authentication>

    e) Run the sample.  The current user is automatically signed in and 
	re-directed to the secured page.

	f) To test that the login form is presented when the system does not recognize
	your login name, update your user name in the pdsaUser table to a domain user name 
	that does not exist and try the previous step again.  You should be able to login
	using the Admin account from the pdsaUser table with the password "password".

--------------------------------------------------------------------------------
IV. Active Directory with PDSA Roles
--------------------------------------------------------------------------------

   The site is configured in IIS for Windows Integrated authentication, and if 
   the site identifies that the user is a valid Active Directory user, then the 
   application looks up the user's roles and permissions in the pdsaRole and 
   pdsaPermission tables. 

   1. Rename the System Administrator role using the name of an Active Directory group
   to which your user account belongs, such as 'MYDOMAIN\Users'.

      UPDATE pdsaRole SET RoleName = '[DOMAIN\GroupName]' 
	    WHERE RoleName = 'System Administrator'

   2. Set up the Web.config file as follows:

     a) In the PDSASecurityConfiguration section, find the authentication 
	 element and set the type attribute to ActiveDirectoryWithPDSARoles: 
	 
	    type="ActiveDirectoryWithPDSARoles"

	 b) In the PDSASecurityProviders section, ensure that the user provider is
	 set up for PDSASecurityActiveDirectory as follows:

	    type="PDSA.Security.ActiveDirectory.PDSASecurityActiveDirectory"
		assembly="PDSA.Security.Providers"

	 c) In the PDSASecurityProviders section, ensure that the roles and permissions
	 provders are set up for PDSASecuritySqlServer as follows:

	    type="PDSA.Security.SqlServer.PDSASecuritySqlServer"
		assembly="PDSA.Security.SqlServer"
		dataProviderName="PDSASqlClient"

	 d) Make sure the PDSASqlClient connection string in the connectionStrings
	 section points to the new database.

	 e) Make sure the authentication element in the web.config file is set up to 
	 use Windows authentication, as follows:

	  <authentication mode="Windows" />
