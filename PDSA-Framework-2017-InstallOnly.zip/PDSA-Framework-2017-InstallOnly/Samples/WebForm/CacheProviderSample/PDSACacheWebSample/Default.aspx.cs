﻿using System;
using PDSA.Cache;
using PDSA.Framework;
using PDSA.Web;

namespace PDSACacheWebSample
{
  public partial class Default : System.Web.UI.Page
  {
    // This needs to be 'static' because we can't serialize
    private static PDSACacheManager _CacheManager = null;
    protected static PDSACacheManager CacheManager
    {
      get
      {
        if (_CacheManager == null)
          _CacheManager = new PDSACacheManager();

        return _CacheManager;
      }
      set { _CacheManager = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnAddGlobalKey_Click(object sender, EventArgs e)
    {
      CacheManager.Provider.Add("CustomerId", 1);
      lblResult.Text = "Set Global CustomerID=1";
    }

    protected void btnGetGlobalKey_Click(object sender, EventArgs e)
    {
      object value;

      value = CacheManager.Provider.Get("CustomerId");
      if (value != null)
        lblResult.Text = "CustomerId=" + value.ToString();
      else
        lblResult.Text = "Can't find CustomerId";
    }

    protected void btnAddUserKey_Click(object sender, EventArgs e)
    {
       // For a user key, you should use the Session ID
      CacheManager.Provider.Add("CustomerId", 2, Session.SessionID);
      lblResult.Text = "Set Global CustomerID=2 with user key=" + Session.SessionID;
    }

    protected void btnGetUserKey_Click(object sender, EventArgs e)
    {
      object value;

      value = CacheManager.Provider.Get("CustomerId", Session.SessionID);
      if (value != null)
         lblResult.Text = "CustomerId=" + value.ToString();
      else
        lblResult.Text = "Can't find CustomerId / " + Session.SessionID;
    }

    protected void btnAddAbsolute_Click(object sender, EventArgs e)
    {
      CacheManager.Provider.Add("CustomerId", 3, DateTime.Now.AddSeconds(10), Session.SessionID);
      lblResult.Text = "Set Global CustomerID=3 with user key=" + Session.SessionID + " absolutely expires in 10 seconds";
    }

    protected void btnAddSlidingExpiration_Click(object sender, EventArgs e)
    {
      CacheManager.Provider.Add("CustomerId", 4, new TimeSpan(0, 0, 10), Session.SessionID);
      lblResult.Text = "Set Global CustomerID=4 with user key=" + Session.SessionID + " sliding expiration in 10 seconds unless you access it.";
    }

    protected void btnRemove_Click(object sender, EventArgs e)
    {
      CacheManager.Provider.Remove("CustomerId");
      CacheManager.Provider.Remove("CustomerId", Session.SessionID);

      CacheManager.Provider.Clear();
      lblResult.Text = "Cache Cleared";
    }

    protected void btnCounter_Click(object sender, EventArgs e)
    {
       lblResult.Text = "Total Keys: " + CacheManager.Provider.Count.ToString();
    }
  }
}