﻿using System;
using System.Web;

using PDSA.Cache;

namespace PDSACacheWebSample
{
  /// <summary>
  /// This class should be used to perform all Caching for your application.
  /// This gives you a consistent model to use across all of your applications.
  /// You may add additional properties or methods to this class.
  /// </summary>
  public class AppCache
  {
    #region Private Variables
    // This needs to be 'static' because we can't serialize the Cache Manager
    private static PDSACacheManager _CacheManager = null;
    private static PDSACacheProvider _CacheProvider = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the PDSA Cache Manager object to use for caching
    /// </summary>
    public static PDSACacheManager CacheManager
    {
      get
      {
        if (_CacheManager == null)
          _CacheManager = new PDSACacheManager();

        return _CacheManager;
      }
      set { _CacheManager = value; }
    }

    /// <summary>
    /// Get/Set the PDSA Cache Provider object to use for caching
    /// </summary>
    public static PDSACacheProvider CacheProvider
    {
      get
      {
        if (_CacheProvider == null)
          _CacheProvider = CacheManager.Provider;

        return _CacheProvider;
      }
      set { _CacheProvider = value; }
    }
    #endregion

    #region Add Methods
    /// <summary>
    /// Call this method to add a key/value pair to a global cache for your application.
    /// This methods adds a value that can be retrieved by all users in your web application.
    /// For desktop applications, this is no different than from the User Cache
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    public static void Add(string key, object value)
    {
      CacheProvider.Add(key, value);
    }

    /// <summary>
    /// Call this method to add a key/value pair to a global cache for your application.
    /// This methods adds a value that can be retrieved by all users in your web application.
    /// For desktop applications, this is no different than from the User Cache.
    /// This value will automatically be removed from the cache at a specific date and time.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="absoluteExpiration">The date/time to remove the value from the cache</param>
    public static void Add(string key, object value, DateTime absoluteExpiration)
    {
      CacheProvider.Add(key, value, absoluteExpiration);
    }

    /// <summary>
    /// Call this method to add a key/value pair to a global cache for your application.
    /// This methods adds a value that can be retrieved by all users in your web application.
    /// For desktop applications, this is no different than from the User Cache.
    /// This value will be removed from the cache at a specific interval of time unless the value is accessed, then the time span will be reset.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="slidingExpiration">An interval of time of when to remove the value unless the value is accessed before that time</param>
    public static void Add(string key, object value, TimeSpan slidingExpiration)
    {
      CacheProvider.Add(key, value, slidingExpiration);
    }
    #endregion

    #region AddToUserCache Methods
    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// The SessionID is used to uniquely identify the user.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    public static void AddToUserCache(string key, object value)
    {
      AddToUserCache(key, value, string.Empty);
    }

    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// Pass in a user key that is unique for your application. If you do not pass in a user key, then the SessionID is used to uniquely identify this key
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="userKey">A unique ID for this key. If null or empty, then SessionID is used.</param>
    public static void AddToUserCache(string key, object value, string userKey)
    {
      if (string.IsNullOrEmpty(userKey))
        userKey = HttpContext.Current.Session.SessionID.ToString();

      CacheProvider.Add(key, value, userKey);
    }

    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// This value will automatically be removed from the cache at a specific date and time.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="absoluteExpiration">The date/time to remove the value from the cache</param>
    public static void AddToUserCache(string key, object value, DateTime absoluteExpiration)
    {
      AddToUserCache(key, value, absoluteExpiration, string.Empty);
    }

    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// This value will automatically be removed from the cache at a specific date and time.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="absoluteExpiration">The date/time to remove the value from the cache</param>
    /// <param name="userKey">A unique ID for this key. If null or empty, then SessionID is used.</param>
    public static void AddToUserCache(string key, object value, DateTime absoluteExpiration, string userKey)
    {
      if (string.IsNullOrEmpty(userKey))
        userKey = HttpContext.Current.Session.SessionID.ToString();

      CacheProvider.Add(key, value, absoluteExpiration, userKey);
    }

    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// This value will be removed from the cache at a specific interval of time unless the value is accessed, then the time span will be reset.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="slidingExpiration">An interval of time of when to remove the value unless the value is accessed before that time</param>
    public static void AddToUserCache(string key, object value, TimeSpan slidingExpiration)
    {
      AddToUserCache(key, value, slidingExpiration, string.Empty);
    }

    /// <summary>
    /// Call this method to add a key/value pair to cache that is specific for a user of the application.
    /// This value will be removed from the cache at a specific interval of time unless the value is accessed, then the time span will be reset.
    /// </summary>
    /// <param name="key">A unique key to identify the cached value</param>
    /// <param name="value">The value to add to the cache</param>
    /// <param name="slidingExpiration">An interval of time of when to remove the value unless the value is accessed before that time</param>
    /// <param name="userKey">A unique ID for this key. If null or empty, then SessionID is used.</param>
    public static void AddToUserCache(string key, object value, TimeSpan slidingExpiration, string userKey)
    {
      if (string.IsNullOrEmpty(userKey))
        userKey = HttpContext.Current.Session.SessionID.ToString();

      CacheProvider.Add(key, value, slidingExpiration, userKey);
    }
    #endregion

    #region Get Methods
    /// <summary>
    /// Get a specific value from the application cache. If the key is not found, a null value is returned.
    /// </summary>
    /// <param name="key">The unique key of the cached value to retrieve</param>
    /// <returns>The cached value or null if the key/value is not found</returns>
    public static object Get(string key)
    {
      object ret = null;
      PDSACacheItem item;

      item = CacheProvider.GetCacheItem(key);
      if (item == null)
        ret = null;
      else
        ret = item.Value;

      return ret;
    }

    /// <summary>
    /// Get a specific value from the user's cache. If the key is not found, a null value is returned.
    /// The SessionID is used to uniquely identify the user.
    /// </summary>
    /// <param name="key">The unique key of the cached value to retrieve</param>
    /// <returns>The cached value or null if the key/value is not found</returns>
    public static object GetFromUserCache(string key)
    {
      return GetFromUserCache(key, string.Empty);
    }

    /// <summary>
    /// Get a specific value from the user's cache. If the key is not found, a null value is returned.
    /// The SessionID is used to uniquely identify the user.
    /// </summary>
    /// <param name="key">The unique key of the cached value to retrieve</param>
    /// <param name="userKey">A unique ID for this key. If null or empty, then SessionID is used.</param>
    /// <returns>The cached value or null if the key/value is not found</returns>
    public static object GetFromUserCache(string key, string userKey)
    {
      object ret = null;
      PDSACacheItem item;

      if (string.IsNullOrEmpty(userKey))
        userKey = HttpContext.Current.Session.SessionID.ToString();

      item = CacheProvider.GetCacheItem(key, userKey);
      if (item == null)
        ret = null;
      else
        ret = item.Value;

      return ret;
    }
    #endregion

    #region Remove Method
    /// <summary>
    /// Removes a specific key/value from the application cache.
    /// </summary>
    /// <param name="key">The unique key of the cached value to remove</param>
    public static void Remove(string key)
    {
      CacheProvider.Remove(key);
    }
    #endregion

    #region RemoveFromUserCache Method
    /// <summary>
    /// Removes a specific key/value from the user's cache.
    /// The SessionID is used to uniquely identify the user.
    /// </summary>
    /// <param name="key">The unique key of the cached value to remove</param>
    public static void RemoveFromUserCache(string key)
    {
      RemoveFromUserCache(key, string.Empty);
    }

    /// <summary>
    /// Removes a specific key/value from the user's cache.
    /// The SessionID is used to uniquely identify the user.
    /// </summary>
    /// <param name="key">The unique key of the cached value to remove</param>
    /// <param name="userKey">A unique ID for this key. If null or empty, then SessionID is used.</param>
    public static void RemoveFromUserCache(string key, string userKey)
    {
      if (string.IsNullOrEmpty(userKey))
        userKey = HttpContext.Current.Session.SessionID.ToString();

      CacheProvider.Remove(key, userKey);
    }
    #endregion

    #region Clear Method
    /// <summary>
    /// Clears all cache items from the application and user cache collections.
    /// </summary>
    public static void Clear()
    {
      CacheProvider.Clear();
    }
    #endregion
  }
}