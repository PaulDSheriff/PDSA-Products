﻿using System;

namespace PDSACacheWebSample
{
   public partial class UsingAppCache : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
      }

      protected void btnAddGlobalKey_Click(object sender, EventArgs e)
      {
         // Create a global key/value pair
         AppCache.Add("CustomerId", 1);
         lblResult.Text = "Set Global CustomerID=1";
      }

      protected void btnGetGlobalKey_Click(object sender, EventArgs e)
      {
         object value;

         value = AppCache.Get("CustomerId");
         if (value != null)
            lblResult.Text = "CustomerId=" + value.ToString();
         else
            lblResult.Text = "Can't find CustomerId";
      }

      protected void btnAddUserKey_Click(object sender, EventArgs e)
      {
         AppCache.AddToUserCache("CustomerId", 2);
         lblResult.Text = "Set Global CustomerID=2 with user key=" + Session.SessionID;
      }

      protected void btnGetUserKey_Click(object sender, EventArgs e)
      {
         object value;

         value = AppCache.GetFromUserCache("CustomerId");
         if (value != null)
            lblResult.Text = "CustomerId=" + value.ToString();
         else
            lblResult.Text = "Can't find CustomerId / " + Session.SessionID;
      }

      protected void btnAddAbsolute_Click(object sender, EventArgs e)
      {
         AppCache.AddToUserCache("CustomerId", 3, DateTime.Now.AddSeconds(10));
         lblResult.Text = "Set Global CustomerID=3 with user key=" + Session.SessionID + " absolutely expires in 10 seconds";
      }

      protected void btnAddSlidingExpiration_Click(object sender, EventArgs e)
      {
         AppCache.AddToUserCache("CustomerId", 4, new TimeSpan(0, 0, 10));
         lblResult.Text = "Set Global CustomerID=4 with user key=" + Session.SessionID + " sliding expiration in 10 seconds unless you access it.";
      }

      protected void btnRemove_Click(object sender, EventArgs e)
      {
         AppCache.Remove("CustomerId");
         AppCache.RemoveFromUserCache("CustomerId");

         AppCache.Clear();
         lblResult.Text = "Cache Cleared";
      }

      protected void btnCounter_Click(object sender, EventArgs e)
      {
         lblResult.Text = "Total Keys: " + AppCache.CacheProvider.Count.ToString();
      }
   }
}