﻿Web Cache Sample
------------------------------------
This sample shows how to use the PDSA Cache Provider in an ASP.NET Web application

There are two pages that illustrate the use of the PDSA Cache Provider.
Default.aspx - Shows how to call the Cache objects directly.
UsingAppCache.aspx - Shows how to use a wrapper class called AppCache to make the calls

Things you can do with the PDSA Cache Provider
==================================================

Add Key/Value
-----------------
This will add a value to the cache and that item will stay in the cache until you remove the item, or the application ends

Add User Key
-----------------
This will add a value to the cache using the "Key" and "User Key" values as the "Key" for the value. That item will stay in the cache until you remove the item, or the application ends

Add Absolute
-------------
Adds a key/value pair to the cache and the value will be removed within "n" seconds of adding the value

Add Sliding
-------------
Adds a key/value pair to the cache and the value will be removed within "n" seconds of adding the value unless you access the item, then the item will last for the same "n" number of seconds

Get Value
-------------
Retrieves a value from the cache

Count
---------------
Tells you how many items are in the cache.

Remove All
-----------
Shows you how to remove an item, or all items, from the cache