﻿Web Menu Sample
----------------------------------
This sample shows how to use the PDSA Menu Provider in an ASP.NET Web application.

Before running this sample, you must do the following:

1. Create a database named PDSAFramework500
2. Run [InstallFiles]\SqlScripts\SqlServer_PDSAFramework500.sql in the new database.
3. Run [InstallFiles]\SqlScripts\CreateFrameworkData.sql in the new database.
4. Adjust the ConnectionString as appropriate in the Web.Config to point to this database.
