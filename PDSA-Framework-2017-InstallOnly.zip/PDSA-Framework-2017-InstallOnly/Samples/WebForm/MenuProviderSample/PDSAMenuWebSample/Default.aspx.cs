﻿using System;
using System.Data;

using PDSA.Framework;
using PDSA.Menus;
using PDSA.Framework.EntityLayer;
using PDSA.Framework.DataLayer;
using PDSA.DataLayer;

namespace PDSAMenuWebSample
{
  public partial class _Default : System.Web.UI.Page
  {
    private pdsaPermissionCollection _permissions;

    private int ExecuteScalar(string sql)
    {
      int result = -1;
      PDSADataManager manager = new PDSADataManager();
      PDSADataProvider provider = manager.Provider;
      IDbConnection cnn = provider.CreateConnection(true);
      result = (int)provider.ExecuteScalar(sql, cnn);
      return result;
    }

    private int GetUserId()
    {
      int result = -1;

      string sql = " SELECT UserId FROM PDSA.pdsaUserApplicationEntity WHERE EntityId = 1 AND ApplicationId = 1 "
                    + " AND UserApplicationEntityId IN (SELECT UserApplicationEntityId FROM PDSA.pdsaUserRole ur INNER JOIN PDSA.pdsaRole r ON r.RoleId = ur.RoleId WHERE r.RoleName = 'System Administrator') ";

      result = this.ExecuteScalar(sql);

      return result;
    }

    private int GetSubMenuId()
    {
      int result = -1;

      string sql = " SELECT Top 1 ParentMenuId FROM PDSA.pdsaMenuItem WHERE ParentMenuId IS NOT NULL AND IsActive = 1 ORDER BY ParentMenuId ";

      result = this.ExecuteScalar(sql);

      return result;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      if (_permissions == null)
      {
        _permissions = new pdsaPermissionCollection();

        // Try a couple of different cases for permissions;
        // this one uses the admin account 

        pdsaPermissionManager manager = new pdsaPermissionManager();
        _permissions = manager.GetPermissions(this.GetUserId(), 1, 1);
      }
    }

    protected void btnGetMenu_Click(object sender, EventArgs e)
    {
      PDSAMenuManager manager = new PDSAMenuManager();
      PDSAMenuProvider provider = manager.GetProvider("SqlServer");

      PDSAMenu menu = provider.GetMenu(_permissions);
      rptMenuItemsRepeater.DataSource = menu.MenuItems;
      rptMenuItemsRepeater.DataBind();
      pnlResultPanel.Visible = true;
    }

    protected void btnGetMenuByID_Click(object sender, EventArgs e)
    {
      PDSAMenuManager manager = new PDSAMenuManager();
      PDSAMenuProvider provider = manager.GetProvider("SqlServer");

      PDSAMenu menu = provider.GetMenu(this.GetSubMenuId(), _permissions);
      rptMenuItemsRepeater.DataSource = menu.MenuItems;
      rptMenuItemsRepeater.DataBind();
      pnlResultPanel.Visible = true;
    }

    protected void btnGetMenuItems_Click(object sender, EventArgs e)
    {
      PDSAMenuManager manager = new PDSAMenuManager();
      PDSAMenuProvider provider = manager.GetProvider("SqlServer");

      rptMenuItemsRepeater.DataSource = provider.GetMenuItems(_permissions);
      rptMenuItemsRepeater.DataBind();
      pnlResultPanel.Visible = true;
    }

    protected void btnGetMenuItemsByID_Click(object sender, EventArgs e)
    {
      PDSAMenuManager manager = new PDSAMenuManager();
      PDSAMenuProvider provider = manager.GetProvider("SqlServer");

      rptMenuItemsRepeater.DataSource = provider.GetMenuItems(this.GetSubMenuId(), _permissions);
      rptMenuItemsRepeater.DataBind();
      pnlResultPanel.Visible = true;
    }
  }
}
