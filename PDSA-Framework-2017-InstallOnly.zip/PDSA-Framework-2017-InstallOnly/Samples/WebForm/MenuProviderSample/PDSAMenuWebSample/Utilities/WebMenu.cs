﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;
using PDSA.Framework.EntityLayer;
using PDSA.Menus;
using PDSA.Framework;
using PDSA.Web;
 
namespace PDSAMenuWebSample.Utilities
{
   public class WebMenu
   {
      public void Bind(Repeater repeater, pdsaPermissionCollection permissions)
      {
         PDSAMenuManager manager = new PDSAMenuManager();
         PDSAMenuProvider provider = manager.GetProvider("SqlServer");
         pdsaMenuItemCollection items = provider.GetMenuItems(permissions);

         repeater.DataSource = items;
         repeater.DataBind();
      }
   }
}