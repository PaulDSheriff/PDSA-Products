Be sure to look at the samples in the Haystack Samples folder as well.
There you will find many samples of how to work with the Data Access Layer and the Data Classes