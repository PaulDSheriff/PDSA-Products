﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

using PDSA.Framework;
using PDSA.Security;

namespace PDSAAuthSample
{
  public partial class App : Application
  {
    #region Application Principal Object
    /// <summary>
    /// Get/Set the PDSAPrincipal object
    /// </summary>
    public PDSAPrincipal AppPrincipal { get; set; }
    #endregion

    #region Global Message Broker
    private PDSA.MessageBroker.PDSAMessageBroker _MessageBroker = null;

    /// <summary>
    /// Global Message Broker Object
    /// </summary>
    public PDSA.MessageBroker.PDSAMessageBroker MessageBroker 
    {
      get
      {
        if (_MessageBroker == null)
          _MessageBroker = new PDSA.MessageBroker.PDSAMessageBroker();

        return _MessageBroker;
      }
      set { _MessageBroker = value; }    
    }    
    #endregion

    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);
    }
  }
}
