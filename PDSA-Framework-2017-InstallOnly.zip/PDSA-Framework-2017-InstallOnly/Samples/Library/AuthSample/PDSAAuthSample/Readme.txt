﻿This sample shows you how to use the PDSA Security Providers to do the following:
  - Login
  - Logout 
  - Check to see if a user has a specific permission
  - Check to see if a user is in a specific role
  - Check for Security Controls
------------------------------------

In order for this sample to work, you must have installed the PDSAFramework500 database with the default data in it

Be sure to set the ConnectionString in the App.Config to point to where the PDSAFramework500 database is located

Login ID: SysAdmin
Password: password