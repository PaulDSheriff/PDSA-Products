﻿using System.Windows;

namespace PDSAAuthSample
{
  public partial class winRolesPermissions : Window
  {
    public winRolesPermissions()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      lstRoles.DisplayMemberPath = PDSA.Framework.BusinessLayer.pdsaRoleValidator.ColumnNames.RoleDescription;
      lstRoles.ItemsSource = (Application.Current as App).AppPrincipal.Roles;

      lstPermissions.DisplayMemberPath = PDSA.Framework.BusinessLayer.pdsaPermissionValidator.ColumnNames.PermissionName;
      lstPermissions.ItemsSource = (Application.Current as App).AppPrincipal.Permissions;
    }

    private void btnRoleCheck_Click(object sender, RoutedEventArgs e)
    {
      CheckRole(txtRoleToCheck.Text);
  }

    private void CheckRole(string roleName)
    {
      if ((Application.Current as App).AppPrincipal.IsInRole(roleName))
        MessageBox.Show("Is in Role");
      else
        MessageBox.Show("Not in Role");
    }

    private void btnPermissionCheck_Click(object sender, RoutedEventArgs e)
    {
      CheckPermission(txtPermissionToCheck.Text);
    }

    private void CheckPermission(string permissionName)
    {
      if ((Application.Current as App).AppPrincipal.HasPermission(permissionName))
        MessageBox.Show("Has Permission");
      else
        MessageBox.Show("Does NOT have Permission");
    }

  }
}
