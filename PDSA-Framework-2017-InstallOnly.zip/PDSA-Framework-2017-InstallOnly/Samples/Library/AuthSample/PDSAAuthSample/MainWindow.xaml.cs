﻿using System.Windows;

namespace PDSAAuthSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Initialize the Message Broker Events
      (Application.Current as App).MessageBroker.MessageReceived += new PDSA.MessageBroker.MessageReceivedEventHandler(MessageBroker_MessageReceived);
    }


    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      LoginWindow win = new LoginWindow();

      win.Owner = this;
      win.ShowDialog();
      if (win.DialogResult.HasValue && win.DialogResult.Value)
        MessageBox.Show("Logged In Successful");
      else
        MessageBox.Show("Login NOT Successful");
    }

    private void btnRolesPerms_Click(object sender, RoutedEventArgs e)
    {
      winRolesPermissions win = new winRolesPermissions();

      win.Owner = this;
      win.Show();
    }

    private void btnSecurityControls_Click(object sender, RoutedEventArgs e)
    {
      if ((Application.Current as App).AppPrincipal == null)
        MessageBox.Show("Please Login Prior to Running This");
      else
      {
        winSecurityControls win = new winSecurityControls();

        win.Owner = this;
        win.Show();
      }
    }

    private void btnLogout_Click(object sender, RoutedEventArgs e)
    {
      // Send this as a message so any objects can respond to this
      (Application.Current as App).MessageBroker.SendMessage(new PDSA.MessageBroker.PDSAMessageBrokerMessage("Logout", "Logout"));
    }

    void MessageBroker_MessageReceived(object sender, PDSA.MessageBroker.PDSAMessageBrokerEventArgs e)
    {
      // Use this event to receive all messages
      switch (e.MessageName.ToLower())
      {
        case "logout":
          (Application.Current as App).AppPrincipal = null;
          break;
      }
    }

  }
}
