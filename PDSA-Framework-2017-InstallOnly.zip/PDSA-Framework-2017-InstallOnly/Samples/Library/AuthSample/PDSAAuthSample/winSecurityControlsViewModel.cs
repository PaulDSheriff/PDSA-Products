﻿using System;

using PDSA.UI;

namespace PDSAAuthSample
{
  public class winSecurityControlsViewModel : PDSAUIViewModelBase
  {
    private string _FirstName = "John";
    private string _LastName = "Smith";

    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        if (_FirstName != value)
        {
          _FirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    public string LastName
    {
      get { return _LastName; }
      set
      {
        if (_LastName != value)
        {
          _LastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }
  }
}
