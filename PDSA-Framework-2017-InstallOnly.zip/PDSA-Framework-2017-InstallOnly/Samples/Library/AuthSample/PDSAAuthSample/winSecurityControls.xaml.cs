﻿using System.Windows;

using PDSA.Framework;
using PDSA.WPF.Security;

namespace PDSAAuthSample
{
  public partial class winSecurityControls : Window
  {
    public winSecurityControls()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      SecurityControlCheck();
    }

    private void SecurityControlCheck()
    {
      PDSAWPFControlSecurity security = new PDSAWPFControlSecurity(this,
        PDSASettings.AllValues.Application.General.ApplicationId,
        "SecureControlsTest",
        (Application.Current as App).AppPrincipal);

      security.SecureControls();
      if (!string.IsNullOrEmpty(security.LastExceptionMessage))
        MessageBox.Show(security.LastExceptionMessage);
    }
  }
}
