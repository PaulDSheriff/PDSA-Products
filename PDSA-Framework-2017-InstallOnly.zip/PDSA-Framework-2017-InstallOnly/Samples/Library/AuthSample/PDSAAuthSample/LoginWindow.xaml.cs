﻿using System.Windows;
using System.Security;
using System.Security.Principal;

using PDSA.Framework;
using PDSA.Framework.ViewModelLayer;
using PDSA.Security;
using PDSA.WPF.Security;

namespace PDSAAuthSample
{
  public partial class LoginWindow : Window
  {
    PDSALoginViewModel _ViewModel = null;

    public LoginWindow()
    {
      InitializeComponent();

      _ViewModel = (PDSALoginViewModel)this.Resources["viewModel"];

      // Initialize Application Context
      _ViewModel.ApplicationContext = new PDSAWPFApplicationContext(
                PDSASettings.AllValues.Application.Entities.DefaultEntityId,
                PDSASettings.AllValues.Application.General.ApplicationId); 
      _ViewModel.LoginName = "SysAdmin";

      _ViewModel.LoadView(true);
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      // Have to set password manually because it is a "secure" string
      _ViewModel.Password = txtPassword.Password;
      _ViewModel.SignIn();
      
      if (_ViewModel.Response.AuthenticationResult == PDSAAuthenticationStatus.Success)
      {
        GenericPrincipal prin;
        prin = PDSAPrincipal.CreateGenericPrincipal(_ViewModel.LoginName, "Application");

        // Create a PDSAPrincipal Object
        (Application.Current as App).AppPrincipal = _ViewModel.SecurityContext.CreatePrincipal(prin, _ViewModel.Response.UserId);
        // Assign the PDSAPrincipal object to the Thread's Current Principal
        System.Threading.Thread.CurrentPrincipal = (Application.Current as App).AppPrincipal;
        
        DialogResult = true;
      }
      else
      {
        // InfoMessage has already been filled in and displayed.
      }
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }
  }
}
