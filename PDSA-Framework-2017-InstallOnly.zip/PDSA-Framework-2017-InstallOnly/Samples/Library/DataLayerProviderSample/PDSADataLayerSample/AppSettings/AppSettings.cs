﻿using System;
using System.Configuration;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public class AppSettings
  {
    #region Static Instance Property
    private static AppSettings _Instance = null;

    public static AppSettings Instance
    {
      get
      {
        if (_Instance == null)
        {
          _Instance = new AppSettings();
        }

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Private Variables
    private bool _IsOracle;
    private bool _UseStoredProcs;
    private string _ProviderName;
    private string _PKField;
    private string _DisplayMember;

    private string _TableName;
    private string _SQL;
    private string _ExecuteSQL;
    private string _ExecuteSQLParams;
    private string _ExecuteSP;
    private string _ExecuteScalar;

    private string _TableNameOracle;
    private string _SQLOracle;
    private string _ExecuteSQLOracle;
    private string _ExecuteSQLParamsOracle;
    private string _ExecuteSPOracle;
    private string _ExecuteScalarOracle;
    #endregion

    #region Public Properties
    public bool IsOracle
    {
      get { return _IsOracle; }
      set { _IsOracle = value; }
    }

    public bool UseStoredProcs
    {
      get { return _UseStoredProcs; }
      set { _UseStoredProcs = value; }
    }

    public string ProviderName
    {
      get { return _ProviderName; }
      set { _ProviderName = value; }
    }

    public string PKField
    {
      get { return _PKField; }
      set { _PKField = value; }
    }

    public string DisplayMember
    {
      get { return _DisplayMember; }
      set { _DisplayMember = value; }
    }

    public string TableName
    {
      get { return _TableName; }
      set { _TableName = value; }
    }

    public string SQL
    {
      get { return _SQL; }
      set { _SQL = value; }
    }

    public string ExecuteSQL
    {
      get { return _ExecuteSQL; }
      set { _ExecuteSQL = value; }
    }

    public string ExecuteSQLParams
    {
      get { return _ExecuteSQLParams; }
      set { _ExecuteSQLParams = value; }
    }

    public string ExecuteSP
    {
      get { return _ExecuteSP; }
      set { _ExecuteSP = value; }
    }

    public string ExecuteScalar
    {
      get { return _ExecuteScalar; }
      set { _ExecuteScalar = value; }
    }

    public string TableNameOracle
    {
      get { return _TableNameOracle; }
      set { _TableNameOracle = value; }
    }

    public string SQLOracle
    {
      get { return _SQLOracle; }
      set { _SQLOracle = value; }
    }

    public string ExecuteSQLOracle
    {
      get { return _ExecuteSQLOracle; }
      set { _ExecuteSQLOracle = value; }
    }

    public string ExecuteSQLParamsOracle
    {
      get { return _ExecuteSQLParamsOracle; }
      set { _ExecuteSQLParamsOracle = value; }
    }

    public string ExecuteSPOracle
    {
      get { return _ExecuteSPOracle; }
      set { _ExecuteSPOracle = value; }
    }

    public string ExecuteScalarOracle
    {
      get { return _ExecuteScalarOracle; }
      set { _ExecuteScalarOracle = value; }
    }
    #endregion

    #region GetDataProviderForSamples Method
    public PDSADataProvider GetDataProviderForSamples()
    {
      PDSADataManager mgr = new PDSADataManager();

      return mgr.GetProvider(_ProviderName);
    }
    #endregion

    #region Load Method
    /// <summary> 
    /// Load all the values from the appSettings section of the Config file. 
    /// </summary> 
    /// <returns>An instance of a AppSettings class</returns> 
    public void Load()
    {
      // Load your Settings here
      PKField = GetSetting("PKField", "");
      ProviderName = GetSetting("ProviderName", "");
      DisplayMember = GetSetting("DisplayMember", "");
      UseStoredProcs = Convert.ToBoolean(GetSetting("UseStoredProcs", "False"));

      TableName = GetSetting("TableName", "");
      SQL = GetSetting("SQL", "");
      ExecuteScalar = GetSetting("ExecuteScalar", "");
      ExecuteSP = GetSetting("ExecuteSP", "");
      ExecuteSQL = GetSetting("ExecuteSQL", "");
      ExecuteSQLParams = GetSetting("ExecuteSQLParams", "");

      TableNameOracle = GetSetting("TableNameOracle", "");
      SQLOracle = GetSetting("SQLOracle", "");
      ExecuteScalarOracle = GetSetting("ExecuteScalarOracle", "");
      ExecuteSPOracle = GetSetting("ExecuteSPOracle", "");
      ExecuteSQLOracle = GetSetting("ExecuteSQLOracle", "");
      ExecuteSQLParamsOracle = GetSetting("ExecuteSQLParamsOracle", "");
    }
    #endregion

    #region GetSetting Method
    protected string GetSetting(string key, string defaultValue)
    {
      string ret = string.Empty;

      try
      {
        ret = ConfigurationManager.AppSettings[key];
      }
      catch
      {
        ret = defaultValue;
      }

      return ret;
    }
    #endregion
  }
}
