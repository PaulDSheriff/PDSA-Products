﻿using System;
using System.Data;
using System.Windows;

using PDSA.DataLayer;
using PDSA.WPF;

namespace PDSADataLayerSample
{
  public partial class winGetDataSet : Window
  {
    public winGetDataSet()
    {
      InitializeComponent();
    }

    private const string SQL_EXCEPTION = "SELECT * FROM BLAH";

    private void btnSqlConnString_Click(object sender, RoutedEventArgs e)
    {
      GetDataSet();
    }

    private void btnSqlConnection_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnection();
    }

    private void btnCommand_Click(object sender, RoutedEventArgs e)
    {
      TestCommand();
    }

    private void btnCmdConn_Click(object sender, RoutedEventArgs e)
    {
      TestCmdConn();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      TestHardCoded();
    }


    private void btnSqlConnString_Click(object sender, EventArgs e)
    {
      GetDataSet();
    }

    private void GetDataSet()
    {
      PDSADataManager mgr;
      DataSet ds;

      try
      {
        mgr = new PDSADataManager();

        //***********************************************
        //* OPTION 1
        //***********************************************
        // Get the Default Data Provider
        mgr.Provider = mgr.GetProvider(AppSettings.Instance.ProviderName);
        if ((bool)chkException.IsChecked)
        {
          ds = mgr.Provider.GetDataSet(SQL_EXCEPTION);
          lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        }
        else
        {
          if (AppSettings.Instance.IsOracle)
            ds = mgr.Provider.GetDataSet(AppSettings.Instance.SQLOracle);
          else
            ds = mgr.Provider.GetDataSet(AppSettings.Instance.SQL);

          lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
          lvwResults.DataContext = ds.Tables[0];
        }

        //***********************************************
        //* OPTION 2
        //***********************************************
        //if ((bool)chkException.IsChecked)
        //grdValues.DataSource = mDataManager.Provider.GetDataSet(SQL_EXCEPTION).Tables[0];
        //else
        //grdValues.DataSource = mDataManager.Provider.GetDataSet(PDSAAppSettings.ConfigSettings.SQL).Tables[0];

      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestSqlConnection()
    {
      IDbConnection cnn = null;
      PDSADataProvider pdp;
      DataSet ds;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();
        // If you pass True to the 2nd parameter, 
        // the connection will stay open after you run 
        // the GetDataSet method. 
        // If you pass False, it will be closed after 
        // the call to the GetDataSet method.
        cnn = pdp.CreateConnection(pdp.ConnectString, true);

        if ((bool)chkException.IsChecked)
        {
          ds = pdp.GetDataSet(SQL_EXCEPTION, cnn);
          lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        }
        else
        {
          if (AppSettings.Instance.IsOracle)
            ds = pdp.GetDataSet(AppSettings.Instance.SQLOracle, cnn);
          else
            ds = pdp.GetDataSet(AppSettings.Instance.SQL, cnn);

          lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        }
        lvwResults.DataContext = ds.Tables[0];

      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void TestCommand()
    {
      IDbConnection cnn;
      IDbCommand cmd;
      PDSADataProvider pdp;
      DataSet ds;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        // Don't open the connection
        cnn = pdp.CreateConnection(pdp.ConnectString, false);
        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.SQLOracle);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.SQL);

        cmd.Connection = cnn;

        // The GetDataSet method will open the connection
        // and then close it once it is done 
        ds = pdp.GetDataSet(cmd);
        lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        lvwResults.DataContext = ds.Tables[0];
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestCmdConn()
    {
      IDbCommand cmd;
      PDSADataProvider pdp;
      DataSet ds;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.SQLOracle);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.SQL);

        ds = pdp.GetDataSet(cmd, pdp.ConnectString);

        lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        lvwResults.DataContext = ds.Tables[0];
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestHardCoded()
    {
      //GetViewInfo();
      GetDataSetHardCoded();
      //GetDataSetSpecificDataProvider();
    }

    private void GetViewInfo()
    {
      PDSADataProvider pdp;
      IDbCommand cmd = null;
      IDataParameter param;
      DataSet ds;
      DataRow dr;

      string mSQL = "SELECT sys_context( 'USERENV', 'DB_NAME') as TABLE_CATALOG, OWNER as TABLE_SCHEMA, VIEW_NAME as TABLE_NAME, TEXT as VIEW_DEFINITION, VIEW_TYPE as CHECK_OPTION, 0 as IS_UPDATABLE FROM ALL_VIEWS WHERE OWNER = :SchemaName AND VIEW_NAME = :ViewName";

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        cmd = pdp.CreateCommand(mSQL);
        cmd.CommandType = CommandType.Text;
        param = pdp.CreateParameter("SchemaName", DbType.String, "HAYSTACK");
        cmd.Parameters.Add(param);
        param = pdp.CreateParameter("ViewName", DbType.String, "VWCUSTOMER_SELECTALL");
        cmd.Parameters.Add(param);

        ds = pdp.GetDataSet(cmd, pdp.ConnectString);
        if (ds != null)
        {
          if (ds.Tables.Count > 0)
          {
            if (ds.Tables[0].Rows.Count > 0)
            {
              dr = ds.Tables[0].Rows[0];
            }
          }
        }
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.Write(ex.ToString());
      }      
    }
        
    private void GetDataSetHardCoded()
    {
      DataSet ds;
      PDSADataManager mgr;

      try
      {
        mgr = new PDSADataManager();

        if ((bool)chkException.IsChecked)
          ds = mgr.Provider.GetDataSet(SQL_EXCEPTION,
                  mgr.Provider.ConnectString);
        else
          if (AppSettings.Instance.IsOracle)
            ds = mgr.Provider.GetDataSet("SELECT * FROM " + AppSettings.Instance.TableNameOracle,
                    mgr.Provider.ConnectString);
          else
            ds = mgr.Provider.GetDataSet("SELECT * FROM " + AppSettings.Instance.TableName,
                    mgr.Provider.ConnectString);

        lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
        lvwResults.DataContext = ds.Tables[0];
      }
      catch (Exception ex)
      {
        Clipboard.SetText(ex.ToString());
        MessageBox.Show(ex.ToString());
      }
    }

    /// <summary>
    /// Use the Default Data Provider
    /// </summary>
    private void GetDataSetDefaultProvider()
    {
      DataSet ds;
      PDSADataManager mgr = new PDSADataManager();

      if (AppSettings.Instance.IsOracle)
        ds = mgr.Provider.GetDataSet("SELECT * FROM Product");
      else
        ds = mgr.Provider.GetDataSet("SELECT * FROM PDSASample.Product");

      lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
      lvwResults.DataContext = ds.Tables[0];
    }

    /// <summary>
    /// Retrieve a specific Data Provider
    /// </summary>
    private void GetDataSetSpecificDataProvider()
    {
      DataSet ds;
      PDSADataManager mgr = new PDSADataManager();

      mgr.Provider = mgr.GetProvider("SqlClient");

      if (AppSettings.Instance.IsOracle)
        ds = mgr.Provider.GetDataSet("SELECT * FROM Product");
      else
        ds = mgr.Provider.GetDataSet("SELECT * FROM PDSASample.Product");

      lvwResults.View = PDSAWPFListView.CreateGridViewColumns(ds.Tables[0]);
      lvwResults.DataContext = ds.Tables[0];
    }

  }
}
