﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Input;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class winConnect : Window
  {
    #region Constructor
    public winConnect()
    {
      InitializeComponent();
    }
    #endregion

    private const string BAD_CONN_STRING = @"Server=BadServer;Database=NoDatabase;uid=sa;pwd=sa";

    PDSADataManager _DataManager;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _DataManager = new PDSADataManager();
    }

    private void btnDefaultProvider_Click(object sender, RoutedEventArgs e)
    {
      TestDefaultProvider();
    }

    private void btnPassConnect_Click(object sender, RoutedEventArgs e)
    {
      TestPassConnect();
    }

    private void btnSpecificProvider_Click(object sender, RoutedEventArgs e)
    {
      TestSpecificProvider();
    }

    private void TestDefaultProvider()
    {
      IDbConnection cnn = null;

      try
      {
        tbMessages.Text = "Attempting to connect...";


        this.Cursor = Cursors.Wait;

        if ((bool)chkException.IsChecked)
        {
          cnn = _DataManager.Provider.CreateConnection(BAD_CONN_STRING);
          cnn.Open();
        }
        else
        {
          cnn = _DataManager.Provider.CreateConnection();
          cnn.Open();
        }

        tbMessages.Text = "Default Provider - Connection Succeeded";
      }
      catch (Exception ex)
      {
        MessageBox.Show("The Open Method is called by us, so NO PDSADataException is Created" + Environment.NewLine + ex.ToString()); ;
        tbMessages.Text = "";
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }

        this.Cursor = Cursors.Arrow;
      }
    }

    private void btnSpecificProviderHardCoded_Click(object sender, RoutedEventArgs e)
    {
      GetSpecificProvider();
    }

    private void GetSpecificProvider()
    {
      PDSADataManager mgr = new PDSADataManager();
      PDSADataProvider prov;

      prov = mgr.GetProvider("SqlClient2");

      MessageBox.Show(prov.ConnectString);
    }

    private void TestPassConnect()
    {
      IDbConnection cnn = null;

      try
      {
        tbMessages.Text = "Attempting to connect...";

        this.Cursor = Cursors.Wait;

        _DataManager.Provider = _DataManager.GetProvider(AppSettings.Instance.ProviderName);

        // Passing a connect String, Don't Open Connection
        if ((bool)chkException.IsChecked)
          cnn = _DataManager.Provider.CreateConnection(BAD_CONN_STRING, true);
        else
          cnn = _DataManager.Provider.CreateConnection(_DataManager.Provider.ConnectString, true);

        tbMessages.Text = "Pass Connection - Connection Succeeded";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
        tbMessages.Text = "";
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }

        this.Cursor = Cursors.Arrow;
      }
    }

    private void TestSpecificProvider()
    {
      IDbConnection cnn = null;

      try
      {
        tbMessages.Text = "Attempting to connect...";

        this.Cursor = Cursors.Wait;

        _DataManager.Provider = _DataManager.GetProvider("SqlClient");

        // Open new connection
        if ((bool)chkException.IsChecked)
          cnn = _DataManager.Provider.CreateConnection(BAD_CONN_STRING, true);
        else
          cnn = _DataManager.Provider.CreateConnection(true);

        tbMessages.Text = "Specific Provider - Connection Succeeded";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
        tbMessages.Text = "";
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }

        this.Cursor = Cursors.Arrow;
      }
    }

    private void btnCanOpenConnection_Click(object sender, RoutedEventArgs e)
    {
      IDbConnection cnn = null;

      try
      {
        tbMessages.Text = "Attempting to connect...";

        this.Cursor = Cursors.Wait;

        _DataManager.Provider = _DataManager.GetProvider("SqlClient");

        if(_DataManager.Provider.CanOpenConnection())
          tbMessages.Text = "Can Open Connection";
        else
          tbMessages.Text = "Can NOT Open Connection";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
        tbMessages.Text = "";
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }

        this.Cursor = Cursors.Arrow;
      }
    }

  }
}
