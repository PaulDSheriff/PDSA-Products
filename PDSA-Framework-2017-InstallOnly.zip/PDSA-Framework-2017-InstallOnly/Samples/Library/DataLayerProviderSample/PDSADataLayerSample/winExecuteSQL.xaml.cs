﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class winExecuteSQL : Window
  {
    public winExecuteSQL()
    {
      InitializeComponent();
    }

    private const string SQL_EXCEPTION = "UPDATE BLAH SET BLAH = 'blah'";

    private void btnSqlConnString_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnString();
    }

    private void btnSqlConnection_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnection();
    }

    private void btnCommand_Click(object sender, RoutedEventArgs e)
    {
      TestCommand();
    }

    private void btnCmdConn_Click(object sender, RoutedEventArgs e)
    {
      TestCmdConn();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      TestHardCoded();
    }
    private void MessageDisplay(string Msg)
    {
      tbResults.Text = string.Empty;
      tbResults.Text = Msg;
    }

    private void TestSqlConnString()
    {
      PDSADataProvider pdp;
      int intRows;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          intRows = pdp.ExecuteSQL(SQL_EXCEPTION, pdp.ConnectString);
        else
          if (AppSettings.Instance.IsOracle)
            intRows = pdp.ExecuteSQL(AppSettings.Instance.ExecuteSQLOracle, pdp.ConnectString);
          else
            intRows = pdp.ExecuteSQL(AppSettings.Instance.ExecuteSQL, pdp.ConnectString);

        MessageDisplay(intRows.ToString());

        MessageBox.Show("SQL Statement Executed using SQL String and Connection String");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestSqlConnection()
    {
      IDbConnection cnn = null;
      PDSADataProvider pdp;
      int intRows;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        // Opens a connection
        cnn = pdp.CreateConnection(pdp.ConnectString, true);
        if ((bool)chkException.IsChecked)
          intRows = pdp.ExecuteSQL(SQL_EXCEPTION, cnn);
        else
          if (AppSettings.Instance.IsOracle)
            intRows = pdp.ExecuteSQL(AppSettings.Instance.ExecuteSQLOracle, cnn);
          else
            intRows = pdp.ExecuteSQL(AppSettings.Instance.ExecuteSQL, cnn);

        MessageDisplay(intRows.ToString());

        MessageBox.Show("SQL Statement Executed using SQL String and Connection Object");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void TestCommand()
    {
      IDbConnection cnn = null;
      IDbCommand cmd = null;
      PDSADataProvider pdp;
      int intRows;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        cnn = pdp.CreateConnection(pdp.ConnectString, false);
        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION, cnn);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQLOracle, cnn);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQL, cnn);

        intRows = pdp.ExecuteSQL(cmd);

        MessageDisplay(intRows.ToString());

        MessageBox.Show("SQL Statement Executed using Command Object");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestCmdConn()
    {
      IDbCommand cmd = null;
      PDSADataProvider pdp;
      int intRows;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQLOracle);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQL);

        intRows = pdp.ExecuteSQL(cmd, pdp.ConnectString);

        MessageDisplay(intRows.ToString());

        MessageBox.Show("SQL Statement Executed using Command Object");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestHardCoded()
    {
      ExecuteSQLHardCodedInterface();
    }

    private void ExecuteSQLHardCodedSqlServer()
    {
      PDSADataManager mgr = new PDSADataManager();
      PDSADataProvider prov;
      SqlCommand cmd;
      SqlParameter param;
      int rows;
      string sql;

      if (AppSettings.Instance.IsOracle)
        sql = "INSERT INTO Product(ProductName,Price) VALUES (@ProductName,@Price)";
      else
        sql = "INSERT INTO PDSASample.Product(ProductName,Price) VALUES (@ProductName,@Price)";

      prov = mgr.Provider;
      cmd = (SqlCommand)prov.CreateCommand(sql);
      cmd.Connection = (SqlConnection)prov.
                          CreateConnection(prov.ConnectString);

      param = (SqlParameter)prov.CreateParameter("@ProductName",
                                    DbType.String);
      param.Value = "A New Product";
      cmd.Parameters.Add(param);

      param = (SqlParameter)prov.CreateParameter("@Price",
                                    DbType.Decimal);
      param.Value = 200;
      cmd.Parameters.Add(param);

      // Execute the SQL and close the connection
      rows = prov.ExecuteSQL(cmd, true);
    }

    private void ExecuteSQLHardCodedInterface()
    {
      PDSADataManager mgr = new PDSADataManager();
      PDSADataProvider prov;
      IDbCommand cmd;
      IDataParameter param;
      int rows;
      string sql;

      if (AppSettings.Instance.IsOracle)
        sql = "INSERT INTO Product(ProductName,Price) VALUES (@ProductName,@Price)";
      else
        sql = "INSERT INTO PDSASample.Product(ProductName,Price) VALUES (@ProductName,@Price)";

      prov = mgr.Provider;
      cmd = prov.CreateCommand(sql);
      cmd.Connection = prov.CreateConnection(prov.ConnectString);

      param = prov.CreateParameter("@ProductName",
                                    DbType.String);
      param.Value = "A New Product";
      cmd.Parameters.Add(param);

      param = prov.CreateParameter("@Price",
                                    DbType.Decimal);
      param.Value = 200;
      cmd.Parameters.Add(param);

      // Execute the SQL and close the connection
      rows = prov.ExecuteSQL(cmd, true);
    }
  }
}
