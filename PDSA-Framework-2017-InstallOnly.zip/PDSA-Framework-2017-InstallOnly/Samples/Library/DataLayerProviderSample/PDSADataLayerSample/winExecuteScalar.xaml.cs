﻿using System;
using System.Data;
using System.Windows;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class winExecuteScalar : Window
  {
    private const string SQL_EXCEPTION = "SELECT Count(*) FROM BLAH";

    #region Form Events
    public winExecuteScalar()
    {
      InitializeComponent();
    }

    private void btnSqlConnString_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnString();
    }

    private void btnSqlConnection_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnection();
    }

    private void btnCommand_Click(object sender, RoutedEventArgs e)
    {
      TestCommand();
    }

    private void btnCmdConn_Click(object sender, RoutedEventArgs e)
    {
      TestCmdConn();
    }
    #endregion

    #region Methods
    private void MessageDisplay(string Msg)
    {
      tbResult.Text = string.Empty;
      tbResult.Text = Msg;
    }

    private void TestSqlConnString()
    {
      PDSADataProvider pdp;
      object obj;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          obj = pdp.ExecuteScalar(SQL_EXCEPTION, pdp.ConnectString);
        else
          if (AppSettings.Instance.IsOracle)
            obj = pdp.ExecuteScalar(AppSettings.Instance.ExecuteScalarOracle, pdp.ConnectString);
          else
            obj = pdp.ExecuteScalar(AppSettings.Instance.ExecuteScalar, pdp.ConnectString);

        MessageDisplay(obj.ToString());

        MessageBox.Show("Scalar Statement Executed using SQL String and Connect String");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void TestSqlConnection()
    {
      IDbConnection cnn = null;
      PDSADataProvider pdp;
      object obj;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();
        // Open connection
        cnn = pdp.CreateConnection(pdp.ConnectString, true);
        if ((bool)chkException.IsChecked)
          obj = pdp.ExecuteScalar(SQL_EXCEPTION, cnn);
        else
          if (AppSettings.Instance.IsOracle)
            obj = pdp.ExecuteScalar(AppSettings.Instance.ExecuteScalarOracle, cnn);
          else
            obj = pdp.ExecuteScalar(AppSettings.Instance.ExecuteScalar, cnn);

        MessageDisplay(obj.ToString());

        MessageBox.Show("Scalar Statement Executed using SQL String and Connection Object");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void TestCommand()
    {
      IDbCommand cmd = null;
      PDSADataProvider pdp;
      object obj;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION, pdp.ConnectString, true);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteScalarOracle, pdp.ConnectString, true);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteScalar, pdp.ConnectString, true);

        obj = pdp.ExecuteScalar(cmd);

        MessageDisplay(obj.ToString());

        MessageBox.Show("Scalar Statement Executed using Command Object");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }     
    }

    private void TestCmdConn()
    {
      IDbCommand cmd = null;
      PDSADataProvider pdp;
      object obj;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteScalarOracle);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteScalar);

        obj = pdp.ExecuteScalar(cmd, pdp.ConnectString);

        MessageDisplay(obj.ToString());

        MessageBox.Show("Scalar Statement Executed using Command Object and Connect String");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion
  }
}
