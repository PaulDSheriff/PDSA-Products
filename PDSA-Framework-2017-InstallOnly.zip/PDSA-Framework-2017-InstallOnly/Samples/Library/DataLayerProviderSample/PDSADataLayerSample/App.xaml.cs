﻿using System.Windows;

namespace PDSADataLayerSample
{
  public partial class App : Application
  {
  }
}
