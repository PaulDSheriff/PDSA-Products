﻿using System;
using System.Data;
using System.Windows;

using PDSA.DataLayer; 

namespace PDSADataLayerSample
{
  public partial class winTrans : Window
  {
    public winTrans()
    {
      InitializeComponent();
    }

    private void btnTransaction_Click(object sender, RoutedEventArgs e)
    {
      TestTransaction();
    } 
    
    private void TestTransaction()
    {
      PDSADataProvider pdp;
      IDbConnection cnn;
      IDbTransaction trn = null;
      IDbCommand cmdProd1;
      IDbCommand cmdProd2;

      pdp = AppSettings.Instance.GetDataProviderForSamples();
      cnn = pdp.CreateConnection(pdp.ConnectString, true);

      try
      {
        trn = cnn.BeginTransaction();

        if ((bool)chkException.IsChecked)
          cmdProd1 = CreateNewProduct("1'st New Productasdfasdfasdfasdfasdfasdfasdfasdfasdfsadfasdfasdfsadfasdfasdfasdfasdfasdfsadfsadf", Convert.ToDecimal(1.0E+16), 200);
        else
          cmdProd1 = CreateNewProduct("1'st New Product", 100, 200);

        cmdProd2 = CreateNewProduct("2nd New Product", 300, 600);

        cmdProd1.Connection = cnn;
        cmdProd1.Transaction = trn;

        cmdProd2.Connection = cnn;
        cmdProd2.Transaction = trn;

        // Execute the SQL, Keep Connection Open
        pdp.ExecuteSQL(cmdProd1, false);
        pdp.ExecuteSQL(cmdProd2, false);

        trn.Commit();

        MessageBox.Show("Transaction Completed Successfully");
      }
      catch (PDSADataException ex)
      {
        trn.Rollback();

        MessageBox.Show("Transaction Rolled Back" + Environment.NewLine + ex.ToString());
      }
      catch (Exception ex)
      {
        trn.Rollback();

        MessageBox.Show("Transaction Rolled Back" + Environment.NewLine + ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
        if (trn != null)
          trn.Dispose();
      }
    }

    private string InsertSQL()
    {
      string ret;

      if(AppSettings.Instance.IsOracle)
        ret = AppSettings.Instance.ExecuteSQLParamsOracle;
      else
        ret = AppSettings.Instance.ExecuteSQLParams;

      return ret;
    }

    private IDbCommand CreateNewProduct(string ProductName, decimal Cost, decimal Price)
    {
      IDbCommand cmd;
      IDataParameter param;
      PDSADataProvider pdp;

      pdp = AppSettings.Instance.GetDataProviderForSamples();
      cmd = pdp.CreateCommand(InsertSQL());

      param = pdp.CreateParameter("@ProductName", DbType.String);
      param.Value = ProductName;
      cmd.Parameters.Add(param);

      param = pdp.CreateParameter("@IntroductionDate", DbType.DateTime);
      param.Value = pdp.NowFormatted();
      cmd.Parameters.Add(param);

      param = pdp.CreateParameter("@Cost", DbType.Decimal);
      param.Value = Cost;
      cmd.Parameters.Add(param);

      param = pdp.CreateParameter("@Price", DbType.Decimal);
      param.Value = Price;
      cmd.Parameters.Add(param);

      param = pdp.CreateParameter("@IsDiscontinued", DbType.Byte);
      param.Value = 0;
      cmd.Parameters.Add(param);

      return cmd;
    }
  }
} 