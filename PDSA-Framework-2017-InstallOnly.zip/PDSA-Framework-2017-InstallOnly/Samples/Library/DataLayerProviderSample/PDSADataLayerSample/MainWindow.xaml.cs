﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.DataLayer;
using PDSA.DataLayer.Configuration;

namespace PDSADataLayerSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    PDSADataManager _DataManager = null;

    #region Window Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      Init();
    }
    #endregion

    #region Init Method
    private void Init()
    {
      // Load application settings
      AppSettings.Instance.Load();

      _DataManager = new PDSADataManager();

      try
      {
        cboProviders.DisplayMemberPath = "ProviderName";
        cboProviders.ItemsSource = _DataManager.GetProviderNames();

        if (cboProviders.Items.Count > 0)
        {
          foreach (PDSA.DataLayer.Configuration.PDSADataConfigProvider prov in cboProviders.Items)
          {
            if (prov.ProviderName == _DataManager.GetDefaultProviderName())
            {
              cboProviders.SelectedItem = prov;

              break;
            }
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Providers Changed Event
    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      SetProviderControls();
    }

    private void SetProviderControls()
    {
      PDSADataProvider provider;

      AppSettings.Instance.ProviderName = ((PDSADataConfigProvider)cboProviders.SelectedValue).ProviderName; 

      if (AppSettings.Instance.ProviderName != string.Empty && AppSettings.Instance.ProviderName != "System.Data.DataRowView")
      {
        try
        {
          provider = _DataManager.GetProvider(AppSettings.Instance.ProviderName);

          AppSettings.Instance.IsOracle = provider.ConfigurationProvider.ProviderName.Contains("Oracle");

          tbConnectStringName.Text = provider.ConfigurationProvider.ConnectStringName;
          tbConnectString.Text = provider.ConnectString;
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.ToString());
        }
      }
    }
    #endregion

    #region Open Other Sample Windows
    private void btnConnect_Click(object sender, RoutedEventArgs e)
    {
      winConnect win = new winConnect();

      win.Owner = this;
      win.Show();
    }

    private void btnGetDataSet_Click(object sender, RoutedEventArgs e)
    {
      winGetDataSet win = new winGetDataSet();
      win.Owner = this;
      win.Show();
    }

    private void btnGetDataReader_Click(object sender, RoutedEventArgs e)
    {
      winGetDataReader win = new winGetDataReader();
      win.Owner = this;
      win.Show();
    }

    private void btnUsingParams_Click(object sender, RoutedEventArgs e)
    {
      winParameters win = new winParameters();
      win.Owner = this;
      win.Show();
    }

    private void btnExecuteSQL_Click(object sender, RoutedEventArgs e)
    {
      winExecuteSQL win = new winExecuteSQL();
      win.Owner = this;
      win.Show();
    }

    private void btnExecuteScalar_Click(object sender, RoutedEventArgs e)
    {
      winExecuteScalar win = new winExecuteScalar();
      win.Owner = this;
      win.Show();
    }

    private void btnTransactions_Click(object sender, RoutedEventArgs e)
    {
      winTrans win = new winTrans();
      win.Show();
    }

    private void btnMultipleProviders_Click(object sender, RoutedEventArgs e)
    {
      winMultipleProviders win = new winMultipleProviders();
      win.Show();
    }
    #endregion
  }
}
