﻿using System;
using System.Data;
using System.Windows;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class winParameters : Window
  {
    public winParameters()
    {
      InitializeComponent();
    }

    private void btnInsertDynamic_Click(object sender, RoutedEventArgs e)
    {
      InsertDynamic();
    }

    private void btnInsertSP_Click(object sender, RoutedEventArgs e)
    {
      InsertSP();
    }

    private void InsertDynamic()
    {
      IDbConnection cnn = null;
      IDbCommand cmd = null;
      PDSADataProvider pdp = null;
      IDataParameter param = null;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if (AppSettings.Instance.IsOracle)
          cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQLParamsOracle);
        else
          cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSQLParams);

        param = pdp.CreateParameter("ProductName", DbType.String);
        param.Value = txtProductName.Text;
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("IntroductionDate", DbType.DateTime);
        param.Value = txtIntroDate.Text;
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("Cost", DbType.Decimal);
        param.Value = Convert.ToDecimal(txtCost.Text);
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("Price", DbType.Decimal);
        param.Value = Convert.ToDecimal(txtPrice.Text);
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("IsDiscontinued", DbType.Byte);
        param.Value = chkDiscontinued.IsChecked;
        cmd.Parameters.Add(param);

        cnn = pdp.CreateConnection(pdp.ConnectString, true);
        cmd.Connection = cnn;
        cmd.CommandType = CommandType.Text;
        cmd.ExecuteNonQuery();

        MessageBox.Show("Insert Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void InsertSP()
    {
      IDbConnection cnn = null;
      IDbCommand cmd = null;
      PDSADataProvider pdp = null;
      IDataParameter param = null;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if (AppSettings.Instance.IsOracle)
          cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSPOracle);
        else
          cmd = pdp.CreateCommand(AppSettings.Instance.ExecuteSP);

        param = pdp.CreateParameter("ProductName", DbType.String);
        param.Value = txtProductName.Text;
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("IntroductionDate", DbType.DateTime);
        param.Value = txtIntroDate.Text;
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("Cost", DbType.Decimal);
        param.Value = Convert.ToDecimal(txtCost.Text);
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("Price", DbType.Decimal);
        param.Value = Convert.ToDecimal(txtPrice.Text);
        cmd.Parameters.Add(param);

        param = pdp.CreateParameter("IsDiscontinued", DbType.Byte);
        param.Value = chkDiscontinued.IsChecked;
        cmd.Parameters.Add(param);

        cnn = pdp.CreateConnection(pdp.ConnectString, true);
        cmd.Connection = cnn;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();

        MessageBox.Show("Insert Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtProductName.Text = "A New Product";
      txtIntroDate.Text = DateTime.Now.ToString();
      txtCost.Text = "20";
      txtPrice.Text = "40";
    }
  }
}
