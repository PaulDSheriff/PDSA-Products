﻿using System;
using System.Configuration;
using System.Data;
using System.Windows;

using PDSA.DataLayer;
using PDSA.WPF;

namespace PDSADataLayerSample
{
  public partial class winMultipleProviders : Window
  {
    public winMultipleProviders()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      GridLoad();
    }

    private void GridLoad()
    {
      string sql;
      PDSADataManager mgr = new PDSADataManager();
      DataTable dt;

      if (AppSettings.Instance.IsOracle)
        sql = AppSettings.Instance.SQLOracle;
      else
        sql = AppSettings.Instance.SQL;

      mgr.Provider = AppSettings.Instance.GetDataProviderForSamples();

      try
      {
        // This one uses the currently selected provider
        dt = mgr.Provider.GetDataSet(sql).Tables[0];

        lvwResults.View = PDSAWPFListView.CreateGridViewColumns(dt);
        lvwResults.DataContext = dt;
      }
      catch (Exception ex)
      {
        tbMessages.Text = ex.Message;
      }

      try
      {
        // This will get a DIFFERENT provider        
        mgr = new PDSADataManager();
        mgr.Provider = mgr.GetProvider("SqlClient", "Different");
        // We will use the PDSAFramework500 for this sample.
        mgr.Provider.ConnectString =
          ConfigurationManager.ConnectionStrings["SqlClientFramework"].ConnectionString;
        dt = mgr.Provider.GetDataSet("SELECT * FROM PDSA.pdsaUser").Tables[0];
        lvwResults2.View = PDSAWPFListView.CreateGridViewColumns(dt);
        lvwResults2.DataContext = dt;
      }
      catch (Exception ex)
      {
        tbMessages.Text = ex.Message;
      }
    }
  }
}
