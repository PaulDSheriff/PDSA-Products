﻿using System;
using System.Data;
using System.Windows;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class winGetDataReader : Window
  {
    public winGetDataReader()
    {
      InitializeComponent();
    }

    private const string SQL_EXCEPTION = "SELECT * FROM BLAH";

    private void btnSqlConnString_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnString();
    }

    private void btnSqlConnection_Click(object sender, RoutedEventArgs e)
    {
      TestSqlConnection();
    }

    private void btnCommand_Click(object sender, RoutedEventArgs e)
    {
      TestCommand();
    }

    private void btnCmdConn_Click(object sender, RoutedEventArgs e)
    {
      TestCmdConn();
    }
    
    private void DisplayDataReader(IDataReader dr)
    {
      lstResults.Items.Clear();

      while (dr.Read())
      {
        lstResults.Items.Add(dr[AppSettings.Instance.DisplayMember]);
      }
    }

    private void TestSqlConnString()
    {
      IDataReader dr = null;
      PDSADataProvider pdp;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          dr = pdp.GetDataReader(SQL_EXCEPTION, pdp.ConnectString);
        else
          if (AppSettings.Instance.IsOracle)
            dr = pdp.GetDataReader(AppSettings.Instance.SQLOracle, pdp.ConnectString);
          else
            dr = pdp.GetDataReader(AppSettings.Instance.SQL, pdp.ConnectString);

        DisplayDataReader(dr);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }

    private void TestSqlConnection()
    {
      IDataReader dr = null;
      IDbConnection cnn = null;
      PDSADataProvider pdp;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        cnn = pdp.CreateConnection(pdp.ConnectString, true);

        if ((bool)chkException.IsChecked)
          dr = pdp.GetDataReader(SQL_EXCEPTION, cnn);
        else
          if (AppSettings.Instance.IsOracle)
            dr = pdp.GetDataReader(AppSettings.Instance.SQLOracle, cnn);
          else
            dr = pdp.GetDataReader(AppSettings.Instance.SQL, cnn);

        DisplayDataReader(dr);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
        if (cnn != null)
        {
          cnn.Close();
          cnn.Dispose();
        }
      }
    }

    private void TestCommand()
    {
      IDataReader dr = null;
      IDbCommand cmd;
      PDSADataProvider pdp;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION, pdp.ConnectString);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.SQLOracle, pdp.ConnectString);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.SQL, pdp.ConnectString);

        dr = pdp.GetDataReader(cmd);
        DisplayDataReader(dr);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }

    private void TestCmdConn()
    {
      IDataReader dr = null;
      IDbCommand cmd;
      PDSADataProvider pdp;

      try
      {
        pdp = AppSettings.Instance.GetDataProviderForSamples();

        if ((bool)chkException.IsChecked)
          cmd = pdp.CreateCommand(SQL_EXCEPTION);
        else
          if (AppSettings.Instance.IsOracle)
            cmd = pdp.CreateCommand(AppSettings.Instance.SQLOracle);
          else
            cmd = pdp.CreateCommand(AppSettings.Instance.SQL);

        dr = pdp.GetDataReader(cmd, pdp.ConnectString);
        DisplayDataReader(dr);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
      finally
      {
        if (dr != null)
        {
          dr.Close();
          dr.Dispose();
        }
      }
    }
  }
}
