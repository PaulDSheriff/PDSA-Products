﻿using System.Windows;
using System.Windows.Controls;

using PDSA.DataLayer;

namespace PDSADataLayerSample
{
  public partial class ucProviderInfo : UserControl
  {
    public ucProviderInfo()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      Init();
    }

    private void Init()
    {
      PDSADataManager mgr;

      try
      {
        mgr = new PDSADataManager();

        mgr.Provider = mgr.GetProvider(AppSettings.Instance.ProviderName);

        tbProviderName.Text = AppSettings.Instance.ProviderName;
        tbConnectStringName.Text = mgr.Provider.ConfigurationProvider.ConnectStringName;
        tbConnectString.Text = mgr.Provider.ConnectString;
      }
      catch
      {
        // Ignore Errors, might be at design time
      }

    }
  }
}
