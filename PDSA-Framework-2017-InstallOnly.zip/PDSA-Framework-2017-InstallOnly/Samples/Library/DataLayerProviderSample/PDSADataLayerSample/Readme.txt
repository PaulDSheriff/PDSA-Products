﻿PDSA Data Layer Namespace Sample
----------------------------------------------
This sample illustrates the use of the PDSA Data Layer classes and methods.

You will normally not need to use these classes and methods as the Haystack Code Generator wraps all of this up into classes.

To run this sample:
Install the 'PDSASamples' database from Haystack
Install the 'PDSAFramework500' database from the PDSA Framework
Open the App.Config file and modify the connection strings to point to the PDSASamples and PDSAFramework500 databases.

