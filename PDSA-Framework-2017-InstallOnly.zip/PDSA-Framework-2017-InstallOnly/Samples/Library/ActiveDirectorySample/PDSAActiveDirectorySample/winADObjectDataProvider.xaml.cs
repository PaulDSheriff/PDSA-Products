﻿using System.Windows;

using PDSA.ActiveDirectory;

namespace PDSAActiveDirectorySample
{
  /// <summary>
  /// Interaction logic for winADObjectDataProvider.xaml
  /// </summary>
  public partial class winADObjectDataProvider : Window
  {
    public winADObjectDataProvider()
    {
      InitializeComponent();
    }

    private PDSAActiveDirectory _DirectoryObject = new PDSAActiveDirectory();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _DirectoryObject.LDAPPath = AppSettings.LDAPPath;
      txtLDAPPath.Text = AppSettings.LDAPPath;
      txtDomain.Text = AppSettings.Domain;
    }

    #region Connection / Default Path
    private void btnGetDefaultPath_Click(object sender, RoutedEventArgs e)
    {
      txtLDAPPath.Text = _DirectoryObject.GetDefaultLDAPPath();
    }

    private void btnTestConnection_Click(object sender, RoutedEventArgs e)
    {
      if (_DirectoryObject.IsLDAPPathValid(txtLDAPPath.Text))
      {
        MessageBox.Show("LDAP URL Is Valid.");
      }
      else
      {
        MessageBox.Show("LDAP test failed. May not be connected to the network.");
      }
    }
    #endregion

    #region Get Domains
    private void btnGetDomains_Click(object sender, RoutedEventArgs e)
    {
      GetDomains();
    }

    private void GetDomains()
    {
      PDSAADDomains coll = new PDSAADDomains(txtDomain.Text, txtUserName.Text, txtPassword.Password);

      coll = coll.GetDomains();

      lstDomains.DataContext = coll;
    }
    #endregion

    #region Get User In OU
    private void btnGetUsersInOUs_Click(object sender, RoutedEventArgs e)
    {
      PDSAADUsers bo = new PDSAADUsers();
      string LDAPPath = txtLDAPPath.Text;
      PDSAADOrganizationalUnits selected = new PDSAADOrganizationalUnits();

      // Get OU
      if (lstOUs.ItemsSource != null)
      {
        selected = ((PDSAADOrganizationalUnits)lstOUs.ItemsSource).GetSelected();
      }

      if (selected.Count == 0)
        lstUsers.ItemsSource = bo.GetUsers(txtPartialName.Text.Trim(), txtLDAPPath.Text.Trim());
      else
        lstUsers.ItemsSource = bo.GetUsersInOU(selected, txtPartialName.Text.Trim());
    }
    #endregion

    #region Get Users In Group
    private void btnGetUsersInGroups_Click(object sender, RoutedEventArgs e)
    {
      PDSAADUsers bo = new PDSAADUsers();
      string LDAPPath = txtLDAPPath.Text;
      PDSAADGroups selected = new PDSAADGroups();

      // Get OU
      if (lstGroups.ItemsSource != null)
      {
        selected = ((PDSAADGroups)lstGroups.ItemsSource).GetSelected();
      }

      if (selected.Count == 0)
        lstUsers.DataContext = bo.GetUsers(txtPartialName.Text.Trim(), txtLDAPPath.Text.Trim());
      else
        lstUsers.ItemsSource = bo.GetUsersInGroup(selected, txtPartialName.Text.Trim());
    }
    #endregion

  }
}
