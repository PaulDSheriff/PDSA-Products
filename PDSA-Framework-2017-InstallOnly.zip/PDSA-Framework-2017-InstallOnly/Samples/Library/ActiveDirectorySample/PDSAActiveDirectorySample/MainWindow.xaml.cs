﻿using System.Windows;

namespace PDSAActiveDirectorySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnAD_Click(object sender, RoutedEventArgs e)
    {
      winAD win = new winAD();

      win.Show();
    }

    private void btnADODP_Click(object sender, RoutedEventArgs e)
    {
      winADObjectDataProvider win = new winADObjectDataProvider();

      win.Show();
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      winLogin win = new winLogin();

      win.Owner = this;
      win.ShowDialog();
      if (win.DialogResult.HasValue && win.DialogResult.Value)
        MessageBox.Show("User Logged In");
      else
        MessageBox.Show("User Did NOT Log In");
    }
  }
}
