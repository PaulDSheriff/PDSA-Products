﻿using System;
using System.Windows;

using PDSA.ActiveDirectory;

namespace PDSAActiveDirectorySample
{
  public partial class winAD : Window
  {
    public winAD()
    {
      InitializeComponent();
    }

    #region Private Variables
    private PDSAActiveDirectory _DirectoryObject = new PDSAActiveDirectory();
    #endregion

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // You can uncomment these out if you have fixed your App.Config appropriately.
      //_DirectoryObject.LDAPPath = AppSettings.LDAPPath;
      //txtLDAPPath.Text = AppSettings.LDAPPath;
      //txtDomain.Text = AppSettings.Domain;
    }
    #endregion

    #region Connection / Default Path
    private void btnGetDefaultPath_Click(object sender, RoutedEventArgs e)
    {
      txtLDAPPath.Text = _DirectoryObject.GetDefaultLDAPPath();
    }

    private void btnGetDefaultDomain_Click(object sender, RoutedEventArgs e)
    {
       txtDomainTest.Text = _DirectoryObject.GetDefaultUserDomain();
       if (txtDomain.Text.Length == 0)
          txtDomain.Text = txtDomainTest.Text;
    }


    private void btnTestConnection_Click(object sender, RoutedEventArgs e)
    {
      if (_DirectoryObject.IsLDAPPathValid(txtLDAPPath.Text))
      {
        MessageBox.Show("LDAP URL Is Valid.");
      }
      else
      {
        MessageBox.Show("LDAP test failed. May not be connected to the network.");
      }
    }
    #endregion

    #region Get Domains
    private void btnGetDomains_Click(object sender, RoutedEventArgs e)
    {
      GetDomains();
    }

    private void GetDomains()
    {
      PDSAADDomains coll = null;

      try
      {
        coll = new PDSAADDomains(txtDomain.Text, txtUserName.Text, txtPassword.Password);
        
        coll = coll.GetDomains();

        lstDomains.DataContext = coll;
      }
      catch (Exception ex)
      {
        DisplayError(ex.Message);
      }
    }
    #endregion

    #region Get Organizational Units
    private void btnGetOUs_Click(object sender, RoutedEventArgs e)
    {
      GetOUs();
    }

    private void GetOUs()
    {
      PDSAADOrganizationalUnits coll = new PDSAADOrganizationalUnits();

      coll.AllowAllOUs = true;
      coll = coll.GetOrganizationalUnits(txtPartialOUName.Text, txtLDAPPath.Text);

      lstOUs.DataContext = coll;
    }
    #endregion

    #region Get Groups
    private void btnGetGroups_Click(object sender, RoutedEventArgs e)
    {
      GetGroups();
    }

    private void GetGroups()
    {
      PDSAADGroups coll = new PDSAADGroups();

      coll.AllowAllGroups = true;
      coll = coll.GetGroups(txtPartialGroupName.Text, txtLDAPPath.Text);

      lstGroups.DataContext = coll;
    }
    #endregion

    #region Get Users
    private void btnGetUsers_Click(object sender, RoutedEventArgs e)
    {
      GetUsers();
    }

    private void GetUsers()
    {
      PDSAADUsers coll = new PDSAADUsers();

      coll.AllowAllUsers = true;
      coll = coll.GetUsers(txtPartialName.Text, txtLDAPPath.Text);

      lstUsers.DataContext = coll;
    }
    #endregion

    #region Get User In OU
    private void btnGetUsersInOUs_Click(object sender, RoutedEventArgs e)
    {
      GetUsersInOU();
    }

    private void GetUsersInOU()
    {
      PDSAADUsers bo = new PDSAADUsers();
      string LDAPPath = txtLDAPPath.Text;
      PDSAADOrganizationalUnits selected = new PDSAADOrganizationalUnits();

      // Get OU
      if (lstOUs.ItemsSource != null)
      {
        selected = ((PDSAADOrganizationalUnits)lstOUs.ItemsSource).GetSelected();
      }

      if (selected.Count == 0)
        lstUsers.ItemsSource = bo.GetUsers(txtPartialName.Text.Trim(), txtLDAPPath.Text.Trim());
      else
        lstUsers.ItemsSource = bo.GetUsersInOU(selected, txtPartialName.Text.Trim());
    }
    #endregion

    #region Get Users In Group
    private void btnGetUsersInGroups_Click(object sender, RoutedEventArgs e)
    {
      GetUsersInGroup();
    }

    private void GetUsersInGroup()
    {
      PDSAADUsers bo = new PDSAADUsers();
      string LDAPPath = txtLDAPPath.Text;
      PDSAADGroups selected = new PDSAADGroups();

      // Get OU
      if (lstGroups.ItemsSource != null)
      {
        selected = ((PDSAADGroups)lstGroups.ItemsSource).GetSelected();
      }

      if (selected.Count == 0)
        lstUsers.DataContext = bo.GetUsers(txtPartialName.Text.Trim(), txtLDAPPath.Text.Trim());
      else
        lstUsers.ItemsSource = bo.GetUsersInGroup(selected, txtPartialName.Text.Trim());
    }
    #endregion

    #region DisplayError Method
    private void DisplayError(string msg)
    {
      txtError.Visibility = Visibility.Visible;
      txtError.Text = msg;
    }
    #endregion

    #region Reset Method
    private void Reset()
    {

      txtError.Visibility = Visibility.Collapsed;
      txtError.Text = string.Empty;
    }
    #endregion
  }
}
