﻿using System;
using System.Configuration;

namespace PDSAActiveDirectorySample
{
  public class AppSettings
  {
    public static string LDAPPath
    {
      get { return ConfigurationManager.AppSettings["LDAPPath"]; }
    }

    public static string Domain
    {
      get { return ConfigurationManager.AppSettings["Domain"]; }
    }
  }
}
