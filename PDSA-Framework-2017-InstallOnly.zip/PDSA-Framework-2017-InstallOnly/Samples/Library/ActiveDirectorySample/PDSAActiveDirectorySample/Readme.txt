﻿PDSA.ActiveDirectory Namespace Sample
----------------------------------------------------------------

This sample shows how to use the PDSA.ActiveDirectory Namespace in a winforms application.

Open up the App.Config file and fill in your default LDAP path string.
Or, simply run the application and click on the "Get Default LDAP Path" button and then copy and paste that back into the App.Config file.

You will have to be able to connect to an Active Directory using a valid ID and password on that domain in order to use this sample.