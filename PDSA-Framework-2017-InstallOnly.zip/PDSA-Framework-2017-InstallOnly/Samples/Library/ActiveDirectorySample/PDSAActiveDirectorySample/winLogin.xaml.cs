﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using PDSA.ActiveDirectory;

namespace PDSAActiveDirectorySample
{
  public partial class winLogin : Window
  {
    public winLogin()
    {
      InitializeComponent();
    }
    
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtDomain.Text = Environment.UserDomainName.ToLower();
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      Cursor oldCursor = this.Cursor;

      this.Cursor = Cursors.Wait;
      if (IsUserValid(txtDomain.Text, txtUserName.Text, txtPassword.Password))
      {
        DialogResult = true;
        this.Close();
      }
      else
        MessageBox.Show("Invalid User Name/Password. Please Reenter.");

      this.Cursor = oldCursor;
    }

    private bool IsUserValid(string domain, string userName, string password)
    {
      bool ret = false;
      PDSAADUsers users = new PDSAADUsers();

      if (domain.Length > 0)
        ret = users.AuthenticateUser(domain, userName, password);

      if (ret == false)
        ret = users.AuthenticateLocalUser(userName, password);

      return ret;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
      this.Close();
    }
  }
}
