﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Framework.ViewModelLayer;

namespace PDSAUserSample
{
  public partial class PDSAucUsers : UserControl
  {
    PDSAUserSearchViewModel _ViewModel = null;

    public PDSAucUsers()
    {
      InitializeComponent();

      _ViewModel = (PDSAUserSearchViewModel)this.Resources["viewModel"];
    }

    private void cboApps_DropDownOpened(object sender, EventArgs e)
    {
      if (_ViewModel.Applications.Count == 1)
      {
        _ViewModel.LoadApplications();
      }
    }

    private void cboApps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (_ViewModel != null)
      {
        _ViewModel.ApplicationChanged();
        if (_ViewModel.ApplicationId != -1)
          if (_ViewModel.Entities.Count > 0)  // Work around, binding is not updating for some reason
            cboEntities.SelectedIndex = 0;
      }
    }

    private void cboEntities_DropDownOpened(object sender, EventArgs e)
    {
      if (_ViewModel.ApplicationId != -1)
      {
        if (_ViewModel.Entities.Count == 1)
        {
          _ViewModel.LoadEntitiesByApplication(_ViewModel.ApplicationId);
        }
      }
    }

    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.LoadUsers();
    }

  }
}
