﻿Sql Server Sample
----------------------
This sample illustrates the handling of Sql Server and its multiple instances


Using the ucPDSASqlServerPicker User Control
-----------------------------------------------
The User Control is included right in this project even though it is also contained in the PDSA.SqlServer.Picker.WPF.dll
We placed it here so you can grab this one and style it to match your project.
Feel free to copy this User Control into your project and use it.

Properties
===========================
ConnectString - Get's the final connection string set by the user when using this control
IsConnectStringVisible - Set to true if you want the user to see the connection string
IsCatalogAreaVisible - Set to true if you want the user to select a database from a drop down list after connecting to the server
IsOKButtonVisible - Set to true if you want the OK button to be visible
IsCancelButtonVisible - Set to true if you want the Cancel button to be visible
PreLoadLocalServers - Set to true if you want to pre-load the sql servers on the local machine into the Server's drop down list


Methods
===========================
SetConnectString - Use this to set the connection string and other attributes on the Control


Using the PDSASqlCmdManager class
=====================================================
This class will allow you to submit a .SQL file using the 'sqlcmd' utility