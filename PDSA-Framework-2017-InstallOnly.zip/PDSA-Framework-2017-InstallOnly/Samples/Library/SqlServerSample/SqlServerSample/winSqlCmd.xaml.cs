﻿using System.Windows;

using PDSA.Common;
using PDSA.SqlServer;

namespace SqlServerSample
{
  public partial class winSqlCmd : Window
  {
    private PDSASqlCmdManager _ViewModel = null;

    public winSqlCmd()
    {
      InitializeComponent();

      _ViewModel = (PDSASqlCmdManager)this.Resources["viewModel"];

      _ViewModel.SqlFileName = PDSAString.ExpandSpecialFolders(@"[FrameworkPath]\SqlScripts\SqlServer_PDSAFramework500.sql");
      _ViewModel.DatabaseName = "TestFW";
      
    }

    private void btnSubmit_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.ProcessSqlCmd();
    }
  }
}
