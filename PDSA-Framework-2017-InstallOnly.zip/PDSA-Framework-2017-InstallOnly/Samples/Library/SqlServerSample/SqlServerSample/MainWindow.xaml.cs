﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SqlServerSample
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnAPI_Click(object sender, RoutedEventArgs e)
    {
      winSqlServerAPI win = new winSqlServerAPI();

      win.Show();
    }

    private void btnPicker_Click(object sender, RoutedEventArgs e)
    {
      winCallPicker win = new winCallPicker();

      win.Show();
    }

    private void btnSqlCmd_Click(object sender, RoutedEventArgs e)
    {
      winSqlCmd win = new winSqlCmd();

      win.Show();
    }
  }
}
