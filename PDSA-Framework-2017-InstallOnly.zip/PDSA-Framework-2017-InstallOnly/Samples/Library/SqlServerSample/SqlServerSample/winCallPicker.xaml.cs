﻿using System.Windows;

namespace SqlServerSample
{
  public partial class winCallPicker : Window
  {
    public winCallPicker()
    {
      InitializeComponent();
    }

    private void btnPassConnect_Click(object sender, RoutedEventArgs e)
    {
      winTestPicker win = new winTestPicker();
      win.SetConnectString(txtConnectString.Text);

      win.Show();
    }

    private void btnSqlPicker_Click(object sender, RoutedEventArgs e)
    {
      winTestPicker win = new winTestPicker();

      win.Show();
    }

    private void btnSqlPicker2_Click(object sender, RoutedEventArgs e)
    {
      winTestPicker2 win = new winTestPicker2();

      win.Show();
    }
  }
}
