﻿using System.Windows;
using System.Windows.Input;

using PDSA.SqlServer;

namespace SqlServerSample
{
  public partial class winSqlServerAPI : Window
  {
    public winSqlServerAPI()
    {
      InitializeComponent();
    }

    private void btnLoadLocal_Click(object sender, RoutedEventArgs e)
    {
      LoadLocal();
    }

    private void LoadLocal()
    {
      PDSASqlServers servers = new PDSASqlServers();

      lstServers.DataContext = servers.BuildLocalCollection((bool)chkLocalSqlExpress.IsChecked, (bool)chkGetProductInfo.IsChecked);
    }

    private void btnLoadAll_Click(object sender, RoutedEventArgs e)
    {
      LoadAll();
    }

    private void LoadAll()
    {
      Cursor cur = this.Cursor;
      PDSASqlServers servers = new PDSASqlServers();

      this.Cursor = Cursors.Wait;

      lstServers.DataContext = servers.BuildCollection((bool)chkLocalSqlExpress.IsChecked, (bool)chkRemoteSqlExpress.IsChecked, (bool)chkGetProductInfo.IsChecked);

      this.Cursor = cur;
    }
  }
}
