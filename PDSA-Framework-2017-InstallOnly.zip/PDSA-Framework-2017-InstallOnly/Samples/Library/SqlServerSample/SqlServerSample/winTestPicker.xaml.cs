﻿using System;
using System.Windows;

namespace SqlServerSample
{
  public partial class winTestPicker : Window
  {
    public winTestPicker()
    {
      InitializeComponent();
    }

    public void SetConnectString(string connectString)
    {
      //ucServerPicker.SetConnectionString(connectString);
    }

    private void ucServerPicker_OkButtonClicked(object sender, PDSA.SqlServer.Picker.PDSASqlServerSelectedEventArgs e)
    {
      tbConnect.Text = e.ConnectString;
    }

    private void ucServerPicker_CancelButtonClicked(object sender, EventArgs e)
    {
      MessageBox.Show("Cancel Button Clicked");
    }

    private void ucServerPicker_ConnectionValid(object sender, PDSA.SqlServer.Picker.PDSASqlServerSelectedEventArgs e)
    {
      MessageBox.Show("Connection is Valid");
    }
  }
}
