﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;

using PDSA.Framework.BusinessLayer;
using PDSA.Framework.DataLayer;
using PDSA.Framework.EntityLayer;
using PDSA.Resource;

namespace PDSAResourceSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    // Set up Resource Manager object
    PDSAResourceManager _ResourceManager = null;

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _ResourceManager = new PDSAResourceManager();
      AppResources.Language = txtLanguage.Text;

      LoadProviders();

      txtConnectString.Text = ConfigurationManager.ConnectionStrings["PDSASamples"].ConnectionString;
    }
    #endregion

    #region Provider SelectionChanged Event
    private void cboProviders_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
      SetProvider();
    }
    #endregion

    #region Hard Coded
    private void HardCodedSample()
    {
      PDSAResourceManager mgr = new PDSAResourceManager();
      string resource;

      resource = mgr.Provider.GetResource("MainResource");
    }
    #endregion

    #region Support Methods
    private void LoadProviders()
    {
      try
      {
        cboProviders.DataContext = _ResourceManager.GetProviderNames();

        cboProviders.SelectedValue = _ResourceManager.Provider.ConfigurationProvider.ProviderName;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void SetProvider()
    {
      _ResourceManager.Provider = _ResourceManager.GetProvider(tbProvider.Text);
      txtLanguage.Text = _ResourceManager.Provider.ResourceLanguage;
      txtLocation.Text = _ResourceManager.Provider.Storage;
    }

    private void DisplayResource(string msg)
    {
      tbMessage.Text = msg;
    }

    private void DisplayError(Exception ex)
    {
      tbErrors.Text = ex.ToString();
      tabError.IsSelected = true;
    }
    #endregion

    #region Get Single Resource Event Procedures
    private void btnResourceClassNameNumber_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(_ResourceManager.Provider.GetResource("frmMain", "MainResource", 1));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnResourceName_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(_ResourceManager.Provider.GetResource("MainResource"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnResourceClassName_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(_ResourceManager.Provider.GetResource("frmMain", "MainResource"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnResourceNameNumber_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(_ResourceManager.Provider.GetResource("MainResource", 2));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnResourceID_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(_ResourceManager.Provider.GetResource(4));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnResourceLanguage_Click(object sender, RoutedEventArgs e)
    {
      _ResourceManager.Provider.ResourceLanguage = txtLanguage.Text;
      AppResources.Language = txtLanguage.Text;

      MessageBox.Show("Language has been set to: " + txtLanguage.Text);
    }
    #endregion

    #region Search Method
    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        lstData.View = PDSA.WPF.PDSAWPFListView.CreateGridViewColumns(typeof(pdsaResource));

        lstData.DataContext = _ResourceManager.Provider.SearchResourcesByName(txtSearch.Text);
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }
    #endregion

    #region Exception Resource Methods
    private void btnResourceException_Click(object sender, RoutedEventArgs e)
    {
      ExceptionDisplay();
    }

    private void ExceptionDisplay()
    {
      SqlCommand cmd = null;
      string strSQL;

      //  Attempt to delete an order with Foreign Key Reference
      strSQL = ConfigurationManager.AppSettings["SQL"];

      try
      {
        cmd = new SqlCommand(strSQL);
        cmd.Connection = new SqlConnection(txtConnectString.Text);
        cmd.Connection.Open();

        cmd.ExecuteNonQuery();

      }
      catch (Exception ex)
      {
        MessageBox.Show(_ResourceManager.Provider.GetResource(ex));
      }
    }

    private void btnResourceDisplayException_Click(object sender, RoutedEventArgs e)
    {
      ExceptionClassNameDisplay();
    }

    private void ExceptionClassNameDisplay()
    {
      SqlCommand cmd = null;
      string strSQL;

      //  Attempt to delete an order with Foreign Key Reference
      strSQL = ConfigurationManager.AppSettings["SQL"];

      try
      {
        cmd = new SqlCommand(strSQL);
        cmd.Connection = new SqlConnection(txtConnectString.Text);
        cmd.Connection.Open();

        cmd.ExecuteNonQuery();

      }
      catch (Exception ex)
      {
        MessageBox.Show(_ResourceManager.Provider.GetResource(ex, "frmMain"));
      }
    }

    private void btnResourceExceptionArgNotNull_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        throw new ArgumentNullException("TestParameter");
      }
      catch (Exception ex)
      {
        MessageBox.Show(_ResourceManager.Provider.GetResource(ex));
      }
    }
    #endregion

    #region Cache Method

    // Write out a test record to sample or change the text if it already exists.

    public void btnResetResourceCacheTestRecord_Click(object sender, RoutedEventArgs e)
    {
      ModifyCacheTestRecord("Original Test Cache message");
    }

    // Change Test record to another message to show the cache working.

    private void btnSetNewResource_Click(object sender, RoutedEventArgs e)
    {
      ModifyCacheTestRecord("Reset Test Cache message");
    }

    // Write/Modify test record

    public void ModifyCacheTestRecord(string messageText)
    {
      pdsaResourceManager mgr = new pdsaResourceManager();
      pdsaResource data = new pdsaResource();

      int messageId;

      // Check to see if row is already in database

      data = mgr.GetResource("TestResourceCacheTestRecord", 0, null, null);
      if (data == null)           // Not in database?
      {
        data = new pdsaResource();
        data.ResourceName = "TestResourceCacheTestRecord";
        data.ResourceText = messageText;
        data.ResourceLanguage = "en-US";
        data.SetAsNullFlagForProperty(pdsaResourceValidator.ColumnNames.ResourceNumber, true);
        data.SetAsNullFlagForProperty(pdsaResourceValidator.ColumnNames.ResourceClassName, true);

        mgr.Insert(data);
      }
      else
      {
        messageId = data.ResourceId;
        data.ResourceText = messageText;
        mgr.Update(data);
      }

      // get a message using the business object 

      data = mgr.GetResource("TestResourceCacheTestRecord", 0, null, null);
      if (data != null)
        txtDatabaseRecord.Text = data.ResourceText;
    }

    // Get the Resource from either the database or cache

    private void btnGetResource_Click(object sender, RoutedEventArgs e)
    {
      txtMessage.Text = _ResourceManager.Provider.GetResource("TestResourceCacheTestRecord");
    }

    // Turn the cache on or off.

    private void btnTurnCacheOnOff_Click(object sender, RoutedEventArgs e)
    {
      if (_ResourceManager.Provider.UseCache)
      {
        _ResourceManager.Provider.UseCache = false;
        btnTurnCacheOnOff.Content = "Turn Cache On";
        tbMessage.Text = "Cache is turned off";
      }
      else
      {
        _ResourceManager.Provider.UseCache = true;
        btnTurnCacheOnOff.Content = "Turn Cache Off";
        tbMessage.Text = "Turn Cache On";
      }

    }

    private void btnClearCache_Click(object sender, RoutedEventArgs e)
    {
      _ResourceManager.Provider.ResetCache();
      tbMessage.Text = "Cache is Cleared";
    }

    // Caching Tab was selected.

    private void TabItem_Selected(object sender, RoutedEventArgs e)
    {
      // Set the provider to SqlClient for the cache portion of this sample.

      cboProviders.SelectedValue = "SqlClient";

      if (_ResourceManager.Provider.UseCache)
      {
        btnTurnCacheOnOff.Content = "Turn Cache Off";
        tbMessage.Text = "Cache is turned On";
      }
      else
      {
        btnTurnCacheOnOff.Content = "Turn Cache On";
        tbMessage.Text = "Turn Cache Off";
      }
    }

    private string BuildCacheKey(string mResourceName, int mResourceNumber, string mResourceClassName, string mResourceLanguage, int mResourceID)
    {
      return mResourceClassName + mResourceName + mResourceNumber + mResourceID + mResourceLanguage;
    }

    #endregion

    #region Using AppResources Class
    private void btnAppResourceClassNameNumber_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(AppResources.GetResource("frmMain", "MainResource", 1, "Default value to return"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnAppResourceName_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(AppResources.GetResource("MainResource", "This is getting Main Resource Message"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnAppResourceClassName_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(AppResources.GetResource("frmMain", "MainResource", "Getting Main Resource for frmMain"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnAppResourceNameNumber_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(AppResources.GetResource("MainResource", 2, "Default value to return"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }

    private void btnAppResourceID_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        DisplayResource(AppResources.GetResource(4, "Default value to return"));
      }
      catch (Exception ex)
      {
        DisplayError(ex);
      }
    }
    #endregion
  }
}
