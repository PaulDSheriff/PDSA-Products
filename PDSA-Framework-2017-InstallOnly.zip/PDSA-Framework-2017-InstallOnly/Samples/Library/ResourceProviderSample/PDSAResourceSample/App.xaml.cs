﻿using System.Windows;

namespace PDSAResourceSample
{
  public partial class App : Application
  {
  }
}
