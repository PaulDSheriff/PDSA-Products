﻿PDSA Resource Samples - XML
-------------------------------------------------
When using the XML resources you need to do the following:

1. The App.Config file is already set for this sample
(In the providerName="Xml", the storage= attribute points to the pdsaResources.xml file located in the \Resources folder)


PDSA Resource Samples - SQL Server
-------------------------------------------------
When using the SQL Server resources you need to do the following:

1. Create a database named PDSAFramework500
2. Run [InstallFiles]\SqlScripts\SqlServer_PDSAFramework500.sql in the new database.
3. Adjust the ConnectionString as appropriate in the App.Config to point to this database.
4. For the Exception Based Error you need to use the PDSASamples Database that comes with Haystack


PDSA Resource Samples - Resources
-------------------------------------------------
When using the built-in resources in the project you need to do the following:

1. The App.Config file is already set for this sample
(The *.resx files are located in the \Resources folder. Thus the 'storage' attribute is set to 'PDSAResourceSample_CS.Resources.Messages' which is the namespace followed by the name of the base .resx file. The language you are running under is appended to the file name automatically)