﻿using System;
using System.Windows;

using PDSA.Cryptography;

namespace PDSACryptographySample
{
  public partial class winDPAPI : Window
  {
    #region Constructor
    public winDPAPI()
    {
      InitializeComponent();
    }
    #endregion

    #region Window methods
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      cboStores.ItemsSource = System.Enum.GetNames(typeof(PDSADPAPI.PDSADataStoreEnum));
    }
    
    private void btnEncrypt_Click(object sender, RoutedEventArgs e)
    {
      EncryptDPAPI();
    }

    private void btnDecrypt_Click(object sender, RoutedEventArgs e)
    {
      DecryptDPAPI();
    }
    #endregion

    #region EncryptDPAPI Method
    private void EncryptDPAPI()
    {
      PDSADPAPI dp = new PDSADPAPI();

      try
      {
        if (cboStores.SelectedItem == null)
        {
          MessageBox.Show("Please select a 'Data Store' from the Drop Down List.");
        }
        else
        {
          dp.Entropy = txtEntropy.Text.Trim();
          dp.DataStore = (PDSADPAPI.PDSADataStoreEnum)System.Enum.Parse(typeof(PDSADPAPI.PDSADataStoreEnum), cboStores.Text);

          tbEncrypted.Text = dp.Encrypt(txtOriginal.Text);
          tbDecrypted.Text = "";
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region DecryptDPAPI Method
    private void DecryptDPAPI()
    {
      PDSADPAPI dp = new PDSADPAPI();

      try
      {
        if (tbEncrypted.Text.Trim() == string.Empty)
        {
          MessageBox.Show("The Encrypted text is not populated.");
        }
        else
        {
          dp.Entropy = txtEntropy.Text.Trim();
          dp.DataStore = (PDSADPAPI.PDSADataStoreEnum)System.Enum.Parse(typeof(PDSADPAPI.PDSADataStoreEnum), cboStores.Text);

          tbDecrypted.Text = dp.Decrypt(tbEncrypted.Text);
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Hard Coded Samples
    private void EncryptDPAPIHardCoded()
    {
      PDSADPAPI dp = new PDSADPAPI();

      try
      {
        dp.Entropy = "MYAPP";
        dp.DataStore = PDSADPAPI.PDSADataStoreEnum.USE_MACHINE_STORE;

        tbEncrypted.Text = dp.Encrypt(txtOriginal.Text);
        tbDecrypted.Text = "";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void DecryptDPAPIHardCoded()
    {
      PDSADPAPI dp = new PDSADPAPI();

      try
      {
        dp.Entropy = "MYAPP";
        dp.DataStore = PDSADPAPI.PDSADataStoreEnum.USE_MACHINE_STORE;

        tbDecrypted.Text = dp.Decrypt(tbEncrypted.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion
  }
}