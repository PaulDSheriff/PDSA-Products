﻿using System.Windows;

namespace PDSACryptographySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnDataProtection_Click(object sender, RoutedEventArgs e)
    {
      winDPAPI win = new winDPAPI();

      win.Show();
    }

    private void btnRSA_Click(object sender, RoutedEventArgs e)
    {
      winRSA win = new winRSA();

      win.Show();
    }
  }
}
