﻿using System.Windows;

namespace PDSACryptographySample
{
  public partial class App : Application
  {
  }
}
