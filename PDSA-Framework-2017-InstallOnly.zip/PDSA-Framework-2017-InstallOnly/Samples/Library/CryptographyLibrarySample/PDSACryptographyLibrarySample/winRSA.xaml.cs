﻿using System;
using System.Diagnostics;
using System.Windows;

using PDSA.Cryptography;

namespace PDSACryptographySample
{
  public partial class winRSA : Window
  {
    #region Constructor
    public winRSA()
    {
      InitializeComponent();
    }
    #endregion

    #region Window Events
    private void btnGenKeys_Click(object sender, RoutedEventArgs e)
    {
      GenKeys();
    }

    private void btnEncrypt_Click(object sender, RoutedEventArgs e)
    {
      Encrypt();
    }

    private void btnEncryptInit_Click(object sender, RoutedEventArgs e)
    {
      EncryptUsingInit();
    }

    private void btnDecrypt_Click(object sender, RoutedEventArgs e)
    {
      Decrypt();
    }
    #endregion

    #region GenKeys Method
    private void GenKeys()
    {
      PDSARSA rsa = new PDSARSA();
      rsa.Init();
      txtPublic.Text = rsa.PublicKey;
      txtPrivate.Text = rsa.PrivateKey;
      tbEncrypted.Text = "";
      tbDecrypted.Text = "";
    }
    #endregion

    #region Encrypt Method
    private void Encrypt()
    {
      try
      {
        if (ValidateEncrypt())
        {
          PDSARSA rsa = new PDSARSA();
          rsa.SetPublicKey(txtPublic.Text);
          tbEncrypted.Text = rsa.Encrypt(txtOriginal.Text);
          tbDecrypted.Text = "";
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private bool ValidateEncrypt()
    {

      bool rtn = true;

      if (txtOriginal.Text.Trim().Length == 0)
      {
        MessageBox.Show("The 'String to Encrypt' must be populated.");
        rtn = false;
      }

      if (!ValidateKeys())
        rtn = false;

      return rtn;
    }

    private bool ValidateKeys()
    {
      bool rtn = true;
      if (txtPublic.Text.Trim().Length == 0)
      {
        MessageBox.Show("The 'Public key' must be populated. Please press the 'Generate Keys' button.");
        rtn = false;
      }

      if (txtPrivate.Text.Trim().Length == 0)
      {
        MessageBox.Show("The 'Private key' must be populated. Please press the 'Generate Keys' button.");
        rtn = false;
      }

      return rtn;
    }
    #endregion

    #region EncryptUsingInit Method
    private void EncryptUsingInit()
    {
      PDSARSA rsa = new PDSARSA();

      try
      {
        // The Init Method generates a Public/Private Key
        rsa.Init();

        Debug.WriteLine(rsa.Encrypt(@"Server=Localhost;Database=Sandbox;uid=sa;password=P@ssw0rd"));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Decrypt Method
    private void Decrypt()
    {
      try
      {
        if (ValidateDecrypt())
        {
          PDSARSA rsa = new PDSARSA();
          rsa.SetPrivateKey(txtPrivate.Text);
          tbDecrypted.Text = rsa.Decrypt(tbEncrypted.Text);
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private bool ValidateDecrypt()
    {

      bool rtn = true;

      if (tbEncrypted.Text.Trim().Length == 0)
      {
        MessageBox.Show("The 'Encrypted String' must be populated.  Please press the 'Encrypt' button.");
        rtn = false;
      }

      if (!ValidateKeys())
        rtn = false;

      return rtn;
    }
    #endregion
  }
}