PDSA Cryptography Samples
-------------------------------------------------------
This library shows you how to call the wrapper classes we have placed around the DPAPI and RSA classes in .NET to encrypt and decrypt data.

These classes significantly simplify the .NET classes.