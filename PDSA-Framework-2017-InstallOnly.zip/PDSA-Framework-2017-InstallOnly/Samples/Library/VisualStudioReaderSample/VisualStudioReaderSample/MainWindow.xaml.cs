﻿using System;
using System.Windows;
using Microsoft.Win32;

using PDSA.VisualStudioReader;
using PDSA.WPF;

namespace VisualStudioReaderSample
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    PDSAVSSolution _Solution = new PDSAVSSolution();

    private void btnGetSolution_Click(object sender, RoutedEventArgs e)
    {
      bool? result;
      OpenFileDialog dialog = new OpenFileDialog();
      dialog.Filter = "Solution Files (*.sln)|*.sln";
     
      if (!string.IsNullOrEmpty(txtSolutionFile.Text))
        dialog.FileName = txtSolutionFile.Text;

      result = dialog.ShowDialog();
      if (result.HasValue)
      {
        txtSolutionFile.Text = dialog.FileName;
      }
    }

    private void btnOpenSolution_Click(object sender, RoutedEventArgs e)
    {
      _Solution = new PDSAVSSolution();
      
      lstProjects.ItemsSource = null;
      lstProjects.View = null;
      lstFolders.ItemsSource = null;
      lstFolders.View = null;

      if (_Solution.OpenSolution(txtSolutionFile.Text))
      {
        txtSolutionName.Text = _Solution.SolutionName;
        txtRootPath.Text = _Solution.SolutionRootPath;
        txtFormatVersion.Text = _Solution.FormatVersion;
        DisplayProjects();
      }
      else
        txtMessage.Text = _Solution.LastExceptionMessage;

    }

    private void DisplayProjects()
    {
      lstProjects.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSAVSProject));

      lstProjects.ItemsSource = _Solution.Projects;
    }

    private void lstProjects_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
      if (lstProjects.SelectedItem != null)
      {
        PDSAVSProject project = (PDSAVSProject)lstProjects.SelectedItem;

        lstFolders.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSAVSProjectFolder));
        lstFolders.ItemsSource = project.GetFoldersInProject();
      }
    }
  }
}
