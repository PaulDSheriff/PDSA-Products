PDSA Visual Studio Reader Sample
------------------------------------------------------------------------------------------------

The Visual Studio Reader will read in a Solution (.SLN) file and get a list of Projects

You can also get a list of folders in each project
 