﻿using System;
using System.Windows;

using System.IO;
using PDSA.Tips;
using PDSA.FileIO;

namespace TipsSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      _ViewModel = (PDSAucTipsViewModel)this.Resources["viewModel"];
    }

    private PDSAucTipsViewModel _ViewModel;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      PDSAFileManager file = new PDSAFileManager();
      PDSAFolderManager fm = new PDSAFolderManager();
      
      _ViewModel.TipManager.LocalTipXmlFileName = file.FileNameWithCurrentDirectory(@"\Xml\Tips.xml");
      _ViewModel.TipManager.LocalPathForTips = fm.GetCurrentDirectory() + @"\Tips";
    }

    private void btnLoadTips_Click(object sender, RoutedEventArgs e)
    {
      if (File.Exists(_ViewModel.TipManager.LocalTipXmlFileName))
        _ViewModel.TipManager.LoadTipsFromLocalPath();
      else
        MessageBox.Show("Tip File does not exist.");
    }

    private void btnNextTip_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.TipManager.NextTip();
    }

    private void btnPreviousTip_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.TipManager.PreviousTip();
    }

    private void btnGetTipsXmlFromServer_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.TipManager.CheckAndDownloadNewTips();
    }
  }
}
