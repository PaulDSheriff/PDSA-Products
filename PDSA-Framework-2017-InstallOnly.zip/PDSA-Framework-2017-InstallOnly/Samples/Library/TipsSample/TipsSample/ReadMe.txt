﻿PDSA Tips Sample
-------------------------
This sample illustrates how to use the PDSA Tip system

This system helps you display tips in your application using HTML files