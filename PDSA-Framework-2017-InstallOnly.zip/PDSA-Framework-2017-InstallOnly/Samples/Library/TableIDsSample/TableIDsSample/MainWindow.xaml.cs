﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using PDSA.Common;
using PDSA.DataLayer;
using PDSA.DataLayer.DataClasses;

namespace TableIDsSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private PDSADataManager mManager;
    private PDSADataProvider mProvider;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      mManager = new PDSADataManager();
      mProvider = mManager.Provider;
    }

    private void btnGetNextPK_Click(object sender, RoutedEventArgs e)
    {
      GetNextPK();
    }

    private void GetNextPK()
    {
      IPDSAPKTableId pk;

      try
      {
        pk = mProvider.CreatePKTableIdObject();

        txtNextPK.Text = pk.GetNewPrimaryKey(txtTableName.Text, txtPK.Text, txtLoginName.Text).ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnResetTable_Click(object sender, RoutedEventArgs e)
    {
      ResetTable();
    }

    private void ResetTable()
    {
      IPDSAPKTableId pk;

      try
      {
        pk = mProvider.CreatePKTableIdObject();

        txtNextPK.Text = pk.ResetTableId(txtTableName.Text, txtPK.Text, txtLoginName.Text).ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnResetTableIDs_Click(object sender, RoutedEventArgs e)
    {
      ResetAllTableIDs();
    }

    private void ResetAllTableIDs()
    {
      IPDSAPKTableId pk;

      try
      {
        pk = mProvider.CreatePKTableIdObject();

        pk.ResetAllTableIds();

        MessageBox.Show("All Rows Deleted in pdsaTableId table");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

  }
}