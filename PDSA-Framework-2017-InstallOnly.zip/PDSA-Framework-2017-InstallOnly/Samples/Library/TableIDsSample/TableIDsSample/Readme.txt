﻿TableIDs Sample
----------------------
This sample illustrates the handling of Primary Key table ID's

Running the PK Generation Sample
------------------------------------------------
Check the App.Config file to see if your connection strings are set correctly
The database you point to you contain the pdsaTableIds table