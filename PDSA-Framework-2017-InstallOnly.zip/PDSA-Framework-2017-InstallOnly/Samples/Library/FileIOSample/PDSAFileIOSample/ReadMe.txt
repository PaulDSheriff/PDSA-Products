﻿File Handling Sample
-------------------------
These samples illustrate the handling of files, folders and the recycle bin.
