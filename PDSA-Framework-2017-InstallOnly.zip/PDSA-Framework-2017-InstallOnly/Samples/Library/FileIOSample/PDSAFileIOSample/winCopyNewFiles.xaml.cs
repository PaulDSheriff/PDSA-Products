﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using PDSA.FileIO;

namespace PDSAFileSample
{
   /// <summary>
   /// Interaction logic for winCopyNewFiles.xaml
   /// </summary>
   public partial class winCopyNewFiles : Window
   {
      PDSAFileManager _fileManager = new PDSAFileManager();

      public winCopyNewFiles()
      {
         InitializeComponent();
         _fileManager.ErrorDisplay += new PDSAFileManager.ErrorDisplayEventHandler(mgr_ErrorDisplay);
         _fileManager.MessageDisplay += new PDSAFileManager.MessageDisplayEventHandler(mgr_MessageDisplay);
         txtSource.Text = _fileManager.FullPath(FileIOSampleUtils.FOLDER_FILE_SOURCE);
         txtDestination.Text = _fileManager.FullPath(FileIOSampleUtils.FOLDER_COPY_TO_FOLDER);
      }

      private void copyFileWindow_Loaded(object sender, RoutedEventArgs e)
      {
         Messages = new ObservableCollection<PDSAFileEventArgs>();
      }

      #region Messages Property
      public ObservableCollection<PDSAFileEventArgs> Messages
      {
         get { return (ObservableCollection<PDSAFileEventArgs>)GetValue(MessagesProperty); }
         set { SetValue(MessagesProperty, value); }
      }

      // Using a DependencyProperty as the backing store for Messages.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty MessagesProperty =
          DependencyProperty.Register("Messages", typeof(ObservableCollection<PDSAFileEventArgs>), typeof(winCopyNewFiles), new UIPropertyMetadata(null));
      #endregion

      #region Copy New Files Method
      private void btnCopy_Click(object sender, RoutedEventArgs e)
      {
         if (Validate())
         {
            Messages.Clear();

            _fileManager.CopyNewFilesOnly(txtSource.Text, txtDestination.Text);
         }
      }

      private void btnSourceFolder_Click(object sender, RoutedEventArgs e)
      {
         PDSAFolderManager folderManager = new PDSAFolderManager();
         string folderName = folderManager.GetPathWithDialog("Select Source Folder", txtSource.Text);
         if (folderName.Length > 0)
            txtSource.Text = folderName;
      }

      private void btnDesinationFolder_Click(object sender, RoutedEventArgs e)
      {
         PDSAFolderManager folderManager = new PDSAFolderManager();
         string folderName = folderManager.GetPathWithDialog("Select Desination Folder", txtDestination.Text);
         if (folderName.Length > 0)
            txtDestination.Text = folderName;
      }

      void mgr_MessageDisplay(object sender, PDSAFileEventArgs e)
      {
         Messages.Add(e);
      }

      void mgr_ErrorDisplay(object sender, PDSAFileEventArgs e)
      {
         Messages.Add(e);
      }
      #endregion

      #region Validate Method
      private bool Validate()
      {
         bool ret = false;
         string messages = string.Empty;

         if (txtSource.Text.Trim() == string.Empty)
            messages += "'Source Folder' must be filled in." + Environment.NewLine;
         else
            if (!Directory.Exists(txtSource.Text))
               messages += "'Source Folder' must exist." + Environment.NewLine;

         if (txtDestination.Text.Trim() == string.Empty)
            messages += "'Destination Folder' must be filled in" + Environment.NewLine;
         else
            if (!Directory.Exists(txtDestination.Text))
               messages += "'Destination Folder' must exist." + Environment.NewLine;

         if (messages != string.Empty)
            MessageBox.Show(messages);
         else
            ret = true;

         return ret;
      }
      #endregion

   }
}
