﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winFileManagerLoadDelete : Window
  {
    #region Constructor
    public winFileManagerLoadDelete()
    {
      InitializeComponent();
      txtFolder.Text = _FileManager.FullPath(FileIOSampleUtils.FOLDER_FILE_SOURCE);
    }
    #endregion

    #region Properties and Fields
    PDSAFileManager _FileManager = new PDSAFileManager();
    private Cursor _CurrentCursor = Cursors.Arrow;

    public ObservableCollection<PDSAFileEventArgs> Messages
    {
      get { return (ObservableCollection<PDSAFileEventArgs>)GetValue(MessagesProperty); }
      set { SetValue(MessagesProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Messages.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty MessagesProperty =
        DependencyProperty.Register("Messages", typeof(ObservableCollection<PDSAFileEventArgs>), typeof(winFileManagerLoadDelete), new UIPropertyMetadata(null));
    #endregion

    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      Messages = new ObservableCollection<PDSAFileEventArgs>();

      // Hook up event handlers
      _FileManager.MessageDisplay += new PDSAFileManager.MessageDisplayEventHandler(_FileManager_MessageDisplay);
      _FileManager.ErrorDisplay += new PDSAFileManager.ErrorDisplayEventHandler(_FileManager_ErrorDisplay);
    }
    #endregion

    #region File Manager Event Procedures
    void _FileManager_ErrorDisplay(object sender, PDSAFileEventArgs e)
    {
      Messages.Add(e);
    }

    void _FileManager_MessageDisplay(object sender, PDSAFileEventArgs e)
    {
      Messages.Add(e);
    }
    #endregion

    #region Support Methods
    private void SetWaitCursor()
    {
      _CurrentCursor = this.Cursor;
      this.Cursor = Cursors.Wait;
    }

    private void RestoreCursor()
    {
      this.Cursor = _CurrentCursor;
    }

    private void SetManagerObject(bool doDeleteFiles)
    {
      _FileManager.Reset();

      if (doDeleteFiles)
      {
        _FileManager.WildCard = txtWildCardDelete.Text;
        if (chkLoadSubFoldersDelete.IsChecked == true)
          _FileManager.FileSearchOption = SearchOption.AllDirectories;
        else
          _FileManager.FileSearchOption = SearchOption.TopDirectoryOnly;
        _FileManager.SendDeletedFilesToRecycleBin = Convert.ToBoolean(chkSendToRecycle.IsChecked);
      }
      else
      {
        _FileManager.WildCard = txtWildCard.Text;
        if (chkLoadSubFolders.IsChecked == true)
          _FileManager.FileSearchOption = SearchOption.AllDirectories;
        else
          _FileManager.FileSearchOption = SearchOption.TopDirectoryOnly;
      }
      _FileManager.Files.Clear();
    }

    private void ResetUI()
    {
      txtFileSize.Text = "0 kb";
      txtFileCount.Text = "0";
    }

    private void tabAction_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
      Clear();
    }

    private void Clear()
    {
      try
      {
        Messages.Clear();
        lstData.DataContext = null;
      }
      catch { }
    }
    #endregion

    #region List Files
    private void btnList_Click(object sender, RoutedEventArgs e)
    {
      ListFiles(false);
    }

    private void ListFiles(bool doDeleteFiles)
    {
      try
      {
        SetWaitCursor();

        // Set Manager Object Properties from UI
        SetManagerObject(doDeleteFiles);

        // Clear Messages
        Messages.Clear();

        // Load Files
        if (doDeleteFiles)
          _FileManager.LoadFiles(txtFolderDelete.Text);
        else
        {
          _FileManager.LoadFiles(txtFolder.Text);
          // Display Counts and Lengths
          txtFileSize.Text = _FileManager.GetTotalFileSizes().ToString() + " kb";
          txtFileCount.Text = _FileManager.Files.Count.ToString("###,###");
        }

        if (_FileManager.Files.Count > 0)
        {
          lstData.DataContext = null;
          lstData.DataContext = _FileManager.Files;
        }
        else
          MessageBox.Show("No Files In This Folder");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        RestoreCursor();
      }
    }

    #endregion

    #region Delete Files Methods
    private void btnDeleteSetUp_Click(object sender, RoutedEventArgs e)
    {
      txtFolderDelete.Text = FileIOSampleUtils.CreateDeleteFoldersAndFiles();
      ListFiles(true);
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (txtFolderDelete.Text.Trim() == string.Empty)
        MessageBox.Show("Fill in the 'Top Folder Name' Text Box");
      else
      {
        try
        {
          if (MessageBox.Show("Delete This Folder?" + Environment.NewLine + txtFolderDelete.Text, "Delete", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
          {
            SetWaitCursor();

            // Set Manager Object Properties from UI
            SetManagerObject(true);

            Clear();

            // Delete Files
            if (_FileManager.DeleteFiles(txtFolderDelete.Text))
            {
              RestoreCursor();
              MessageBox.Show("Files Deleted");
            }

            tabMessages.IsSelected = true;
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
        finally
        {
          RestoreCursor();
        }
      }
    }
    #endregion

    #region Check if File Is In Use Method
    private void btnCheckIsInUse_Click(object sender, RoutedEventArgs e)
    {
      FileStream fs = null;
      try
      {
        if (txtFile.Text.Length > 0)
        {
          if (File.Exists(txtFile.Text))
          {

            if ((bool)cbFourceInUse.IsChecked)
            {
              if (!_FileManager.IsFileLocked(txtFile.Text))
              {
                fs = new FileStream(txtFile.Text, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
              }
            }

            if (_FileManager.IsFileLocked(txtFile.Text))
              MessageBox.Show("File is in use");
            else
              MessageBox.Show("File is NOT in use");
          }
          else
            MessageBox.Show("File does not exist, please re-enter");
        }
        else
          MessageBox.Show(string.Format("Please select a File from the list to populate the '{0}' label.", tbFile.Text));

      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (fs != null)
        {
          fs.Close();
          fs.Dispose();
        }
      }
    }
    #endregion
  }
}