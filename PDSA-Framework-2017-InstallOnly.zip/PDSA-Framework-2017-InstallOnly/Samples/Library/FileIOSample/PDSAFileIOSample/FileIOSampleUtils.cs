﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public class FileIOSampleUtils
  {
    public const string FOLDER_TEMP_DELETE = "TempSampleDeleteFromFolder";
    public const string FOLDER_COPY_TO_FOLDER = "SampleCopyToFolder";
    public const string FOLDER_FILE_SOURCE = "SampleFileFolder";

    public static string CreateDeleteFoldersAndFiles()
    {
      PDSAFolderManager _folderManager = new PDSAFolderManager();
      PDSAFileManager _fileManager = new PDSAFileManager();
      string tempFolderName = _folderManager.GetCurrentDirectory() + @"\" + FOLDER_TEMP_DELETE;
      string sourceFolderName = _folderManager.GetCurrentDirectory() + @"\" + FOLDER_FILE_SOURCE;

      if (!System.IO.Directory.Exists(tempFolderName))
        System.IO.Directory.CreateDirectory(tempFolderName);

      _fileManager.CopyNewFilesOnly(sourceFolderName, tempFolderName);

      return tempFolderName;
    }

    public static string CreateDeleteFoldersAndFilesSub()
    {
      string tempFolderName = CreateDeleteFoldersAndFiles();
      CreateSubFolder(tempFolderName);
      return tempFolderName;
    }

    private static void CreateSubFolder(string StartFolder)
    {
      PDSAFolderManager _folderManager = new PDSAFolderManager();
      PDSAFileManager _fileManager = new PDSAFileManager();
      string tempFolderName = StartFolder + @"\" + String.Format("tempFolder_{0}", DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_f"));
      string sourceFolderName = _folderManager.GetCurrentDirectory() + @"\" + FOLDER_FILE_SOURCE;

      if (!System.IO.Directory.Exists(tempFolderName))
        System.IO.Directory.CreateDirectory(tempFolderName);

      _fileManager.CopyNewFilesOnly(sourceFolderName, tempFolderName);

    }
  }
}
