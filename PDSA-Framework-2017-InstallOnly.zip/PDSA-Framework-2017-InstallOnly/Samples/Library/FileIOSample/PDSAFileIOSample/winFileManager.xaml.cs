﻿using System.Windows;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winFileManager : Window
  {
    #region Constructor
    public winFileManager()
    {
      InitializeComponent();
      _fileManager = new PDSAFileManager();
    }
    #endregion

    PDSAFileManager _fileManager;

    #region Events
    private void btnFileNameWithCurrentDir_Click(object sender, RoutedEventArgs e)
    {
      GetFileNameWithCurrentDir();
    }

    private void btnFileAndPathIsValid_Click(object sender, RoutedEventArgs e)
    {
      GetFileAndPathIsValid();
    }

    private void btnFileNameIsValid_Click(object sender, RoutedEventArgs e)
    {
      GetFileNameIsValid();
    }

    private void btnFullPath_Click(object sender, RoutedEventArgs e)
    {
      GetFullPath();
    }

    private void btnGetConfigFileName_Click(object sender, RoutedEventArgs e)
    {
      GetConfigFileName();
    }

    private void btnCreateUserConfigFile_Click(object sender, RoutedEventArgs e)
    {
      CreateUserConfigFile();
    }

    private void btnGetFileName_Click(object sender, RoutedEventArgs e)
    {
      GetFileName();
    }

    private void btnGetPath_Click(object sender, RoutedEventArgs e)
    {
      GetPath();
    }

    private void btnGetBaseFileName_Click(object sender, RoutedEventArgs e)
    {
      GetBaseFileName();
    }

    private void btnGetFileNameNoExt_Click(object sender, RoutedEventArgs e)
    {
      GetFileNameNoExt();
    }

    private void btnGetExtension_Click(object sender, RoutedEventArgs e)
    {
      GetExtension();
    }

    private void btnLoadFoldersDoNotDeleteFilesFrom_Click(object sender, RoutedEventArgs e)
    {
      LoadFoldersDoNotDeleteFilesFrom();
    }

    private void btnGetFileWithDialog_Click(object sender, RoutedEventArgs e)
    {
      GetFileWithDialog();
    }

    private void btnGetFileSize_Click(object sender, RoutedEventArgs e)
    {
      GetFileSize();
    }
    #endregion

    #region GetFileNameWithCurrentDir Method
    private void GetFileNameWithCurrentDir()
    {
      txtFileNameWithCurrentDir.Text = _fileManager.FileNameWithCurrentDirectory(txtFileName.Text);
    }
    #endregion

    #region GetFileAndPathIsValid Method
    private void GetFileAndPathIsValid()
    {
      txtFileAndPathIsValid.Text = _fileManager.FileAndPathIsValid(txtPathFileName.Text).ToString();
    }
    #endregion

    #region GetFileNameIsValid Method
    private void GetFileNameIsValid()
    {
      txtFileNameIsValid.Text = _fileManager.FileNameIsValid(txtFileName.Text).ToString();
    }
    #endregion

    #region GetFullPath Method
    private void GetFullPath()
    {
      txtFullPath.Text = _fileManager.FullPath(txtFileName.Text);
    }
    #endregion

    #region GetConfigFileName Method
    private void GetConfigFileName()
    {
      txtGetConfigFileName.Text = _fileManager.GetConfigFileName();
    }
    #endregion

    #region GetFileSize Method
    private void GetFileSize()
    {
      txtGetFileSize.Text = _fileManager.GetFileSize(_fileManager.GetConfigFileName()).ToString();
    }
    #endregion


    #region CreateUserConfigFile Method
    private void CreateUserConfigFile()
    {
      // Note: Method will copy the ASampleUser.config in the project to user folder
      txtCreateUserConfigFile.Text = _fileManager.CreateUserConfigFile("ASampleUser.config");
    }
    #endregion

    #region GetExtension Method
    private void GetExtension()
    {
      txtGetExtension.Text = _fileManager.GetExtension(txtFileName.Text);
    }
    #endregion

    #region GetFileName Method
    private void GetFileName()
    {
      txtGetFileName.Text = _fileManager.GetFileName(txtPathFileName.Text);
    }
    #endregion

    #region GetPath Method
    private void GetPath()
    {
      txtGetPath.Text = _fileManager.GetPath(txtPathFileName.Text);
    }
    #endregion

    #region GetBaseFileName Method
    private void GetBaseFileName()
    {
      txtGetBaseFileName.Text = _fileManager.GetBaseFileName(txtPathFileName.Text);
    }
    #endregion

    #region GetFileNameNoExt Method
    private void GetFileNameNoExt()
    {
      txtGetFileNameNoExt.Text = _fileManager.GetBaseFileName(txtPathFileName.Text);
    }
    #endregion

    #region LoadFoldersDoNotDeleteFilesFrom Method
    private void LoadFoldersDoNotDeleteFilesFrom()
    {
      _fileManager.LoadFoldersDoNotDeleteFilesFrom();
      lstLoadFoldersDoNotDeleteFilesFrom.DataContext = null;
      lstLoadFoldersDoNotDeleteFilesFrom.DataContext = _fileManager.FoldersDoNotDeleteFilesFrom;
    }
    #endregion

    #region GetFileWithDialog Method
    private void GetFileWithDialog()
    {
      txtGetFileWithDialog.Text = _fileManager.GetFileWithDialog(_fileManager.FullPath(FileIOSampleUtils.FOLDER_FILE_SOURCE), "txt", "Text files (*.txt)|*.txt|All files (*.*)|*.*");
    }
    #endregion
  }
}
