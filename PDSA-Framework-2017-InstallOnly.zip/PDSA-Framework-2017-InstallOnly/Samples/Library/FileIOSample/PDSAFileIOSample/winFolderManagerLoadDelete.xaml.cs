﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using PDSA.FileIO;

namespace PDSAFileSample
{
   public partial class winFolderManagerLoadDelete : Window
   {
      #region Properties and Fields
      PDSAFolderManager _FolderManager = new PDSAFolderManager();
      PDSAFileManager _FileManager = new PDSAFileManager();
      private Cursor _CurrentCursor = Cursors.Arrow;

      public ObservableCollection<PDSAFolderEventArgs> Messages
      {
         get { return (ObservableCollection<PDSAFolderEventArgs>)GetValue(MessagesProperty); }
         set { SetValue(MessagesProperty, value); }
      }

      // Using a DependencyProperty as the backing store for Messages.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty MessagesProperty =
          DependencyProperty.Register("Messages", typeof(ObservableCollection<PDSAFolderEventArgs>), typeof(winFolderManagerLoadDelete), new UIPropertyMetadata(null));
      #endregion

      #region Constructor
      public winFolderManagerLoadDelete()
      {
         InitializeComponent();
         txtFolder.Text =  FileIOSampleUtils.CreateDeleteFoldersAndFiles();
         // Get a couple of folders under the primary one
         FileIOSampleUtils.CreateDeleteFoldersAndFilesSub();
         FileIOSampleUtils.CreateDeleteFoldersAndFilesSub();
      }
      #endregion

      #region Loaded Event Procedure
      private void Window_Loaded(object sender, RoutedEventArgs e)
      {
         Messages = new ObservableCollection<PDSAFolderEventArgs>();

         // Hook up event handlers
         _FolderManager.ErrorDisplay += new PDSAFolderManager.ErrorDisplayEventHandler(_FolderManager_ErrorDisplay);
         _FolderManager.MessageDisplay += new PDSAFolderManager.MessageDisplayEventHandler(_FolderManager_MessageDisplay);
      }
      #endregion

      #region Folder Manager Events
      void _FolderManager_MessageDisplay(object sender, PDSAFolderEventArgs e)
      {
         Messages.Add(e);
      }

      void _FolderManager_ErrorDisplay(object sender, PDSAFolderEventArgs e)
      {
         Messages.Add(e);
      }
      #endregion

      #region Support Methods
      private void SetWaitCursor()
      {
         _CurrentCursor = this.Cursor;
         this.Cursor = Cursors.Wait;
      }

      private void RestoreCursor()
      {
         this.Cursor = _CurrentCursor;
      }

      private void SetManagerObject()
      {
         _FolderManager.WildCard = txtWildCard.Text;
         if (chkLoadSubFolders.IsChecked == true)
            _FolderManager.FolderSearchOption = SearchOption.AllDirectories;
         else
            _FolderManager.FolderSearchOption = SearchOption.TopDirectoryOnly;
         _FolderManager.SendDeletedFoldersToRecycleBin = Convert.ToBoolean(chkSendToRecycle.IsChecked);

         _FolderManager.Folders.Clear();
      }
      #endregion

      #region List Folders
      private void btnList_Click(object sender, RoutedEventArgs e)
      {
         ListFolders();
      }

      private void ListFolders()
      {
         try
         {
            SetWaitCursor();

            // Set Manager Object Properties from UI
            SetManagerObject();

            // Clear Messages
            Messages.Clear();

            // Load Folders
            _FolderManager.LoadFolders(txtFolder.Text);

            // Display Folder Count
            txtFileCount.Text = _FolderManager.Folders.Count.ToString("###,###");

            lstData.DataContext = null;
            lstData.DataContext = _FolderManager.Folders;
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
         finally
         {
            RestoreCursor();
         }
      }

      #endregion
      private void btnAddFolder_Click(object sender, RoutedEventArgs e)
      {
         FileIOSampleUtils.CreateDeleteFoldersAndFilesSub();
         ListFolders();
      }

      #region Delete Folders
      private void btnDelete_Click(object sender, RoutedEventArgs e)
      {

         if (txtFolderToProcess.Text.Trim() == string.Empty)
            MessageBox.Show("Fill in the Folder To Process Text Box");
         else
         {
            try
            {
               if (MessageBox.Show("Delete This Folder?" + Environment.NewLine + txtFolderToProcess.Text, "Delete", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
               {
                  SetWaitCursor();

                  // Set Manager Object Properties from UI
                  SetManagerObject();

                  // Clear Messages
                  Messages.Clear();

                  // Delete Folder
                  if (_FolderManager.DeleteFolder(txtFolderToProcess.Text))
                  {
                     RestoreCursor();
                     MessageBox.Show("Folder Deleted");
                  }

                  ListFolders();

               }
            }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
            finally
            {
               RestoreCursor();
            }
         }
      }
      #endregion

   }
}