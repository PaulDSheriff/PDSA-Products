﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winRecycleBin : Window
  {
    #region Constructor
    public winRecycleBin()
    {
      InitializeComponent();
    }
    #endregion

    #region Properties and Fields
    private Cursor _CurrentCursor = Cursors.Arrow;

    public ObservableCollection<PDSAFolderEventArgs> Messages
    {
      get { return (ObservableCollection<PDSAFolderEventArgs>)GetValue(MessagesProperty); }
      set { SetValue(MessagesProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Messages.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty MessagesProperty =
        DependencyProperty.Register("Messages", typeof(ObservableCollection<PDSAFolderEventArgs>), typeof(winRecycleBin), new UIPropertyMetadata(null));
    #endregion

    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      Messages = new ObservableCollection<PDSAFolderEventArgs>();
    }
    #endregion

    #region Support Methods
    private void SetWaitCursor()
    {
      _CurrentCursor = this.Cursor;
      this.Cursor = Cursors.Wait;
    }

    private void RestoreCursor()
    {
      this.Cursor = _CurrentCursor;
    }
    #endregion

    #region Empty Recycle Bin Methods
    private void btnEmptyRecycleBin_Click(object sender, RoutedEventArgs e)
    {
      if (MessageBox.Show("Empty Recycle Bin?", "Empty Recycle Bin", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
      {
        EmptyRecycleBin();
      }
    }

    private void EmptyRecycleBin()
    {
      try
      {
        SetWaitCursor();

        PDSARecycleBin recycle = new PDSARecycleBin();

        recycle.ErrorDisplay += new PDSARecycleBin.ErrorDisplayEventHandler(recycle_ErrorDisplay);
        recycle.MessageDisplay += new PDSARecycleBin.MessageDisplayEventHandler(recycle_MessageDisplay);

        if (recycle.EmptyRecycleBin())
          MessageBox.Show("Recycle Bin Emptied");
        else
          MessageBox.Show("Recycle Bin NOT Emptied");
      }

      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        RestoreCursor();
      }
    }
    #endregion

    #region MessageDisplay Event
    void recycle_MessageDisplay(object sender, PDSARecycleBinEventArgs e)
    {
      PDSAFolderEventArgs arg = new PDSAFolderEventArgs();
      arg.ClassName = e.ClassName;
      arg.Message = e.Message;
      arg.MethodName = e.MethodName;
      arg.LastException = e.LastException;

      Messages.Add(arg);
    }
    #endregion

    #region ErrorDisplay Event
    void recycle_ErrorDisplay(object sender, PDSARecycleBinEventArgs e)
    {
      PDSAFolderEventArgs arg = new PDSAFolderEventArgs();
      arg.ClassName = e.ClassName;
      arg.Message = e.Message;
      arg.MethodName = e.MethodName;
      arg.LastException = e.LastException;

      Messages.Add(arg);
    }
    #endregion
  }
}