﻿using System.Windows;
using System.Windows.Controls;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winFolders : Window
  {
    #region Constructor
    public winFolders()
    {
      InitializeComponent();
    }
    #endregion

    PDSAFolderManager _folderManager = new PDSAFolderManager();
    PDSAFolders _folders;

    #region GetFolderName Methods
    private void btnGetFolderName_Click(object sender, RoutedEventArgs e)
    {
      txtFolderName.Text = _folderManager.GetPathWithDialog("Select Folder", _folderManager.GetCurrentDirectory());
      if (txtFolderName.Text != string.Empty)
      {
        lstSubFolders.DataContext = null;
        _folders = (PDSAFolders)_folderManager.LoadFolders(txtFolderName.Text);
        lstSubFolders.DataContext = _folders;
      }
      else
        MessageBox.Show("No Folder Selected");
    }

    private void lstSubFolders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      PDSAFolder folder = (PDSAFolder)lstSubFolders.SelectedItem;
      MessageBox.Show(string.Format("Folder: '{0}' HasFolderBeenLoaded: '{1}'", folder.FolderName, _folders.HasFolderBeenLoaded(folder.FolderName)));
    }
    #endregion
  }
}
