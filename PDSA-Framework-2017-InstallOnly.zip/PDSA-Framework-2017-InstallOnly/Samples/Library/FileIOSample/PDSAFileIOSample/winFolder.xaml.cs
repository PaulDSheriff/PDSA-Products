﻿using System.Windows;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winFolder : Window
  {
    #region Constructor
    public winFolder()
    {
      InitializeComponent();
    }
    #endregion
    
    PDSAFolderManager _folderManager = new PDSAFolderManager();

    #region GetFolderName Method
    private void btnGetFolderName_Click(object sender, RoutedEventArgs e)
    {
      GetFolderName();
    }

    private void GetFolderName()
    {
      PDSAFolder Folder;
      txtFolderName.Text = _folderManager.GetPathWithDialog("Select Folder", _folderManager.GetCurrentDirectory());
      if (txtFolderName.Text != string.Empty)
      {
        Folder = new PDSAFolder(txtFolderName.Text);
        txtFolderNameFromFolderObject.Text = Folder.FolderName;
      }
      else
        MessageBox.Show("No Folder Selected");
    }
    #endregion

  }
}
