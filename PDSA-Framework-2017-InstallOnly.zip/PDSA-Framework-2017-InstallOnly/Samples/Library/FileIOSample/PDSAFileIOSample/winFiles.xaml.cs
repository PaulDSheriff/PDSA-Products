﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using PDSA.FileIO;

namespace PDSAFileSample
{
  /// <summary>
  /// Interaction logic for winFiles.xaml
  /// </summary>
  public partial class winFiles : Window
  {
    #region Properties and Fields
    PDSAFileManager _FileManager = new PDSAFileManager();
    private Cursor _CurrentCursor = Cursors.Arrow;
    
    public ObservableCollection<PDSAFileEventArgs> Messages
    {
      get { return (ObservableCollection<PDSAFileEventArgs>)GetValue(MessagesProperty); }
      set { SetValue(MessagesProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Messages.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty MessagesProperty =
        DependencyProperty.Register("Messages", typeof(ObservableCollection<PDSAFileEventArgs>), typeof(winFiles), new UIPropertyMetadata(null));
    #endregion

    #region Constructor
    public winFiles()
    {
      InitializeComponent();
    }
    #endregion

    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      Messages = new ObservableCollection<PDSAFileEventArgs>();

      // Hook up event handlers
      _FileManager.MessageDisplay += new PDSAFileManager.MessageDisplayEventHandler(_FileManager_MessageDisplay);
      _FileManager.ErrorDisplay += new PDSAFileManager.ErrorDisplayEventHandler(_FileManager_ErrorDisplay);
    }
    #endregion

    #region File Manager Event Procedures
    void _FileManager_ErrorDisplay(object sender, PDSAFileEventArgs e)
    {
      Messages.Add(e);
    }

    void _FileManager_MessageDisplay(object sender, PDSAFileEventArgs e)
    {
      Messages.Add(e);
    }
    #endregion

    #region Support Methods
    private void SetWaitCursor()
    {
      _CurrentCursor = this.Cursor;
      this.Cursor = Cursors.Wait;
    }

    private void RestoreCursor()
    {
      this.Cursor = _CurrentCursor;
    }

    private void SetManagerObject()
    {
      _FileManager.WildCard = txtWildCard.Text;
      if (chkLoadSubFolders.IsChecked == true)
        _FileManager.FileSearchOption = SearchOption.AllDirectories;
      else
        _FileManager.FileSearchOption = SearchOption.TopDirectoryOnly;
      _FileManager.SendDeletedFilesToRecycleBin = Convert.ToBoolean(chkSendToRecycle.IsChecked);

      _FileManager.Files.Clear();
    }

    private void ResetUI()
    {
      txtFileSize.Text = "0 kb";
      txtFileCount.Text = "0";
    }
    #endregion

    #region List Files
    private void btnList_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        SetWaitCursor();

        // Set Manager Object Properties from UI
        SetManagerObject();

        // Clear Messages
        Messages.Clear();

        // Load Files
        _FileManager.LoadFiles(txtFolder.Text);

        // Display Counts and Lengths
        txtFileSize.Text = _FileManager.GetTotalFileSizes().ToString() + " kb";
        txtFileCount.Text = _FileManager.Files.Count.ToString("###,###");

        if (_FileManager.Files.Count > 0)
          lstData.DataContext = _FileManager.Files;
        else
          MessageBox.Show("No Files In This Folder");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        RestoreCursor();
      }
    }
    #endregion
    
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (txtFolder.Text.Trim() == string.Empty)
        MessageBox.Show("Fill in the 'Top Folder Name' Text Box");
      else
      {
        try
        {
          if (MessageBox.Show("Delete This Folder?" + Environment.NewLine + txtFolder.Text, "Delete", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
          {
            SetWaitCursor();

            // Set Manager Object Properties from UI
            SetManagerObject();

            // Clear Messages
            Messages.Clear();

            // Delete Files
            if (_FileManager.DeleteFiles(txtFolder.Text))
            {
              RestoreCursor();
              MessageBox.Show("Files Deleted");
            }

            tabMessages.IsSelected = true;
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
        finally
        {
          RestoreCursor();
        }
      }
    }

    private void btnCheckIsInUse_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (File.Exists(txtFile.Text))
        {
          if (_FileManager.IsFileLocked(txtFile.Text))
            MessageBox.Show("File is in use");
          else
            MessageBox.Show("File is NOT in use");
        }
        else
          MessageBox.Show("File does not exist, please re-enter");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}