﻿using System.Windows;

using PDSA.FileIO;

namespace PDSAFileSample
{
  public partial class winFile : Window
  {
    public winFile()
    {
      InitializeComponent();
    }

    #region Get File Name Methods
    private void btnGetFileName_Click(object sender, RoutedEventArgs e)
    {
      GetFileName();
    }

    private void GetFileName()
    {
      PDSAFileManager mgr = new PDSAFileManager();
      PDSAFile file;

      txtFileName.Text = mgr.GetFileWithDialog(string.Empty, string.Empty, string.Empty);
      if (txtFileName.Text != string.Empty)
      {
        file = new PDSAFile(txtFileName.Text);
        txtFileNameFromFileObject.Text = file.FileName;
      }
      else
        MessageBox.Show("No File Selected");
    }
    #endregion
  }
}
