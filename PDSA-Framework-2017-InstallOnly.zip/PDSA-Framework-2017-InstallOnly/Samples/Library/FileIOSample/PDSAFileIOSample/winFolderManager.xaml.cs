﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using PDSA.Common;
using PDSA.FileIO;

namespace PDSAFileSample
{
  /// <summary>
   /// Interaction logic for winFolderManager.xaml
  /// </summary>
  public partial class winFolderManager : Window
  {
     PDSAFolderManager _FolderManager;
     public winFolderManager()
    {
      InitializeComponent();
      _FolderManager = new PDSAFolderManager();
    }

    #region Events

    private void btnGetCurrentDirectory_Click(object sender, RoutedEventArgs e)
    {
       GetCurrentDirectory();
    }

    private void btnGetDriveLetter_Click(object sender, RoutedEventArgs e)
    {
       GetDriveLetter();
    }

    private void btnAddBackSlash_Click(object sender, RoutedEventArgs e)
    {
       AddBackSlash();
    }

    private void btnGetCurrentFolder_Click(object sender, RoutedEventArgs e)
    {
       GetCurrentFolder();
    }

    private void btnGetUserAppDataPath_Click(object sender, RoutedEventArgs e)
    {
       GetUserAppDataPath();
    }

    private void btnGetDotNetFrameworkRootFolder_Click(object sender, RoutedEventArgs e)
    {
       GetDotNetFrameworkRootFolder();
    }

    private void btnGetCurrentDotNetFrameworkFolder_Click(object sender, RoutedEventArgs e)
    {
       GetCurrentDotNetFrameworkFolder();
    }

    private void btnGetPathWithDialog_Click(object sender, RoutedEventArgs e)
    {
       GetPathWithDialog();
    }

    private void btnLoadFoldersDoNotDeleteFilesFrom_Click(object sender, RoutedEventArgs e)
    {
       LoadFoldersDoNotDeleteFilesFrom();
    }

    private void btnLoadFoldersNotAllowedToBeDeleted_Click(object sender, RoutedEventArgs e)
    {
       LoadFoldersNotAllowedToBeDeleted();
    }

    #endregion


    #region PDSA Folder Manager Methods

    private void GetCurrentDirectory()
    {
       txtGetCurrentDirectory.Text = _FolderManager.GetCurrentDirectory();
    }

    private void GetDriveLetter()
    {
       txtGetDriveLetter.Text = _FolderManager.GetCurrentDirectory();
       txtGetDriveLetter.Text = _FolderManager.GetDriveLetter(txtGetDriveLetter.Text);
    }

    private void AddBackSlash()
    {
       txtAddBackSlash.Text = _FolderManager.GetCurrentDirectory();
       txtAddBackSlash.Text = _FolderManager.AddBackSlash(txtAddBackSlash.Text);
    }

    private void GetCurrentFolder()
    {
       txtGetCurrentFolder.Text = _FolderManager.GetCurrentFolder();
    }

    private void GetUserAppDataPath()
    {
       txtGetUserAppDataPath.Text = _FolderManager.GetUserAppDataPath();
    }

    private void GetDotNetFrameworkRootFolder()
    {
       txtGetDotNetFrameworkRootFolder.Text = _FolderManager.GetDotNetFrameworkRootFolder();
    }

    private void GetCurrentDotNetFrameworkFolder()
    {
       txtGetCurrentDotNetFrameworkFolder.Text = _FolderManager.GetCurrentDotNetFrameworkFolder();
    }

    private void GetPathWithDialog()
    {
       txtGetPathWithDialog.Text = string.Empty;
       txtGetPathWithDialog.Text = _FolderManager.GetPathWithDialog("Message Here", _FolderManager.GetCurrentDirectory());
       if (txtGetPathWithDialog.Text.Length == 0)
          MessageBox.Show("No Folder Selected");
    }

    private void LoadFoldersDoNotDeleteFilesFrom()
    {
       _FolderManager.LoadFoldersDoNotDeleteFilesFrom();
       lstLoadFoldersDoNotDeleteFilesFrom.DataContext = null;
       lstLoadFoldersDoNotDeleteFilesFrom.DataContext = _FolderManager.FoldersDoNotDeleteFilesFrom;
    }

    private void LoadFoldersNotAllowedToBeDeleted()
    {
       PDSAFolders folders;
       folders = _FolderManager.LoadFoldersNotAllowedToBeDeleted();
       lstLoadFoldersNotAllowedToBeDeleted.DataContext = null;
       lstLoadFoldersNotAllowedToBeDeleted.DataContext = (PDSAFolders)folders;
    }

    #endregion

  }
}
