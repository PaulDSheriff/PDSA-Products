﻿using System.Windows;

namespace PDSAFileSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
    
    private void btnFile_Click(object sender, RoutedEventArgs e)
    {
      winFile win = new winFile();
      win.Show();
    }

    private void btnNewFilesOnly_Click(object sender, RoutedEventArgs e)
    {
      winCopyNewFiles win = new winCopyNewFiles();
      win.Show();
    }

    private void btnFolderManager_Click(object sender, RoutedEventArgs e)
    {
      winFolderManagerLoadDelete win = new winFolderManagerLoadDelete();
      win.Show();
    }

    private void btnRecycleBin_Click(object sender, RoutedEventArgs e)
    {
      winRecycleBin win = new winRecycleBin();
      win.Show();
    }

    private void btnPDSAFolderManager_Click(object sender, RoutedEventArgs e)
    {
      winFolderManager win = new winFolderManager();
      win.Show();
    }

    private void btnPDSAFolder_Click(object sender, RoutedEventArgs e)
    {
      winFolder win = new winFolder();
      win.Show();
    }

    private void btnPDSAFolders_Click(object sender, RoutedEventArgs e)
    {
      winFolders win = new winFolders();
      win.Show();
    }

    private void btnFileManager_Click(object sender, RoutedEventArgs e)
    {
      winFileManagerLoadDelete win = new winFileManagerLoadDelete();
      win.Show();
    }

    private void btnFileManager1_Click(object sender, RoutedEventArgs e)
    {
      winFileManager win = new winFileManager();
      win.Show();
    }
  }
}
