﻿using System.Windows;

namespace PDSACryptoSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSymmetric_Click(object sender, RoutedEventArgs e)
    {
      winSymmetric win = new winSymmetric();

      win.Owner = this;
      win.Show();
    }

    private void btnHash_Click(object sender, RoutedEventArgs e)
    {
      winHash win = new winHash();

      win.Owner = this;
      win.Show();
    }

    private void btnKeyMgmt_Click(object sender, RoutedEventArgs e)
    {
      winKeyMgmt win = new winKeyMgmt();

      win.Owner = this;
      win.Show();
    }
  }
}
