﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Cryptography.Hash;

namespace PDSACryptoSample
{
  public partial class winHash : Window
  {
    PDSAHashProvider _HashProvider;

    #region Constructor
    public winHash()
    {
      InitializeComponent();
    }
    #endregion

    #region Windows Events
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProvidersLoad();
    }
    private void btnGenSalt_Click(object sender, RoutedEventArgs e)
    {
      txtSalt.Text = _HashProvider.CreateSalt();
    }

    private void btnHash_Click(object sender, RoutedEventArgs e)
    {
      Hash();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      HardCodedSamples();
    }

    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DisplayProviderInfo();
    }

    private void chkUseSalt_CheckedChanged(object sender, EventArgs e)
    {
      txtSalt.IsEnabled = (bool)chkUseSalt.IsChecked;
      btnGenSalt.IsEnabled = (bool)chkUseSalt.IsChecked;
    }
    #endregion

    #region ProvidersLoad Method
    private void ProvidersLoad()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      try
      {
        cboProviders.DisplayMemberPath = "ProviderName";
        cboProviders.ItemsSource = mgr.GetProviderNames();

        if (cboProviders.Items.Count > 0)
        {
          foreach (PDSA.Cryptography.Configuration.PDSAHashConfigProvider prov in cboProviders.Items)
          {
            if (prov.ProviderName == mgr.ConfigurationProviders.DefaultProvider)
            {
              cboProviders.SelectedItem = prov;
              break;
            }
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region DisplayProviderInfo Method
    private void DisplayProviderInfo()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      try
      {
        _HashProvider = mgr.GetProvider(((PDSA.Cryptography.Configuration.PDSAHashConfigProvider)cboProviders.SelectedValue).ProviderName);

        tbProviderType.Text = _HashProvider.ConfigurationProvider.Type;
        tbEncrypted.Text = "";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Hash Method
    private void Hash()
    {
      if ((bool)chkUseSalt.IsChecked)
      {
        _HashProvider.UseSalt = true;
        _HashProvider.SaltValue = txtSalt.Text;
      }
      else
      {
        _HashProvider.UseSalt = false;
        _HashProvider.SaltValue = string.Empty;
      }

      tbEncrypted.Text = _HashProvider.CreateHash(txtOriginal.Text);
    }
    #endregion

    #region Hard Coded Samples
    private void HardCodedSamples()
    {
      GenerateHashUsingDefault();
      GenerateHashUsingDefaultWithSalt();
      GenerateHashUsingSHA1();
      GenerateHashWithSalt();
    }

    private void GenerateHashUsingDefault()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      MessageBox.Show("Hashed Password: " + mgr.Provider.CreateHash("MyPassword"));
    }

    private void GenerateHashUsingDefaultWithSalt()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      mgr.Provider.UseSalt = true;
      mgr.Provider.SaltValue = "somesaltvalue";
      MessageBox.Show("Hashed Password with Salt: " + mgr.Provider.CreateHash("MyPassword"));
    }

    private void GenerateHashUsingSHA1()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      mgr.Provider = mgr.GetProvider("SHA1");

      MessageBox.Show("SHA1 Hashed Password: " + mgr.Provider.CreateHash("MyPassword"));
    }

    private void GenerateHashWithSalt()
    {
      PDSAHashManager mgr = new PDSAHashManager();

      mgr.Provider = mgr.GetProvider("SHA1");
      mgr.Provider.SaltValue = mgr.Provider.CreateSalt();
      mgr.Provider.UseSalt = true;

      MessageBox.Show("Salt: " + mgr.Provider.SaltValue);
      MessageBox.Show("SHA1 Hashed Password with Salt: " + mgr.Provider.CreateHash("MyPassword"));
    }
    #endregion
  }
}
