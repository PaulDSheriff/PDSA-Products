﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

using PDSA.Cryptography.KeyManagement; 

namespace PDSACryptoSample
{
  public partial class winKeyMgmt : Window
  {
    private PDSAKeyMgmtProvider _KeyMgmtProvider;

    #region Constructor
    public winKeyMgmt()
    {
      InitializeComponent();
    }
    #endregion

    #region Window Events
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProvidersLoad();
    }

    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DisplayProviderInfo();
    }

    private void btnSymWrite_Click(object sender, RoutedEventArgs e)
    {
      SymWrite();
    }

    private void btnSymRead_Click(object sender, RoutedEventArgs e)
    {
      SymRead();
    }

    private void btnRSAWrite_Click(object sender, RoutedEventArgs e)
    {
      RSAWrite();
    }

    private void btnRSARead_Click(object sender, RoutedEventArgs e)
    {
      RSARead();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      HardCoded();
    }
    #endregion

    #region ProvidersLoad Method
    private void ProvidersLoad()
    {
      PDSAKeyMgmtManager mgr = new PDSAKeyMgmtManager();

      try
      {
        cboProviders.DisplayMemberPath = "ProviderName";
        cboProviders.ItemsSource = mgr.GetProviderNames();

        if (cboProviders.Items.Count > 0) 
        {
          foreach (PDSA.Cryptography.Configuration.PDSAKeyMgmtConfigProvider prov in cboProviders.Items)
          {
            if (prov.ProviderName == mgr.GetDefaultProviderName()) 
            {
              cboProviders.SelectedItem = prov;

              break;
            }
          }
        }  
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region DisplayProviderInfo Method
    private void DisplayProviderInfo()
    {
      PDSAKeyMgmtManager mgr = new PDSAKeyMgmtManager();

      try
      {
        _KeyMgmtProvider = mgr.GetProvider(((PDSA.Cryptography.Configuration.PDSAKeyMgmtConfigProvider)cboProviders.SelectedValue).ProviderName);

        tbProviderType.Text = _KeyMgmtProvider.ConfigurationProvider.Type;
        txtPublicLocation.Text = _KeyMgmtProvider.ConfigurationProvider.PublicLocation;
        txtPrivateLocation.Text = _KeyMgmtProvider.ConfigurationProvider.PrivateLocation;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Symmetric Methods
    private void SymWrite()
    {
      try
      {
        _KeyMgmtProvider.PublicKey = txtKey.Text;
        _KeyMgmtProvider.PrivateKey = txtIV.Text;
        _KeyMgmtProvider.KeyType = PDSACryptoKeyTypeEnum.Symmetric;
        _KeyMgmtProvider.EncryptKeyInfo = (bool) chkEncrypt.IsChecked;
        _KeyMgmtProvider.Write();

        MessageBox.Show("Writing Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void SymRead()
    {
      txtKey.Text = string.Empty;
      txtIV.Text = string.Empty;
      try
      {
        _KeyMgmtProvider.KeyType = PDSACryptoKeyTypeEnum.Symmetric;
        _KeyMgmtProvider.EncryptKeyInfo = (bool) chkEncrypt.IsChecked;

        _KeyMgmtProvider.Read();
        txtKey.Text = _KeyMgmtProvider.PublicKey;
        txtIV.Text = _KeyMgmtProvider.PrivateKey;

        MessageBox.Show("Reading Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region RSA Methods
    private void RSAWrite(
      )
    {
      try
      {
        _KeyMgmtProvider.PublicKey = txtPublicKey.Text;
        _KeyMgmtProvider.PrivateKey = txtPrivateKey.Text;
        _KeyMgmtProvider.KeyType = PDSACryptoKeyTypeEnum.RSA;
        _KeyMgmtProvider.EncryptKeyInfo = (bool) chkEncrypt.IsChecked;
        _KeyMgmtProvider.Write();

        MessageBox.Show("Writing Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void RSARead()
    {
      txtPublicKey.Text = string.Empty;
      txtPrivateKey.Text = string.Empty;
      try
      {
        _KeyMgmtProvider.KeyType = PDSACryptoKeyTypeEnum.RSA;
        _KeyMgmtProvider.EncryptKeyInfo = (bool) chkEncrypt.IsChecked;

        _KeyMgmtProvider.Read();
        txtPublicKey.Text = _KeyMgmtProvider.PublicKey;
        txtPrivateKey.Text = _KeyMgmtProvider.PrivateKey;

        MessageBox.Show("Reading Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Hard Coded Samples
    private void HardCoded()
    {     
      PDSAKeyMgmtManager mgr = new PDSAKeyMgmtManager();

      txtPublicKey.Text = string.Empty;
      txtPrivateKey.Text = string.Empty;
      try
      {
        _KeyMgmtProvider = mgr.GetProvider("Xml");
        _KeyMgmtProvider.KeyType = PDSACryptoKeyTypeEnum.Symmetric;
        _KeyMgmtProvider.EncryptKeyInfo = false;
        _KeyMgmtProvider.ConfigurationProvider.PrivateLocation = txtPrivateLocation.Text;
        _KeyMgmtProvider.Read();

        txtKey.Text = _KeyMgmtProvider.PublicKey;
        txtIV.Text = _KeyMgmtProvider.PrivateKey;

        MessageBox.Show("Hard Coded Reading of Keys Successful");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }

    }
    #endregion
  }
}