﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Cryptography.Symmetric;

namespace PDSACryptoSample
{
  public partial class winSymmetric : Window
  {
    private PDSASymmetricProvider _SymProvider;

    #region Constructor
    public winSymmetric()
    {
      InitializeComponent();
    }
    #endregion

    #region Windows Events
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProvidersLoad();
    }

    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DisplayProviderInfo();
    }

    private void GenKeyIV_Click(object sender, RoutedEventArgs e)
    {
      GenerateKeyInfo();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      HardCoded();
    }

    private void btnEncrypt_Click(object sender, RoutedEventArgs e)
    {
      Encrypt();
    }

    private void btnDecrypt_Click(object sender, RoutedEventArgs e)
    {
      Decrypt();
    }
    #endregion

    #region ProvidersLoad Method
    private void ProvidersLoad()
    {
      PDSASymmetricManager mgr = new PDSASymmetricManager();

      try
      {
        cboProviders.DisplayMemberPath = "ProviderName";
        cboProviders.ItemsSource = mgr.GetProviderNames();

        if (cboProviders.Items.Count > 0)
        {
          foreach (PDSA.Cryptography.Configuration.PDSASymmetricConfigProvider prov in cboProviders.Items)
          {
            if (prov.ProviderName == mgr.GetDefaultProviderName())
            {
              cboProviders.SelectedItem = prov;
              break;
            }
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region DisplayProviderInfo Method
    private void DisplayProviderInfo()
    {
      PDSASymmetricManager mgr = new PDSASymmetricManager();

      try
      {
        _SymProvider = mgr.GetProvider(((PDSA.Cryptography.Configuration.PDSASymmetricConfigProvider)cboProviders.SelectedValue).ProviderName);

        tbProviderType.Text = _SymProvider.ConfigurationProvider.Type;
        txtKey.Text = "";
        txtIV.Text = "";
        tbEncrypted.Text = "";
        tbDecrypted.Text = "";
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region GenerateKeyInfo Method
    private void GenerateKeyInfo()
    {
      try
      {
        txtKey.Text = _SymProvider.GenerateKey();
        txtIV.Text = _SymProvider.GenerateIV();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Encrypt Method
    private void Encrypt()
    {
      try
      {
        tbEncrypted.Text = _SymProvider.Encrypt(txtOriginal.Text);
      }

      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Decrypt Method
    private void Decrypt()
    {
      try
      {
        tbDecrypted.Text = _SymProvider.Decrypt(tbEncrypted.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Hard Coded Samples
    private void HardCoded()
    {
      EncryptConnectString();
      EncryptUsingHardCodedKeys();
    }

    /// <summary>
    /// This sample uses the default symmetric provider to encrypt a connection string
    /// A random Key and IV are used for the encryption and decryption
    /// </summary>
    private void EncryptConnectString()
    {
      PDSASymmetricManager mgr = new PDSASymmetricManager();
      string encryptedString;

      mgr.Provider.GenerateKey();
      mgr.Provider.GenerateIV();

      encryptedString = mgr.Provider.Encrypt(@"Server=Localhost;Database=Sandbox;uid=sa;pwd=P@ssw0rd");

      MessageBox.Show(encryptedString);

      MessageBox.Show(mgr.Provider.Decrypt(encryptedString));
    }

    /// <summary>
    /// This sample gets the TripleDES symmetric provider and uses a hard coded key and iv for the encryption
    /// </summary>
    private void EncryptUsingHardCodedKeys()
    {
      PDSASymmetricManager mgr = new PDSASymmetricManager();
      string encryptedString;

      mgr.Provider = mgr.GetProvider("TripleDES");
      mgr.Provider.KeyString = "0Ixly1qRWl2BYBrB+dYl2rPbzo2j2aes";
      mgr.Provider.IVString = "uimngi1dPlw=";

      encryptedString = mgr.Provider.Encrypt(@"Server=Localhost;Database=Sandbox;uid=sa;pwd=P@ssw0rd");
      MessageBox.Show(encryptedString);

      MessageBox.Show(mgr.Provider.Decrypt(encryptedString));
    }
    #endregion
  }
}
