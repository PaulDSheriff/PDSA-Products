﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

using PDSA.Framework.DataLayer;
using PDSA.Framework.EntityLayer;
using PDSA.Framework.ViewModelLayer;

namespace PDSAFrameworkSample
{
  public partial class winMenus : Window
  {
    PDSAUserSearchViewModel _ViewModel = null;

    #region Constructor
    public winMenus()
    {
      InitializeComponent();

      _ViewModel = (PDSAUserSearchViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region GetAllMenus Click Event
    private void btnGetAllMenus_Click(object sender, RoutedEventArgs e)
    {
      int userId;

      if (cboUsers.SelectedIndex != -1)
      {
        pdsaMenuItemManager mgr = new pdsaMenuItemManager();
        pdsaMenuItemCollection coll = null;

        userId = Convert.ToInt32(((pdsaUser)cboUsers.SelectedItem).UserId);

        coll = mgr.GetAllMenuItems(_ViewModel.ApplicationId, GetPermissionsForUser(userId), "en-US");
        tvMenus.DataContext = coll;
      }
    }
    #endregion

    #region GetPermissionsForUser Method
    private pdsaPermissionCollection GetPermissionsForUser(int userId)
    {
      pdsaPermission_FindPermissionsAssignedToUserData data = new pdsaPermission_FindPermissionsAssignedToUserData();
      DataTable dt;
      pdsaPermissionCollection ret = new pdsaPermissionCollection();
      pdsaPermission entity;

      data.Entity.ApplicationId = _ViewModel.ApplicationId;
      data.Entity.EntityId = _ViewModel.EntityIdFilter;
      data.Entity.UserId = userId;

      dt = data.GetDataTable();

      foreach (DataRow item in dt.Rows)
      {
        entity = new pdsaPermission();
  
        ret.Add(data.CreateEntityFromDataRow(item));
      }

      return ret;
    }
    #endregion

    #region Loading Apps/Entities/Users Methods
    private void cboApps_DropDownOpened(object sender, EventArgs e)
    {
      if (_ViewModel != null)
      {
        if (_ViewModel.Applications.Count == 1)
        {
          _ViewModel.LoadApplications();
        }
      }
    }

    private void cboApps_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (_ViewModel != null)
      {
        _ViewModel.ApplicationChanged();
        if (_ViewModel.ApplicationId != -1)
          if (_ViewModel.Entities.Count > 0)  // Work around, binding is not updating for some reason
          {
            cboEntities.SelectedIndex = 0;
            if (_ViewModel.Entities.Count == 1)
              _ViewModel.LoadUsers();
          }
      }
    }

    private void cboEntities_DropDownOpened(object sender, EventArgs e)
    {
      if (_ViewModel != null)
      {
        if (_ViewModel.ApplicationId != -1)
        {
          if (_ViewModel.Entities.Count == 1)
          {
            _ViewModel.LoadEntitiesByApplication(_ViewModel.ApplicationId);
          }
        }
      }
    }

    private void cboEntities_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (_ViewModel != null)
      {
        if (_ViewModel.ApplicationId != -1)
        {
          if (_ViewModel.EntityIdFilter != 1)
          {
            _ViewModel.LoadUsers();
          }
        }
      }
    }
    #endregion
  }
}
