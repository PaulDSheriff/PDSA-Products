﻿using System.Windows;

using PDSA.Framework;

namespace PDSAFrameworkSample
{
  public partial class winConfigInfo : Window
  {
    public winConfigInfo()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayMailInfo();
    }

    #region DisplayMailInfo Method
    private void DisplayMailInfo()
    {      
      txtSMTPServer.Text = PDSASettings.AllValues.Application.Mail.SmtpServer;
      chkUseSSL.IsChecked = PDSASettings.AllValues.Application.Mail.UseSsl;
      txtNoReplyAddress.Text = PDSASettings.AllValues.Application.Mail.NoReplyAddress;
      txtSMTPPort.Text = PDSASettings.AllValues.Application.Mail.SmtpPort.ToString();
      txtUserName.Text = PDSASettings.AllValues.Application.Mail.UserName;
      txtPassword.Text = PDSASettings.AllValues.Application.Mail.Password;
    }
    #endregion
  }
}
