﻿Framework Sample
-------------------------

winConfigInfo - This sample shows how to read the config settings related to mail

winMail - This sample illustrates the various ways of sending Mail

winMenus - This sample illustrates how to retrieve menus in a hierarchical format
         - The menus are retrieved for a specific user according to their permissions
         - In order to use this sample, you must ensure that the connection string in the App.Config is pointing to a valid PDSA Framework database
         - You also need to have a Framework application with users in this database
