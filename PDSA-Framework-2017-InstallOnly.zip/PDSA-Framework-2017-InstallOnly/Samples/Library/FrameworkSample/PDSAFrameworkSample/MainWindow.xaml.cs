﻿using System.Windows;

using PDSA.Framework;
using PDSA.Framework.EntityLayer;
using PDSA.Framework.DataLayer;

namespace PDSAFrameworkSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnEmail_Click(object sender, RoutedEventArgs e)
    {
      winMail win = new winMail();

      win.Show();
    }

    private void btnConfigSettings_Click(object sender, RoutedEventArgs e)
    {
      winConfigInfo win = new winConfigInfo();

      win.Show();
    }

    private void btnHierarchicalMenu_Click(object sender, RoutedEventArgs e)
    {
      winMenus win = new winMenus();

      win.Show();
    }
  }
}
