﻿using System;
using System.Net.Mail;
using System.Windows;
using PDSA.Framework;

namespace PDSAFrameworkSample
{
  public partial class winMail : Window
  {
    #region Constructor
    public winMail()
    {
      InitializeComponent();
    }
    #endregion

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtTo.Text = Environment.UserName.ToLower() + "@" + Environment.UserDomainName.ToLower() + ".com";
      txtFrom.Text = Environment.UserName.ToLower() + "@" + Environment.UserDomainName.ToLower() + ".com";
    }

    #region SendMail Method
    private void btnSendMail_Click(object sender, RoutedEventArgs e)
    {
      PDSAMail mail = new PDSAMail();

      mail.Send(txtFrom.Text, txtTo.Text, txtSubject.Text, txtBody.Text);
    }
    #endregion

    #region SendMailAsHtml Method
    private void btnSendMailHtml_Click(object sender, RoutedEventArgs e)
    {
      PDSAMail mail = new PDSAMail();

      mail.Send(txtFrom.Text, txtTo.Text, txtSubject.Text, txtBody.Text, chkBodyHTML.IsChecked.Value);
    }
    #endregion

    #region SendMailUsingEmailObject Method
    private void btnSendMailByMailObject_Click(object sender, RoutedEventArgs e)
    {
      PDSAMail mail = new PDSAMail();
      MailMessage message = new MailMessage();

      message.From = new MailAddress(txtFrom.Text);
      message.To.Add(new MailAddress(txtTo.Text));
      message.Subject = txtSubject.Text;
      message.Body = txtBody.Text;
      message.IsBodyHtml = chkBodyHTML.IsChecked.Value;

      mail.Send(message);
    }
    #endregion
  }
}
