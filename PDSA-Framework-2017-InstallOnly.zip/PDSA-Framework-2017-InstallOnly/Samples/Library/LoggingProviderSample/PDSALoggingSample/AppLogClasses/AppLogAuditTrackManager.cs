﻿using System;
using System.Collections.Specialized;

using PDSA.Common;
using PDSA.Logging;

namespace PDSALoggingSample
{
   /// <summary>
   /// Class to Log Audit Tracking XML that come from Data Classes
   /// </summary>
   public class AppLogAuditTrackManager
   {
      /// <summary>
      /// Log an Insert audit track record
      /// </summary>
      /// <param name="valueToLog">The XML value to log</param>
      /// <param name="tableName">The table name</param>
      /// <param name="key">A unique key (usually the PK of the table)</param>
      public static void Insert(string valueToLog, string tableName, string key)
      {
         Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackInsert);
      }

      /// <summary>
      /// Log an Update audit track record
      /// </summary>
      /// <param name="valueToLog">The XML value to log</param>
      /// <param name="tableName">The table name</param>
      /// <param name="key">A unique key (usually the PK of the table)</param>
      public static void Update(string valueToLog, string tableName, string key)
      {
         Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackUpdate);
      }

      /// <summary>
      /// Log a Delete audit track record
      /// </summary>
      /// <param name="valueToLog">The XML value to log</param>
      /// <param name="tableName">The table name</param>
      /// <param name="key">A unique key (usually the PK of the table)</param>
      public static void Delete(string valueToLog, string tableName, string key)
      {
         Log(valueToLog, tableName, key, PDSALoggingTypes.AuditTrackDelete);
      }

      #region Log Methods
      /// <summary>
      /// Method to log anything. Called by the Insert(), Update() and Delete() methods
      /// This method also calls the AppLogCommon.BuildCommonNVC() method to gather any of your specific data you want to log.
      /// </summary>
      /// <param name="valueToLog">The XML value to log</param>
      /// <param name="tableName">The table name</param>
      /// <param name="key">A unique key (usually the PK of the table)</param>
      /// <param name="logType">The Log Type to Create</param>
      public static void Log(string valueToLog, string tableName, string key, PDSALoggingTypes logType)
      {
         NameValueCollection nvc;
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Grab Standard NVC Values for logging in this Application
         nvc = AppLogCommon.BuildCommonNVC();

         switch (logType)
         {
            case PDSALoggingTypes.AuditTrackInsert:
             mgr.LogAuditTrackInsert(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
            case PDSALoggingTypes.AuditTrackUpdate:
               mgr.LogAuditTrackUpdate(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
            case PDSALoggingTypes.AuditTrackDelete:
               mgr.LogAuditTrackDelete(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
         }
      }

      /// <summary>
      /// Method to log anything. You can also pass in your own Name/Value collection object
      /// </summary>
      /// <param name="valueToLog">The XML value to log</param>
      /// <param name="tableName">The table name</param>
      /// <param name="key">A unique key (usually the PK of the table)</param>
      /// <param name="logType">The Log Type to Create</param>
      /// <param name="nvc">A NameValueCollection Object</param>
      public static void Log(string valueToLog, string tableName, string key, PDSALoggingTypes logType, NameValueCollection nvc)
      {
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Add the passed in NVC values to the standard NVC
         nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

         switch (logType)
         {
            case PDSALoggingTypes.AuditTrackInsert:
             mgr.LogAuditTrackInsert(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
            case PDSALoggingTypes.AuditTrackUpdate:
               mgr.LogAuditTrackUpdate(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
            case PDSALoggingTypes.AuditTrackDelete:
               mgr.LogAuditTrackDelete(tableName, key, valueToLog, AppSettings.Instance.EntityId);
               break;
         }
         
      }
      #endregion
   }
}
