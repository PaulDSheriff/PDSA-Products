﻿using System;
using System.Collections.Specialized;

using PDSA.Common;
using PDSA.Logging;

namespace PDSALoggingSample
{
   /// <summary>
   /// This class makes log entries only during the DEBUG process when running in VS.NET
   /// </summary>
   public class AppLogDebugManager
   {
      /// <summary>
      /// Write a "Debug" entry to the log
      /// </summary>
      /// <param name="valueToLog">The value to write to the log</param>
      public static void Log(string valueToLog)
      {
#if DEBUG
         NameValueCollection nvc;
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Grab Standard NVC Values for logging in this Application
         nvc = AppLogCommon.BuildCommonNVC();

         // Log the Information
         Log(valueToLog, nvc, false);
#endif
      }

      /// <summary>
      /// Write a "Debug" entry to the log
      /// </summary>
      /// <param name="valueToLog">The value to write to the log</param>
      /// <param name="logValueOnly">Log only the 'valueToLog' value, no extra information</param>
      public static void Log(string valueToLog, bool logValueOnly)
      {
#if DEBUG
         NameValueCollection nvc;
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Grab Standard NVC Values for logging in this Application
         nvc = AppLogCommon.BuildCommonNVC();

         // Log the Information
         Log(valueToLog, nvc, logValueOnly);
#endif
      }

      /// <summary>
      /// Write a "Debug" entry to the log
      /// </summary>
      /// <param name="valueToLog">The value to write to the log</param>
      /// <param name="nvc">A NameValueCollection object</param>
      public static void Log(string valueToLog, NameValueCollection nvc)
      {
#if DEBUG
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Add the passed in NVC values to the standard NVC
         nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

         // Log the Information
         Log(valueToLog, nvc, false);
#endif
      }

      /// <summary>
      /// Write a "Debug" entry to the log
      /// </summary>
      /// <param name="valueToLog">The value to write to the log</param>
      /// <param name="nvc">A NameValueCollection object</param>
      /// <param name="systemInfo">Log only the 'valueToLog' value, no extra information</param>
      public static void Log(string valueToLog, NameValueCollection nvc, bool systemInfo)
      {
#if DEBUG
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Set whether or not to just write the 'valueToLog', or include full system information too.
         mgr.ConfigurationProviders.LogSystemInfo = systemInfo;

         // Add the passed in NVC values to the standard NVC
         nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

         // Log the Information
         mgr.LogDebug(valueToLog, nvc, AppSettings.Instance.EntityId);
#endif
      }
   }
}
