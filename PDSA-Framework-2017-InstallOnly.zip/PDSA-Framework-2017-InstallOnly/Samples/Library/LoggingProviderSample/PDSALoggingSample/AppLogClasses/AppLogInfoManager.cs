﻿using System;
using System.Collections.Specialized;

using PDSA.Common;
using PDSA.Logging;

namespace PDSALoggingSample
{
   /// <summary>
   /// Add some Informational message to the log
   /// </summary>
   public class AppLogInfoManager
   {
      /// <summary>
      /// Adds an info message to the log
      /// </summary>
      /// <param name="valueToLog">The value to log</param>
      public static void Log(string valueToLog)
      {
         NameValueCollection nvc;
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Grab Standard NVC Values for logging in this Application
         nvc = AppLogCommon.BuildCommonNVC();

         // Log the Information
         Log(valueToLog, nvc, false);
      }

      /// <summary>
      /// Adds an info message to the log
      /// </summary>
      /// <param name="valueToLog">The value to log</param>
      /// <param name="logValueOnly">Log only the 'valueToLog' value, no extra information</param>
      public static void Log(string valueToLog, bool logValueOnly)
      {
         NameValueCollection nvc;
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Grab Standard NVC Values for logging in this Application
         nvc = AppLogCommon.BuildCommonNVC();

         // Log the Information
         Log(valueToLog, nvc, logValueOnly);
      }

      /// <summary>
      /// Adds an info message to the log
      /// </summary>
      /// <param name="valueToLog">The value to log</param>
      /// <param name="nvc">A NameValueCollection Object</param>
      public static void Log(string valueToLog, NameValueCollection nvc)
      {
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Add the passed in NVC values to the standard NVC
         nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

         // Log the Information
         Log(valueToLog, nvc, false);
      }

      /// <summary>
      /// Adds an info message to the log
      /// </summary>
      /// <param name="valueToLog">The value to log</param>
      /// <param name="nvc">A NameValueCollection Object</param>
      /// <param name="systemInfo">Log only the 'valueToLog' value, no extra information</param>
      public static void Log(string valueToLog, NameValueCollection nvc, bool systemInfo)
      {
         PDSALoggingManager mgr;

         // Get an instance of the Logging Manager
         mgr = AppLogCommon.GetLoggingManager();

         // Set whether or not to just write the 'valueToLog', or include full system information too.
         mgr.ConfigurationProviders.LogSystemInfo = systemInfo;

         // Add the passed in NVC values to the standard NVC
         nvc = PDSACollections.CombineNVCs(nvc, AppLogCommon.BuildCommonNVC());

         // Log the Information
         mgr.Log(valueToLog, nvc, AppSettings.Instance.EntityId);
      }
   }
}
