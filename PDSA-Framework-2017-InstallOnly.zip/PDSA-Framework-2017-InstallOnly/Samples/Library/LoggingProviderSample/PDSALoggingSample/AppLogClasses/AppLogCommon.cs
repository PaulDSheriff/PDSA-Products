﻿using System;
using System.Collections.Specialized;
using PDSA.Logging;

namespace PDSALoggingSample
{
  /// <summary>
  /// This class is for you to add common variables, session variables, application variables, etc. to your Logging manager.
  /// </summary>
  public class AppLogCommon
  {
    #region Private Variables
    private static PDSALoggingManager _LogManager = null;
    #endregion

    #region GetLoggingManager Method
    /// <summary>
    /// Gets the default Logging Manager and Provider.
    /// You can modify this code if you want to add or remove any providers.
    /// However, generally you control this thru the .Config file
    /// </summary>
    /// <returns>A PDSALoggingManager object</returns>
    public static PDSALoggingManager GetLoggingManager()
    {
      if (_LogManager == null)
      {
        _LogManager = new PDSALoggingManager();
        // Initialize the Providers Collection
        _LogManager.GetProvidersCollection();
      }

      return _LogManager;
    }
    #endregion

    #region BuildCommonNVC Method
    /// <summary>
    /// Add your own variables to this method that you wish to store into the log
    /// These will be added to every log entry you make in this application
    /// </summary>
    /// <returns>A NameValueCollection Object</returns>
    public static NameValueCollection BuildCommonNVC()
    {
      NameValueCollection nvc = new NameValueCollection();

      // Add Your Key/Value pairs here. The following two are just samples...
      nvc.Add("Client Machine", Environment.MachineName);
      nvc.Add("User Name", Environment.UserName);
      nvc.Add("WhereAmI", "I am here");

      return nvc;
    }
    #endregion
  }
}
