PDSA Log Handling Samples
--------------------------------------------------------------
This sample shows you how to work with the PDSA logging system in your application

To Run this Sample:
Install the PDSAFramework500 database from the PDSA Framework
Modify the App.Config file and change the connection strings to point to the PDSAFramework500 database
In the "email" provider, modify the "from", "to", and "SMTP" attributes to settings that make sense for your environment.

The winHardCoded.xaml file shows how to just call the PDSALoggingManager directly.

The rest of the XAML files use wrapper classes around the PDSALoggingManager
  These wrapper classes make the calls a little simpler
  The wrapper also allows you to add extra values to your logging
    This is done by using a NameValueCollection class with values you add. You could grab global values, session values in ASP.NET pages, etc.

There are 8 different types of logging you can record in the PDSA Logging System. They are the following:
- Informational
- Exception
- Audit
- Debug
- Warning
- UserLogin
- UserLogout
- UserVisit

For each provider listed in the App.Config file you can specify a semi-colon delimited list of which ones you want to record in which provider.
For example, in the EventLog provider you can see that the 'logTypes' attribute contains only 3 of the 8

<add providerName="eventLog"
     mode="On"
     logSystemInfo="false"
     logTypes="Informational;Warning;Exception"
     logValueOnly="false"
     type="PDSA.Logging.Providers.PDSALogEventLog"
     assembly="PDSA.Logging,Culture=neutral"
     logName="Application"/>

In the SqlServer provider there are all 8 listed.

<add providerName="SqlServer"
     mode="On"
     logSystemInfo="true"
     useStoredProcedures="true"
     logTypes="Informational;Exception;Debug;Audit;Warning;UserLogin;UserLogout;UserVisit"
     logValueOnly="false"
     type="PDSA.Logging.Providers.PDSALogSqlServer"
     assembly="PDSA.Logging.SqlServer,Culture=neutral"
     dataProviderName="SqlClient"/>

If you log an Exception it will go to both the EventLog and the SQL Server because the 'mode' attribute is 'on' for both, and both have 'Exception' listed in their 'logTypes'
However, if you log a 'UserLogin' it will only go to the SQL Server provider because EventLog does not list 'UserLogin' in the 'logTypes'
