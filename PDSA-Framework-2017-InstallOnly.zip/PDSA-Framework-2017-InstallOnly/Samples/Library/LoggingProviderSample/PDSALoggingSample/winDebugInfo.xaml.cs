﻿using System;
using System.Collections.Specialized;
using System.Windows;

namespace PDSALoggingSample
{
  public partial class winDebugInfo : Window
  {
    public winDebugInfo()
    {
      InitializeComponent();
    }

    #region Event Procedures
    private void btnDebug_Click(object sender, RoutedEventArgs e)
    {
      LogDebugInfo();
    }

    private void btnDebugNVC_Click(object sender, RoutedEventArgs e)
    {
      LogDebugInfoWithNVC();
    }

    private void btnInfo_Click(object sender, RoutedEventArgs e)
    {
      LogInfo();
    }

    private void btnInfoNVC_Click(object sender, RoutedEventArgs e)
    {
      LogInfoWithNVC();
    }

    private void btnWarning_Click(object sender, RoutedEventArgs e)
    {
      LogWarningInfo();
    }

    private void btnWarningNVC_Click(object sender, RoutedEventArgs e)
    {
      LogWarningInfoWithNVC();
    }
    #endregion

    private void LogDebugInfo()
    {
      AppLogDebugManager.Log(txtInfo.Text, Convert.ToBoolean(chkLogValueOnly.IsChecked));
    }

    private void LogDebugInfoWithNVC()
    {
      NameValueCollection nvc = new NameValueCollection();

      nvc.Add("FormName", "winDebugInfo");
      nvc.Add("AppName", "PDSALoggingHandler-SampleCS");

      AppLogDebugManager.Log(txtInfo.Text, nvc, Convert.ToBoolean(chkLogValueOnly.IsChecked));
    }

    private void LogInfo()
    {
      AppLogInfoManager.Log(txtInfo.Text, Convert.ToBoolean(chkLogValueOnly.IsChecked));
    }

    private void LogInfoWithNVC()
    {
      NameValueCollection nvc = new NameValueCollection();

      nvc.Add("FormName", "winDebugInfo");
      nvc.Add("AppName", "PDSALoggingHandler-SampleCS");

      AppLogInfoManager.Log(txtInfo.Text, nvc, Convert.ToBoolean(chkLogValueOnly.IsChecked));
    }

    private void LogWarningInfo()
    {
      AppLogWarningManager.Log(txtInfo.Text);
    }

    private void LogWarningInfoWithNVC()
    {
      NameValueCollection nvc = new NameValueCollection();

      nvc.Add("FormName", "winDebugInfo");
      nvc.Add("AppName", "PDSALoggingHandler-SampleCS");

      AppLogWarningManager.Log(txtInfo.Text, nvc, Convert.ToBoolean(chkLogValueOnly.IsChecked));
    }

  }
}
