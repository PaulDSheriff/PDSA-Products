﻿using System;
using System.Collections.Specialized;
using System.Windows;

namespace PDSALoggingSample
{
  public partial class winUserTrack : Window
  {
    public winUserTrack()
    {
      InitializeComponent();
    }

    #region Event Procedures
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtClientName.Text = Environment.MachineName;
    }

    private void btnUserLogin_Click(object sender, RoutedEventArgs e)
    {
      UserLoginTrack();
    }

    private void btnUserLogout_Click(object sender, RoutedEventArgs e)
    {
      UserLogoutTrack();
    }

    private void btnUserVisit_Click(object sender, RoutedEventArgs e)
    {
      UserVisitTrack(txtPageName.Text);
    }

    private void btnUserVisitClient_Click(object sender, RoutedEventArgs e)
    {
      UserVisitTrackClient(txtPageName.Text, txtClientName.Text);
    }
    #endregion

    private void UserLoginTrack()
    {
      AppLogUserTrackManager.Login("User Logged In");
    }

    private void UserLogoutTrack()
    {
      AppLogUserTrackManager.Logout("User Logged Out");
    }

    private void UserVisitTrack(string pageName)
    {
      AppLogUserTrackManager.UserVisit("User Visited: " + pageName, pageName);
    }

    private void UserVisitTrackClient(string pageName, string clientName)
    {
      AppLogUserTrackManager.UserVisit("User Visited: " + pageName, pageName, clientName);
    }
  }
}
