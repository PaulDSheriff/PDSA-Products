﻿using System;
using System.Configuration;

namespace PDSALoggingSample
{
  public class AppSettings
  {
    #region Private Variables
    private int _EntityId = -1;
    #endregion

    #region Static Instance Property
    private static AppSettings _Instance = null;

    /// <summary>
    /// Get/Set a specific instance of an AppSettings class
    /// </summary>
    public static AppSettings Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new AppSettings();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set Entity ID
    /// </summary>
    public int EntityId
    {
      get
      {
        if (_EntityId == -1)
          _EntityId = Convert.ToInt32(ConfigurationManager.AppSettings["EntityId"]);

        return _EntityId;
      }
      set
      {
        if (_EntityId != value)
        {
          _EntityId = value;
        }
      }
    }
    #endregion
  }
}
