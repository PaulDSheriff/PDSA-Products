﻿using System.Collections.Specialized;
using System.Windows;

namespace PDSALoggingSample
{
  /// <summary>
  /// Interaction logic for winAuditTrack.xaml
  /// </summary>
  public partial class winAuditTrack : Window
  {
    public winAuditTrack()
    {
      InitializeComponent();
    }

    #region Audit Track Insert
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      AuditTrackInsert();
    }

    private void AuditTrackInsert()
    {
      AppLogAuditTrackManager.Insert(txtAuditXml.Text, txtTableName.Text, txtPrimaryKey.Text);
    }
    #endregion

    #region Audit Track Update
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      AuditTrackUpdate();
    }

    private void AuditTrackUpdate()
    {
      AppLogAuditTrackManager.Update(txtAuditXml.Text, txtTableName.Text, txtPrimaryKey.Text);
    }
    #endregion

    #region Audit Track Delete
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      AuditTrackDelete();
    }

    private void AuditTrackDelete()
    {
      AppLogAuditTrackManager.Delete(txtAuditXml.Text, txtTableName.Text, txtPrimaryKey.Text);
    }
    #endregion
  }
}
