﻿using System.Windows;

namespace PDSALoggingSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      winHardCoded win = new winHardCoded();

      win.Owner = this;
      win.Show();
    }

    private void btnException_Click(object sender, RoutedEventArgs e)
    {
      winException win = new winException();

      win.Owner = this;
      win.Show();
    }

    private void btnDebugInfo_Click(object sender, RoutedEventArgs e)
    {
      winDebugInfo win = new winDebugInfo();

      win.Owner = this;
      win.Show();
    }

    private void btnAuditTrack_Click(object sender, RoutedEventArgs e)
    {
      winAuditTrack win = new winAuditTrack();

      win.Owner = this;
      win.Show();
    }

    private void btnUserTrack_Click(object sender, RoutedEventArgs e)
    {
      winUserTrack win = new winUserTrack();

      win.Owner = this;
      win.Show();
    }

  }
}
