﻿using System;
using System.Collections.Specialized;
using System.Windows;

using PDSA.Logging;

namespace PDSALoggingSample
{
  public partial class winHardCoded : Window
  {
    // Create Logging Manager globally so we can just use a single instance.
    PDSALoggingManager _LogManager = null;

    public winHardCoded()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Create an instance of the Logging Manager
      _LogManager = new PDSALoggingManager();
    }


    private void btnInfo_Click(object sender, RoutedEventArgs e)
    {
      PDSALoggingManager mgr = new PDSALoggingManager();

      // Just use the 'Log' method for informational logs
      mgr.Log("This is some pure informational text");

      // Pass in Default Entity ID from the App.Config file
      // Logging the entity let's us know to which application this log belongs
      mgr.Log("This is some pure informational text",
       AppSettings.Instance.EntityId);
    }

    private void btnInfoExtraValues_Click(object sender, RoutedEventArgs e)
    {
      PDSALoggingManager mgr = new PDSALoggingManager();

      // Publish some extra values along with the exception information
      NameValueCollection nvc = new NameValueCollection();

      nvc.Add("Value1", "This is Value 1");
      nvc.Add("Value2", "This is Value 2");

      // Just use the 'Log' method for informational logs
      mgr.Log("This is some pure informational text", nvc);
    }

    private void btnDebug_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogDebug("This is some DEBUG text");
    }

    private void btnWarn_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogWarning("This is a WARNING!");
    }

    private void btnAudit_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogAuditTrackInsert("ProductTable", "212",
        "<AuditRecord><Column name='ProductId' insertedValue='213' /></AuditRecord>");
    }

    private void btnUserVisit_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogUserVisit("BJones", "Default.aspx");
    }

    private void btnUserLogin_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogUserLogin("BJones");
    }

    private void btnUserLogout_Click(object sender, RoutedEventArgs e)
    {
      _LogManager.LogUserLogout("BJones");
    }

    private void btnException_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        // Do something to create an exception
        throw new ArgumentNullException("BadArgument");
      }
      catch (Exception ex)
      {
        PDSALoggingManager mgr = new PDSALoggingManager();
        // Log the exception 
        mgr.LogException(ex);

        MessageBox.Show("Exception has been published.");
      }
    }

    private void btnExceptionExtra_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        // Do something to create an exception
        throw new ArgumentNullException("BadArgument");
      }
      catch (Exception ex)
      {
        // Publish some extra values along with the exception information
        NameValueCollection nvc = new NameValueCollection();

        nvc.Add("Value1", "This is Value 1");
        nvc.Add("Value2", "This is Value 2");

        // Log the exception with the default Entity ID from the App.Config File
        // Logging the entity let's us know to which application this exception belongs
        _LogManager.LogException(ex, nvc,
          AppSettings.Instance.EntityId);

        MessageBox.Show("Exception has been published.");
      }
    }
  }
}
