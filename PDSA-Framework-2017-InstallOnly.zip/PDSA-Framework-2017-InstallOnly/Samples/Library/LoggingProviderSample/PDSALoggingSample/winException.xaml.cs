﻿using System;
using System.Collections.Specialized;
using System.Data;
using System.Windows;
using System.Windows.Input;

using PDSA.Logging;

namespace PDSALoggingSample
{
  public partial class winException : Window
  {
    public winException()
    {
      InitializeComponent();
    }

    #region Event Procedures
    private void btnPublish_Click(object sender, RoutedEventArgs e)
    {
      PublishNormal();
    }

    private void btnExtraValues_Click(object sender, RoutedEventArgs e)
    {
      PublishExtraValues();
    }

    private void btnFatal_Click(object sender, RoutedEventArgs e)
    {
      PublishFatal();
    }
    #endregion

    private void PublishNormal()
    {
      DataSet ds = null;
       
      this.Cursor = Cursors.Wait;
      try
      {
        ds.ReadXml("Test");
      }       
      catch (Exception ex)
      {
        AppLogExceptionManager.Log(ex);

        MessageBox.Show("Success Publishing!" + Environment.NewLine + Environment.NewLine + ex.ToString());
      }

      this.Cursor = Cursors.Arrow; 
    }     

    private void PublishExtraValues()
    {
      DataSet ds = null;
      NameValueCollection nvc = new NameValueCollection();
       
      this.Cursor = Cursors.Wait;
      try
      {
        ds.ReadXml("Test");
      }
      catch (Exception ex)
      {
        nvc.Add("ClassName", "frmMain");
        nvc.Add("MethodName", "PublishExtraValues");
        nvc.Add("LoginName", Environment.UserName);

        AppLogExceptionManager.Log(ex, nvc);

        MessageBox.Show("Success Publishing with Extra Values!" + Environment.NewLine + Environment.NewLine + ex.ToString());
      }

      this.Cursor = Cursors.Arrow; 
    }
 
    private void PublishFatal()
    {
      DataSet ds = null;
      PDSALoggingManager mgr;
      PDSALoggingProvider pe;

      // Get an instance of the Logging Manager
      mgr = AppLogCommon.GetLoggingManager();
           
      this.Cursor = Cursors.Wait;

      // NOTE: Before running this, change the provider to invalid value
      pe = mgr.GetProvider("email");
      pe.ConfigurationProvider.ExtraAttributesCollection["SMTP"] = "111.111.111.111";
      pe.ConfigurationProvider.Mode = "On";
      mgr.Provider = pe;

      try
      {
        ds.ReadXml("Test");
      }
      catch (Exception ex)
      {
        mgr.LogException(ex,1);

        MessageBox.Show("Success Publishing!" + Environment.NewLine + Environment.NewLine + ex.ToString());
      }

      this.Cursor = Cursors.Arrow; 
    }
  }
} 
