﻿using System;
using System.Security;
using System.Windows;
using System.Windows.Controls;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winRegistry : Window
  {
    public winRegistry()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      LoadHives();
      txtKeyName.Text = CommonSampleUtils.GetSampleKeyName();
      SetSecurityControls();
      SetRemoteMachineControls();
      LoadSubKeyName();
    }

    #region Init Methods
    private void LoadHives()
    {
      cboHives.ItemsSource = System.Enum.GetNames(typeof(PDSARegistry.PDSAHive));
      cboHives.SelectedIndex = (int)PDSARegistry.PDSAHive.CurrentUser;
    }
    #endregion

    #region Events

    private void btnLoadSampleData_Click(object sender, RoutedEventArgs e)
    {
      PDSAUserIdentity us = null;
      bool valid = true;
      try
      {

        if (Convert.ToBoolean(chkUseSecurity.IsChecked))
        {
          if (FormValid())
          {
            us = new PDSAUserIdentity();
            us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
            us.Impersonate();
          }
          else
            valid = false;
        }

        if (valid)
        {
          CommonSampleUtils.DeleteSampleValues(GetSelectedHive(), txtKeyName.Text, GetMachineName());
          CommonSampleUtils.BuildRegistry(GetSelectedHive(), txtKeyName.Text, GetMachineName());
          LoadSubKeyName();
          lblMessage.Text = "Sample data populated.  Open Regedit for the above hive and key to view.";
        }
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (us != null)
        {
          us.Undo();
        }
      }
    }


    private void btnRemoveSampleData_Click(object sender, RoutedEventArgs e)
    {
      PDSAUserIdentity us = null;
      bool valid = true;
      try
      {

        if (Convert.ToBoolean(chkUseSecurity.IsChecked))
        {
          if (FormValid())
          {
            us = new PDSAUserIdentity();
            us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
            us.Impersonate();
          }
          else
            valid = false;
        }

        if (valid)
        {
          CommonSampleUtils.DeleteSampleValues(GetSelectedHive(), txtKeyName.Text, GetMachineName());
          LoadSubKeyName();
          lblMessage.Text = "Sample data removed.";
        }
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (us != null)
        {
          us.Undo();
        }
      }
    }


    private void chkUseSecurity_Click(object sender, RoutedEventArgs e)
    {
      SetSecurityControls();
    }

    private void chkUseRemoteMachine_Click(object sender, RoutedEventArgs e)
    {
      SetRemoteMachineControls();
    }

    private void btnNew_Click(object sender, RoutedEventArgs e)
    {
      txtSubKeyName.IsEnabled = true;
      txtSubKeyName.Text = string.Empty;
      txtSubKeyValue.Text = string.Empty;
      btnDelete.IsEnabled = false;
      txtSubKeyName.Focus();
      lblMessage.Text = "Please enter a 'Sub Key Name' and value.";
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      DoDeleteRegistry();
    }

    private void btnWrite_Click(object sender, RoutedEventArgs e)
    {
      DoWriteRegistry();
      btnDelete.IsEnabled = true;
    }

    private void cboSubKeyName_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (cboSubKeyName.SelectedItem != null)
      {
        txtSubKeyName.Text = cboSubKeyName.SelectedItem.ToString();
        txtSubKeyName.IsEnabled = false;
        btnDelete.IsEnabled = true;
        DoReadRegistry();
      }
      else
      {
      }
    }

    #endregion

    #region Read Registry Methods
    private void DoReadRegistry()
    {
      if (Convert.ToBoolean(chkUseSecurity.IsChecked))
      {
        if (FormValid())
          RegistryReadSecurity();
      }
      else
        RegistryRead();
    }

    private void RegistryReadSecurity()
    {
      PDSAUserIdentity us = new PDSAUserIdentity();
      try
      {
        us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
        us.Impersonate();

        RegistryRead();
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (us != null)
        {
          us.Undo();
        }
      }
    }

    private void RegistryRead()
    {
      PDSARegistry reg = new PDSARegistry();

      try
      {
        reg.Hive = reg.StringToPDSAHive(cboHives.Text);
        reg.RemoteMachine = GetMachineName();

        switch (txtSubKeyName.Text)
        {
          case CommonSampleUtils.REG_SUB_KEY_NAME_BOOL:
            bool valueBool = reg.ReadAsBoolean(txtKeyName.Text, txtSubKeyName.Text);
            txtSubKeyValue.Text = valueBool.ToString();
            break;
          case CommonSampleUtils.REG_SUB_KEY_NAME_DATE:
            DateTime valueDateTime = reg.ReadAsDateTime(txtKeyName.Text, txtSubKeyName.Text);
            txtSubKeyValue.Text = valueDateTime.ToString();
            break;
          case CommonSampleUtils.REG_SUB_KEY_NAME_DECIMAL:
            decimal valueDecimal = reg.ReadAsDecimal(txtKeyName.Text, txtSubKeyName.Text);
            txtSubKeyValue.Text = valueDecimal.ToString();
            break;
          case CommonSampleUtils.REG_SUB_KEY_NAME_INTEGER:
            int valueInt = reg.ReadAsInteger(txtKeyName.Text, txtSubKeyName.Text);
            txtSubKeyValue.Text = valueInt.ToString();
            break;
          case CommonSampleUtils.REG_SUB_KEY_NAME_SHORT:
            short valueShort = reg.ReadAsShort(txtKeyName.Text, txtSubKeyName.Text);
            txtSubKeyValue.Text = valueShort.ToString();
            break;
          case CommonSampleUtils.REG_SUB_KEY_NAME_STRING:
            txtSubKeyValue.Text = reg.Read(txtKeyName.Text, txtSubKeyName.Text, GetMachineName());
            break;
          default:
            txtSubKeyValue.Text = reg.Read(txtKeyName.Text, txtSubKeyName.Text, "", GetMachineName());
            break;
        }
        lblMessage.Text = string.Format("The Sub Key '{0}' has a value of '{1}'.", txtSubKeyName.Text, txtSubKeyValue.Text);
      }
      catch (SecurityException ex)
      {
        lblMessage.Text = "You do not have permissions to access this registry key." + Environment.NewLine + ex.Message;
        MessageBox.Show(lblMessage.Text.ToString());
        txtSubKeyValue.Text = string.Empty;
      }
      catch (Exception ex)
      {
        lblMessage.Text = ex.Message;
        MessageBox.Show(lblMessage.Text.ToString());
        txtSubKeyValue.Text = string.Empty;
      }
    }

    private bool FormValid()
    {
      bool boolRet = true;
      string strMsg = string.Empty;

      if (txtDomain.Text.Trim() == string.Empty)
        strMsg += "Domain field must be filled in." + Environment.NewLine;

      if (txtLoginID.Text.Trim() == string.Empty)
        strMsg += "Login ID field must be filled in." + Environment.NewLine;

      if (txtPassword.Password.Trim() == string.Empty)
        strMsg += "Password field must be filled in." + Environment.NewLine;

      if (strMsg.Trim() != string.Empty)
      {
        boolRet = false;
        MessageBox.Show(strMsg);
      }

      return boolRet;
    }


    #endregion

    #region Registry Write Methods
    private void DoWriteRegistry()
    {
      if (Convert.ToBoolean(chkUseSecurity.IsChecked))
      {
        if (FormValid())
          RegistryWriteSecurity();
      }
      else
        RegistryWrite();

      LoadSubKeyName();
    }

    private void RegistryWriteSecurity()
    {
      PDSAUserIdentity us = new PDSAUserIdentity();

      try
      {
        us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
        us.Impersonate();
        RegistryWrite();
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        us.Undo();
      }
    }

    private void RegistryWrite()
    {
      PDSARegistry reg = new PDSARegistry();

      try
      {
        reg.Hive = reg.StringToPDSAHive(cboHives.Text);
        reg.RemoteMachine = GetMachineName();
        string value = string.Empty;
        string msg = string.Empty;

        if (txtSubKeyName.Text.Trim().Length > 0)
        {
          if (txtSubKeyValue.Text.Trim().Length > 0)
          {

            switch (txtSubKeyName.Text)
            {
              case CommonSampleUtils.REG_SUB_KEY_NAME_BOOL:
                bool valueBool;
                if (bool.TryParse(txtSubKeyValue.Text.Trim(), out valueBool))
                  value = valueBool.ToString();
                else
                  msg = string.Format("'{0}' is not a valid bool value.", txtSubKeyValue.Text.Trim());
                break;
              case CommonSampleUtils.REG_SUB_KEY_NAME_DATE:
                DateTime valueDateTime;
                if (DateTime.TryParse(txtSubKeyValue.Text.Trim(), out valueDateTime))
                  value = valueDateTime.ToString();
                else
                  msg = string.Format("'{0}' is not a valid DateTime value.", txtSubKeyValue.Text.Trim());
                break;
              case CommonSampleUtils.REG_SUB_KEY_NAME_DECIMAL:
                decimal valueDecimal;
                if (decimal.TryParse(txtSubKeyValue.Text.Trim(), out valueDecimal))
                  value = valueDecimal.ToString();
                else
                  msg = string.Format("'{0}' is not a valid decimal value.", txtSubKeyValue.Text.Trim());
                break;
              case CommonSampleUtils.REG_SUB_KEY_NAME_INTEGER:
                int valueInt;
                if (int.TryParse(txtSubKeyValue.Text.Trim(), out valueInt))
                  value = valueInt.ToString();
                else
                  msg = string.Format("'{0}' is not a valid int value.", txtSubKeyValue.Text.Trim());
                break;
              case CommonSampleUtils.REG_SUB_KEY_NAME_SHORT:
                short valueShort;
                if (short.TryParse(txtSubKeyValue.Text.Trim(), out valueShort))
                  value = valueShort.ToString();
                else
                  msg = string.Format("'{0}' is not a valid short value.", txtSubKeyValue.Text.Trim());
                break;
              case CommonSampleUtils.REG_SUB_KEY_NAME_STRING:
                value = txtSubKeyValue.Text.Trim();
                break;
              default:
                value = txtSubKeyValue.Text.Trim();
                break;
            }

            if (msg.Length == 0)
            {
              reg.Save(txtKeyName.Text, txtSubKeyName.Text, value, GetMachineName());
              lblMessage.Text = string.Format("The Sub Key: '{0}' and Value: '{1}' was saved.", txtSubKeyName.Text, value);
            }
            else
              MessageBox.Show(msg);
          }
          else
            MessageBox.Show("Please fill in the 'Value' Field");
        }
        else
          MessageBox.Show("Please fill in the 'Sub Key Name' Field");
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
    #endregion

    #region Registry Delete Methods
    private void DoDeleteRegistry()
    {
      if (Convert.ToBoolean(chkUseSecurity.IsChecked))
      {
        if (FormValid())
          RegistryDeleteSecurity();
      }
      else
        RegistryDelete();

      LoadSubKeyName();
    }

    private void RegistryDeleteSecurity()
    {
      PDSAUserIdentity us = new PDSAUserIdentity();

      try
      {
        us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
        us.Impersonate();
        RegistryDelete();
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        us.Undo();
      }

    }

    private void RegistryDelete()
    {
      PDSARegistry reg = new PDSARegistry();

      try
      {
        reg.Hive = reg.StringToPDSAHive(cboHives.Text);
        reg.RemoteMachine = GetMachineName();
        string msg;

        if (txtSubKeyName.Text.Trim().Length > 0)
        {
          msg = string.Format("The Sub Key: '{0}' was delete.", txtSubKeyName.Text);
          reg.Delete(txtKeyName.Text, txtSubKeyName.Text);
          lblMessage.Text = msg;
        }
        else
          MessageBox.Show("Please fill in the 'Sub Key Name' Field");
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
    #endregion

    #region Read/Write Key Value Pairs
    PDSAKeyValuePairs mKeyValues;

    private void btnConvert_Click(object sender, RoutedEventArgs e)
    {
      ConvertToCollection();
    }

    private void ConvertToCollection()
    {
      PDSARegistry reg = new PDSARegistry();
      PDSAUserIdentity us = null;
      bool valid = true;
      try
      {

        if (Convert.ToBoolean(chkUseSecurity.IsChecked))
        {
          if (FormValid())
          {
            us = new PDSAUserIdentity();
            us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
            us.Impersonate();
          }
          else
            valid = false;
        }

        if (valid)
        {
          reg.RemoteMachine = GetMachineName();
          mKeyValues = reg.RegistryToKeyValuePairs(reg.StringToPDSAHive(cboHives.Text), txtKeyName.Text);
          lstKeyValues.DataContext = null;
          lstKeyValues.DataContext = mKeyValues;
          if (mKeyValues.Count > 0)
            lblMessage.Text = string.Format(@"The key name '{0}' has {1} name\values", txtKeyName.Text, mKeyValues.Count);
          else
            lblMessage.Text = string.Format(@"No name\values for the key name {0}", txtKeyName.Text);
        }
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (us != null)
        {
          us.Undo();
        }
      }
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      UpdateKeyValuePairs();
    }

    private void UpdateKeyValuePairs()
    {
      PDSARegistry reg = new PDSARegistry();
      PDSAKeyValuePair kp = new PDSAKeyValuePair();
      PDSAUserIdentity us = null;
      bool valid = true;
      try
      {

        if (Convert.ToBoolean(chkUseSecurity.IsChecked))
        {
          if (FormValid())
          {
            us = new PDSAUserIdentity();
            us.Logon(txtLoginID.Text, txtPassword.Password, txtDomain.Text);
            us.Impersonate();
          }
          else
            valid = false;
        }

        if (valid)
        {
          reg.RemoteMachine = GetMachineName();
          mKeyValues = (PDSAKeyValuePairs)lstKeyValues.DataContext;
          reg.KeyValuePairsToRegistry(reg.StringToPDSAHive(cboHives.Text), txtKeyName.Text, mKeyValues);
          lblMessage.Text = "All Value Pairs saved.";
        }
      }
      catch (SecurityException ex)
      {
        MessageBox.Show("You do not have permissions to access this registry key." + Environment.NewLine + ex.Message);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (us != null)
        {
          us.Undo();
        }
      }
    }

    #endregion

    private void SetSecurityControls()
    {
      bool isChecked = (bool)chkUseSecurity.IsChecked;
      txtDomain.IsEnabled = isChecked;
      txtLoginID.IsEnabled = isChecked;
      txtPassword.IsEnabled = isChecked;
    }

    private void SetRemoteMachineControls()
    {
      bool isChecked = (bool)chkUseRemoteMachine.IsChecked;
      txtMachineName.IsEnabled = isChecked;
    }

    private PDSA.Common.PDSARegistry.PDSAHive GetSelectedHive()
    {
      PDSARegistry reg = new PDSARegistry();
      reg.RemoteMachine = GetMachineName();
      return reg.StringToPDSAHive(cboHives.Text);
    }

    private void LoadSubKeyName()
    {
      txtSubKeyName.Text = string.Empty;
      txtSubKeyValue.Text = string.Empty;
      PDSA.Common.PDSARegistry reg = new PDSA.Common.PDSARegistry();
      reg.RemoteMachine = GetMachineName();
      string[] subNames = reg.GetValueNames(txtKeyName.Text, GetSelectedHive());
      cboSubKeyName.ItemsSource = null;

      if (subNames.Length > 0)
        cboSubKeyName.ItemsSource = subNames;
    }

    private string GetMachineName()
    {
      string machineName = string.Empty;
      if (Convert.ToBoolean(chkUseRemoteMachine.IsChecked))
        machineName = txtMachineName.Text;

      return machineName;
    }

    private void btnDotNetCleanUp_Click(object sender, RoutedEventArgs e)
    {
      PDSA.Common.PDSARegistry reg = new PDSA.Common.PDSARegistry();

      reg.CleanUpDotNetLists();
    }
  }
}
