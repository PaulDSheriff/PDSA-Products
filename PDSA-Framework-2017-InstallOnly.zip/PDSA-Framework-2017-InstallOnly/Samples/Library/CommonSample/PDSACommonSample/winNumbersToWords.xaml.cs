﻿using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
   public partial class winNumbersToWords : Window
   {
      public winNumbersToWords()
      {
         InitializeComponent();
      }

      PDSANumbersToWords _numbersToWords = new PDSANumbersToWords();

      #region Events

      private void btnConvertToWords_Click(object sender, RoutedEventArgs e)
      {
         int value;

         if (int.TryParse(txtInterger.Text, out value))
            txtIntergerResult.Text = _numbersToWords.NumberToWords(value).ToString();
         else
            MessageBox.Show("Please enter a integer value.");
      }

      #endregion
   }
}
