PDSA.Common Namespace Sample
----------------------------------------------
This sample illustrates the various classes and methods contained in the PDSA.Common Namespace.


Remote Registry Sample
----------------------------------------------
To test the remote registry functions you will need to install the RemoveRegCall.reg file included on a machine on your network that you have rights to.
Run the application and fill in the machine name
Click on the Read button.
NOTE: To be sure this works correctly, be sure you turn on the "Remote Registry" service on the remote machine.
You will also need to be able to access that registry key using your credentials.


GetWords Sample
----------------------------------------------
There is a file called SampleText.txt that can be used to input different sentences when testing the "Get Words" method.