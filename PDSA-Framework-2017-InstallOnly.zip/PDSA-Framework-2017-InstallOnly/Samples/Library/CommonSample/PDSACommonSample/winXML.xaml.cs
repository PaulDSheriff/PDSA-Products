﻿using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using PDSA.Common;
using PDSA.WPF;

namespace PDSACommonSample
{
  public partial class winXML : Window
  {
    public winXML()
    {
      InitializeComponent();
    }

    private class FileItem
    {
      public string FileName { get; set; }
      public bool ConfigFile { get; set; }
      public string[] Section { get; set; }
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      PDSA.FileIO.PDSAFileManager _fileManager = new PDSA.FileIO.PDSAFileManager();
      txtFileToDataset.Text = _fileManager.FileNameWithCurrentDirectory("Countries.xml");
      txtDatasetToFile.Text = _fileManager.FileNameWithCurrentDirectory("CountriesSaved.xml");
      SampleSetupReSet();
    }

    #region Events

    private void btnDataSetToFile_Click(object sender, RoutedEventArgs e)
    {
      DataTableToFile();
    }

    private void btnFileToDataSet_Click(object sender, RoutedEventArgs e)
    {
      FileToDataTable();
    }

    private void cboFileToRead_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DisplayXMLFile();
    }

    private void btnAddNVP_Click(object sender, RoutedEventArgs e)
    {
      if (lstValues.DataContext != null)
      {
        mKeyValues = (PDSAKeyValuePairs)lstValues.DataContext;
        mKeyValues.Add(new PDSAKeyValuePair(String.Format("Key Created {0}", DateTime.Now.ToString()), "value"));
        lstValues.DataContext = null;
        lstValues.DataContext = mKeyValues;
      }
    }
    #endregion

    #region DataTableToFile Method
    private void DataTableToFile()
    {
      DataTable dt;

      dt = (DataTable)lstXML.DataContext;

      if (txtDatasetToFile.Text.Trim() == string.Empty)
      {
        MessageBox.Show("Please enter an XML File Name to write to");
      }
      else
      {
        PDSAXML.DataTableToFile(dt, txtDatasetToFile.Text);
        MessageBox.Show("XML File has been written to: " + txtDatasetToFile.Text);
      }
    }
#endregion

    #region FileToDataTable Method
    private void FileToDataTable()
    {
      DataTable dt;

      dt = PDSAXML.XmlFileToDataTable(txtFileToDataset.Text);

      lstXML.View = PDSAWPFListView.CreateGridViewColumns(dt);
      lstXML.DataContext = dt;
    }
    #endregion

    #region Read/Write Key Value Pairs
    PDSAKeyValuePairs mKeyValues;

    private void btnFileToRead_Click(object sender, RoutedEventArgs e)
    {
      ConvertXmlFile();
    }

    private void ConvertXmlFile()
    {
      mKeyValues = PDSAXML.XmlFileToKeyValuePairs(cboFileToRead.Text, cboSection.Text, Convert.ToBoolean(chkIsConfig.IsChecked));
      lstValues.DataContext = null;
      lstValues.DataContext = mKeyValues;
    }

    private void btnWrite_Click(object sender, RoutedEventArgs e)
    {
      PDSA.FileIO.PDSAFolderManager _folderManager = new PDSA.FileIO.PDSAFolderManager();
      mKeyValues = (PDSAKeyValuePairs)lstValues.DataContext;
      PDSAXML.KeyValuePairsToXmlFile(cboFileToRead.Text, cboSection.Text, Convert.ToBoolean(chkIsConfig.IsChecked), mKeyValues);
    }

    private void SampleSetupReSet()
    {
      PDSA.FileIO.PDSAFolderManager _folderManager = new PDSA.FileIO.PDSAFolderManager();
      ArrayList al = new ArrayList();

      FileItem file1 = new FileItem();
      file1.FileName = string.Format(@"{0}\{1}\{2}", _folderManager.GetCurrentDirectory(), "XMLSampleFiles", "XMLKeyValuePairSample1.xml");
      file1.ConfigFile = false;
      file1.Section = new string[1];
      file1.Section[0] = "SectionA";
      al.Add(file1);

      FileItem file2 = new FileItem();
      file2.FileName = string.Format(@"{0}\{1}\{2}", _folderManager.GetCurrentDirectory(), "XMLSampleFiles", "XMLKeyValuePairSample2.xml");
      file2.ConfigFile = true;
      file2.Section = new string[2];
      file2.Section[0] = "SectionA";
      file2.Section[1] = "SectionB";

      al.Add(file2);

      cboFileToRead.ItemsSource = al;
      cboFileToRead.SelectedIndex = 0;
      DisplayFile(tbFileDisplay, file1.FileName);
    }

    private void DisplayXMLFile()
    {
      FileItem file = (FileItem)cboFileToRead.SelectedItem;
      DisplayFile(tbFileDisplay, file.FileName);
      chkIsConfig.IsChecked = file.ConfigFile;
      cboSection.ItemsSource = null;
      cboSection.ItemsSource = file.Section;
      cboSection.SelectedIndex = 0;
      lstValues.DataContext = null;

    }

    #endregion

    #region DisplayFile Method
    private void DisplayFile(TextBlock tb, string FileName)
    {
      StreamReader reader;
      tb.Text = string.Empty;

      if (FileName.Length > 0)
      {
        if (File.Exists(FileName))
        {
          reader = new StreamReader(FileName);
          tb.Text = reader.ReadToEnd();
          reader.Close();
        }
        else
          tb.Text = string.Format("File: '{0}' not found;", FileName);
      }
    }
    #endregion
  }
}