﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using PDSA.Common;
using PDSA.FileIO;

namespace PDSACommonSample
{
  public partial class winXMLSynch : Window
  {
    #region Constructor
    public winXMLSynch()
    {
      InitializeComponent();
    }
    #endregion

    #region Properties and Fields
    PDSAXMLSynch _XMLSync = new PDSAXMLSynch();
    private Cursor _CurrentCursor = Cursors.Arrow;
    #endregion
    
    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Hook up event handlers
      _XMLSync.NewNode += new PDSAXMLSynch.NewNodeEventHandler(_XMLSync_Event);
      _XMLSync.Status += new PDSAXMLSynch.StatusEventHandler(_XMLSync_Event);
      Reset();
    }
    #endregion

    #region File Manager Event Procedures
    void _XMLSync_Event(object sender, PDSAXMLSynchEventArgs e)
    {
      lstMessages.Items.Add(e.Message);
    }

    #endregion

    #region Support Methods
    private void SetWaitCursor()
    {
      _CurrentCursor = this.Cursor;
      this.Cursor = Cursors.Wait;
    }

    private void RestoreCursor()
    {
      this.Cursor = _CurrentCursor;
    }
    #endregion

    #region Events
    private void btnFromConfigFile_Click(object sender, RoutedEventArgs e)
    {
      GetFileName(txtFromConfigFile);
      DisplayFromFile();
    }

    private void btnMergeToConfigFile_Click(object sender, RoutedEventArgs e)
    {
      GetFileName(txtMergeToConfigFile);
      DisplayToFile();
    }

    private void btnResultConfigFile_Click(object sender, RoutedEventArgs e)
    {
      GetFileName(txtResultConfigFile);
      DisplayResultFile();
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      Process();
      DisplayResultFile();
    }

    private void btnSeutpSample_Click(object sender, RoutedEventArgs e)
    {
      Reset();
    }
    #endregion

    #region Process
    private void Process()
    {
      try
      {
        if (Validate())
        {
          _XMLSync.XmlFileFrom = txtFromConfigFile.Text;
          _XMLSync.XmlFileTo = txtMergeToConfigFile.Text;
          _XMLSync.RootNode = txtXPath.Text;
          _XMLSync.XmlFileNew = txtResultConfigFile.Text;
          _XMLSync.Process();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message, "Error in processing.");
      }
    }
    #endregion

    #region Validate Method
    private bool Validate()
    {
      bool rtn = true;
      string msg = string.Empty;
      PDSAFileManager _fileManager = new PDSAFileManager();

      if (txtFromConfigFile.Text.Length == 0)
      {
        msg += "The 'From' file is required.";
      }
      else if (!File.Exists(txtFromConfigFile.Text))
      {
        msg += "The 'From' file does not Exists.";
      }

      if (txtMergeToConfigFile.Text.Length == 0)
      {
        if (msg.Length > 0)
          msg += Environment.NewLine;
        msg += "The 'To' file is required.";
      }
      else if (!File.Exists(txtMergeToConfigFile.Text))
      {
        if (msg.Length > 0)
          msg += Environment.NewLine;
        msg += "The 'To' file does not Exists.";
      }

      if (txtResultConfigFile.Text.Length == 0)
      {
        if (msg.Length > 0)
          msg += Environment.NewLine;
        msg += "The 'Result' file is required.";
      }
      else if (!_fileManager.FileAndPathIsValid(txtResultConfigFile.Text))
      {
        if (msg.Length > 0)
          msg += Environment.NewLine;
        msg += @"The 'Result' file is not a valid path\filename.";
      }
      else if (File.Exists(txtResultConfigFile.Text))
      {
        if (_fileManager.IsFileLocked(txtResultConfigFile.Text))
        {
          if (msg.Length > 0)
            msg += Environment.NewLine;
          msg += "The 'Result' file is in use.";
        }
      }


      if (txtXPath.Text.Length == 0)
      {
        if (msg.Length > 0)
          msg += Environment.NewLine;
        msg += "The 'XPath of Settings to Add' is required.";
      }

      if (msg.Length != 0)
      {
        rtn = false;
        MessageBox.Show(msg);
      }

      return rtn;
    }
    #endregion

    #region GetFileName Method
    private void GetFileName(TextBox tB)
    {
      PDSAFileManager _fileManager = new PDSAFileManager();
      string fileName = _fileManager.GetFileWithDialog(tB.Text, ".config", "Config Files (*.config)|*.Config|XML Files (*.xml)|*.xml|All Files (*.*)|*.*");

      if (fileName.Length > 0)
        tB.Text = fileName;
    }
    #endregion

    #region Display Files Methods
    private void DisplayFromFile()
    {
      DisplayFile(tbFromFile, txtFromConfigFile.Text);
    }

    private void DisplayToFile()
    {
      DisplayFile(tbToFile, txtMergeToConfigFile.Text);
    }

    private void DisplayResultFile()
    {
      DisplayFile(tbResultFile, txtResultConfigFile.Text);
    }

    private void DisplayFile(TextBlock tb, string FileName)
    {
      StreamReader reader;
      tb.Text = string.Empty;

      if (FileName.Length > 0)
      {
        if (File.Exists(FileName))
        {
          reader = new StreamReader(FileName);
          tb.Text = reader.ReadToEnd();
          reader.Close();
        }
        else
          tb.Text = string.Format("File: '{0}' not found;", FileName);
      }
    }
    #endregion

    #region Reset Method
    private void Reset()
    {
      PDSAFolderManager _folderManager = new PDSAFolderManager();

      txtFromConfigFile.Text = string.Format(@"{0}\{1}\{2}", _folderManager.GetCurrentDirectory(), "XMLSynchSampleFiles", "XMLSyncSampleAddFrom.xml");
      DisplayFromFile();
      txtMergeToConfigFile.Text = string.Format(@"{0}\{1}\{2}", _folderManager.GetCurrentDirectory(), "XMLSynchSampleFiles", "XMLSyncSampleAddTo.config");
      DisplayToFile();
      txtResultConfigFile.Text = string.Format(@"{0}\{1}\{2}", _folderManager.GetCurrentDirectory(), "XMLSynchSampleFiles", "XMLSyncSampleResult.config");
      if (File.Exists(txtResultConfigFile.Text))
        File.Delete(txtResultConfigFile.Text);

      txtXPath.Text = "/configuration";

      DisplayFromFile();
      DisplayToFile();
      DisplayResultFile();
      lstMessages.Items.Clear();
    }
    #endregion
  }
}