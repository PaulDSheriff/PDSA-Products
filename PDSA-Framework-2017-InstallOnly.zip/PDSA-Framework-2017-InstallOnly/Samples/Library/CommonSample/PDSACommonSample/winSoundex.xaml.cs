﻿using System.Windows;
using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winSoundex : Window
  {
    public winSoundex()
    {
      InitializeComponent();
    }

    private void btnGetSoundexCode_Click(object sender, RoutedEventArgs e)
    {
      PDSASoundex soundex = new PDSASoundex();
      txtbSoundexResult.Text = soundex.SoundEx(txtSoundexInput.Text);
    }
  }
}
