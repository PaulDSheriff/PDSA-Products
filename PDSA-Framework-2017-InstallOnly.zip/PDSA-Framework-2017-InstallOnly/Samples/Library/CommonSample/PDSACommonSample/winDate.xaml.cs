﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winDate : Window
  {
    public winDate()
    {
      InitializeComponent();
    }

    #region Events

    private void btnToday_Click(object sender, RoutedEventArgs e)
    {
      SetToday();
    }

    private void btnFill_Click(object sender, RoutedEventArgs e)
    {
      FillResults();
    }
    #endregion
    
    #region PDSA Common Method Calls

    private void SetToday()
    {
      txtDate.Text = System.DateTime.Today.ToShortDateString();
    }

    private void FillResults()
    {
      DateTime dt;

      if (PDSADate.IsADate(txtDate.Text))
      {
        if (DateTime.TryParse(txtDate.Text, out dt))
        {
          txtGetSecondsSinceMidnight.Text = PDSADate.GetSecondsSinceMidnight().ToString();

          txtIsADate_1.Text = PDSADate.IsADate(txtDate.Text).ToString();
          txtIsADate_2.Text = PDSADate.IsADate(txtDate.Text, "M/d/yyyy").ToString();

          txtNowFormatted_1.Text = PDSADate.NowFormatted();
          txtNowFormatted_2.Text = PDSADate.NowFormatted("MM/dd/yyyy");
          txtNowFormatted_3.Text = PDSADate.NowFormatted(dt);
          txtGetWeek.Text = PDSADate.GetWeek(dt).ToString();
 
          txtMonthName_1.Text = PDSADate.GetMonthName(dt.Month);
          txtMonthName_2.Text = PDSADate.GetMonthName(dt);
          txtMonthStart.Text = PDSADate.MonthStart(dt).ToShortDateString();
          txtMonthEnd.Text = PDSADate.MonthEnd(dt).ToShortDateString();

          txtQuarterNumber.Text = PDSADate.GetQuarter(dt).ToString();
          txtQuarterStart.Text = PDSADate.QuarterStart(dt).ToShortDateString();
          txtQuarterEnd.Text = PDSADate.QuarterEnd(dt).ToShortDateString();

          txtYearStart.Text = PDSADate.YearStart(dt).ToShortDateString();
          txtYearEnd.Text = PDSADate.YearEnd(dt).ToShortDateString();
        }
      }
      else
      {
        MessageBox.Show("Invalid Date");
      }

    }
    #endregion

  }
}
