﻿using System;

namespace PDSACommonSample
{
  // This class needs to be serializable for the sample to work
  [Serializable()]
  public class UserInfo
  {
    public string UserName { get; set; }
    public string LastMenu { get; set; }
    public int LastCustomerID { get; set; }
  }
}
