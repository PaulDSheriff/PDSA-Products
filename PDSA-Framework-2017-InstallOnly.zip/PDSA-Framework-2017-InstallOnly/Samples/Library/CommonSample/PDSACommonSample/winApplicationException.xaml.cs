﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winApplicationException : Window
  {
    public winApplicationException()
    {
      InitializeComponent();
    }

    private const string EXCEPTION_MESSAGE = "Exception Message Here";
    
    #region Events

    private void btnApplicationException1_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        throw new PDSAApplicationException();
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void btnApplicationException2_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        throw new PDSAApplicationException(EXCEPTION_MESSAGE);
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void btnApplicationException3_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex);
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.Message + Environment.NewLine + Environment.NewLine + ex.InnerException);
      }
    }

    private void btnApplicationException4_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex, "Application Exception Samples", "Sample 4");
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.Message + Environment.NewLine + Environment.NewLine + ex.InnerException, ex.ClassName + " : " + ex.MethodName);
      }
    }

    private void btnGetFullExceptionMessage_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex, "Application Exception Samples", "Sample 4");
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.GetFullExceptionMessage(false));
      }
    }

    private void btnToString_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex, "Application Exception Samples", "Sample 4");
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(ex.ToString());
        // Note: same as ex.GetFullExceptionMessage(true)
      }
    }

    private void btnGetAllExceptionMessages1_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex);
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(PDSAExceptionInfo.GetAllExceptionMessages(ex));
      }
    }



    private void btnGetAllExceptionMessages2_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        try
        {
          CreateDivideByZeroError();
        }
        catch (Exception ex)
        {
          throw new PDSAApplicationException(EXCEPTION_MESSAGE, ex);
        }
      }
      catch (PDSAApplicationException ex)
      {
        MessageBox.Show(PDSAExceptionInfo.GetAllExceptionMessages(ex, "<Delimiter Here>"));
      }
    }

    #endregion

    #region CreateDivideByZeroError Method
    private void CreateDivideByZeroError()
    {
      int i = 0;
      int j = 0;
      int k = 0;

      k = i / j;
    }
    #endregion
  }
}
