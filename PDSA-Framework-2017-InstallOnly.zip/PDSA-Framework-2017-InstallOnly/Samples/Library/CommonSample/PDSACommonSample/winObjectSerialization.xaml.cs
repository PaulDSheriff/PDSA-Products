﻿using System;
using System.Windows;

using PDSA.Common;
using PDSA.FileIO;

namespace PDSACommonSample
{
   public partial class winObjectSerialization : Window
   {
      PDSAFileManager _fileManager;
      private enum LastObjectSerializationTypes
      {
         None,
         XMLString,
         XMLFile,
         BinaryString,
         BinaryFile,
         JSONString
      }

      #region Constructor
      public winObjectSerialization()
      {
         InitializeComponent();
         _fileManager = new PDSAFileManager();
      }
      #endregion

      #region User Object
      UserInfo mUI;

      private void CreateUserObject()
      {
         mUI = new UserInfo();

         mUI.UserName = txtUserName.Text;
         mUI.LastCustomerID = Convert.ToInt32(txtLastCustomer.Text);
         mUI.LastMenu = txtLastMenu.Text;
      }

      private void DisplayObject(UserInfo ui)
      {
         txtUserName.Text = ui.UserName;
         txtLastCustomer.Text = Convert.ToString(ui.LastCustomerID);
         txtLastMenu.Text = ui.LastMenu;
      }
      #endregion

      #region Loaded Event
      private void Window_Loaded(object sender, RoutedEventArgs e)
      {
         txtFileName.Text = _fileManager.FileNameWithCurrentDirectory(txtFileName.Text);
      }
      #endregion

      #region Write To XML String
      private void btnObjectToXML_Click(object sender, RoutedEventArgs e)
      {
         WriteToXMLString();
      }

      private void WriteToXMLString()
      {
         try
         {
            if (Validate())
            {
               CreateUserObject();
               txtResults.Text = PDSASerializer.ObjectToXmlString(mUI);
               Clear();
               SetButtons(false, LastObjectSerializationTypes.XMLString);
               MessageBox.Show(string.Format("Object written to XML String.{0}{0}{0}Please press the '{1}' button to populate user info.", Environment.NewLine, btnReadXMLString.Content));
            }
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Write To XML File
      private void btnObjectToXMLFile_Click(object sender, RoutedEventArgs e)
      {
         WriteToXMLFile();
      }

      private void WriteToXMLFile()
      {
         try
         {
            if (Validate())
            {
               CreateUserObject();
               PDSASerializer.ObjectToXml(mUI, txtFileName.Text);
               txtResults.Text = string.Empty;
               Clear();
               SetButtons(false, LastObjectSerializationTypes.XMLFile);
               MessageBox.Show(string.Format("Object written to XML File.{0}{0}{0}Please press the '{1}' button to populate user info.", Environment.NewLine, btnReadFromXMLFile.Content));
            }
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Write To Binary String
      private void btnObjectToBinary_Click(object sender, RoutedEventArgs e)
      {
         WriteToBinaryString();
      }

      private void WriteToBinaryString()
      {
         try
         {
            if (Validate())
            {
               CreateUserObject();
               txtResults.Text = PDSASerializer.ObjectToBinaryBase64String(mUI);
               Clear();
               SetButtons(false, LastObjectSerializationTypes.BinaryString);
               MessageBox.Show(string.Format("Object written to Binary String.{0}{0}{0}Please press the '{1}' button to populate user info.", Environment.NewLine, btnReadBinary.Content));

            }
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Write To Binary File
      private void btnObjectToBinaryFile_Click(object sender, RoutedEventArgs e)
      {
         WriteToBinaryFile();
      }

      private void WriteToBinaryFile()
      {
         try
         {
            if (Validate())
            {
               CreateUserObject();
               PDSASerializer.ObjectToBinary(mUI, txtFileName.Text);
               txtResults.Text = string.Empty;
               Clear();
               SetButtons(false, LastObjectSerializationTypes.BinaryFile);
               MessageBox.Show(string.Format("Object written to Binary File.{0}{0}{0}Please press the '{1}' button to populate user info.", Environment.NewLine, btnReadFromBinaryFile.Content));
            }
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Read From XML String
      private void btnReadXMLString_Click(object sender, RoutedEventArgs e)
      {
         ReadFromXmlString();
      }

      private void ReadFromXmlString()
      {
         try
         {
            UserInfo ui;

            ui = (UserInfo)PDSASerializer.XmlStringToObject(txtResults.Text);
            // Deserialize and Display Data
            DisplayObject(ui);
            SetButtons(true, LastObjectSerializationTypes.None);
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Read From XML File
      private void btnReadFromXMLFile_Click(object sender, RoutedEventArgs e)
      {
         ReadFromXmlFile();
      }

      private void ReadFromXmlFile()
      {
         try
         {
            // Deserialize and Display Data
            DisplayObject((UserInfo)PDSASerializer.XmlToObject(txtFileName.Text));
            SetButtons(true, LastObjectSerializationTypes.None);
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Read From Binary String
      private void btnReadBinary_Click(object sender, RoutedEventArgs e)
      {
         ReadFromBinaryString();
      }

      private void ReadFromBinaryString()
      {
         try
         {
            // Deserialize and Display Data
            DisplayObject((UserInfo)PDSASerializer.BinaryBase64StringToObject(txtResults.Text));
            SetButtons(true, LastObjectSerializationTypes.None);
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region Read From Binary File
      private void btnReadFromBinaryFile_Click(object sender, RoutedEventArgs e)
      {
         ReadFromBinaryFile();
      }

      private void ReadFromBinaryFile()
      {
         try
         {
            // Deserialize and Display Data
            DisplayObject((UserInfo)PDSASerializer.BinaryToObject(txtFileName.Text));
            SetButtons(true, LastObjectSerializationTypes.None);
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
      }
      #endregion

      #region JSON String Serialization
      private void btnObjectToJSON_Click(object sender, RoutedEventArgs e)
      {
        WriteToJSONString();
      }

      private void WriteToJSONString()
      {
        try
        {
          if (Validate())
          {
            CreateUserObject();
            txtResults.Text = PDSAString.GetAsJSON(typeof(UserInfo), mUI);
            Clear();
            SetButtons(false, LastObjectSerializationTypes.JSONString);
            MessageBox.Show(string.Format("Object written to JSON String.{0}{0}{0}Please press the '{1}' button to populate user info.", Environment.NewLine, btnReadFromJSONString.Content));
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }

      private void btnReadFromJSONString_Click(object sender, RoutedEventArgs e)
      {
        ReadFromJSONString();
      }

      private void ReadFromJSONString()
      {
        try
        {
          UserInfo ui;

          ui = (UserInfo)PDSAString.GetFromJSON(typeof(UserInfo), txtResults.Text);
          // Deserialize and Display Data
          DisplayObject(ui);
          SetButtons(true, LastObjectSerializationTypes.None);
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }
      #endregion

      private void btnClearUserInfo_Click(object sender, RoutedEventArgs e)
      {
         Clear();
      }

      private void Clear()
      {
         txtUserName.Text = string.Empty;
         txtLastCustomer.Text = string.Empty;
         txtLastMenu.Text = string.Empty;
      }

      private bool Validate()
      {
         string errorMSG = string.Empty;
         int LastCustomerId;
         bool rtn = true;

         if (txtUserName.Text.Length == 0)
            errorMSG += "'User Name' is required.";

         if (txtLastCustomer.Text.Length == 0)
         {
            if (errorMSG.Length > 0)
               errorMSG += Environment.NewLine;
            errorMSG += "'Last Customer' is required.";
         }
         else if (!int.TryParse(txtLastCustomer.Text, out LastCustomerId))
         {
            if (errorMSG.Length > 0)
               errorMSG += Environment.NewLine;
            errorMSG += "'Last Customer ID' must be an integer.";
         }

         if (txtLastMenu.Text.Length == 0)
         {
            if (errorMSG.Length > 0)
               errorMSG += Environment.NewLine;
            errorMSG += "'Last Menu' is required.";
         }

         if (errorMSG.Length > 0)
         {
            MessageBox.Show(errorMSG);
            rtn = false;
         }

         return rtn;
      }
      private void SetButtons(bool IsEnabled, LastObjectSerializationTypes lastType)
      {
         btnObjectToBinary.IsEnabled = IsEnabled;
         btnObjectToBinaryFile.IsEnabled = IsEnabled;
         btnObjectToXML.IsEnabled = IsEnabled;
         btnObjectToXMLFile.IsEnabled = IsEnabled;

         if (lastType == LastObjectSerializationTypes.BinaryString)
            btnReadBinary.IsEnabled = true;
         else
            btnReadBinary.IsEnabled = IsEnabled;

         if (lastType == LastObjectSerializationTypes.BinaryFile)
            btnReadFromBinaryFile.IsEnabled = true;
         else
            btnReadFromBinaryFile.IsEnabled = IsEnabled;

         if (lastType == LastObjectSerializationTypes.XMLFile)
            btnReadFromXMLFile.IsEnabled = true;
         else
            btnReadFromXMLFile.IsEnabled = IsEnabled;
         if (lastType == LastObjectSerializationTypes.XMLString)
            btnReadXMLString.IsEnabled = true;
         else
            btnReadXMLString.IsEnabled = IsEnabled;
      }
   }
}
