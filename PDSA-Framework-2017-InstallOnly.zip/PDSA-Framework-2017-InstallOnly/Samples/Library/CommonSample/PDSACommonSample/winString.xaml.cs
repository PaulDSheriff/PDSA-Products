﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winString : Window
  {
    public winString()
    {
      InitializeComponent();
      txtTrimCRLF.Text = txtTrimCRLF.Text + Environment.NewLine + Environment.NewLine + Environment.NewLine;
      txtnRemoveSpecialChars.Text = string.Format("Chars like: Tab(\t) and CRLF(\n\r) will be replaced with space.");
    }

    #region Event Handlers

    private void btnCamelCaseWordSplit_Click(object sender, RoutedEventArgs e)
    {
      CamelCaseWordSplit();
    }

    private void btnConvertToStringTrim_Click(object sender, RoutedEventArgs e)
    {
      ConvertToStringTrim();
    }

    private void btnExpandSpecialFolders_Click(object sender, RoutedEventArgs e)
    {
      ExpandSpecialFolders();
    }

    private void btnGetData_Click(object sender, RoutedEventArgs e)
    {
      GetData();
    }

    private void btnRemoveDuplicates_Click(object sender, RoutedEventArgs e)
    {
      RemoveDuplicates();
    }

    private void btnStringToBoolean_Click(object sender, RoutedEventArgs e)
    {
      StringToBoolean();
    }

    private void btnMakeFieldAValidIdentifier1_Click(object sender, RoutedEventArgs e)
    {
      MakeFieldAValidIdentifier1();
    }

    private void btnMakeFieldAValidIdentifier2_Click(object sender, RoutedEventArgs e)
    {
      MakeFieldAValidIdentifier2();
    }

    private void btnReverseString_Click(object sender, RoutedEventArgs e)
    {
      ReverseString();
    }

    private void btnIsAllLowerCase_Click(object sender, RoutedEventArgs e)
    {
      IsAllLowerCase();
    }

    private void btnIsAllUpperCase_Click(object sender, RoutedEventArgs e)
    {
      IsAllUpperCase();
    }

    private void btnFieldNameWrap1_Click(object sender, RoutedEventArgs e)
    {
      FieldNameWrap1();
    }

    private void btnFieldNameWrap2_Click(object sender, RoutedEventArgs e)
    {
      FieldNameWrap2();
    }

    private void btnIsValidEmail_Click(object sender, RoutedEventArgs e)
    {
      IsValidEmail();
    }

    private void btnProperCase_Click(object sender, RoutedEventArgs e)
    {
      ProperCase();
    }

    private void btnTrimCRLF_Click(object sender, RoutedEventArgs e)
    {
      TrimCRLF();
    }

    private void btnCountChars_Click(object sender, RoutedEventArgs e)
    {
      CountChars();
    }

    private void btnGetConfigFileName_Click(object sender, RoutedEventArgs e)
    {
      GetConfigFileName();
    }

    private void btnGetQuotedWords_Click(object sender, RoutedEventArgs e)
    {
      GetQuotedWords();
    }

    private void btnRemoveSpecialChars_Click(object sender, RoutedEventArgs e)
    {
      RemoveSpecialChars();
    }

    private void btnGetWords_Click(object sender, RoutedEventArgs e)
    {
      string[] results;
      StringBuilder sb = new StringBuilder(1024);

      results = PDSAString.GetWords(txtGetWords.Text);

      foreach (string item in results)
      {
        sb.Append(item + Environment.NewLine);
      }

      txtGetWordsResults.Text = sb.ToString();
    }
    #endregion

    #region PDSA Common Method Calls
    private void ReverseString()
    {
      txtReverseStringResults.Text = PDSAString.ReverseString(txtReverseString.Text);
    }

    private void MakeFieldAValidIdentifier1()
    {
      txtMakeFieldAValidIdentifier1Results.Text = PDSAString.MakeFieldAValidIdentifier(txtMakeFieldAValidIdentifier1.Text).ToString();
    }

    private void IsAllLowerCase()
    {
      txtIsAllLowerCaseResults.Text = PDSAString.IsAllLowerCase(txtIsAllLowerCase.Text).ToString();
    }

    private void IsAllUpperCase()
    {
      txtIsAllUpperCaseResults.Text = PDSAString.IsAllUpperCase(txtIsAllUpperCase.Text).ToString();
    }

    private void FieldNameWrap1()
    {
      txtFieldNameWrap1Results.Text = PDSAString.FieldNameWrap(txtFieldNameWrap_1.Text);
    }

    private void FieldNameWrap2()
    {
      txtFieldNameWrap2Results.Text = PDSAString.FieldNameWrap(txtFieldNameWrap_2.Text, "<prefix>", "<suffix>").ToString();
    }

    private void IsValidEmail()
    {
      if (PDSAString.IsValidEmail(txtIsValidEmail.Text))
        txtIsValidEmailResults.Text = String.Format("'{0}' is a valid email.", txtIsValidEmail.Text);
      else
        txtIsValidEmailResults.Text = String.Format("'{0}' is not valid.  Try Support@PDSA.COM.", txtIsValidEmail.Text);
    }

    private void ProperCase()
    {
      txtProperCaseResults.Text = PDSAString.ProperCase(txtProperCase.Text).ToString();
    }

    private void TrimCRLF()
    {
      txtTrimCRLFResults.Text = PDSAString.TrimCRLF(txtTrimCRLF.Text).ToString();
    }

    private void CamelCaseWordSplit()
    {
      txtCamelCaseWordSplitResults.Text = PDSAString.CamelCaseWordSplit(txtCamelCaseWordSplit.Text).ToString();
    }

    private void btnProperCaseWithUnderscore_Click(object sender, RoutedEventArgs e)
    {
      txtProperCaseWithUnderscoreResults.Text = PDSAString.ProperCase(txtnProperCaseWithUnderscore.Text, "_");
    }

    private void CountChars()
    {
      txtCountCharsResults.Text = PDSAString.CountChars(txtCountChars.Text, Convert.ToChar("C")).ToString();
    }

    private void GetConfigFileName()
    {
      txtGetConfigFileNameResults.Text = PDSAString.GetConfigFileName();
    }

    private void RemoveSpecialChars()
    {
      txtRemoveSpecialCharsResults.Text = PDSAString.RemoveSpecialChars(txtnRemoveSpecialChars.Text);
    }

    private void ConvertToStringTrim()
    {

      object value = txtConvertToStringTrim.Text;
      txtConvertToStringTrimResults.Text = PDSAString.ConvertToStringTrim(value);
    }

    private void ExpandSpecialFolders()
    {
      txtExpandSpecialFoldersResults.Text = PDSAString.ExpandSpecialFolders("[MyDocuments]");
    }

    private void GetData()
    {
      object valueDBNull;
      valueDBNull = DBNull.Value;

      txtGetDataResults.Text = PDSAString.GetData(valueDBNull, lnlGetData.Text);
    }

    private void RemoveDuplicates()
    {
      System.Collections.ArrayList stringArraySource = new System.Collections.ArrayList();
      System.Collections.ArrayList stringArrayResults;

      foreach (ListBoxItem item in lbnRemoveDuplicates.Items)
      {
        stringArraySource.Add(item.Content.ToString());
      }

      stringArrayResults = PDSAString.RemoveDuplicates(stringArraySource);

      lbRemoveDuplicatesResults.ItemsSource = stringArrayResults;
    }

    private void StringToBoolean()
    {
      string name;
      string selectedText;

      if (cbStringToBoolean.SelectedItem != null)
      {
        name = ((ComboBoxItem)cbStringToBoolean.SelectedItem).Name;
        selectedText = ((ComboBoxItem)cbStringToBoolean.SelectedItem).Content.ToString();
        switch (name)
        {
          case "P1":
            name = "1";
            break;
          case "M1":
            name = "-1";
            break;
        }

        if (PDSAString.StringToBoolean(name))
          txtStringToBooleanResults.Text = String.Format("The Selected value '{0}' is true.", selectedText);
        else
          txtStringToBooleanResults.Text = String.Format("The Selected value '{0}' is false.", selectedText);
      }
      else
        txtStringToBooleanResults.Text = "Please select a True/False item from the Combo Box";
    }

    private void MakeFieldAValidIdentifier2()
    {
      txtMakeFieldAValidIdentifier2Results.Text = PDSAString.MakeFieldAValidIdentifier(txtMakeFieldAValidIdentifier2.Text, "_");
    }

    private void GetQuotedWords()
    {
      string[] results;
      StringBuilder sb = new StringBuilder(1024);

      results = PDSAString.GetQuotedWords(txtGetQuotedWords.Text);

      foreach (string item in results)
      {
        sb.Append(item + Environment.NewLine);
      }

      txtGetQuotedWordsResults.Text = sb.ToString();
    }

    private void btnCountSpecial_Click(object sender, RoutedEventArgs e)
    {
      string value = "John!1sd&";

      txtCountSpecial.Text = PDSAString.CountSpecialChars(value).ToString();
    }
    #endregion
  }
}
