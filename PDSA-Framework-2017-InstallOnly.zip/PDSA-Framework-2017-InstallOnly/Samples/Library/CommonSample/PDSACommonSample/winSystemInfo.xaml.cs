﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winSystemInfo : Window
  {
    public winSystemInfo()
    {
      InitializeComponent();
    }

    PDSASystemInfo _si;
    const string DELIMIT_VALUE = "<Delimiter Here>";

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _si = new PDSASystemInfo();
      LoadProperties();
    }
    
    private void LoadProperties()
    {
      Type typ;

      typ = typeof(PDSASystemInfo);

      // Get the public properties.
      PropertyInfo[] propInfo = typ.GetProperties(BindingFlags.Public | BindingFlags.Instance);

      foreach (PropertyInfo item in propInfo)
      {
        cboProperties.Items.Add(item.Name);
      }
    }

    private void CallProperty(string name)
    {

      Type type = _si.GetType();

      BindingFlags flags = BindingFlags.GetProperty;
      Binder binder = null;
      object[] args = null;

      object result = type.InvokeMember(
         name,
         flags,
         binder,
         _si,
         args
         );

      if (result != null)
        txtResult.Text = result.ToString();
      else
        txtResult.Text = "Can't read property.";
    }

    private void cboProperties_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      CallProperty(cboProperties.SelectedItem.ToString());
    }


    private void btnAssembliesGet1_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.AssembliesGet();
    }

    private void btnAssembliesGet2_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.AssembliesGet(DELIMIT_VALUE);
    }

    private void btnEnvVariablesGet1_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.EnvVariablesGet();
    }

    private void btnEnvVariablesGet2_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.EnvVariablesGet(DELIMIT_VALUE);
    }

    private void btnIPAddresses1_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.IPAddresses();
    }

    private void btnIPAddresses2_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.IPAddresses(DELIMIT_VALUE);
    }

    private void btnGetAllSystemInfo1_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.GetAllSystemInfo();
    }

    private void btnGetAllSystemInfo2_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.GetAllSystemInfo(DELIMIT_VALUE);
    }

    private void btnGetAllSystemInfo3_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.GetAllSystemInfo(false);
    }

    private void btnGetAllSystemInfo4_Click(object sender, RoutedEventArgs e)
    {
      txtResult.Text = _si.GetAllSystemInfo(DELIMIT_VALUE, false);
    }
  }
}
