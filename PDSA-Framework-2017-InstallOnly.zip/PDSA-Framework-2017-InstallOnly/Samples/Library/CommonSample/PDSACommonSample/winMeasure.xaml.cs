﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
   public partial class winMeasure : Window
   {
      public winMeasure()
      {
         InitializeComponent();
      }

      #region Events

      private void btnITFConvert1_Click(object sender, RoutedEventArgs e)
      {
         InchesToFeet1();
      }

      private void btnITFConvert2_Click(object sender, RoutedEventArgs e)
      {
         InchesToFeet2();
      }

      private void btnFTIConvert1_Click(object sender, RoutedEventArgs e)
      {
         FeetInchesToInches1();
      }

      private void btnFTIConvert2_Click(object sender, RoutedEventArgs e)
      {
         FeetInchesToInches2();
      }

      private void btnFTCConvert_Click(object sender, RoutedEventArgs e)
      {
         FahrenheitToCelsius();
      }

      private void btnCTFConvert_Click(object sender, RoutedEventArgs e)
      {
         CelsiusToFahrenheit();
      }


      #endregion

      #region PDSA Common Calls

      private void InchesToFeet1()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForIntegerNonBlank(txtITFInches.Text, true))
         {
            instance.InchesToFeet(Convert.ToInt32(txtITFInches.Text));

            txtITFFeetResult.Text = instance.Feet.ToString();
            txtITFInchesResult.Text = instance.Inches.ToString();
         }
         else
         {
            MessageBox.Show("Enter valid Inches");
         }

      }

      private void InchesToFeet2()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForIntegerNonBlank(txtITFInches.Text, true))
         {
            instance.Inches = Convert.ToInt32(txtITFInches.Text);
            instance.InchesToFeet();

            txtITFFeetResult.Text = instance.Feet.ToString();
            txtITFInchesResult.Text = instance.Inches.ToString();
         }
         else
         {
            MessageBox.Show("Enter valid Inches");
         }

      }

      private void FeetInchesToInches1()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForIntegerNonBlank(txtFTIFeet.Text, true))
         {
            if (PDSANumbers.CheckForIntegerNonBlank(txtFTIInches.Text, true))
            {
               instance.FeetAndInchesToInches(Convert.ToInt32(txtFTIFeet.Text), Convert.ToInt32(txtFTIInches.Text));
               txtFTIInchesResult.Text = instance.Inches.ToString();
            }
            else
            {
               MessageBox.Show("Please input a valid Integer value for 'Inches'");
            }
         }
         else
         {
            MessageBox.Show("Please input a valid Integer value for 'Feet'");
         }

      }

      private void FeetInchesToInches2()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForIntegerNonBlank(txtFTIFeet.Text, true))
         {
            if (PDSANumbers.CheckForIntegerNonBlank(txtFTIInches.Text, true))
            {
               instance.Feet = Convert.ToInt32(txtFTIFeet.Text);
               instance.Inches = Convert.ToInt32(txtFTIInches.Text);
               instance.FeetAndInchesToInches();
               txtFTIInchesResult.Text = instance.Inches.ToString();
            }
            else
            {
               MessageBox.Show("Please input a valid Integer value for 'Inches'");
            }
         }
         else
         {
            MessageBox.Show("Please input a valid Integer value for 'Feet'");
         }

      }

      private void FahrenheitToCelsius()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForNumericNonBlank(txtFTCFahrenheit.Text))
         {
            txtFTCCelsius.Text = instance.FahrenheitToCelsius(Convert.ToDouble(txtFTCFahrenheit.Text)).ToString();
         }
         else
         {
            MessageBox.Show("Please input a valid Double value for 'Fahrenheit'");
         }
      }

      private void CelsiusToFahrenheit()
      {
         PDSAMeasurements instance = new PDSAMeasurements();

         if (PDSANumbers.CheckForNumericNonBlank(txtCTFCelsius.Text))
         {
            txtCTFFahrenheit.Text = instance.CelsiusToFahrenheit(Convert.ToDouble(txtCTFCelsius.Text)).ToString();
         }
         else
         {
            MessageBox.Show("Please input a valid Double value for 'Celsius'");
         }
      }

      #endregion

   }
}
