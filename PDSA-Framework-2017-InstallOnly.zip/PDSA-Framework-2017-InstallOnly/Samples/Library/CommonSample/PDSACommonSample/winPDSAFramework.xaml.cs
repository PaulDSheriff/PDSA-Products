﻿using System.Windows;


namespace PDSACommonSample
{
  public partial class winPDSAFramework : Window
  {
    public winPDSAFramework()
    {
      InitializeComponent();
    }

    #region Events

    private void btnGetFrameworkFolder_Click(object sender, RoutedEventArgs e)
    {
      txtResults.Text = PDSA.Common.PDSAFramework.GetFrameworkFolder();
    }

    private void btnGetFrameworkVersion_Click(object sender, RoutedEventArgs e)
    {
      txtVersion.Text = PDSA.Common.PDSAFramework.GetFrameworkVersion();
    }


    #endregion
    
  }
}
