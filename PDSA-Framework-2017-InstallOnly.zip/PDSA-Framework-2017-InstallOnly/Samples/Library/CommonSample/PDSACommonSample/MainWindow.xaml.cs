﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


using PDSA.WPF;
using PDSA.Common;

namespace PDSACommonSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void  btnApplicationException_Click(object sender, RoutedEventArgs e)
    {
       winApplicationException win = new winApplicationException();
       win.Show();
    }

    private void btnString_Click(object sender, RoutedEventArgs e)
    {
        winString win = new winString();
        win.Show();
    }

    private void btnAssemblyInfo_Click(object sender, RoutedEventArgs e)
    {
        winAssemblyInfo win = new winAssemblyInfo();
        win.Show();
    }

    private void btnRegistry_Click(object sender, RoutedEventArgs e)
    {
        winRegistry win = new winRegistry();
        win.Show();
    }

    private void btnDate_Click(object sender, RoutedEventArgs e)
    {
        winDate win = new winDate();
        win.Show();
    }

    private void btnMeasurements_Click(object sender, RoutedEventArgs e)
    {
        winMeasure win = new winMeasure();
        win.Show();
    }

    private void btnSerializer_Click(object sender, RoutedEventArgs e)
    {
        winObjectSerialization win = new winObjectSerialization();
        win.Show();
    }

    private void btnXML_Click(object sender, RoutedEventArgs e)
    {
        winXML win = new winXML();
        win.Show();
    }

    private void btnXMLSync_Click(object sender, RoutedEventArgs e)
    {
       winXMLSynch win = new winXMLSynch();
       win.Show();
    }

     private void btnSystemInfo_Click(object sender, RoutedEventArgs e)
    {
      winSystemInfo win = new winSystemInfo();

      win.Show();
    }

    private void btnSpecialFolders_Click(object sender, RoutedEventArgs e)
    {
       winSpecialFolders win = new winSpecialFolders();

      win.Show();
    }

    private void btnRemoteMachine_Click(object sender, RoutedEventArgs e)
    {
      winRemoteMachine win = new winRemoteMachine();
      win.Show();
    }

    private void btnNumbers_Click(object sender, RoutedEventArgs e)
    {
       winNumbers win = new winNumbers();
       win.Show();
    }

    private void btnNumbersToWords_Click(object sender, RoutedEventArgs e)
    {
       winNumbersToWords win = new winNumbersToWords();
       win.Show();
    }
     

    private void btnPDSAFramework_Click(object sender, RoutedEventArgs e)
    {
       winPDSAFramework win = new winPDSAFramework();
       win.Show();
    }

    private void btnMath_Click(object sender, RoutedEventArgs e)
    {
      winMath win = new winMath();

      win.Show();
    }

    private void btnSoundex_Click(object sender, RoutedEventArgs e)
    {
      winSoundex win = new winSoundex();

      win.Show();
    }
  }
}
