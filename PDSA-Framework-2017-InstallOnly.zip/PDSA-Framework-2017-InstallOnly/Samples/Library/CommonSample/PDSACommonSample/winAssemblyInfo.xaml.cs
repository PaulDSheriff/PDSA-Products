﻿using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winAssemblyInfo : Window
  {
    public winAssemblyInfo()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      LoadAssemblyInfo();
    }


    private void LoadAssemblyInfo()
    {
      PDSAAssemblyInfo instance = new PDSAAssemblyInfo();
      System.Reflection.Assembly assm = System.Reflection.Assembly.GetExecutingAssembly();
      instance = new PDSAAssemblyInfo(assm);
      txtCodeBase.Text = instance.CodeBase;
      txtCopyright.Text = instance.Copyright;
      txtCompany.Text = instance.Company;
      txtDescription.Text = instance.Description;
      txtProduct.Text = instance.Product;
      txtTitle.Text = instance.Title;
      txtVersion.Text = instance.Version;
    }
  }
}
