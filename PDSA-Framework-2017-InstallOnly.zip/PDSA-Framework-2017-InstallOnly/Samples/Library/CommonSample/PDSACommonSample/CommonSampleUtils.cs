﻿using System;

using PDSA.Common;

namespace PDSACommonSample
{
  public class CommonSampleUtils
  {
    public const string REG_SUB_KEY_NAME_BOOL = "boolValue";
    public const string REG_SUB_KEY_NAME_DATE = "dateValue";
    public const string REG_SUB_KEY_NAME_DECIMAL = "decValue";
    public const string REG_SUB_KEY_NAME_INTEGER = "intValue";
    public const string REG_SUB_KEY_NAME_SHORT = "shortValue";
    public const string REG_SUB_KEY_NAME_STRING = "stringValue";

    public static void BuildRegistry(PDSARegistry.PDSAHive hive, string keyName, string MachineName)
    {
      PDSARegistry reg = new PDSARegistry();

      reg.RemoteMachine = MachineName;
      reg.Hive = hive;
      if (!reg.KeyExists(keyName))
        reg.CreateSubKey(keyName);

      reg.Save(keyName, REG_SUB_KEY_NAME_BOOL, true);
      reg.Save(keyName, REG_SUB_KEY_NAME_DATE, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss"));
      reg.Save(keyName, REG_SUB_KEY_NAME_DECIMAL, Math.PI);
      reg.Save(keyName, REG_SUB_KEY_NAME_INTEGER, int.MinValue);
      reg.Save(keyName, REG_SUB_KEY_NAME_SHORT, short.MinValue);
      reg.Save(keyName, REG_SUB_KEY_NAME_STRING, "To be or NOT...");

      reg.KeyValuePairsToRegistry(keyName, getKeyValuePairs());
    }

    private static PDSAKeyValuePairs getKeyValuePairs()
    {
      PDSAKeyValuePairs kv = new PDSAKeyValuePairs();

      kv.Add(new PDSAKeyValuePair("key_1", "value_1"));
      kv.Add(new PDSAKeyValuePair("key_2", "value_2"));
      kv.Add(new PDSAKeyValuePair("key_3", "value_3"));
      kv.Add(new PDSAKeyValuePair("key_4", "value_4"));
      kv.Add(new PDSAKeyValuePair("key_5", "value_5"));

      return kv;
    }

    public static string GetSampleKeyName()
    {
      return string.Format(@"Software\PDSA, Inc.\{0}\{1}", PDSAFramework.FW_FOLDER, "PDSARegistrySample");
    }

    public static void DeleteSampleValues(PDSARegistry.PDSAHive hive, string keyName, string machineName)
    {
      PDSARegistry reg = new PDSARegistry();

      reg.RemoteMachine = machineName;
      if (reg.KeyExists(keyName, hive))
      {
        foreach (string valueName in reg.GetValueNames(keyName, hive))
        {
          reg.Delete(hive, keyName, valueName);
        }
      }
    }
  }
}
