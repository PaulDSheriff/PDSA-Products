﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winRemoteMachine : Window
  {
    public winRemoteMachine()
    {
      InitializeComponent();

      RemoteMachineInfo = (PDSARemoteMachineInfo)this.FindResource("machineInfo");
    }

    protected PDSARemoteMachineInfo RemoteMachineInfo;

    private void btnGetRemoteMachineInfo_Click(object sender, RoutedEventArgs e)
    {
      // We can't data bind to a PasswordBox
      try
      {
        RemoteMachineInfo.Password = txtPassword.Password;

        RemoteMachineInfo.GetAllProperties();

        MessageBox.Show(RemoteMachineInfo.RemoteDateTime.ToString());
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
