﻿using System;
using System.Windows;
using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winMath : Window
  {
    public winMath()
    {
      InitializeComponent();
    }

    private void btnDegreesToRadians_Click(object sender, RoutedEventArgs e)
    {
      double value;
      PDSAMath math = new PDSAMath();

      txtbRadians.Text = math.DegreesToRadians(Double.TryParse(txtDegrees.Text, out value) ? value : 0).ToString();
    }

    private void btnRadiansToDegrees_Click(object sender, RoutedEventArgs e)
    {
      double value;
      PDSAMath math = new PDSAMath();

      txtbDegrees.Text = math.RadiansToDegrees(Double.TryParse(txtRadians.Text, out value) ? value : 0).ToString();
    }

    private void btnBitToTest_Click(object sender, RoutedEventArgs e)
    {
      int value;
      int value2;
      PDSAMath math = new PDSAMath();

      txtbBitTestResult.Text = math.BitTest(int.TryParse(txtValueToTest.Text, out value) ? value : 0,
                                            int.TryParse(txtBitToTest.Text, out value2) ? value2 : 0).ToString();
    }

    private void btnBitToSet_Click(object sender, RoutedEventArgs e)
    {
      int value;
      int value2;
      PDSAMath math = new PDSAMath();

      txtbBitSetResult.Text = math.BitSet(int.TryParse(txtValueToSet.Text, out value) ? value : 0,
                                          int.TryParse(txtBitToSet.Text, out value2) ? value2 : 0).ToString();
    }

    private void btnBitToSetRev_Click(object sender, RoutedEventArgs e)
    {
      int value;
      int value2;
      PDSAMath math = new PDSAMath();

      txtbBitSetResultRev.Text = math.BitSet(int.TryParse(txtValueToSetRev.Text, out value) ? value : 0,
                                             int.TryParse(txtBitToSetRev.Text, out value2) ? value2 : 0, true).ToString();
    }
  }
}
