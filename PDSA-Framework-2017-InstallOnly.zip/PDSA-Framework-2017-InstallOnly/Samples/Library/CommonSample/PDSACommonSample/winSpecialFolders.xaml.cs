﻿using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winSpecialFolders : Window
  {
    public winSpecialFolders()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      tbAppPath.Text = PDSAString.ExpandSpecialFolders("[AppPath]");
      tbUserAppData.Text = PDSAString.ExpandSpecialFolders("[UserAppData]");
      tbMyDocuments.Text = PDSAString.ExpandSpecialFolders("[MyDocuments]");
      tbFrameworkPath.Text = PDSAString.ExpandSpecialFolders("[FrameworkPath]");
      tbFrameworkUserPath.Text = PDSAString.ExpandSpecialFolders("[FrameworkUserPath]");

      tbAppPathEnum.Text = PDSAString.ExpandSpecialFolders(PDSAString.SpecialFolderNameTypes.AppPath);
      tbUserAppDataEnum.Text = PDSAString.ExpandSpecialFolders(PDSAString.SpecialFolderNameTypes.UserAppData);
      tbMyDocumentsEnum.Text = PDSAString.ExpandSpecialFolders(PDSAString.SpecialFolderNameTypes.MyDocuments);
      tbFrameworkPathEnum.Text = PDSAString.ExpandSpecialFolders(PDSAString.SpecialFolderNameTypes.FrameworkPath);
      tbFrameworkUserPathEnum.Text = PDSAString.ExpandSpecialFolders(PDSAString.SpecialFolderNameTypes.FrameworkUserPath);
    }
  }
}
