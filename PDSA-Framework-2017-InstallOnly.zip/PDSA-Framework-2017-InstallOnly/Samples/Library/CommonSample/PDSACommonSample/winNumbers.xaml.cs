﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSACommonSample
{
  public partial class winNumbers : Window
  {
    public winNumbers()
    {
      InitializeComponent();
    }

    #region Events

    private void btnCheckForIntegerNonBlank1_Click(object sender, RoutedEventArgs e)
    {
      txtIntergerResult.Text = PDSANumbers.CheckForIntegerNonBlank(txtInterger.Text).ToString();
    }

    private void btnCheckForIntegerNonBlank2_Click(object sender, RoutedEventArgs e)
    {
      txtIntergerResult.Text = PDSANumbers.CheckForIntegerNonBlank(txtInterger.Text, true).ToString();
    }

    private void btnIsNumeric_Click(object sender, RoutedEventArgs e)
    {
      txtNumericResult.Text = PDSANumbers.IsNumeric(txtNumeric.Text).ToString();
    }

    private void btnCheckForNumericNonBlank1_Click(object sender, RoutedEventArgs e)
    {
      txtNumericResult.Text = PDSANumbers.CheckForNumericNonBlank(txtNumeric.Text).ToString();
    }

    private void btnCheckForNumericNonBlank2_Click(object sender, RoutedEventArgs e)
    {
      txtNumericResult.Text = PDSANumbers.CheckForNumericNonBlank(txtNumeric.Text, true).ToString();
    }

    private void btnNumberOfPages_Click(object sender, RoutedEventArgs e)
    {
      if (PDSANumbers.CheckForIntegerNonBlank(txtTotalRows.Text, true))
      {
        if (PDSANumbers.CheckForIntegerNonBlank(txtPageSize.Text, true))
        {
          txtNumberOfPagesResult.Text = PDSANumbers.NumberOfPages(Convert.ToInt64(txtTotalRows.Text), Convert.ToInt32(txtPageSize.Text)).ToString();
        }
        else
        {
          MessageBox.Show("Invalid 'Page Size'");
        }
      }
      else
      {
        MessageBox.Show("Invalid 'Total Number of Rows'");
      }
    }

    #endregion
  }
}
