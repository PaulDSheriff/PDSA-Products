﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;

using PDSA.DataLayer;
using PDSA.FileIO;

namespace SqlImageSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Window_Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      PDSAFileManager mgr = new PDSAFileManager();

      txtFileName.Text = mgr.FileNameWithCurrentDirectory("Koala.jpg");
    }
    #endregion

    #region Retrieve Image from Disk
    private void btnDisplay_Click(object sender, RoutedEventArgs e)
    {
      theImage.Source = BitmapFrame.Create(new Uri(txtFileName.Text),
        BitmapCreateOptions.DelayCreation, BitmapCacheOption.None);
    }
    #endregion

    #region Store into Database
    private void btnStore_Click(object sender, RoutedEventArgs e)
    {
      StorePicture(txtFileName.Text);
    }

    private void StorePicture(string fileName)
    {
      byte[] picture = null;
      PDSADataManager mgr = new PDSADataManager();
      IDbCommand cmd = null;
      SqlParameter param;

      try
      {
        // Get picture as a byte array from disk
        picture = GetPictureAsBytesFromDisk(fileName);
        // Create Command Object
        cmd = mgr.Provider.CreateCommand("INSERT INTO Pictures(APicture) VALUES(@APicture)");
        // Create Parameter
        // Have to cast to a SqlParameter because the generic DbType does not support "Image"
        param = (SqlParameter)mgr.Provider.CreateParameter("@APicture");
        param.SqlDbType = SqlDbType.Image;
        param.Value = picture;
        cmd.Parameters.Add(param);

        // Create Connection
        cmd.Connection = mgr.Provider.CreateConnection();
        // Execute the SQL
        mgr.Provider.ExecuteSQL(cmd, true);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (cmd != null)
        {
          cmd.Connection.Close();
          cmd.Connection.Dispose();
          cmd.Dispose();
        }
      }
    }
    #endregion

    #region Retrieve From Database
    private void btnRetrieve_Click(object sender, RoutedEventArgs e)
    {
      GetPicture();
    }

    private void GetPicture()
    {
      MemoryStream ms = null;
      byte[] picture = null;
      PDSADataManager mgr = new PDSADataManager();
      IDbCommand cmd = null;

      try
      {
        // Create Command Object
        cmd = mgr.Provider.CreateCommand("SELECT APicture FROM Pictures");
        // Create Connection
        cmd.Connection = mgr.Provider.CreateConnection();
        cmd.Connection.Open();
        // Execute Scalar to get Picture
        picture = (byte[])mgr.Provider.ExecuteScalar(cmd);
        // Turn byte array into Memory Stream
        ms = new MemoryStream(picture);
        // Convert Memory Stream into BitmapFrame 
        theImage.Source = BitmapFrame.Create(ms);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (cmd != null)
        {
          cmd.Connection.Close();
          cmd.Connection.Dispose();
          cmd.Dispose();
        }
      }
    }
    #endregion

    #region GetPictureAsBytesFromDisk Method
    private byte[] GetPictureAsBytesFromDisk(string fileName)
    {
      byte[] picture = null;
      FileStream fs = null;

      try
      {
        fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);

        picture = new byte[fs.Length];

        fs.Read(picture, 0, Convert.ToInt32(fs.Length));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (fs != null)
          fs.Close();
      }

      return picture;
    }
    #endregion
  }
}
