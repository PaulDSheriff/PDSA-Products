CREATE TABLE Pictures
(
  APicture image NULL
)
