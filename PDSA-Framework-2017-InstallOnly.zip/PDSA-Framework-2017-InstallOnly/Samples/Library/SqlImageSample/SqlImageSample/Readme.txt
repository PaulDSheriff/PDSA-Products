SQL Image Sample
-------------------
This sample illustrates procedures for reading images from and writing images to an SQL database.

Open the Pictures.sql and create this table in a SQL Server database
Open the App.Config file and modify the connection string
Run the application to store and retrieve pictures