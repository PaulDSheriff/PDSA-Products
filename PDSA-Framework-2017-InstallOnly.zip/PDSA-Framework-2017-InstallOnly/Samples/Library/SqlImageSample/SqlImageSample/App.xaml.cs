﻿using System.Windows;

namespace SqlImageSample
{
  public partial class App : Application
  {
  }
}
