﻿using System.ComponentModel;
using PDSA.Validation;

namespace PDSASecuritySample
{
  class Role : PDSAEntityBase
  {
    public Role(int id, string name)
    {
      RoleId = id;
      RoleName = name;
    }

    private int _RoleId = 0;
    private string _RoleName = string.Empty;

    public int RoleId
    {
      get { return _RoleId; }
      set
      {
        _RoleId = value;
        RaisePropertyChanged("RoleId");
      }
    }

    public string RoleName
    {
      get { return _RoleName; }
      set
      {
        _RoleName = value;
        RaisePropertyChanged("RoleName");
      }
    }

    public override string ToString()
    {
      return RoleName;
    }
  }
}
