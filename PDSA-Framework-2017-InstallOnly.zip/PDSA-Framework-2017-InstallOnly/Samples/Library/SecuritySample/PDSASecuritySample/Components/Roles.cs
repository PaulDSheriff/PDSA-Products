﻿using System.Collections.Generic;

namespace PDSASecuritySample
{
  class Roles : List<Role>
  {
    public Roles(string name, int count)
    {
      for (int i = 0; i <= count; i++)
        this.Add(new Role(i, name + i.ToString()));
    }
  }
}
