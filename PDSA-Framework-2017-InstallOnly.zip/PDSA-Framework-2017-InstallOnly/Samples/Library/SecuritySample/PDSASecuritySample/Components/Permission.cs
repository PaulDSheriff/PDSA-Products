﻿using System.ComponentModel;
using PDSA.Validation;

namespace PDSASecuritySample
{
  class Permission : PDSAEntityBase
  {
    public Permission(int id, string name)
    {
      PermissionId = id;
      PermissionName = name;
    }

    private int _PermissionId = 0;
    private string _PermissionName = string.Empty;

    public int PermissionId
    {
      get { return _PermissionId; }
      set
      {
        _PermissionId = value;
        RaisePropertyChanged("PermissionId");
      }
    }

    public string PermissionName
    {
      get { return _PermissionName; }
      set
      {
        _PermissionName = value;
        RaisePropertyChanged("PermissionName");
      }
    }

    public override string ToString()
    {
      return PermissionName;
    }
  }
}

