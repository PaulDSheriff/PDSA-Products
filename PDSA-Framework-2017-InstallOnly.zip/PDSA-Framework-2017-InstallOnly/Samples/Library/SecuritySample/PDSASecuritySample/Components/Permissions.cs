﻿using System.Collections.Generic;

namespace PDSASecuritySample
{
  class Permissions : List<Permission>
  {
    public Permissions(string name, int count)
    {
      for (int i = 0; i <= count; i++)
        this.Add(new Permission(i, name + i.ToString()));
    }
  }
}
