﻿using System;
using System.Windows;

using PDSA.Common;

namespace PDSASecuritySample
{
  public partial class winUserIdentitySwitch : Window
  {
    #region Constructor
    public winUserIdentitySwitch()
    {
      InitializeComponent();
    }
    #endregion

    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      ReadFile();
    }

    private void ReadFile()
    {
      PDSAUserIdentity uid = new PDSAUserIdentity();

      try
      {
        if (txtFileName.Text.Length > 0)
        {
          //Path for test: D:\TESTReadFileWPF\ReadMe.txt
          uid.Logon(txtUserName.Text, txtPassword.Password, txtDomain.Text);
          uid.Impersonate();

          //Show machine name and username.
          MessageBox.Show(System.Security.Principal.WindowsIdentity.GetCurrent().Name);

          // Read from file here
          txtContents.Text = System.IO.File.ReadAllText(txtFileName.Text);

          uid.Undo();
        }
        else
        {
          MessageBox.Show("Please input file name and path.");
        }

      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      ClearAll();
    }

    private void ClearAll()
    {
      txtFileName.Text = String.Empty;
      txtContents.Text = String.Empty;
    }
  }
}
