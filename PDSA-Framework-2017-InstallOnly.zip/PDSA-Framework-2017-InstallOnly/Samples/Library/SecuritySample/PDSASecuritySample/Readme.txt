This sample shows you how to use the classes in the PDSA.Security samples
----------------------------------------------------------------------------

winUserIdentitySwitch Sample
This sample shows how to secure a file in a folder

===========================================================================================
Have an administrator of a computer create a new user (for example: John) for a computer or domain.
Have the admin create a folder either on a local hard drive or on a network share and place a file into that folder. 
Lock the folder down so only this new user (John) can read from this folder. The Admin should have full rights to this folder of course.
In this sample application, modify the call to uid.LogonAsUser to use John's credentials.
Your current user id should be able to run this application and be able to read from this file even though you do not have rights to this folder.
This is because for the small amount of time where you read the file you are impersonating someone else.
This can be used to secure connection strings on a computer so normal users can not see the connection information.
