﻿using System;
using System.Windows;

namespace PDSASecuritySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnPassword_Click(object sender, RoutedEventArgs e)
    {
      winPassword win = new winPassword();

      win.Show();
    }

    private void btnPrincipal_Click(object sender, RoutedEventArgs e)
    {
      winPrincipal win = new winPrincipal();

      win.Show();
    }

    private void btnUserIdentitySwitch_Click(object sender, RoutedEventArgs e)
    {
      winUserIdentitySwitch win = new winUserIdentitySwitch();

      win.Show();
    }
  }
}
