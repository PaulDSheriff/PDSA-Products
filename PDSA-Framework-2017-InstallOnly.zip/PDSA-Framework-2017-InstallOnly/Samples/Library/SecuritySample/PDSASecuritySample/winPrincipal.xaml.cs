﻿using System;
using System.Security.Principal;
using System.Windows;

using PDSA.Framework.EntityLayer;
using PDSA.Security;

namespace PDSASecuritySample
{
  public partial class winPrincipal : Window
  {
    #region Constructor
    public winPrincipal()
    {
      InitializeComponent();
    }
    #endregion

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtUserName.Text = Environment.UserName;

      Roles roles = new Roles("Role Number ", 5);

      lstRoles.DataContext = roles;
      
      Permissions permissions = new Permissions("Permissions Number ", 5);
      lstPermissions.DataContext = permissions;
    }

    private void btnCreateCustomPrincipal_Click(object sender, RoutedEventArgs e)
    {
      CreateCustomIdentity();
    }

    private void CreateCustomIdentity()
    {
      PDSAPrincipal prin;
      GenericIdentity identity;
      pdsaPermissionCollection permissions;
      pdsaRoleCollection roles;

      // Create new GenericIdentity
      identity = new GenericIdentity(txtUserName.Text);

      // Get permissions selected from List
      permissions = CreatePermissionCollection();

      // Get roles selected from List
      roles = CreateRoleCollection();

      // Create new Principal Object
      prin = new PDSAPrincipal(identity, roles, permissions);

      // Now hover over the "prin" variable and view the values
      System.Diagnostics.Debugger.Break();
    }

    private void CreateWindowsIdentity()
    {
      PDSAPrincipal prin;
      WindowsIdentity wi = WindowsIdentity.GetCurrent();
      pdsaPermissionCollection permissions = new pdsaPermissionCollection();
      pdsaRoleCollection roles = new pdsaRoleCollection();

      prin = new PDSAPrincipal(wi, roles, permissions);

      // Now hover over the "prin" variable and view the values
      System.Diagnostics.Debugger.Break();
    }

    #region CreatePermissionCollection Method
    private pdsaPermissionCollection CreatePermissionCollection()
    {
      pdsaPermissionCollection ret = new pdsaPermissionCollection();
      pdsaPermission perm;

      foreach (Permission item in lstPermissions.Items)
      {
        if (item.IsSelected)
        {
          perm = new pdsaPermission();

          perm.PermissionId = item.PermissionId;
          perm.PermissionName = item.PermissionName;

          ret.Add(perm);
        }
      }

      return ret;
    }
    #endregion

    #region CreateRoleCollection Method
    private pdsaRoleCollection CreateRoleCollection()
    {
      pdsaRoleCollection ret = new pdsaRoleCollection();
      pdsaRole role;

      foreach (Role item in lstRoles.Items)
      {
        if (item.IsSelected)
        {
          role = new pdsaRole();

          role.RoleId = item.RoleId;
          role.RoleName = item.RoleName;

          ret.Add(role);
        }
      }

      return ret;
    }
    #endregion

  }
}
