﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using PDSA.Security;

namespace PDSASecuritySample
{
  public partial class winPassword : Window
  {
    public winPassword()
    {
      InitializeComponent();
    }

    private void btnGenerateStrongPassword_Click(object sender, RoutedEventArgs e)
    {
      PDSAPassword _pw = new PDSAPassword();

      txtGenerateStrongPassword.Text = _pw.GenerateStrongPassword(Convert.ToInt32(cbMinLength.Text));
    }

    private void btnGetStrongPasswordRegularExpression_Click(object sender, RoutedEventArgs e)
    {
      txtGetStrongPasswordRegularExpression.Text = PDSAPassword.GetStrongPasswordRegularExpression(8, 15);
    }

    private void btnIsPasswordStrong_Click(object sender, RoutedEventArgs e)
    {
      PDSAPassword _pw = new PDSAPassword();
      int min = 0;
      int max = 0;

      if (txtPassword.Text.Trim().Length != 0)
      {
        min = Convert.ToInt32(cbMinLength.Text);
        max = Convert.ToInt32(cbMaxLength.Text);

        if (min != 0 && max != 0)
          ShowPWMessage(PDSAPassword.IsPasswordStrong(txtPassword.Text, min, max));
        else if (max == 0)
          ShowPWMessage(PDSAPassword.IsPasswordStrong(txtPassword.Text, min));
        else
          ShowPWMessage(PDSAPassword.IsPasswordStrong(txtPassword.Text));
      }
      else
        MessageBox.Show("Please enter a password.");
    }
    private void ShowPWMessage(bool IsPasswordStrong)
    {
      MessageBox.Show(string.Format("The password '{0}' IsPasswordStrong: {1}.", txtPassword.Text, IsPasswordStrong));
    }

    private void btnIsPasswordStrongRX_Click(object sender, RoutedEventArgs e)
    {
      Regex rex = new Regex(txtGetStrongPasswordRegularExpression.Text);

      if (txtGetStrongPasswordRegularExpression.Text.Length != 0)
      {
        if (txtPassword.Text.Trim().Length != 0)
          ShowPWMessage(rex.IsMatch(txtPassword.Text));
        else
          MessageBox.Show("Please enter a password.");
      }
      else
        MessageBox.Show(string.Format("Please press '{0}' button to get the Regular Expression.", btnGetStrongPasswordRegularExpression.Content));
    }
  }
}