﻿using System.Windows;
using System.Windows.Input;

using PDSA.Common;

namespace SoftwareInstalled
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    PDSASoftwareManager _Manager = new PDSASoftwareManager();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      PDSASystemInfo si = new PDSASystemInfo();

      if (si.Is64bitOS)
        rdo64Bit.IsChecked = true;
      else
        rdo32Bit.IsChecked = true;
      
      txtRegistryKey.Text = _Manager.RegistryKeyToSearch;
    }

    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      Cursor old = this.Cursor;

      this.Cursor = Cursors.Wait;
      _Manager.LoadInstalledSoftware(txtRegistryKey.Text, txtWildCard.Text);

      lstData.View = PDSA.WPF.PDSAWPFListView.CreateGridViewColumns(typeof(PDSASoftware));
      lstData.ItemsSource = _Manager.InstalledSoftware;

      txtMsg.Text = _Manager.LastExceptionMessage;
      this.Cursor = old;
    }

    private void rdo32Bit_Checked(object sender, RoutedEventArgs e)
    {
      _Manager.Set32BitRegistrySearchKey();
      txtRegistryKey.Text = _Manager.RegistryKeyToSearch;
    }

    private void rdo64Bit_Checked(object sender, RoutedEventArgs e)
    {
      _Manager.Set64BitRegistrySearchKey();
      txtRegistryKey.Text = _Manager.RegistryKeyToSearch;
    }  
  }
}
