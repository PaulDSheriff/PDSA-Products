﻿Software Installed Sample
----------------------------------------------------------------
This sample will display the list of software installed on your computer.
This is similar to going into the Control Panel and clicking on Uninstall Programs

NOTE: You may need to run this sample as an 'Administrator' in order to read the software.
