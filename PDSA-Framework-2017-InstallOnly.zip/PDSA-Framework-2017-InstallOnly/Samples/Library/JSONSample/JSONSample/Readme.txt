﻿JSON Sample
----------------------------------
This sample shows the built-in JSON formatting in the PDSA Data Layer objects

Before running this sample, you must do the following:

1. Create the 'PDSASamples' database from Haystack if you have not already.
2. Adjust the ConnectionString as appropriate in the App.Config to point to this database.
