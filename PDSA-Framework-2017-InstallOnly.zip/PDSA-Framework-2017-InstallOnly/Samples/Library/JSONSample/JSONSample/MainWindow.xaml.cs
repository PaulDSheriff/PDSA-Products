﻿using System.Windows;

using PDSA.Common;
using Sample.Project.DataLayer;
using Sample.Project.EntityLayer;

namespace JSONSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      mgr.DataObject.LoadByPK(1);

      txtJSON.Text = PDSAString.GetAsJSON(typeof(Product), mgr.Entity);
    }

    private void btnGetProducts_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();
      ProductCollection coll;

      coll = mgr.BuildCollection();

      txtJSON.Text = PDSAString.GetAsJSON(typeof(ProductCollection), coll);
    }

    private void btnDataSet_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      txtJSON.Text = PDSAString.GetAsJSON(mgr.DataObject.GetDataSet());
    }

    private void btnDataTable_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      txtJSON.Text = PDSAString.GetAsJSON(mgr.DataObject.GetDataSet().Tables[0]);
    }
  }
}
