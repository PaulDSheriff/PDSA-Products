﻿using System;
using System.Configuration;

namespace PDSADBSchemaSample
{
  internal class AppSettings
  {
    #region Static Instance Property
    private static AppSettings _Instance = null;

    public static AppSettings Instance
    {
      get
      {
        if (_Instance == null)
        {
          _Instance = new AppSettings();
        }

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Public Properties
    public int RowThreshold
    {
      get { return Convert.ToInt32(ConfigurationManager.AppSettings["RowThreshold"]); }
    }

    public string ProviderName { get; set; }
    public string Schema { get; set; }
    public string Table { get; set; }
    public string Column { get; set; }
    #endregion

    #region Load Method
    public void Load()
    {
      Schema = GetSetting("Schema");
      Table = GetSetting("Table");
    }
    #endregion

    #region Support Methods
    protected static string GetConnectString(string key)
    {
      return ConfigurationManager.ConnectionStrings[key].ConnectionString;
    }

    protected static string GetSetting(string key)
    {
      return ConfigurationManager.AppSettings[key];
    }
    #endregion
  }
}
