PDSA Database Schema Sample - VB
----------------------------------------------
This sample will show you samples of how to read Database Schema information from SQL Server

These classes are contained in the PDSA.DataLayer.Schema namespace

To Run this Sample:
Install the PDSASamples database from Haystack
Install the PDSAFramework500 database from the PDSA Framework
Modify the App.Config file and change the connection strings to point to the PDSASamples and PDSAFramework500 databases
