﻿using System.Windows.Controls;

namespace PDSADBSchemaSample
{
  public partial class ucSchemaTableInfo : UserControl
  {
    public ucSchemaTableInfo()
    {
      InitializeComponent();
    }

    private void btnSClear_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      txtColumnName.Text = string.Empty;
      txtSchemaName.Text = string.Empty;
      txtTableName.Text = string.Empty;
    }
  }
}
