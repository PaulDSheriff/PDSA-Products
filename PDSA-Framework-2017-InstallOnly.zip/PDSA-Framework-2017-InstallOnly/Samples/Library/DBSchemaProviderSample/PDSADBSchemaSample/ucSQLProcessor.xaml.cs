﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;

using PDSA.DataLayer.Schema;

namespace PDSADBSchemaSample
{
  public partial class ucSQLProcessor : UserControl
  {
    public ucSQLProcessor()
    {
      InitializeComponent();
    }

    public string ProviderName
    {
      get { return txtProvider.Text; }
      set { txtProvider.Text = value; }
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      AppSettings.Instance.Load();
    }

    private void btnGetTokens_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        DisplayOutput(provider.GetAllTokens(txtSentence.Text));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void GetColumnsParameters_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        DisplayOutput(provider.GetAllColumnsAndParameters(txtSentence.Text));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void GetColumns_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        DisplayOutput(provider.GetAllColumns(txtSentence.Text));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void GetParameters_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        DisplayOutput(provider.GetAllParameters(txtSentence.Text));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private PDSADBSchemaProvider GetProvider()
    {
      PDSADBSchemaManager mgr = new PDSADBSchemaManager();

      mgr.Provider = mgr.GetProvider(txtProvider.Text);

      return mgr.Provider;
    }

    private void DisplayOutput(string[] tokens)
    {
      lstWords.DataContext = tokens;

      if (txtSnippet.Text.Trim() != string.Empty)
      {
        StringBuilder sb = new StringBuilder(2048);

        foreach (string token in tokens)
        {
          sb.AppendFormat(txtSnippet.Text, token);
          sb.Append(Environment.NewLine);
        }

        txtOutput.Text = sb.ToString();
      }
    }

    private void btnFormatSQL_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        txtOutput.Text = provider.FormatSQL(txtSentence.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnRemoveComments_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        txtOutput.Text = provider.RemoveComments(txtSentence.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      lstWords.DataContext = null;
      txtOutput.Clear();
      txtSentence.Clear();
      txtSentence.Focus();
    }

    private void btnProcedureType_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        txtOutput.Text = provider.ProcedureType(txtSentence.Text).ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnOrderBy_Click(object sender, RoutedEventArgs e)
    {
      PDSASqlOrderByColumn col = new PDSASqlOrderByColumn();

      try
      {
        lstWords.DataContext = null;

        lstWords.DataContext = col.GetColumns(txtSentence.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnSplitSelect_Click(object sender, RoutedEventArgs e)
    {
      PDSASqlSelectStatement sel = new PDSASqlSelectStatement();

      try
      {
        txtOutput.Text = string.Empty;

        if (!sel.SplitIntoParts(txtSentence.Text))
          MessageBox.Show("Invalid SELECT Statement");
        else
          txtOutput.Text = "Columns: " + sel.Columns + Environment.NewLine + Environment.NewLine + "Rest of Statement: " + sel.RestOfStatement;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }

    private void btnProcSpec_Click(object sender, RoutedEventArgs e)
    {
      PDSADBSchemaProvider provider = null;

      try
      {
        provider = GetProvider();

        lstWords.DataContext = null;
        txtOutput.Text = provider.GetStoredProcedureSpecification(txtSentence.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
  }
}
