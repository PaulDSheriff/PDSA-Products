﻿using System.Windows;

namespace PDSADBSchemaSample
{
  public partial class App : Application
  {
  }
}
