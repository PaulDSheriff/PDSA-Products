﻿using System.Windows.Controls;

namespace PDSADBSchemaSample
{
  public partial class ucPackageInfo : UserControl
  {
    public ucPackageInfo()
    {
      InitializeComponent();
    }

    private void btnPClear_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      txtPackageName.Text = string.Empty;
      txtSchemaName.Text = string.Empty;
      txtSPName.Text = string.Empty;
    }
  }
}
