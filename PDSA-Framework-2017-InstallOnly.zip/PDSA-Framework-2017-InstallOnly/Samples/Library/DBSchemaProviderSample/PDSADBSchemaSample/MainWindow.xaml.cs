﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Data;

using PDSA.CodeGeneration;
using PDSA.DataLayer.Schema;
using PDSA.DataLayer.Schema.Configuration;
using PDSA.WPF;

namespace PDSADBSchemaSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Window_Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProvidersLoad();
    }
    #endregion

    #region ProvidersLoad Method
    private void ProvidersLoad()
    {
      PDSADBSchemaManager mgr = new PDSADBSchemaManager();

      cboProviders.DataContext = mgr.GetProviderNames();

      cboProviders.SelectedIndex = 0;
    }
    #endregion

    #region Private Variables
    StringBuilder _InfoMessages = new StringBuilder(2048);
    StringBuilder _ErrorMessages = new StringBuilder(2048);

    PDSADBSchemaProvider _SchemaProvider = null;
    PDSADBSchemaManager _Manager = new PDSADBSchemaManager();
    #endregion

    #region Message Events
    void provider_InfoMessage(object sender, PDSADBSchemaEventArgs e)
    {
      MessageDisplay(e.Message);
    }

    void provider_ErrorMessage(object sender, PDSADBSchemaEventArgs e)
    {
      ErrorDisplay(e.LastException.ToString());
    }
    #endregion

    #region Display Messages/Error Methods
    private void MessageDisplay(string message)
    {
      _InfoMessages.Append(message + Environment.NewLine);
    }

    private void ErrorDisplay(string message)
    {
      _ErrorMessages.Append(message + Environment.NewLine);

      tabSchema.SelectedItem = tabErrors;
    }
    #endregion

    #region IsViewSchemaFilledIn Method
    private bool IsViewSchemaFilledIn()
    {
      return (ucInfoViews.txtSchemaName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsTableSchemaFilledIn Method
    private bool IsTableSchemaFilledIn()
    {
      return (ucInfoTable.txtSchemaName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSPsSchemaFilledIn Method
    private bool IsSPsSchemaFilledIn()
    {
      return (ucInfoSPs.txtSchemaName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSchemaTableFilledIn Method
    private bool IsSchemaTableFilledIn()
    {
      return (ucInfoTable.txtSchemaName.Text.Trim() != string.Empty && ucInfoTable.txtTableName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSchemaTableColumnFilledIn Method
    private bool IsSchemaTableColumnFilledIn()
    {
      return (ucInfoTable.txtSchemaName.Text.Trim() != string.Empty && ucInfoTable.txtTableName.Text.Trim() != string.Empty && ucInfoTable.txtColumnName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSchemaViewColumnFilledIn Method
    private bool IsSchemaViewColumnFilledIn()
    {
      return (ucInfoViews.txtSchemaName.Text.Trim() != string.Empty && ucInfoViews.txtViewName.Text.Trim() != string.Empty && ucInfoViews.txtColumnName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSchemaViewFilledIn Method
    private bool IsSchemaViewFilledIn()
    {
      return (ucInfoViews.txtSchemaName.Text.Trim() != string.Empty && ucInfoViews.txtViewName.Text.Trim() != string.Empty);
    }
    #endregion

    #region IsSchemaSPFilledIn Method
    private bool IsSchemaSPFilledIn()
    {
      return (ucInfoSPs.txtSchemaName.Text.Trim() != string.Empty && ucInfoSPs.txtSPName.Text.Trim() != string.Empty);
    }
    #endregion

    #region Providers ComboBox SelectionChanged Event
    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      PDSADBSchemaConfigProvider configProvider = null;

      try
      {
        if (cboProviders.SelectedIndex >= 0)
        {
          configProvider = (PDSADBSchemaConfigProvider)cboProviders.SelectedItem;
          _SchemaProvider = _Manager.GetProvider(configProvider.ProviderName);
          ucProcessor.ProviderName = _SchemaProvider.ProviderName;

          // Fill in Project property in Code Generation Manager
          PDSACodeGenerationManager.Instance.Project.SchemaProvider = _SchemaProvider;

          _SchemaProvider.RaiseEvents = false;
          _SchemaProvider.ReportErrorMessage += new PDSADBSchemaProvider.ErrorMessageEventHandler(provider_ErrorMessage);
          _SchemaProvider.ReportInfoMessage += new PDSADBSchemaProvider.InfoMessageEventHandler(provider_InfoMessage);

          lblDataProviderName.Text = _SchemaProvider.ConfigurationProvider.DataProviderName;
          txtConnectString.Text = _SchemaProvider.DataProvider.ConnectString;
          lblSchemaFilter.Text = _SchemaProvider.FilterOutSchemas;

          if (configProvider.UserNameIsSchemaName)
          {
            ucInfoTable.txtSchemaName.Text = _SchemaProvider.GetUserIDFromConnectString();
            ucInfoViews.txtSchemaName.Text = _SchemaProvider.GetUserIDFromConnectString();
            ucInfoSPs.txtSchemaName.Text = _SchemaProvider.GetUserIDFromConnectString();
            ucInfoPackage.txtSchemaName.Text = _SchemaProvider.GetUserIDFromConnectString();
            txtMiscSchemaName.Text = _SchemaProvider.GetUserIDFromConnectString();
          }

          tabCatalog.IsEnabled = true;
          tabCounts.IsEnabled = true;
          tabTables.IsEnabled = true;
          tabViews.IsEnabled = true;
          tabSPs.IsEnabled = true;
          tabIndexes.IsEnabled = true;
          tabProcessor.IsEnabled = true;
          tabInfo.IsEnabled = true;
          tabErrors.IsEnabled = true;

          if (_SchemaProvider.DatabaseType == PDSA.DataLayer.PDSADatabaseType.Oracle)
          {
            tabPackages.IsEnabled = true;
            btnCountsPackages.IsEnabled = true;
            btnCountsCatalog.IsEnabled = false;
            btnAllCatalogs.IsEnabled = false;
          }
          else
          {
            tabPackages.IsEnabled = false;
            btnCountsPackages.IsEnabled = false;
            btnCountsCatalog.IsEnabled = true;
            btnAllCatalogs.IsEnabled = true;
          }
        }
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }
    #endregion

    #region All Catalog/All Schemas Methods
    private void btnAllCatalogs_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllCatalogsLoad();
      this.Cursor = c;
    }

    private void AllCatalogsLoadHardCoded()
    {
      PDSADBSchemaManager mgr = new PDSADBSchemaManager();

      lstData.ItemsSource = mgr.Provider.GetCatalogs();
    }

    private void AllCatalogsLoad()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaCatalog));

        lstData.ItemsSource = _SchemaProvider.GetCatalogs();
        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }

    private void btnAllSchemas_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllSchemasLoad();
      this.Cursor = c;
    }

    private void AllSchemasLoad()
    {      
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchema));

        lstData.ItemsSource = _SchemaProvider.GetSchemas();
        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Counts Methods
    private void btnCountsCatalog_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      CatalogCount();
      this.Cursor = c;
    }

    private void CatalogCount()
    {
      try
      {
        tbCatalogCount.Text = _SchemaProvider.GetCatalogCount().ToString();
        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }

    private void btnCountsSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      SchemaCount();
      this.Cursor = c;
    }

    private void SchemaCount()
    {
      try
      {
        tbSchemaCount.Text = _SchemaProvider.GetSchemaCount().ToString();
        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }

    private void btnCountsTable_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableCount();
      this.Cursor = c;
    }

    private void TableCount()
    {
      try
      {
        if (txtCountsSchemaName.Text.Trim() == string.Empty)
          tbTableCount.Text = _SchemaProvider.GetTableCount().ToString();
        else
          tbTableCount.Text = _SchemaProvider.GetTableCount(txtCountsSchemaName.Text.Trim()).ToString();

        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }

    private void btnCountsView_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      ViewCount();
      this.Cursor = c;
    }

    private void ViewCount()
    {
      try
      {
        if (txtCountsSchemaName.Text.Trim() == string.Empty)
          tbViewCount.Text = _SchemaProvider.GetViewCount().ToString();
        else
          tbViewCount.Text = _SchemaProvider.GetViewCount(txtCountsSchemaName.Text.Trim()).ToString();

        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }

    private void btnCountsStoredProc_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcCount();
      this.Cursor = c;
    }

    private void StoredProcCount()
    {
      try
      {
        if (txtCountsSchemaName.Text.Trim() == string.Empty)
          tbSPCount.Text = _SchemaProvider.GetStoredProcedureCount().ToString();
        else
          tbSPCount.Text = _SchemaProvider.GetStoredProcedureCount(txtCountsSchemaName.Text.Trim()).ToString();

        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }

    private void btnCountsPackages_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      PackageCount();
      this.Cursor = c;
    }

    private void PackageCount()
    {
      try
      {
        if (txtCountsSchemaName.Text.Trim() == string.Empty)
          tbPackageCount.Text = _SchemaProvider.GetPackageCount().ToString();
        else
          tbPackageCount.Text = _SchemaProvider.GetPackageCount(txtCountsSchemaName.Text.Trim()).ToString();

        SetSQL();
      }
      catch (Exception ex)
      {
        MessageDisplay(ex.ToString());
      }
    }
    #endregion

    #region SchemaExists
    private void btnSchemaExists_Click(object sender, RoutedEventArgs e)
    {
      SchemaExists();
    }

    private void SchemaExists()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() == string.Empty)
          MessageBox.Show("Fill in a Valid Schema Name");
        else
        {
          if (_SchemaProvider.DoesSchemaExist(txtMiscSchemaName.Text.Trim()))
            MessageBox.Show("Schema Exists");
          else
            MessageBox.Show("Schema Does NOT Exist");

          SetSQL();
        }
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllTables
    private void btnAllTables_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetAllTables();
      this.Cursor = c;
    }

    private void GetAllTables()
    {
      try
      {
        lstData.View = PDSA.WPF.PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaTable));

        lstData.ItemsSource = _SchemaProvider.GetTables(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());
        // Load all info when loading tables
        //lstData.ItemsSource = _SchemaProvider.GetTables(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim(), true);

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TablesInSchema
    private void btnTablesInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TablesInSchema();
      this.Cursor = c;
    }

    private void TablesInSchema()
    {
      try
      {
        lstData.View = PDSA.WPF.PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaTable));
        lstData.ItemsSource = _SchemaProvider.GetTables(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableExists
    private void btnTableExists_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;
      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableExists();
      this.Cursor = c;
    }

    private void TableExists()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          if (_SchemaProvider.DoesTableExist(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim()))
            MessageBox.Show("Table Exists");
          else
            MessageBox.Show("Table Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllViews
    private void btnAllViews_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetAllViews();
      this.Cursor = c;
    }

    private void GetAllViews()
    {
      try
      {
        lstData.View = PDSA.WPF.PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaView));
        lstData.ItemsSource = _SchemaProvider.GetViews(ucInfoViews.txtSchemaName.Text, ucInfoViews.txtViewName.Text, false);

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ViewsInSchema
    private void btnViewsInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      ViewsInSchema();
      this.Cursor = c;
    }

    private void ViewsInSchema()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaView));
        lstData.ItemsSource = _SchemaProvider.GetViews(ucInfoViews.txtSchemaName.Text, ucInfoViews.txtViewName.Text, false);

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ViewExists
    private void btnViewExists_Click(object sender, RoutedEventArgs e)
    {
      ViewExists();
    }

    private void ViewExists()
    {
      try
      {
        if (IsSchemaViewFilledIn())
        {
          if (_SchemaProvider.DoesViewExist(ucInfoViews.txtSchemaName.Text.Trim(), ucInfoViews.txtViewName.Text.Trim()))
            MessageBox.Show("View Exists");
          else
            MessageBox.Show("View Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/View Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllStoredProcs
    private void btnAllSPs_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllStoredProcs();
      this.Cursor = c;
    }

    private void AllStoredProcs()
    {
      GridView gv;
      int rows;

      try
      {
        rows = _SchemaProvider.GetStoredProcedureCount();
        if (rows > AppSettings.Instance.RowThreshold)
        {
          MessageBox.Show("This query would return " + rows.ToString() + "rows. This amount exceeds the RowThreshold of " + AppSettings.Instance.RowThreshold.ToString() + " set in the App.Config file. This query will not run.");
        }
        else
        {
          gv = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));

          lstData.View = gv;
          lstData.ItemsSource = _SchemaProvider.GetStoredProcedures(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text);
        }

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region StoredProcsInSchema
    private void btnSPsInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcsInSchema();
      this.Cursor = c;
    }

    private void StoredProcsInSchema()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));
        lstData.ItemsSource = _SchemaProvider.GetStoredProcedures(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text);

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region StoredProcExists
    private void btnSPExists_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcExists();
      this.Cursor = c;
    }

    private void StoredProcExists()
    {
      try
      {
        if (IsSchemaSPFilledIn())
        {
          if (_SchemaProvider.DoesStoredProcExist(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text.Trim()))
            MessageBox.Show("Stored Proc Exists");
          else
            MessageBox.Show("Stored Proc Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in Schema Name/Stored Proc Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region StoredProcDefinition
    private void btnSPText_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetStoredProcDefinition();
      this.Cursor = c;
    }

    private void GetStoredProcDefinition()
    {
      PDSASchemaStoredProc proc;
      PDSASchemaStoredProcs procs = new PDSASchemaStoredProcs();

      try
      {
        proc = _SchemaProvider.GetStoredProcedure(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text.Trim());
        proc.Definition = _SchemaProvider.GetStoredProcedureText(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text.Trim(), string.Empty);
        procs.Add(proc);

        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));
        lstData.ItemsSource = procs;

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableIndexes
    private void btnTableIndexes_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableIndexes();
      this.Cursor = c;
    }

    private void TableIndexes()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaIndex));
          lstData.ItemsSource = _SchemaProvider.GetIndexes(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region GetAllTable Info Method
    private void btnAllForTable_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetAllTableInfo();
      this.Cursor = c;
    }

    private void GetAllTableInfo()
    {
      PDSASchemaTable tbl;

      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaColumn));
          tbl = _SchemaProvider.GetTable(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim(), true);

          lstData.ItemsSource = tbl.Columns;

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill In Schema and Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TablePrimaryKey
    private void btnTablePK_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TablePrimaryKey();
      this.Cursor = c;
    }

    private void TablePrimaryKey()
    {
      PDSASchemaPrimaryKeys keys = new PDSASchemaPrimaryKeys();

      try
      {
        if (IsSchemaTableFilledIn())
        {
          keys.Add(_SchemaProvider.GetPrimaryKeyInfo(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim()));

          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPrimaryKey));
          lstData.ItemsSource = keys;

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableForeignKeys
    private void btnTableForeigns_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;
      TableForeignKeys();
      c = this.Cursor;
      this.Cursor = Cursors.Wait;

      this.Cursor = c;
    }

    private void TableForeignKeys()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaForeignKey));
          lstData.ItemsSource = _SchemaProvider.GetForeignKeys(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableAndAllRelated
    private void btnTableAllRelated_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetTableAndAllRelated();
      this.Cursor = c;
    }

    private void GetTableAndAllRelated()
    {
      PDSASchemaTables tbls;

      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaTable));
          tbls = _SchemaProvider.GetTableFKTablesAndChildTables(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim(), true);

          lstData.ItemsSource = tbls;

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill In Schema and Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Child Tables
    private void btnChildTables_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;
      ChildTables();
      c = this.Cursor;
      this.Cursor = Cursors.Wait;

      this.Cursor = c;
    }

    private void ChildTables()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaTable));
          lstData.ItemsSource = _SchemaProvider.GetChildTables(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableUniqueConstraints
    private void btnTableUniques_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableUniqueConstraints();
      this.Cursor = c;
    }

    private void TableUniqueConstraints()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaUniqueConstraint));
          lstData.ItemsSource = _SchemaProvider.GetUniqueConstraints(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableCheckConstraints
    private void btnTableChecks_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableCheckConstraints();
      this.Cursor = c;
    }

    private void TableCheckConstraints()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaCheckConstraint));
          lstData.ItemsSource = _SchemaProvider.GetCheckConstraints(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region TableColumns
    private void btnTableColumns_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      TableColumns();
      this.Cursor = c;
    }

    private void TableColumns()
    {
      try
      {
        if (IsSchemaTableFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaColumn));
          lstData.ItemsSource = _SchemaProvider.GetColumns(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim());
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name");

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ColumnExistsInTable
    private void btnColumInTable_Click(object sender, RoutedEventArgs e)
    {
      ColumnExistsInTable();
    }

    private void ColumnExistsInTable()
    {
      try
      {
        if (IsSchemaTableColumnFilledIn())
        {
          if (_SchemaProvider.DoesColumnExist(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim(), ucInfoTable.txtColumnName.Text.Trim()))
            MessageBox.Show("Column Exists");
          else
            MessageBox.Show("Column Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name/Column Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ColumnsInView
    private void btnViewColumns_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      ViewColumns();
      this.Cursor = c;
    }

    private void ViewColumns()
    {
      try
      {
        if (IsSchemaViewFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaColumn));
          lstData.ItemsSource = _SchemaProvider.GetView(ucInfoViews.txtSchemaName.Text.Trim(), ucInfoViews.txtViewName.Text.Trim(), true).Columns;

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/View Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ColumnExistsInView
    private void btnColumnInView_Click(object sender, RoutedEventArgs e)
    {
      ColumnExistsInView();
    }

    private void ColumnExistsInView()
    {
      try
      {
        if (IsSchemaViewColumnFilledIn())
        {
          if (_SchemaProvider.DoesColumnExist(ucInfoViews.txtSchemaName.Text.Trim(), ucInfoViews.txtViewName.Text.Trim(), ucInfoViews.txtColumnName.Text.Trim()))
            MessageBox.Show("Column Exists");
          else
            MessageBox.Show("Column Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/View Name/Column Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region IsColumnPrimaryKey
    private void btnIsColumnPK_Click(object sender, RoutedEventArgs e)
    {
      IsColumnPrimayKey();
    }

    private void IsColumnPrimayKey()
    {
      try
      {
        if (IsSchemaTableColumnFilledIn())
        {
          if (_SchemaProvider.IsColumnPrimaryKey(ucInfoTable.txtSchemaName.Text.Trim(), ucInfoTable.txtTableName.Text.Trim(), ucInfoTable.txtColumnName.Text.Trim()))
            MessageBox.Show("Column is Primary Key");
          else
            MessageBox.Show("Column is NOT a Primary Key");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in a Schema Name/Table Name/Column Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region StoredProcParameters
    private void btnSPParams_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcParameters();
      this.Cursor = c;
    }

    private void StoredProcParameters()
    {
      try
      {
        if (IsSchemaSPFilledIn())
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProcParameter));
          lstData.ItemsSource = _SchemaProvider.GetStoredProcedureParameters(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in Schema/Stored Proc Name");

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllColumns
    private void btnAllColumns_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllColumns();
      this.Cursor = c;
    }

    private void AllColumns()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaColumn));
        lstData.ItemsSource = _SchemaProvider.GetColumns();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ColumnsInSchema
    private void btnColumnsInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllColumnsInSchema();
      this.Cursor = c;
    }

    private void AllColumnsInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaColumn));
          lstData.ItemsSource = _SchemaProvider.GetColumns(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllForeignKeys
    private void btnAllForeigns_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllForeignKeys();
      this.Cursor = c;
    }

    private void AllForeignKeys()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaForeignKey));
        lstData.ItemsSource = _SchemaProvider.GetForeignKeys();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region ForeignKeysInSchema
    private void btnForeignInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllForeignKeysInSchema();
      this.Cursor = c;
    }

    private void AllForeignKeysInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaForeignKey));
          lstData.ItemsSource = _SchemaProvider.GetForeignKeys(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllIndexes
    private void btnAllIndexes_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllIndexes();
      this.Cursor = c;
    }

    private void AllIndexes()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaIndex));
        lstData.ItemsSource = _SchemaProvider.GetIndexes();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region IndexesInSchema
    private void btnIndexInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllIndexesInSchema();
      this.Cursor = c;
    }

    private void AllIndexesInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaIndex));
          lstData.ItemsSource = _SchemaProvider.GetIndexes(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllUniqueConstraints
    private void btnAllUniques_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllUniqueConstraints();
      this.Cursor = c;
    }

    private void AllUniqueConstraints()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaUniqueConstraint));
        lstData.ItemsSource = _SchemaProvider.GetUniqueConstraints();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region UniqueConstraintsInSchema
    private void btnUniqueInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllUniqueConstraintsInSchema();
      this.Cursor = c;
    }

    private void AllUniqueConstraintsInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaUniqueConstraint));
          lstData.ItemsSource = _SchemaProvider.GetUniqueConstraints(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllCheckConstraints
    private void btnAllChecks_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllCheckConstraints();
      this.Cursor = c;
    }

    private void AllCheckConstraints()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaCheckConstraint));
        lstData.ItemsSource = _SchemaProvider.GetCheckConstraints();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region CheckConstraintsInSchema
    private void btnChecksInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllCheckConstraintsInSchema();
      this.Cursor = c;
    }

    private void AllCheckConstraintsInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaCheckConstraint));
          lstData.ItemsSource = _SchemaProvider.GetCheckConstraints(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllPrimaryKeys
    private void btnAllPKs_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllPrimaryKeys();
      this.Cursor = c;
    }

    private void AllPrimaryKeys()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPrimaryKey));
        lstData.ItemsSource = _SchemaProvider.GetPrimaryKeys();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region PrimaryKeysInSchema
    private void btnPKsInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllPrimaryKeysInSchema();
      this.Cursor = c;
    }

    private void AllPrimaryKeysInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPrimaryKey));
          lstData.ItemsSource = _SchemaProvider.GetPrimaryKeys(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region AllDomains
    private void btnAllDomains_Click(object sender, RoutedEventArgs e)
    {
      AllDomainsUserTypes();
    }

    private void AllDomainsUserTypes()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaDomain));

        lstData.ItemsSource = _SchemaProvider.GetDomains();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region DomainsInSchema
    private void btnDomainsInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      AllDomainsInSchema();
      this.Cursor = c;
    }

    private void AllDomainsInSchema()
    {
      try
      {
        if (txtMiscSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaDomain));
          lstData.ItemsSource = _SchemaProvider.GetDomains(txtMiscSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Info/Error Events
    private void btnClearInfo_Click(object sender, RoutedEventArgs e)
    {
      _InfoMessages = new StringBuilder(2048);
      txtInfo.Clear();
    }

    private void btnClearErrors_Click(object sender, RoutedEventArgs e)
    {
      _ErrorMessages = new StringBuilder(2048);
      txtErrors.Clear();
    }

    private void btnCopyInfo_Click(object sender, RoutedEventArgs e)
    {
      Clipboard.Clear();
      Clipboard.SetText(txtInfo.Text, TextDataFormat.Text);
    }

    private void btnCopyErrors_Click(object sender, RoutedEventArgs e)
    {
      Clipboard.Clear();
      Clipboard.SetText(txtErrors.Text, TextDataFormat.Text);
    }
    #endregion

    #region TabSchema SelectionChanged Event
    private void tabSchema_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      lstData.View = null;
      lstData.ItemsSource = null;
      if (tabSchema.SelectedItem == tabInfo)
        txtInfo.Text = _InfoMessages.ToString();
      else if (tabSchema.SelectedItem == tabErrors)
        txtErrors.Text = _ErrorMessages.ToString();
    }
    #endregion

    #region Connect String Lost Focus Event
    private void txtConnectString_LostFocus(object sender, RoutedEventArgs e)
    {
      _SchemaProvider.DataProvider.ConnectString = txtConnectString.Text;
    }
    #endregion

    #region Test Connection
    private void btnTestConnection_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        if (_SchemaProvider.DataProvider.CanOpenConnection())
          MessageBox.Show("Connection is Valid");
        else
          MessageBox.Show("Connection is NOT Valid. Please Re-enter.");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
    #endregion

    #region lstData_SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (lstData != null)
      {
        if (lstData.SelectedItem != null)
        {
          if (tabSchema.SelectedItem.Equals(tabPackages))
          {
            if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaPackage)))
            {
              PDSASchemaPackage item = (PDSASchemaPackage)lstData.SelectedItem;

              ucInfoPackage.txtPackageName.Text = item.PackageName;
              ucInfoPackage.txtSchemaName.Text = item.SchemaName;
            }
            if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaStoredProc)))
            {
              PDSASchemaStoredProc item = (PDSASchemaStoredProc)lstData.SelectedItem;

              ucInfoPackage.txtPackageName.Text = item.PackageName;
              ucInfoPackage.txtSchemaName.Text = item.SchemaName;
              ucInfoPackage.txtSPName.Text = item.StoredProcName;
            }
          }
          else if (tabSchema.SelectedItem.Equals(tabTables))
          {
            if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaTable)))
            {
              PDSASchemaTable item = (PDSASchemaTable)lstData.SelectedItem;

              ucInfoTable.txtSchemaName.Text = item.SchemaName;
              ucInfoTable.txtTableName.Text = item.TableName;
            }
            else if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaColumn)))
            {
              PDSASchemaColumn item = (PDSASchemaColumn)lstData.SelectedItem;

              ucInfoTable.txtSchemaName.Text = item.SchemaName;
              ucInfoTable.txtTableName.Text = item.DbObjectName;
              ucInfoTable.txtColumnName.Text = item.ColumnName;
            }
          }
          else if (tabSchema.SelectedItem.Equals(tabViews))
          {
            if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaView)))
            {
              PDSASchemaView item = (PDSASchemaView)lstData.SelectedItem;

              ucInfoViews.txtSchemaName.Text = item.SchemaName;
              ucInfoViews.txtViewName.Text = item.ViewName;
            }
            else if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaColumn)))
            {
              PDSASchemaColumn item = (PDSASchemaColumn)lstData.SelectedItem;

              ucInfoViews.txtSchemaName.Text = item.SchemaName;
              ucInfoViews.txtColumnName.Text = item.ColumnName;
            }
          }
          else if (tabSchema.SelectedItem.Equals(tabSPs))
          {
            if (lstData.SelectedItem.GetType().Equals(typeof(PDSASchemaStoredProc)))
            {
              PDSASchemaStoredProc item = (PDSASchemaStoredProc)lstData.SelectedItem;

              ucInfoSPs.txtSchemaName.Text = item.SchemaName;
              ucInfoSPs.txtSPName.Text = item.StoredProcName;
            }
          }
        }
      }
    }
    #endregion

    #region SetSQL Method
    private void SetSQL()
    {
      if (_SchemaProvider != null)
      {
        tbSQL.Text = _SchemaProvider.SQL;
      }
    }
    #endregion

    #region Get All Packages
    private void btnAllPackages_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetAllPackages();
      this.Cursor = c;
    }

    private void GetAllPackages()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPackage));
        lstData.ItemsSource = _SchemaProvider.GetPackages();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region GetPackagesInSchema
    private void btnAllPackagesInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetPackagesInSchema();
      this.Cursor = c;
    }

    private void GetPackagesInSchema()
    {
      try
      {
        if (ucInfoPackage.txtSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPackage));
          lstData.ItemsSource = _SchemaProvider.GetPackages(ucInfoPackage.txtSchemaName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in a Valid Schema");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Package Exists
    private void btnPackageExists_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      PackageExists();
      this.Cursor = c;
    }

    private void PackageExists()
    {
      try
      {
        if (ucInfoPackage.txtSchemaName.Text.Trim() != string.Empty && ucInfoPackage.txtPackageName.Text.Trim() != string.Empty)
        {
          if (_SchemaProvider.DoesPackageExist(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text.Trim()))
            MessageBox.Show("Package Exists");
          else
            MessageBox.Show("Package Does NOT Exist");

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in Schema Name/Package Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region StoredProcsInPackage Method
    private void btnStoredProcsInPackage_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcsInPackage();
      this.Cursor = c;
    }

    private void StoredProcsInPackage()
    {
      try
      {
        if (ucInfoPackage.txtSchemaName.Text.Trim() != string.Empty && ucInfoPackage.txtPackageName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));
          lstData.ItemsSource = _SchemaProvider.GetStoredProceduresInPackage(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please fill in Schema Name/Package Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region GetPackageText Methods
    private void btnPackageText_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetPackageDefinition();
      this.Cursor = c;
    }

    private void GetPackageDefinition()
    {
      PDSASchemaPackage pack;
      PDSASchemaPackages packs = new PDSASchemaPackages();

      try
      {
        pack = _SchemaProvider.GetPackage(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text);
        pack.Definition = _SchemaProvider.GetPackageText(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text.Trim());
        packs.Add(pack);

        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaPackage));
        lstData.ItemsSource = packs;

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region GetStoredProcDefinitionText in Package
    private void btnPackageSPText_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      GetStoredProcDefinition();
      this.Cursor = c;
    }
    #endregion

    #region Get Stored Proc Params in Package
    private void btnGetStoredProcParamsInPackage_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcParametersInPackage();
      this.Cursor = c;
    }

    private void StoredProcParametersInPackage()
    {
      try
      {
        if (ucInfoPackage.txtSchemaName.Text.Trim() != string.Empty && ucInfoPackage.txtPackageName.Text.Trim() != string.Empty && ucInfoPackage.txtSPName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProcParameter));
          lstData.ItemsSource = _SchemaProvider.GetStoredProcedureParameters(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text.Trim() + "." + ucInfoPackage.txtSPName.Text.Trim());

          SetSQL();
        }
        else
          MessageBox.Show("Please Fill in Schema/Package/Stored Proc Name");

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Stored Procs In Packages
    private void btnGetAllStoredProcsAndPackageSPs_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcsAndInPackages();
      this.Cursor = c;
    }

    private void StoredProcsAndInPackages()
    {
      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));
        lstData.ItemsSource = _SchemaProvider.GetStoredProceduresPackages(string.Empty);

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region SP's in Package in Schema
    private void btnAllSPsInPackageInSchema_Click(object sender, RoutedEventArgs e)
    {
      Cursor c;

      c = this.Cursor;
      this.Cursor = Cursors.Wait;
      StoredProcsAndInPackagesInSchema();
      this.Cursor = c;
    }

    private void StoredProcsAndInPackagesInSchema()
    {
      try
      {
        if (ucInfoPackage.txtSchemaName.Text.Trim() != string.Empty)
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaStoredProc));
          if (ucInfoPackage.txtPackageName.Text.Trim() == string.Empty && ucInfoPackage.txtSPName.Text.Trim() == string.Empty)
            lstData.ItemsSource = _SchemaProvider.GetStoredProceduresPackages(ucInfoPackage.txtSchemaName.Text.Trim());
          else if (ucInfoPackage.txtPackageName.Text.Trim() != string.Empty && ucInfoPackage.txtSPName.Text.Trim() == string.Empty)
            lstData.ItemsSource = _SchemaProvider.GetStoredProceduresPackages(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtPackageName.Text.Trim(), true);
          else if (ucInfoPackage.txtPackageName.Text.Trim() == string.Empty && ucInfoPackage.txtSPName.Text.Trim() != string.Empty)
            lstData.ItemsSource = _SchemaProvider.GetStoredProceduresPackages(ucInfoPackage.txtSchemaName.Text.Trim(), ucInfoPackage.txtSPName.Text.Trim(), false);


          SetSQL();
        }
        else
          MessageBox.Show("Please Fill In Schema Name");
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region SP Return Columns
    private void btnSPReturnColumns_Click(object sender, RoutedEventArgs e)
    {
      SPReturnColumnsSample();
    }

    private void SPReturnColumnsSample()
    {
      PDSASchemaStoredProcParameter parm = new PDSASchemaStoredProcParameter();
      PDSASchemaStoredProcParameters parms = new PDSASchemaStoredProcParameters();

      try
      {
        if (IsSchemaSPFilledIn())
        {
          parm.ParameterName = "@DistrictId";
          parm.DBType = System.Data.DbType.Guid;
          parm.Value = "d3e8c1de-ddca-4388-9d59-6a9bfc9eaed9";
          parms.Add(parm);

          _SchemaProvider.GetStoredProcedureReturnColumns(ucInfoSPs.txtSchemaName.Text.Trim(), ucInfoSPs.txtSPName.Text.Trim(), parms);
        }
        else
          MessageBox.Show("Please Fill in Schema/Stored Proc Name");

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }
    #endregion

    #region Defaults
    private void btnAllDefaults_Click(object sender, RoutedEventArgs e)
    {
      AllDefaults();
    }

    private void AllDefaults()
    {
      PDSASchemaDefaults coll = new PDSASchemaDefaults();

      try
      {
        lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaDefault));
        lstData.ItemsSource = _SchemaProvider.GetDefaults();

        SetSQL();
      }
      catch (Exception ex)
      {
        ErrorDisplay(ex.ToString());
      }
    }

    private void btnDefaultsInSchema_Click(object sender, RoutedEventArgs e)
    {
      DefaultsInSchema();
    }

    private void DefaultsInSchema()
    {
      PDSASchemaDefaults coll = new PDSASchemaDefaults();

      if (IsTableSchemaFilledIn())
      {
        try
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaDefault));
          lstData.ItemsSource = _SchemaProvider.GetDefaults(ucInfoTable.txtSchemaName.Text);

          SetSQL();
        }
        catch (Exception ex)
        {
          ErrorDisplay(ex.ToString());
        }
      }
      else
        MessageBox.Show("Please Fill in Schema Name");
    }

    private void btnDefaultsInTable_Click(object sender, RoutedEventArgs e)
    {
      DefaultsInSchemaTable();
    }

    private void DefaultsInSchemaTable()
    {
      PDSASchemaDefaults coll = new PDSASchemaDefaults();

      if (IsSchemaTableFilledIn())
      {
        try
        {
          lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSASchemaDefault));
          lstData.ItemsSource = _SchemaProvider.GetDefaults(ucInfoTable.txtSchemaName.Text, ucInfoTable.txtTableName.Text);

          SetSQL();
        }
        catch (Exception ex)
        {
          ErrorDisplay(ex.ToString());
        }
      }
      else
        MessageBox.Show("Please Fill in Schema/Table Name");
    }
    #endregion 
  }
}
