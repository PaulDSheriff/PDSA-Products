﻿using System.Windows.Controls;

namespace PDSADBSchemaSample
{
  public partial class ucSchemaSPsInfo : UserControl
  {
    public ucSchemaSPsInfo()
    {
      InitializeComponent();
    }

    private void btnSClear_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      txtSchemaName.Text = string.Empty;
      txtSPName.Text = string.Empty;
    }
  }
}
