﻿using System.Windows.Controls;

namespace PDSADBSchemaSample
{
  public partial class ucSchemaViewsInfo : UserControl
  {
    public ucSchemaViewsInfo()
    {
      InitializeComponent();
    }

    private void btnSClear_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      txtColumnName.Text = string.Empty;
      txtSchemaName.Text = string.Empty;
      txtViewName.Text = string.Empty;      
    }
  }
}
