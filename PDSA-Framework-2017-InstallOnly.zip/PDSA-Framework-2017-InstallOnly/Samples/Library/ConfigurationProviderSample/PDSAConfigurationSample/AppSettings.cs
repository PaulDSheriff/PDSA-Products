﻿using System;

using PDSA.Configuration;

namespace PDSAConfigurationSample
{
  class AppSettings
  {
    #region Constructor
    public AppSettings()
    {
    }
    #endregion

    #region Configuration Provider Property
    private PDSAConfigProvider _ConfigProvider = null;

    public PDSAConfigProvider ConfigProvider
    {
      get
      {
        if (_ConfigProvider == null)
          _ConfigProvider = new PDSAConfigManager().Provider;

        return _ConfigProvider;
      }
      set { _ConfigProvider = value; }
    }
    #endregion

    #region Private Variables
    private string _AppName;
    private string _ConnectString;
    private int _FormTimeOutInSeconds;
    private bool _UserTracking;
    #endregion

    #region Public Properties
    public string AppName
    {
      get { return _AppName; }
      set { _AppName = value; }
    }

    public string ConnectString
    {
      get { return _ConnectString; }
      set { _ConnectString = value; }
    }

    public int FormTimeOutInSeconds
    {
      get { return _FormTimeOutInSeconds; }
      set { _FormTimeOutInSeconds = value; }
    }

    public bool UserTracking
    {
      get { return _UserTracking; }
      set { _UserTracking = value; }
    }
    #endregion

    #region Load Method
    public void Load()
    {
      _AppName = ConfigProvider.GetSetting("AppName", "N/A");
      _UserTracking = ConfigProvider.GetSetting("UserTracking", false);
      _FormTimeOutInSeconds = ConfigProvider.GetSetting("FormTimeOutInSeconds", -1);
      _ConnectString = ConfigProvider.GetSetting("ConnectString", "");
    }
    #endregion

    #region Save Method
    public void Save()
    {
      ConfigProvider.SaveSetting("AppName", _AppName);
      ConfigProvider.SaveSetting("UserTracking", _UserTracking.ToString());
      ConfigProvider.SaveSetting("FormTimeOutInSeconds", _FormTimeOutInSeconds.ToString());
      ConfigProvider.SaveSetting("ConnectString", _ConnectString);
    }
    #endregion
  }
}

