﻿using System;
using System.Diagnostics;
using System.Windows;

using PDSA.Configuration;
using PDSA.WPF;

namespace PDSAConfigurationSample
{
  public partial class winHardCoded : Window
  {
    #region Constructor
    public winHardCoded()
    {
      InitializeComponent();
    }
    #endregion

    #region ReadUsingDefaultProvider Method
    private void btnReadUsingDefault_Click(object sender, RoutedEventArgs e)
    {
      ReadUsingDefaultProvider();
    }

    private void ReadUsingDefaultProvider()
    {
      PDSAConfigManager mgr = null;

      try
      {
        // Create a new Configuration Manager object        
        mgr = new PDSAConfigManager();

        // The first time you access the "Provider" property it will 
        // get the default provider from the .Config file to use
        // to return the values requested
        Debug.WriteLine(mgr.Provider.GetSetting("AppName", "N/A"));
        Debug.WriteLine(mgr.Provider.GetSetting("UserTracking", false));
        Debug.WriteLine(mgr.Provider.GetSetting("FormTimeOutInSeconds", -1));

        DisplaySettings(mgr.Provider);
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }
    #endregion

    #region ReadUsingXmlProvider Method
    private void btnReadUsingXml_Click(object sender, RoutedEventArgs e)
    {
      ReadUsingXmlProvider();
    }

    private void ReadUsingXmlProvider()
    {
      PDSAConfigProvider provider = null;
      PDSAConfigManager mgr = null;

      try
      {
        mgr = new PDSAConfigManager();

        // Get the 'Xml' provider
        // The name passed to the GetProvider method must 
        // match the providerName="Xml" in the 
        // configuration section of the .Config file
        provider = mgr.GetProvider("Xml");

        Debug.WriteLine(provider.GetSetting("AppName", "N/A"));
        Debug.WriteLine(provider.GetSetting("UserTracking", false));
        Debug.WriteLine(provider.GetSetting("FormTimeOutInSeconds", -1));

        DisplaySettings(provider);
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }
    #endregion

    #region SimpleWrapper Method
    private void btnSimpleWrapper_Click(object sender, RoutedEventArgs e)
    {
      SimpleWrapper();
    }

    /// <summary>
    /// This sample shows how to put a wrapper around the configuration settings
    /// This is a best practice because you  encapsulate the Configuration provider,
    /// plus you get intellisense on the values in the config file
    /// </summary>
    private void SimpleWrapper()
    {
      AppSettings settings = null;

      try
      {
        settings = new AppSettings();

        // Load the settings
        settings.Load();

        Debug.WriteLine(settings.AppName);
        Debug.WriteLine(settings.UserTracking);
        Debug.WriteLine(settings.FormTimeOutInSeconds);

        DisplaySettings(settings.ConfigProvider);
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }
    #endregion

    private void btnSaveSettings_Click(object sender, RoutedEventArgs e)
    {
      SaveConfigSettings();
    }

    /// <summary>
    /// This sample shows how to save configuration settings back to the provider
    /// </summary>
    private void SaveConfigSettings()
    {
      PDSAConfigManager mgr = null;

      try
      {
        mgr = new PDSAConfigManager();

        // Get the XML provider
        mgr.Provider = mgr.GetProvider("Xml");

        // Save the settings back
        mgr.Provider.SaveSetting("AppName", "Changed App Name");
        mgr.Provider.SaveSetting("UserTracking", "false");
        mgr.Provider.SaveSetting("FormTimeOutInSeconds", "55");

        DisplaySettings(mgr.Provider);

        MessageBox.Show("Settings Saved");
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }

    private void DisplaySettings(PDSAConfigProvider provider)
    {
      // Load all settings from Provider
      PDSAConfigSettings settings = provider.GetAllSettings();

      lvwSettings.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSAConfigSetting));
      lvwSettings.ItemsSource = settings;
    }
  }
}
