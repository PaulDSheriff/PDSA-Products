﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Configuration;
using PDSA.Configuration.Configuration;
using PDSA.WPF;

namespace PDSAConfigurationSample
{
  public partial class winProviders : Window
  {
    public winProviders()
    {
      InitializeComponent();
    }

    #region Form Events
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      LoadProviders();
    }

    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      DisplayProviderInfo();
    }

    private void btnGetSettings_Click(object sender, RoutedEventArgs e)
    {
      GetSettings();
    }
    #endregion

    #region LoadProviders Method
    private void LoadProviders()
    {
      PDSAConfigManager mgr = new PDSAConfigManager();

      try
      {
        cboProviders.DisplayMemberPath = "ProviderName";
        // Get all Provider Objects to load into the Providers combo box
        cboProviders.ItemsSource = mgr.GetProviderNames();

        if (cboProviders.Items.Count > 0)
        {
          foreach (PDSAConfigConfigProvider prov in cboProviders.Items)
          {
            if (prov.ProviderName == mgr.ConfigurationProviders.DefaultProvider)
            {
              cboProviders.SelectedItem = prov;

              break;
            }
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }
    #endregion

    #region DisplayProviderInfo Method
    private void DisplayProviderInfo()
    {
      PDSAConfigConfigProvider config;
      PDSAConfigManager mgr = new PDSAConfigManager();

      try
      {
        // Get Provider from Selected one in Combo Box
        mgr.Provider = mgr.GetProvider(((PDSAConfigConfigProvider)cboProviders.SelectedItem).ProviderName);
        // Get the Configuration Provider object
        config = mgr.Provider.ConfigurationProvider;

        // Display Configuration Provider Information
        tbProviderName.Text = config.ProviderName;
        tbProviderType.Text = config.Type;
        tbProviderAssembly.Text = config.Assembly;
        txtLocation.Text = config.Location;
        txtXPath.Text = config.XPath;
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }

    private void GetSettings()
    {
      AppSettings settings = new AppSettings();
      PDSAConfigManager mgr = null;

      tbAppName.Text = "";
      tbUserTracking.Text = "";
      tbFormTimeoutInSeconds.Text = "";

      try
      {
        // Create new ConfigManager object
        mgr = new PDSAConfigManager();
        // Need to load all settings from Provider
        settings.ConfigProvider = null;

        // Set new Config Provider into AppSettings class
        settings.ConfigProvider = mgr.GetProvider(cboProviders.Text);
        // Load from new configuration provider
        settings.Load();

        // You can override the "Location" property.
        // AppConfig.ConfigProvider.ConfigurationProvider.Location = "D:\Samples\Settings.xml"

        tbAppName.Text = settings.AppName;
        tbUserTracking.Text = settings.UserTracking.ToString();
        tbFormTimeoutInSeconds.Text = settings.FormTimeOutInSeconds.ToString();

        // Display all settings from Provider in ListView
        lvwSettings.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSAConfigSetting));
        lvwSettings.ItemsSource = settings.ConfigProvider.GetAllSettings();
      }
      catch (Exception ex)
      {
        MessageBox.Show("NOTE: PLEASE READ THE Readme.txt FILE FOR INFORMATION ON HOW TO RUN THIS SAMPLE" + Environment.NewLine + ex.ToString());
      }
    }
    #endregion
  }
}