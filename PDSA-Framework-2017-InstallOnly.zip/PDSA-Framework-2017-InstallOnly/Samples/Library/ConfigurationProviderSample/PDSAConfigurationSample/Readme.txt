PDSA Configuration Samples
----------------------------------------------------------------
This sample shows how to retrieve configuration settings from appsettings, xml, SQL Server and the registry in a winforms application.

For this sample you should do the following:

- Run the Settings.reg file from windows explorer to place entries into the Registry.
- If you will save settings to the 'App.Config' or 'Settings.xml' files located in this sample folder, make sure you have rights to write to these files. 
  Otherwise you can move the file and/or sample to another location and adjust the setting in the App.Config file to point to this new file location.

If you wish to use the SQL Server provider make sure the PDSASqlClient connection string points to a valid instance of the PDSAFramework500 database
