﻿using System.Windows;

namespace PDSAConfigurationSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      winHardCoded win = new winHardCoded();
      win.Show();
    }

    private void btnProviders_Click(object sender, RoutedEventArgs e)
    {
      winProviders win = new winProviders();
      win.Show();
    }
  }
}
