﻿using System.Windows;

namespace PDSAConfigurationSample
{
  public partial class App : Application
  {
  }
}
