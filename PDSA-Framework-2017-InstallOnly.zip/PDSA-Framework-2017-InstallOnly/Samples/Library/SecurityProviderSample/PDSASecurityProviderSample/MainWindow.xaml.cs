﻿using System.Windows;

namespace PDSASecuritySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      this.InitializeComponent();
    }
  }
}
