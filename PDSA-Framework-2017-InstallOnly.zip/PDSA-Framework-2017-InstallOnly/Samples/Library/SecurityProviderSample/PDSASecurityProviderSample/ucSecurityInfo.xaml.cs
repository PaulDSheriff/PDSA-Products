﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Security;
using PDSA.Framework;
using PDSA.WPF;

namespace PDSASecuritySample
{
  public partial class ucSecurityInfo : UserControl
  {
    public ucSecurityInfo()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      if (!PDSAWPFUserControl.IsInDesignMode(this))
      {
        DisplaySecurityInfo();
      }
    }

    private void DisplaySecurityInfo()
    {
      PDSASecuritySettings settings;

      try
      {
        settings = PDSASecuritySettings.GetSettings();

        txtAuthType.Text = settings.Authentication.AuthenticationType.ToString();
        txtEncryptionMethod.Text = settings.UserPassword.EncryptionMethod.ToString();
        txtEncryptionProvider.Text = settings.UserPassword.EncryptionProvider.ToString();
        txtLoginMaxLength.Text = settings.UserAccount.MaxLength.ToString();
        txtLoginMinLength.Text = settings.UserAccount.MinLength.ToString();
        txtPwdMaxLength.Text = settings.UserPassword.MaxLength.ToString();
        txtPwdMinLength.Text = settings.UserPassword.MinLength.ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
