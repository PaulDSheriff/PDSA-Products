﻿using System;
using System.Collections.Specialized;
using System.Net;
using System.Net.Sockets;
using PDSA.Framework;
using PDSA.Security;

namespace PDSASecuritySample.Security
{
  public class PDSAWindowsSecurityContext : PDSAApplicationContext
  {
    private int _entityId = int.MinValue;
    private int _applicationId = int.MinValue;

    /// <summary>
    /// Initializes a new instance of the web security session object
    /// </summary>
    /// <param name="entityId"></param>
    /// <param name="applicationId"></param>
    public PDSAWindowsSecurityContext(int entityId, int applicationId)
    {
      _entityId = entityId;
      _applicationId = applicationId;
    }

    /// <summary>
    /// Gets the application ID associated with this application
    /// </summary>
    public override int ApplicationId
    {
      get
      {
        return _applicationId;
      }
    }

    /// <summary>
    /// Gets the entity ID associated with this entity
    /// </summary>
    public override int EntityId
    {
      get
      {
        return _entityId;
      }
    }

    public override string UserSessionId
    {
      get { return Guid.NewGuid().ToString(); }
    }

    public int UserId { get; set; }

    public override NameValueCollection GetEnvironmentValues()
    {
      NameValueCollection values = new NameValueCollection();

      values.Add("AppName", PDSASettings.AllValues.Application.General.ApplicationName);
      values.Add("MachineName", Environment.MachineName);
      values.Add("UserLanguage", System.Threading.Thread.CurrentThread.CurrentUICulture.EnglishName);

      return values;
    }

    public override void ResetUserSession()
    {
      // Nothing to do
    }

    public override void CreateNavigationContext(PDSAAuthenticationResponse response)
    {
      this.UserId = response.UserId;
    }

    public override void CreateNavigationContext(PDSAAuthenticationResponse response, bool persistCookie)
    {
      this.UserId = response.UserId;
    }

    public override string UserHostAddress
    {
      get
      {
        string result = string.Empty;

        IPAddress[] addresses = Dns.GetHostAddresses(Dns.GetHostName());

        foreach (IPAddress item in addresses)
        {
          if (item.AddressFamily == AddressFamily.InterNetwork)
          {
            result = item.ToString();
          }
        }
        return result;
      }
    }

    public override void ClearPrincipalCache(PDSAPrincipal principal)
    {
      // Nothing to do
    }

    public override void ClearSession()
    {
      // Nothing to do
    }

    public override void SignOut()
    {
      // Nothing to do
    }

    public override void ClearPrincipalCache(int userId)
    {
      // Nothing to do
    }
  }
}
