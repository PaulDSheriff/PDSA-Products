﻿using System;
using System.Security;
using System.Security.Principal;
using System.Windows;
using System.Windows.Controls;

using PDSA.Framework;
using PDSA.Security;
using PDSA.Validation;
using PDSASecuritySample.Security;

namespace PDSASecuritySample
{
  public partial class ucSignIn : UserControl
  {
    public ucSignIn()
    {
      InitializeComponent();
    }

    #region Properties
    protected PDSAAuthenticationResponse _Response { get; set; }
    private PDSASecurityContext _SecurityContext = null;
    private PDSAWindowsSecurityContext _WinSecurityContext = null;
    protected string LoginName
    {
      get { return txtLoginID.Text; }
    }
    protected string Password
    {
      get { return txtPassword.Password; }
    }
    protected bool IsRememberMeChecked { get; set; }

    protected PDSASecurityContext SecurityContext
    {
      get
      {
        if (_SecurityContext == null)
        {
          _SecurityContext = PDSASecurityContext.CreateContext(ApplicationContext);
        }
        return _SecurityContext;
      }
    }

    protected PDSAWindowsSecurityContext ApplicationContext
    {
      get
      {
        if (_WinSecurityContext == null)
        {
          _WinSecurityContext = new PDSAWindowsSecurityContext(
             PDSASettings.AllValues.Application.Entities.DefaultEntityId,
             PDSASettings.AllValues.Application.General.ApplicationId);
        }
        return _WinSecurityContext;
      }
    }

    protected IPrincipal SourcePrincipal
    {
      get
      {
        IPrincipal principal = null;
        switch (PDSASettings.AllValues.Security.Authentication.AuthenticationType)
        {
          case PDSAAuthenticationType.ActiveDirectory:
            principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
            break;
          case PDSAAuthenticationType.ActiveDirectoryWithPDSARoles:
            principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
            break;
          case PDSAAuthenticationType.Application:
            principal = new GenericPrincipal(new GenericIdentity(ApplicationContext.UserId.ToString()), null);
            break;
          case PDSAAuthenticationType.ApplicationWithSingleSignOn:
            principal = new GenericPrincipal(new GenericIdentity(ApplicationContext.UserId.ToString()), null);
            break;
        }
        return principal;
      }
    }
    #endregion

    #region Support Methods
    protected void Display(string message)
    {
      tbMessage.Text = message;
    }

    protected void Display(PDSAValidationRules rules)
    {
      foreach (PDSAValidationRule item in rules)
      {
        tbMessage.Text += item.Message + Environment.NewLine;
      }
    }
    #endregion

    #region AutoSignIn Method
    protected void AutoSignIn()
    {
      try
      {
        // The following attempts to authenticate using Windows Credentials
        // NOTE: This only works if using <authentication type="ActiveDirectory" ...>
        _Response = SecurityContext.Authenticate();
        if (_Response.AuthenticationResult == PDSAAuthenticationStatus.Success)
        {
          Display(string.Format("Auto-sign in as {0}!", _Response.LoginName));
          DisplayAuthenticatedUser();
        }
        else
          Display("Can't Auto Sign In using your Windows Credentials");
      }
      catch (Exception ex)
      {
        Display(ex.Message);
      }
    }
    #endregion

    #region SignIn Method
    protected void SignIn()
    {
      try
      {
        // The following is used for "Forms" authentication
        _Response = SecurityContext.Authenticate(LoginName, Password, IsRememberMeChecked);
      }
      catch (Exception ex)
      {
        Display(ex.Message);
      }
    }
    #endregion

    protected void DisplayAuthenticatedUser()
    {
      txtLoginID.IsEnabled = false;
      txtPassword.IsEnabled = false;
      btnSignIn.IsEnabled = false;
      try
      {
        PDSAPrincipal principal = SecurityContext.CreatePrincipal(SourcePrincipal);
        txtLoginID.Text = principal.LoginName;
        lstRoles.DataContext = principal.Roles;
        lstPermissions.DataContext = principal.Permissions;
      }
      catch (Exception ex)
      {
        Display(ex.Message);
        throw;
      }
    }

    protected void btnSignIn_Click(object sender, RoutedEventArgs e)
    {
      if (Convert.ToBoolean(chkWindowsAuth.IsChecked))
      {
        AutoSignIn();
      }
      else
      {
        SignIn();

        switch (_Response.AuthenticationResult)
        {
          case PDSAAuthenticationStatus.ErrorOccurred:
            Display("An error occurred while attempting to login.");
            break;
          case PDSAAuthenticationStatus.ForcePasswordChange:
            Display("User must change password");
            break;
          case PDSAAuthenticationStatus.InvalidEntries:
            Display(_Response.ValidationMessages);
            break;
          case PDSAAuthenticationStatus.InvalidPassword:
            Display(PDSASettings.AllValues.Security.Authentication.InvalidCredentialsMessage);
            break;
          case PDSAAuthenticationStatus.LockedOut:
            Display("Account locked out.");
            break;
          case PDSAAuthenticationStatus.LoginTriesExceeded:
            Display("Login attempts exceeded.");
            break;
          case PDSAAuthenticationStatus.None:
            Display(PDSASettings.AllValues.Security.Authentication.InvalidCredentialsMessage);
            break;
          case PDSAAuthenticationStatus.Success:
            DisplayAuthenticatedUser();
            break;
          case PDSAAuthenticationStatus.UserInactive:
            Display("Account is inactive.");
            break;
          case PDSAAuthenticationStatus.UserNotFound:
            Display("Account not found.");
            break;
        }
      }
    }

    private void chkWindowsAuth_Unchecked(object sender, RoutedEventArgs e)
    {
      txtLoginID.IsEnabled = true;
      txtPassword.IsEnabled = true;
    }

    private void chkWindowsAuth_Checked(object sender, RoutedEventArgs e)
    {
      txtLoginID.IsEnabled = false;
      txtPassword.IsEnabled = false;
    }
  }
}
