﻿PDSA Security Providers Sample
---------------------------------
This sample shows how to use the various login scenarios in the PDSA Framework v5.x

Before running this sample, you must do the following:

1. Create a database named PDSAFramework500
2. Run [InstallFiles]\SqlScripts\SqlServer_PDSAFramework500.sql in the new database.
3. Run [InstallFiles]\SqlScripts\CreateFrameworkData.sql in the new database.
4. Adjust the ConnectionString as appropriate in the App.Config to point to this database.

Login ID: SysAdmin
Password: password