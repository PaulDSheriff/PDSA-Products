﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace PDSACacheSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      winHardCoded win = new winHardCoded();

      win.Owner = this;
      win.Show();
    }

    private void btnProviders_Click(object sender, RoutedEventArgs e)
    {
      winProvider win = new winProvider();

      win.Owner = this;
      win.Show();
    }

    private void btnAppCache_Click(object sender, RoutedEventArgs e)
    {
      winAppCache win = new winAppCache();

      win.Owner = this;
      win.Show();
    }
  }
}
