﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.Cache;
using PDSA.Cache.Configuration;
using PDSA.WPF;

namespace PDSACacheSample
{
  /// <summary>
  /// Interaction logic for winProvider.xaml
  /// </summary>
  public partial class winProvider : Window
  {
    public winProvider()
    {
      InitializeComponent();
    }

    /// <summary>
    /// Create instance here to hold the values in Cache while program runs
    /// </summary>
    PDSACacheManager _CacheManager = null;

    #region Window_Loaded and Providers Load methods
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _CacheManager = new PDSACacheManager();

      txtUserKey.Text = Environment.UserDomainName + @"\" + Environment.UserName;

      ProvidersLoad();
    }

    private void ProvidersLoad()
    {
      cboProviders.DataContext = _CacheManager.GetProvidersCollection();

      if (_CacheManager.ConfigurationProviders.Count == 1)
        cboProviders.SelectedIndex = 0;
    }

    private void cboProviders_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      PDSACacheConfigProvider prov;

      prov = (PDSACacheConfigProvider)cboProviders.SelectedItem;

      tbProviderAssembly.Text = prov.Assembly;
      tbProviderName.Text = prov.ProviderName;
      tbProviderType.Text = prov.Type;
    }
    #endregion

    #region Add Key Value
    private void btnAddKeyValue_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        _CacheManager.Provider.Add(txtKey.Text, txtValue.Text);

        UpdateCounter();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Add Key/User Key
    private void btnAddUserKey_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        _CacheManager.Provider.Add(txtKey.Text, txtValue.Text, txtUserKey.Text);

        UpdateCounter();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Add Key with Absolute Expiration
    private void btnAddAbsolute_Click(object sender, RoutedEventArgs e)
    {
      int value;

      try
      {
        value = Convert.ToInt32(txtAbsolute.Text);

        _CacheManager.Provider.Add(txtKey.Text, txtValue.Text, DateTime.Now.AddSeconds(value));

        UpdateCounter();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Add Key with Sliding Expiration
    private void btnAddSlidingExpiration_Click(object sender, RoutedEventArgs e)
    {
      int value;

      try
      {
        value = Convert.ToInt32(txtSliding.Text);

        _CacheManager.Provider.Add(txtKey.Text, txtValue.Text, new TimeSpan(0, 0, value));

        UpdateCounter();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Get Value
    private void btnGetValue_Click(object sender, RoutedEventArgs e)
    {
      object value;

      try
      {
        value = _CacheManager.Provider.Get(txtKey.Text, txtUserKey.Text);

        if (value != null)
          txtValue.Text = value.ToString();
        else
          txtValue.Text = string.Empty;

        UpdateCounter();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion

    #region Refresh/Update Counter
    private void btnRefresh_Click(object sender, RoutedEventArgs e)
    {
      UpdateCounter();
    }

    private void UpdateCounter()
    {
      tbCounter.Text = _CacheManager.Provider.Count.ToString();
      DisplayCacheInList();
    }
    #endregion

    #region Display Cache in ListView
    private void DisplayCacheInList()
    {
      lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(PDSACacheItem));
      lstData.DataContext = _CacheManager.Provider.CacheCollection;
    }
    #endregion

    #region Remove Key/Value
    private void btnRemove_Click(object sender, RoutedEventArgs e)
    {
      object value;

      try
      {
        value = _CacheManager.Provider.Get(txtKey.Text, txtUserKey.Text);

        if (value != null)
        {
          _CacheManager.Provider.Remove(txtKey.Text);
          txtValue.Text = string.Empty;
          UpdateCounter();
        }
        else
          MessageBox.Show("Can't Find Key to Remove");
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
      }
    }
    #endregion
  }
}
