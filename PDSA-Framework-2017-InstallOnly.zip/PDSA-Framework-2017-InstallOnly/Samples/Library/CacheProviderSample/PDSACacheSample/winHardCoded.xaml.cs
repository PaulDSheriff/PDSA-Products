﻿using System;
using System.Diagnostics;
using System.Windows;

using PDSA.Cache;

namespace PDSACacheSample
{
  public partial class winHardCoded : Window
  {
    public winHardCoded()
    {
      InitializeComponent();
    }

    PDSACacheManager _Cache = new PDSACacheManager();

    #region Add Key/Value Pair
    private void btnAddKey_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Add("CustomerId", 1);
      DisplayMessage("Added 1 to CustomerId cache");
    }

    private void btnGetKey_Click(object sender, RoutedEventArgs e)
    {
      object value;

      value = _Cache.Provider.Get("CustomerId");
      if(value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");
    }
    #endregion

    #region Add Key/User Key/Value
    private Guid _UserKey = System.Guid.NewGuid();

    private void btnAddUserKey_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Add("CustomerId", 1, @"xyz\bjones");
      _Cache.Provider.Add("CustomerId", 1, _UserKey.ToString());
      DisplayMessage("Added 1 to CustomerId cache for user xzy\bjones and as user: " + _UserKey);
    }

    private void btnGetUserKey_Click(object sender, RoutedEventArgs e)
    {
      object value;
      value = _Cache.Provider.Get("CustomerId", @"xyz\bjones");
      if (value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");

      value = _Cache.Provider.Get("CustomerId", _UserKey.ToString());
      if (value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");
    }
    #endregion

    #region Absolute Expiration
    private void btnAddAbsolute_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Add("CustomerId", 1, DateTime.Now.AddSeconds(10));

      DisplayMessage("Added CustomerId of 1 that will expire in 10 seconds.");
    }
    #endregion

    #region Sliding Expiration
    private void btnAddSlidingExpiration_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Add("CustomerId", 1, new TimeSpan(0, 0, 10));

      DisplayMessage("Added CustomerId of 1 that will expire in 10 seconds unless accessed.");
    }
    #endregion

    #region Remove Method
    private void btnRemove_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Remove("CustomerId");
      _Cache.Provider.Remove("CustomerId", @"xyz\bjones");
      _Cache.Provider.Remove("CustomerId", _UserKey.ToString());

      DisplayMessage("Removed CustomerId cache items");
    }
    #endregion

    #region Clear Method
    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      _Cache.Provider.Clear();

      DisplayMessage("Cleared all Cache Items");
    }
    #endregion

    #region DisplayMessage Method
    private void DisplayMessage(string msg)
    {
      tbMessage.Text = msg;
    }
    #endregion
  }
}
