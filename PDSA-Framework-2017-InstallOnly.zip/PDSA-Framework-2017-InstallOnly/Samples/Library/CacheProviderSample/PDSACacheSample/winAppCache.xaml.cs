﻿using System;
using System.Diagnostics;
using System.Windows;

namespace PDSACacheSample
{
  public partial class winAppCache : Window
  {
    public winAppCache()
    {
      InitializeComponent();
    }

    #region Add Key/Value Pair
    private void btnAddKey_Click(object sender, RoutedEventArgs e)
    {
      AppCache.Add("CustomerId", 1);
      DisplayMessage("Added 1 to CustomerId cache");
    }

    private void btnGetKey_Click(object sender, RoutedEventArgs e)
    {
      object value;

      value = AppCache.Get("CustomerId");
      if (value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");
    }
    #endregion
    
    #region Add Key/User Key/Value
    private Guid _UserKey = System.Guid.NewGuid();

    private void btnAddUserKey_Click(object sender, RoutedEventArgs e)
    {
      AppCache.AddToUserCache("CustomerId", 1, @"xyz\bjones");
      AppCache.AddToUserCache("CustomerId", 1, _UserKey.ToString());
      DisplayMessage("Added 1 to CustomerId cache for user xzy\bjones and as user: " + _UserKey);
    }

    private void btnGetUserKey_Click(object sender, RoutedEventArgs e)
    {
      object value;
      value = AppCache.GetFromUserCache("CustomerId", @"xyz\bjones");
      if (value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");

      value = AppCache.GetFromUserCache("CustomerId", _UserKey.ToString());
      if (value != null)
        DisplayMessage("CustomerId=" + value.ToString());
      else
        DisplayMessage("Can't find CustomerId");
    }
    #endregion

    #region Absolute Expiration
    private void btnAddAbsolute_Click(object sender, RoutedEventArgs e)
    {
      AppCache.Add("CustomerId", 1, DateTime.Now.AddSeconds(10));

      DisplayMessage("Added CustomerId of 1 that will expire in 10 seconds.");
    }
    #endregion

    #region Sliding Expiration
    private void btnAddSlidingExpiration_Click(object sender, RoutedEventArgs e)
    {
      AppCache.Add("CustomerId", 1, new TimeSpan(0, 0, 10));

      DisplayMessage("Added CustomerId of 1 that will expire in 10 seconds unless accessed.");
    }
    #endregion

    #region Remove Method
    private void btnRemove_Click(object sender, RoutedEventArgs e)
    {
      AppCache.Remove("CustomerId");
      AppCache.RemoveFromUserCache("CustomerId", @"xyz\bjones");
      AppCache.RemoveFromUserCache("CustomerId", _UserKey.ToString());

      DisplayMessage("Removed CustomerId cache items");
    }
    #endregion

    #region Clear Method
    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      AppCache.Clear();

      DisplayMessage("Cleared all Cache Items");
    }
    #endregion

    #region DisplayMessage Method
    private void DisplayMessage(string msg)
    {
      tbMessage.Text = msg;
    }
    #endregion
  }
}
