PDSA Cache (Client) Sample
----------------------------------------------
This sample illustrates the handling of a user cache using the Client provider for a client-side cache.
This cache provider is normally used in WPF and Windows Forms.
You can use this provider in ASP.NET, however we have a Cache provider specifically for ASP.NET applications.
This sample shows how to add keys and values and the various options associated with them.

Add Key/Value
-----------------
This will add a value to the cache and that item will stay in the cache until you remove the item, or the application ends

Add User Key
-----------------
This will add a value to the cache using the "Key" and "User Key" values as the "Key" for the value. That item will stay in the cache until you remove the item, or the application ends

Add Absolute
-------------
Adds a key/value pair to the cache and the value will be removed within "n" seconds of adding the value

Add Sliding
-------------
Adds a key/value pair to the cache and the value will be removed within "n" seconds of adding the value unless you access the item, then the item will last for the same "n" number of seconds

Get Value
-------------
Retrieves a value from the cache

Refresh Counter
---------------
Tells you how many items are in the cache.
