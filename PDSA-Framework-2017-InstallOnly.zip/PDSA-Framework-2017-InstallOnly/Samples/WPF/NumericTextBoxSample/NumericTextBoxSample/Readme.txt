﻿PDSA.WPF.PDSANumericTextBoxExtension Sample
----------------------------------------------------------------
This sample shows how to use the PDSANumericTextBoxExtension class to enforce numeric value entry only into a text box. 

Be sure to attempt Copy and Paste into the text boxes to ensure this works.
