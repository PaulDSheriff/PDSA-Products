﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WPFBrushesSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ResourceDictionary dict;

      dict = ((ResourceDictionary)this.Resources).MergedDictionaries[0];
      foreach (string key in dict.Keys)
      {
        cboBrushes.Items.Add(key);
      }
    }

    private void cboBrushes_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      string name;

      if (e.AddedItems.Count > 0)
      {
        name = e.AddedItems[0].ToString();
        borderColor.Background = (LinearGradientBrush)this.Resources[name];
      }
    }
  }
}
