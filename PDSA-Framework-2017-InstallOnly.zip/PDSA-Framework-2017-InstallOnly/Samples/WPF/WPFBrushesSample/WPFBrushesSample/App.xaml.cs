﻿using System.Windows;

namespace WPFBrushesSample
{
  public partial class App : Application
  {
  }
}
