﻿using System.Windows;
using System.Windows.Controls;
using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class ucPage3 : UserControl
  {
    public ucPage3()
    {
      InitializeComponent();
    }

    private void btnRaiseEvent_Click(object sender, RoutedEventArgs e)
    {
      MySpecialMessage msg = new MySpecialMessage();

      msg.MessageName = "SpecialMessage";
      msg.MessageBody = string.Empty;  // Leave blank
      msg.SpecialMessage = "This is a special message";

      (Application.Current as App).MessageBroker.SendMessage(msg);
    }
  }
}
