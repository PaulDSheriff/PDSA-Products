﻿
using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public class Page4ViewModel
  {
    // Constructor
    public Page4ViewModel()
    {
    }

    private PDSAMessageBroker _MessageBroker = null;

    /// <summary>
    /// Get/Set a Message Broker to use to send messages
    /// Set this property from the page that is hooked to this View Model
    /// </summary>
    public PDSAMessageBroker MessageBroker
    {
      get { return _MessageBroker; }
      set
      {
        _MessageBroker = value;
        if(_MessageBroker != null)
          _MessageBroker.MessageReceived += new MessageReceivedEventHandler(_MessageBroker_MessageReceived);
      }
    }

    void _MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      switch (e.MessageName)
      {
        case "SomeMessage":
          // Do something here

          break;
      }
    }

    public void DoSomething()
    {
      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      // Write some code to do something...


      // Send a message back to the ucPage3 User Control
      arg.MessageName = "Page4ViewModel.FromViewModel4";
      arg.MessageBody = "I am a message from View Model for Page 4";

      // Check to make sure the MessageBroker object was set.
      if (_MessageBroker != null)
      {
        _MessageBroker.SendMessage(arg);
      }
    }

    public void Dispose()
    {
      _MessageBroker.MessageReceived -= _MessageBroker_MessageReceived;
    }
  }
}
