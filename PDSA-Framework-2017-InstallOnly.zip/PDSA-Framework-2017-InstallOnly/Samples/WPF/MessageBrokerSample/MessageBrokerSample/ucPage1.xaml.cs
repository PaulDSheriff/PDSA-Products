﻿using System.Windows;
using System.Windows.Controls;
using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class ucPage1 : UserControl
  {
    private PDSAMessageBroker _MessageBroker { get; set; }

    public ucPage1()
    {
      InitializeComponent();

      // Hook to the Global Message Broker
      _MessageBroker = (Application.Current as App).MessageBroker;
      _MessageBroker.MessageReceived += new MessageReceivedEventHandler(_MessageBroker_MessageReceived);
    }

    void _MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      // Look for messages intended for Page 1
      switch (e.MessageName)
      {
        case "ucPage1.ForPage1":
          MessageBox.Show(e.MessageObject.MessageBody.ToString());
          break;
      }
    }
    
    private void btnRaiseEvent_Click(object sender, RoutedEventArgs e)
    {
      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ucPage1.FromPage1";
      arg.MessageBody = "Hello From Page 1";

      // Send a message
      _MessageBroker.SendMessage(arg);
    }

    private void UserControl_Unloaded(object sender, RoutedEventArgs e)
    {
      if (_MessageBroker != null)
        _MessageBroker.MessageReceived -= _MessageBroker_MessageReceived;
    }
  }
}
