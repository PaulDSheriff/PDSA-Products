﻿using System.Windows;

using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class MainWindow : Window
  {
    private PDSAMessageBroker _MessageBroker = null;

    public MainWindow()
    {
      InitializeComponent();

      _MessageBroker = (Application.Current as App).MessageBroker;

      // Initialize the Message Broker Events
      _MessageBroker.MessageReceived += new MessageReceivedEventHandler(MessageBroker_MessageReceived);
      _MessageBroker.MessageReceived += new MessageReceivedEventHandler(MessageBroker_SpecialMessageReceived);
    }

    void MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      // Use this event to receive all messages
      switch (e.MessageName)
      {
        case "ucPage1.FromPage1":
          MessageBox.Show(e.MessageObject.MessageBody.ToString());
          break;
        case "ucPage2.FromPage2":
          MessageBox.Show(e.MessageObject.MessageBody.ToString());
          break;
        case "etc.":
          // Do something with this message
          break;

        default:
          // Do something to check for any message here...
          //if (e.MessageObject.GetType().Name.Equals("PDSAMessageBrokerMessage"))
          //{
          //  if (e.MessageObject.MessageBody != null)
          //    MessageBox.Show(e.MessageObject.MessageBody.ToString());
          //}

          break;
      }
    }

    void MessageBroker_SpecialMessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      // Use this event to receive any special message objects
      if (e.MessageObject is MySpecialMessage)
        MessageBox.Show(((MySpecialMessage)e.MessageObject).SpecialMessage);
    }

    private void btnPage1_Click(object sender, RoutedEventArgs e)
    {
      ucPage1 uc = new ucPage1();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnSendToPage1_Click(object sender, RoutedEventArgs e)
    {
      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ucPage1.ForPage1";
      arg.MessageBody = "Message For Page 1";

      // Send a message to Page 1
      (Application.Current as App).MessageBroker.SendMessage(arg);
    }

    private void btnPage2_Click(object sender, RoutedEventArgs e)
    {
      ucPage2 uc = new ucPage2();

      // If for some reason you want to pass in a custom MessageBroker you can do that
      // In this sample we are just using the global one
      // You just need to add a public property for the MessageBroker to your Window or User Control
      uc.MessageBroker = (Application.Current as App).MessageBroker;

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnPage3_Click(object sender, RoutedEventArgs e)
    {
      ucPage3 uc = new ucPage3();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnPage4_Click(object sender, RoutedEventArgs e)
    {
      ucPage4 uc = new ucPage4();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void Window_Unloaded(object sender, RoutedEventArgs e)
    {
      _MessageBroker.MessageReceived -= new MessageReceivedEventHandler(MessageBroker_MessageReceived);
      _MessageBroker.MessageReceived -= new MessageReceivedEventHandler(MessageBroker_SpecialMessageReceived);
    }
  }
}
