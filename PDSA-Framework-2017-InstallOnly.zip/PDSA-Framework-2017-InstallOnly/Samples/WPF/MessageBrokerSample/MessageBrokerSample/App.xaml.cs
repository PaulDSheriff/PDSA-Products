﻿using System.Windows;
using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class App : Application
  {

    #region Global Message Broker
    private PDSAMessageBroker _MessageBroker = null;

    /// <summary>
    /// Global Message Broker Object
    /// </summary>
    public PDSAMessageBroker MessageBroker
    {
      get
      {
        if (_MessageBroker == null)
          _MessageBroker = new PDSAMessageBroker();

        return _MessageBroker;
      }
      set { _MessageBroker = value; }
    }
    #endregion

    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);
    }
  }
}
