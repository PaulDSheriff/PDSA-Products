﻿using System.Windows;
using System.Windows.Controls;

using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class ucPage4 : UserControl
  {
    private Page4ViewModel _ViewModel;
    private PDSAMessageBroker _MessageBroker;

    public ucPage4()
    {
      InitializeComponent();

      // Hook into View Model
      _ViewModel = (Page4ViewModel)this.Resources["viewModel"];
      // Hook into Global Message Broker
      _MessageBroker = (Application.Current as App).MessageBroker;
      _MessageBroker.MessageReceived += new MessageReceivedEventHandler(_MessageBroker_MessageReceived);
      // Pass in Message Broker to View Model
      _ViewModel.MessageBroker = _MessageBroker;
    }

    void _MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      switch (e.MessageName)
      {
        case "Page4ViewModel.FromViewModel4":
          MessageBox.Show(e.MessageObject.MessageBody.ToString());
          break;
      }
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.DoSomething();
    }

    private void UserControl_Unloaded(object sender, RoutedEventArgs e)
    {
      // Get rid of event handler
      _ViewModel.Dispose();
      if(_MessageBroker != null)
        _MessageBroker.MessageReceived -= new MessageReceivedEventHandler(_MessageBroker_MessageReceived);
    }
  }
}
