﻿using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public class MySpecialMessage : PDSAMessageBrokerMessage
  {
    public string SpecialMessage { get; set; }
  }
}
