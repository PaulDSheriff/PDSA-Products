﻿using System.Windows;
using System.Windows.Controls;
using PDSA.MessageBroker;

namespace MessageBrokerSample
{
  public partial class ucPage2 : UserControl
  {
    public ucPage2()
    {
      InitializeComponent();
    }

    public PDSAMessageBroker MessageBroker { get; set; }

    private void btnRaiseEvent_Click(object sender, RoutedEventArgs e)
    {
      // Raise event using passed-in MessageBroker object
      if (MessageBroker != null)
        MessageBroker.SendMessage(new PDSAMessageBrokerMessage("ucPage2.FromPage2", "Hello From Page 2"));
    }

  }
}
