﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class winCustomers : Window
  {
    public winCustomers()
    {
      InitializeComponent();
    }
  }
}
