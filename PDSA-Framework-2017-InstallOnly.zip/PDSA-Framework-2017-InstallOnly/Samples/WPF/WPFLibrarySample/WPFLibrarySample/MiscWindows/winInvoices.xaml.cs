﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class winInvoices : Window
  {
    public winInvoices()
    {
      InitializeComponent();
    }
  }
}
