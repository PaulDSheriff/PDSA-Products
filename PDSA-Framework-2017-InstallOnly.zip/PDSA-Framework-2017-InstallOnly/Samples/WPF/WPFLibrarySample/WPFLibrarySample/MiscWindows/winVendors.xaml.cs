﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class winVendors : Window
  {
    public winVendors()
    {
      InitializeComponent();
    }
  }
}
