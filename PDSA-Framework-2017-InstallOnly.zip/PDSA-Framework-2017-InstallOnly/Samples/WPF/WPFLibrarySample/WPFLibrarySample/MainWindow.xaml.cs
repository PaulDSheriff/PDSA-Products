﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnAnimateUserControls_Click(object sender, RoutedEventArgs e)
    {
      winAnimate win = new winAnimate();

      win.Show(); 
    }

    private void btnWindowTracker_Click(object sender, RoutedEventArgs e)
    {
      winWindowTracker win = new winWindowTracker();

      win.Show();
    }


    private void btnUserControlTracker_Click(object sender, RoutedEventArgs e)
    {
      winUserControlTracker win = new winUserControlTracker();

      win.Show();
    }

    private void btnIndexToMargin_Click(object sender, RoutedEventArgs e)
    {
      winRotatePicture win = new winRotatePicture();

      win.Show();
    }

    private void btnDesignMode_Click(object sender, RoutedEventArgs e)
    {
       winDesignMode win = new winDesignMode();

       win.Show();
    }

    private void btnListView_Click(object sender, RoutedEventArgs e)
    {
       winListView win = new winListView();

       win.Show();
    }

    private void btnListAllWindows_Click(object sender, RoutedEventArgs e)
    {
      winWPFWindow win = new winWPFWindow();

      win.Owner = this;
      win.Show();
    }

    private void btnButtons_Click(object sender, RoutedEventArgs e)
    {
      winButtons win = new winButtons();

      win.Owner = this;
      win.Show();
    }

    private void btnMessageBox_Click(object sender, RoutedEventArgs e)
    {
      winMessageBox win = new winMessageBox();

      win.Owner = this;
      win.Show();
    }
  }
}
