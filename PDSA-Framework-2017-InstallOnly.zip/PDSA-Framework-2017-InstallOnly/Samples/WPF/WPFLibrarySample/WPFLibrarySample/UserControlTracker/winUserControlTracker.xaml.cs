﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.WPF;

namespace WPFLibrarySample
{
  public partial class winUserControlTracker : Window
  {
    public winUserControlTracker()
    {
      InitializeComponent();
    }

    private const string CUST_OBJECT1 = "Customer 1";
    private const string CUST_OBJECT2 = "Customer 2";

    private PDSAFormTrackers _UCTracker;
    private ucCustomers _CustomerUC;
    private int _ucNumber = 0;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Create User Control Tracker
      _UCTracker = new PDSAFormTrackers();

      // Setup binding to display all user controls added to tracker
      lstUCs.DataContext = _UCTracker;
    }

    private void DisplayUserControl(UserControl uc, string name)
    {
      if (name == "")
        MessageBox.Show("You must pass in a name for the User Control");
      else
      {
        _UCTracker.Add(uc, name);
        contentArea.Children.Clear();
        contentArea.Children.Add(uc);

        DisplayCount();
      }
    }

    private void btnShow_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(CUST_OBJECT1))
        DisplayUserControl((UserControl)_UCTracker.GetByTitle(CUST_OBJECT1).DisplayObject, "Customer");
      else
      {
        _CustomerUC = new ucCustomers();
        DisplayUserControl(_CustomerUC, CUST_OBJECT1);
      }
    }

    private void btnIsLoaded1_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(CUST_OBJECT1))
        MessageBox.Show("Yes");
      else
        MessageBox.Show("No");
    }

    private void btnGetByObject1_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(CUST_OBJECT1))
        MessageBox.Show("The Name is:" + _UCTracker.GetByObject(_CustomerUC).Title);
      else
        MessageBox.Show("Customer 1 is not loaded");
    }

    private void btnShow2_Click(object sender, RoutedEventArgs e)
    {
      ucCustomers cust;

      if (_UCTracker.IsLoaded(CUST_OBJECT2))
        DisplayUserControl((UserControl)_UCTracker.GetByTitle(CUST_OBJECT2).DisplayObject, "Customer2");
      else
      {
        cust = new ucCustomers();
        DisplayUserControl(cust, CUST_OBJECT2);
      }
    }

    private void btnIsLoaded2_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(CUST_OBJECT2))
        MessageBox.Show("Yes");
      else
        MessageBox.Show("No");
    }

    private void btnGetByName2_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(CUST_OBJECT2))
        MessageBox.Show("The Name is:" + _UCTracker.GetByTitle(CUST_OBJECT2).Title);
      else
        MessageBox.Show("Customer 2 is not loaded");
    }

    private void btnShowByName_Click(object sender, RoutedEventArgs e)
    {
      UserControl uc = null;
      string name = string.Empty;

      _ucNumber++;
      if (_UCTracker.IsLoaded(txtUCName.Text))
        DisplayUserControl((UserControl)_UCTracker.GetByTitle(txtUCName.Text).DisplayObject, txtUCName.Text);
      else
      {
        switch (txtUCName.Text.Trim().ToLower())
        {
          case "uccustomers":
            uc = new ucCustomers();
            name = "Customer " + _ucNumber.ToString();
            break;

          case "ucinvoices":
            uc = new ucInvoices();
            name = "Invoice " + _ucNumber.ToString();
            break;

          case "ucvendors":
            uc = new ucVendors();
            name = "Vendor " + _ucNumber.ToString();
            break;

        }
        if (uc != null)
          DisplayUserControl(uc, name);
      }
    }

    private void btnActivateByName_Click(object sender, RoutedEventArgs e)
    {
      if (_UCTracker.IsLoaded(txtUCNameToActivate.Text))
      {
        DisplayUserControl((UserControl)_UCTracker.GetByTitle(txtUCNameToActivate.Text).DisplayObject, txtUCNameToActivate.Text);
      }
      else
        MessageBox.Show("UserControl is not loaded.");
    }

    private void btnClose_Click(object sender, RoutedEventArgs e)
    {
      _UCTracker.Remove(_UCTracker.GetByTitle(txtUCNameToActivate.Text));
      contentArea.Children.Clear();
      DisplayCount();
    }

    private void btnCloseAll_Click(object sender, RoutedEventArgs e)
    {
      _UCTracker.Clear();
      contentArea.Children.Clear();
      DisplayCount();
    }

    private void DisplayCount()
    {
      txtCount.Text = _UCTracker.Count.ToString();
    }

    private void btnListUserControls_Click(object sender, RoutedEventArgs e)
    {
    }
  }
}
