﻿using System.Windows.Controls;

namespace WPFLibrarySample
{
  public partial class ucVendors : UserControl
  {
    public ucVendors()
    {
      InitializeComponent();
    }
  }
}
