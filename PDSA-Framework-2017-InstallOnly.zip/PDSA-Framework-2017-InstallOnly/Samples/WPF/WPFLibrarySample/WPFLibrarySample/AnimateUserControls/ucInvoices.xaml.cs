﻿using System.Windows;
using System.Windows.Controls;

namespace WPFLibrarySample
{
  public partial class ucInvoices : UserControl
  {
    public ucInvoices()
    {
      InitializeComponent();
    }

    private void UserControl_Unloaded(object sender, RoutedEventArgs e)
    {
      System.Diagnostics.Debug.WriteLine("Unloading ucPage2");
    }
  }
}
