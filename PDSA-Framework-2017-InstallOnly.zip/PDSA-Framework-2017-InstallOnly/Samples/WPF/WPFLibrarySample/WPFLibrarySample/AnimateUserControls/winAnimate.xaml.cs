﻿using System;
using System.Windows;
using System.Windows.Controls;

using PDSA.WPF;

namespace WPFLibrarySample
{
  public partial class winAnimate : Window
  {
    public winAnimate()
    {
      InitializeComponent();
    }

    private PDSAUserControlAnimation mUCAnimate;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      mUCAnimate = new PDSAUserControlAnimation(this.contentArea);
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      mUCAnimate.AnimateControls(null);
    }

    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      ucCustomers ctl = new ucCustomers();

      Animate(ctl);
    }

    private void btnInvoices_Click(object sender, RoutedEventArgs e)
    {
      ucInvoices ctl = new ucInvoices();

      Animate(ctl);
    }

    private void btnVendors_Click(object sender, RoutedEventArgs e)
    {
      ucVendors ctl = new ucVendors();

      Animate(ctl);
    }

    private void Animate(UserControl ctl)
    {
      mUCAnimate.CurrentControlAnimationType = (PDSAAnimationType)cboCurrentAnimationType.SelectedValue;
      mUCAnimate.NewControlAnimationType = (PDSAAnimationType)cboNewAnimationType.SelectedValue;
      mUCAnimate.CurrentControlAnimationTime = Convert.ToInt32(txtCurrentAnimationTime.Text);
      mUCAnimate.NewControlAnimationTime = Convert.ToInt32(txtNewAnimationTime.Text);

      mUCAnimate.AnimateControls(ctl);
    }
  }
}
