﻿using System.Windows.Controls;

namespace WPFLibrarySample
{
  public partial class ucCustomers : UserControl
  {
    public ucCustomers()
    {
      InitializeComponent();      
    }

  }
}
