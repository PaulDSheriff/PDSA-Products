﻿using System.Collections.Generic;

namespace WPFLibrarySample
{
  public class Products : List<Product>
  {
    public Products(string name, int count)
    {
      List<Product> _products = new List<Product>();
      for (int i = 0; i <= count; i++)
        this.Add(new Product(i, name + i.ToString()));
    }
  }
}
