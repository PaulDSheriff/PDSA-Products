﻿
using PDSA.Common;

namespace WPFLibrarySample
{
  public class Product : PDSACommonBase
  {
    public Product(int id, string name)
    {
      ProductId = id;
      ProductName = name;
    }

    private int _ProductId = 0;
    private string _ProductName = string.Empty;

    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        _ProductId = value;
        RaisePropertyChanged("ProductId");
      }
    }

    public string ProductName
    {
      get { return _ProductName; }
      set
      {
        _ProductName = value;
        RaisePropertyChanged("ProductName");
      }
    }

    public override string ToString()
    {
      return ProductName;
    }
  }
}
