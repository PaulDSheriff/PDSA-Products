﻿using System.Collections.ObjectModel;
using System.Windows;
using System.ComponentModel;

namespace WPFLibrarySample
{
   class WindowViewModel : DependencyObject
   {
      public WindowViewModel()
      {
         DataCollection = new ObservableCollection<Product>();

         LoadProducts();
      }

      public ObservableCollection<Product> DataCollection
      {
         get { return (ObservableCollection<Product>)GetValue(DataCollectionProperty); }
         set { SetValue(DataCollectionProperty, value); }
      }

      // Using a DependencyProperty as the backing store for DataCollection.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty DataCollectionProperty =
          DependencyProperty.Register("DataCollection", typeof(ObservableCollection<Product>), typeof(winDesignMode), null);

      private void LoadProducts()
      {
         if (IsInDesignMode())
         {
            for (int i = 0; i <= 4; i++)
               DataCollection.Add(new Product(i, "Window View Model: Design Time Product " + i.ToString()));
         }
         else
            for (int i = 0; i <= 10; i++)
               DataCollection.Add(new Product(i, "Window View Model: Runtime Product " + i.ToString()));
      }

      public bool IsInDesignMode()
      {
         //return DesignerProperties.GetIsInDesignMode(win);
         return (null == Application.Current) ||
                   Application.Current.GetType() == typeof(Application);
      }
   }
}
