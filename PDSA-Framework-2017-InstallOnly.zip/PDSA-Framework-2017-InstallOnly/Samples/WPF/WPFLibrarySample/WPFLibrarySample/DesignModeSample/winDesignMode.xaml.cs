﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class winDesignMode : Window
  {
    public winDesignMode()
    {
      InitializeComponent();
    }
  }
}
