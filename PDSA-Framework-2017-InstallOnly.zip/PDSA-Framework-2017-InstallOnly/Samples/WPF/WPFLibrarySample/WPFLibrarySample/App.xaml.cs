﻿using System.Windows;

namespace WPFLibrarySample
{
  public partial class App : Application
  {
  }
}
