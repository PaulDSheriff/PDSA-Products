﻿using System;
using System.Windows;

using PDSA.WPF;

namespace WPFLibrarySample
{
  public partial class winWPFWindow : Window
  {
    public winWPFWindow()
    {
      InitializeComponent();
    }

    private void btnListWindows_Click(object sender, RoutedEventArgs e)
    {
      lstWindows.DataContext = PDSAWPFWindow.Instance.GetOpenWindows();
    }

    private void btnCloseWindows_Click(object sender, RoutedEventArgs e)
    {
      PDSAWPFWindow.Instance.CloseAllOpenWindows(this.Owner);
    }
  }
}
