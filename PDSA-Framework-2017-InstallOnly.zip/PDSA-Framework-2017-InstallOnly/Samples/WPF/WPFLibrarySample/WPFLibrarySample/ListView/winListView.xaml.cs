﻿using System.Windows;

using PDSA.WPF;
using PDSA.Validation;

namespace WPFLibrarySample
{
  public partial class winListView : Window
  {
    public winListView()
    {
      InitializeComponent();
    }

    Products _Products = null;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _Products = new Products("Product", 10);
    }
    
    private void typeof_Click(object sender, RoutedEventArgs e)
    {
      typeofSample();
    }

    private void typeofSample()
    {
      lstData.View = PDSAWPFListView.CreateGridViewColumns(typeof(Product));
      lstData.ItemsSource = _Products;
    }

    private void btnProperties_Click(object sender, RoutedEventArgs e)
    {
      PropertiesSample();
    }

    private void PropertiesSample()
    {
      PDSAProperties props = new PDSAProperties();
      props.Add(new PDSAProperty("ProductId", "Product Id"));
      props.Add(new PDSAProperty("ProductName", "Product Name"));

      lstData.View = PDSAWPFListView.CreateGridViewColumns(props);
      lstData.ItemsSource = _Products;
    }
  }
}
