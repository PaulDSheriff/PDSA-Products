﻿using System;
using System.Windows;

using PDSA.WPF;

namespace WPFLibrarySample
{
  public partial class winWindowTracker : Window
  {
    public winWindowTracker()
    {
      InitializeComponent();
    }

    private const string CUST_OBJECT1 = "Customer 1";
    private const string CUST_OBJECT2 = "Customer 2";

    private PDSAFormTrackers _WindowTracker;
    private winCustomers _CustomerWindow;
    private int _ucNumber = 0;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Create Window Tracker
      _WindowTracker = new PDSAFormTrackers();

      // Setup binding to display all windows added to tracker
      lstWindows.DataContext = _WindowTracker;
    }

    private void DisplayWindow(Window win, string name)
    {
      // Add to Window Tracker
      _WindowTracker.Add(win, name);

      // Display Window
      win.Owner = this;
      win.Show();

      // Display Count
      DisplayCount();
    }

    private void btnShow_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(CUST_OBJECT1))
        ((Window)_WindowTracker.GetByTitle(CUST_OBJECT1).DisplayObject).Focus();
      else
      {
        _CustomerWindow = new winCustomers();
        _CustomerWindow.Title = CUST_OBJECT1;
        DisplayWindow(_CustomerWindow, CUST_OBJECT1);
      }
    }

    private void btnIsLoaded1_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(CUST_OBJECT1))
        MessageBox.Show("Yes");
      else
        MessageBox.Show("No");
    }

    private void btnGetByObject1_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(CUST_OBJECT1))
        MessageBox.Show("The Title is :" + _WindowTracker.GetByObject(_CustomerWindow).Title);
      else
        MessageBox.Show("Customer Window 1 is not loaded");
    }

    private void btnShow2_Click(object sender, RoutedEventArgs e)
    {
      winCustomers win;

      if (_WindowTracker.IsLoaded(CUST_OBJECT2))
        ((Window)_WindowTracker.GetByTitle(CUST_OBJECT2).DisplayObject).Focus();
      else
      {
        win = new winCustomers();
        win.Title = "Customer 2";

        DisplayWindow(win, CUST_OBJECT2);
      }
    }

    private void btnIsLoaded2_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(CUST_OBJECT2))
        MessageBox.Show("Yes");
      else
        MessageBox.Show("No");
    }


    private void btnGetByName2_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(CUST_OBJECT2))
        MessageBox.Show("The Title is :" + ((Window)_WindowTracker.GetByTitle(CUST_OBJECT2).DisplayObject).Title);
      else
        MessageBox.Show("Customer Window 2 is not loaded");
    }

    private void btnShowByName_Click(object sender, RoutedEventArgs e)
    {
      Window win = null;

      _ucNumber++;

      if (_WindowTracker.IsLoaded(txtWinName.Text))
        ((Window)_WindowTracker.GetByTitle(txtWinName.Text).DisplayObject).Focus();        
      else
      {
        switch (txtWinName.Text.Trim().ToLower())
        {
          case "wincustomers":
            win = new winCustomers();
            win.Title = "Customer " + _ucNumber.ToString();
            break;

          case "wininvoices":
            win = new winInvoices();
            win.Title = "Invoice " + _ucNumber.ToString();
            break;

          case "winvendors":
            win = new winVendors();
            win.Title = "Vendor " + _ucNumber.ToString();
            break;

        }
        if (win != null)
          DisplayWindow(win, txtWinName.Text);
      }
    }

    private void btnActivateByName_Click(object sender, RoutedEventArgs e)
    {
      if (_WindowTracker.IsLoaded(txtWinNameToActivate.Text))
        ((Window)_WindowTracker.GetByTitle(txtWinNameToActivate.Text).DisplayObject).Focus();                
      else
        MessageBox.Show("Window is not loaded.");
    }

    private void btnClose_Click(object sender, RoutedEventArgs e)
    {
      _WindowTracker.Close(txtWinNameToClose.Text);
      DisplayCount();
    }

    private void btnCloseAll_Click(object sender, RoutedEventArgs e)
    {
      _WindowTracker.CloseAll();
      DisplayCount();
    }

    private void DisplayCount()
    {
      txtCount.Text = _WindowTracker.Count.ToString();
    }
  }
}
