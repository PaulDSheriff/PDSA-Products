﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLibrarySample
{
  public partial class winButtons : Window
  {
    public winButtons()
    {
      InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Hello from normal button");
    }

    private void btn1_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Hello From Gray Style");
    }

    private void btn2_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Hello From Flat Blue Style");
    }

    private void btn3_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Hello From Flat Red Style");
    }

    private void btn4_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Hello From Blue Style");
    }


    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Edit");
    }

    private void btnNew_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("New");
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Save");
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Delete");
    }  
  }
}
