Welcome to the PDSA .NET Productivity Framework v5.1
------------------------------------------------------------
After installation, please run the PDSA Framework Utilities and click 'Trial Version' or if you have a license key, then enter that along with your personal information and click on 'Activate'.

Be sure to read the ReleaseNotes.pdf for the latest changes to the PDSA Framework.

For information on how to use the Framework, check the \Samples folder. There is a Readme.txt file with each sample that explains what each one does.

Read the documentation under the \Documentation\UserManual folder.